#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<vector>
#include<map>
using namespace std;
#define ll long long
#define mod (1000000007)
#define maxn 512345
inline ll read(){
	ll w=1,x=0;char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-'){w=-1;}ch=getchar();}
	while(ch>='0' && ch<='9') {x=x*10+(ch-'0');ch=getchar();}
	return x*w;
}
ll poww(ll a,ll b,ll m){
	ll res=1;a%=m;
	while(b>0){
		if(b&1)	res=res*a%m;
		a=(a*a)%m;b>>=1;
	}
	return res;
}
map < pair<ll,ll>,bool> viss;
vector < ll > e[maxn];
ll n,m;bool flag=true;
bool vis[maxn];
struct edge{
	ll u,v;
};
vector <edge> ee;
ll fa[maxn],ans=0,tot;
ll find(ll x){
	if(fa[x]!=x){
		fa[x]=find(fa[x]);
	}
	return fa[x];
}
//void dfs(ll now,ll cnt){
//	if(now>=m){
//		return;
//	}
//	ll u=ee[now].u,v=ee[now].v;
//	if(find(u)!=find(v)){
//		cout<<u<<' '<<v<<endl;
//		ll xx=fa[u],yy=fa[v];
//		fa[u]=yy;
//		if(cnt>=1){
//			ans+=poww(2,m-cnt-1,mod) * poww(2,cnt-1,mod);
//		}
//		else
//			ans+=poww(2,m-cnt-1,mod);
//		ans%=mod;
//		dfs(now+1,cnt+1);
//		fa[u]=xx;fa[v]=yy;
//		dfs(now+1,cnt);
//	}
//	ll u=ee[now].u,v=ee[now].v;bool firstu=false,firstv=false;
//	//ans+=poww(2,tot,mod)-1;
//	if(!vis[u]){
//		firstu=1;tot++;	
//	}
//	if(!vis[v]){
//		firstv=1;tot++;
//	}
//	vis[u]=vis[v]=true;
//	ans+=poww(2,tot,mod)-1;
//	dfs(now+1,cnt+1);
//	if(firstu){
//		vis[u]=false;tot--;
//	}
//	if(firstu){
//		vis[v]=false;tot--;
//	}
//	dfs(now+1,cnt);
//}
void dfs(ll now,ll cnte,ll cntn)
{
	if(vis[now]){
		return;
	}
	vis[now]=true;
	if(cnte!=0 && cntn>2)
		ans+=poww(2,m-cnte,mod) * poww(2,cntn-1,mod);
	else if(cntn==2){
		ans+=poww(2,m-cnte,mod);
	}
	for(int i=0;i<e[now].size();i++){
		ll v=e[now][i];
		if(vis[e[now][i]] && !viss[make_pair(now,v)]){
			viss[make_pair(now,v)]=1;
			dfs(e[now][i],cnte+1,cntn);
		}
		else if(!viss[make_pair(now,v)]){
			viss[make_pair(now,v)]=1;
			dfs(e[now][i],cnte+1,cntn+1);	
		}
	}
	vis[now]=false;
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
	for(int i=1;i<=m;i++){
		ll u=read(),v=read();
		e[u].push_back(v);ee.push_back((edge){u,v});
		e[v].push_back(u);
	}
//	for(int i=1;i<=n;i++)
//	{
//		dfs(i,0,1);
//	}
	//cout<<ans+(n*poww(2,m,mod));
	dfs(1,0,1);
	cout<<ans+(n*poww(2,m,mod));
	fclose(stdin);
	fclose(stdout);
	return 0;
 }

