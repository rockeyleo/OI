#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
#define ll long long
#define mod 998244353
inline ll read(){
	ll w=1,x=0;char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-'){w=-1;}ch=getchar();}
	while(ch>='0' && ch<='9') {x=x*10+(ch-'0');ch=getchar();}
	return x*w;
}
ll T,id;
ll n,m,c,f;
ll a[1100][1100],nxt[1100][1100],down[1100][1100];
ll ansc,ansf;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read(),id=read();
	for(int step=1;step<=T;step++)
	{
		n=read();m=read();c=read();f=read();
		ansc=0,ansf=0;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				char s;
				cin>>s;
				a[i][j]=s-'0';
			}
		}
		if(n<3){
			printf("0 0\n");
			continue;
		}
		for(int i=1;i<=n;++i)
		{
			ll pre=m;
			for(int j=m;j>=1;--j)
			{
				if(a[i][j]==1){
					pre=j-1;continue;
				}
				nxt[i][j]=pre;
			}
		}
		for(int j=1;j<=m;j++){
			ll pre=n;
			for(int i=n;i>=3;--i){
				if(a[i][j]==1)	pre=i-1;
				down[i][j]=pre;
			}
		}
		for(int j=1;j<=m-1;j++)
		{
			for(int i=1;i<=n-2;i++)
			{
				if(a[i][j+1]==1)	continue;
				if(a[i+1][j]==1)	continue;
				if(a[i][j]==1)	continue;
				for(int di=i+2;di<=n;di++)
				{
					if(a[di][j]==1)	break;
					ansc+=((nxt[i][j]-j) * (nxt[di][j]-j) );
					ansc%=mod;
				}
			}
		}
		if(n==3){
			printf("%lld 0\n",(ansc*c)%mod);
		}
		for(int j=1;j<=m-1;j++)
		{
			for(int i=1;i<=n-3;i++)
			{
				if(a[i][j+1]==1)	continue;
				if(a[i+1][j]==1)	continue;
				if(a[i][j]==1)	continue;
				for(int xia=i+2;xia<=n-1;xia++)
				{
					if(a[xia][j]==1)	break;
					ansf+=(nxt[i][j]-j) *(nxt[xia][j]-j)*(down[xia][j]-xia);
					ansf%=mod;
				}
			}
		}
		printf("%lld %lld\n",(ansc*c)%mod,(ansf*f)%mod);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
 }

