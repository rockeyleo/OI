#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
#define ll long long
#define mod 18446744073709551616
#define maxn 250001
#define ls(x) (x<<1)
#define rs(x) (x<<1 | 1)
inline ll read(){
	ll w=1,x=0;char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-'){w=-1;}ch=getchar();}
	while(ch>='0' && ch<='9') {x=x*10+(ch-'0');ch=getchar();}
	return x*w;
}
ll maxx(ll x_x,ll y_y){
	return x_x>y_y ? x_x:y_y;
}
ll T,n,q,l,r,ans;
ll a[maxn],b[maxn];
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read(),n=read();
	for(int i=1;i<=n;i++)	a[i]=read();
	for(int i=1;i<=n;i++)	b[i]=read();
	q=read();
	for(int step=1;step<=q;step++)
	{
		ans=0;
		l=read(),r=read();
		for(int i=l;i<=r;i++)
		{
			ll max1=a[i],max2=b[i];
			for(int j=i;j<=r;j++){
				max1=maxx(a[j],max1);max2=maxx(b[j],max2);
				ans+=max1*max2;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
 }

