#include <bits/stdc++.h>
using namespace std;
const int N=2e6+9;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return f*x;
}
int T,n,m,k,tot1=0,tot2=0,a[N],st1[N],st2[N];
bool F=false;
struct node{
	int op,ind1,ind2;
}ans[N<<1];
void dfs(int now,int ste){
	if(F){
		return;
	}
	if(now==m+1){
		if(tot1==0&&tot2==0){
			for (int i=1;i<=ste;i++){
				printf("%d ",ans[i].op);
				if(ans[i].op==1){
					printf("%d\n",ans[i].ind1);
				}
				else{
					printf("%d %d\n",ans[i].ind1,ans[i].ind2);
				}
			}
			F=true;
		}
		return;
	}
	if(tot1>0&&tot2>0){
		if(st1[1]==st2[1]){
			ans[ste+1].op=2,ans[ste+1].ind1=1,ans[ste+1].ind2=2;
			for (int i=2;i<=tot1;i++){
				st1[i-1]=st1[i];
			}
			tot1--;
			for (int i=2;i<=tot2;i++){
				st2[i-1]=st2[i];
			}
			tot2--;
			dfs(now,ste+1);
		}
	}
	st1[++tot1]=a[now];
	bool f1=false;
	if(tot1>=2){
		if(st1[tot1]==st1[tot1-1]){
			tot1-=2,f1=true;
		}	
	}
	ans[ste+1].op=1,ans[ste+1].ind1=1;
	dfs(now+1,ste+1);
	if(f1){
		tot1++;
	}
	else{
		tot1--;
	}
	st2[++tot2]=a[now];
	bool f2=false;
	if(tot2>=2){
		if(st2[tot2]==st2[tot2-1]){
			tot2-=2,f2=true;
		}
	}
	ans[ste+1].op=1,ans[ste+1].ind1=2;
	dfs(now+1,ste+1);
	if(f2){
		tot2++;
	}
	else{
		tot2--;
	}
	return;
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=read();
	while(T--){
		n=read(),m=read(),k=read(),tot1=0,tot2=0,F=false;
		for (int i=1;i<=m;i++){
			a[i]=read();
		}
		dfs(1,0);
	}
	return 0;
}
