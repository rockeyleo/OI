#include <bits/stdc++.h>
using namespace std;
const int N=3e5+9,M=18;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return f*x;
}
int T,n,q,l,r,maxn1[N][M],maxn2[N][M];
unsigned long long ans=0;
int Get1(int l,int r){
	int k=log2(r-l+1);
	return max(maxn1[l][k],maxn1[r-(1<<k)+1][k]);
}
int Get2(int l,int r){
	int k=log2(r-l+1);
	return max(maxn2[l][k],maxn2[r-(1<<k)+1][k]);
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read(),n=read();
	for (int i=1;i<=n;i++){
		maxn1[i][0]=read();
	}
	for (int i=1;i<=n;i++){
		maxn2[i][0]=read();
	}
	for (int j=1;j<=18;j++){
		for (int i=1;i+(1<<j)-1<=n;i++){
			maxn1[i][j]=max(maxn1[i][j-1],maxn1[i+(1<<(j-1))][j-1]);
			maxn2[i][j]=max(maxn2[i][j-1],maxn2[i+(1<<(j-1))][j-1]);
		}
	}
//	for (int i=1;i<=n;i++){
//		int cnt=i-1;
//		while(b[cnt]<b[i]&&cnt>=1){
//			cnt--;
//		}
//		l2[i]=cnt+1;
//		cnt=i+1;
//		while(b[cnt]<b[i]&&cnt<=n){
//			cnt++;
//		}
//		r2[i]=cnt-1;
//	}
//	for (int i=1;i<=n;i++){
//		printf("%d %d\n",l1[i],r1[i]);
//	}
//	for (int i=1;i<=n;i++){
//		printf("%d %d\n",l2[i],r2[i]);
//	}
	q=read();
	while(q--){
		l=read(),r=read(),ans=0;
		for (int i=l;i<=r;i++){
//			tot=tot+(unsigned long long)(a[i]));
//			cout<<tot<<endl;
			for (int j=i;j<=r;j++){
				ans=ans+Get1(i,j)*Get2(i,j);
			}
		}
		printf("%llu\n",ans);
	}
	return 0;
}
/*
0 2
2 1
1 2
1
1 2
*/
