#include <bits/stdc++.h>
using namespace std;
const int N=1010,mod=998244353;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return f*x;
}
int T,id,n,m,c,f,l_cnt[N][N],c_cnt[N][N],sum[N][N]; 
long long ans_c=0,ans_f=0;
char a[N][N];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read(),id=read();
	while(T--){
		n=read(),m=read(),c=read(),f=read(),ans_c=0,ans_f=0;
		for (int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
		}
		if(c==0&&f==0){
			printf("0 0\n");
			continue;
		}
		for (int i=1;i<=n;i++){
			for (int j=1;j<=m;j++){
				sum[i][j]=0;
				l_cnt[i][j]=0,c_cnt[i][j]=0;
			}
		}
		for (int i=1;i<=n;i++){
			for (int j=1;j<=m;j++){
				sum[i][j]=sum[i-1][j];
				if(a[i][j]=='1'){
					continue;
				}
				if(l_cnt[i][j]>0){
					sum[i][j]+=l_cnt[i][j];
					continue;
				}
				l_cnt[i][j]=1;
				int lx=j;
				for (int k=j+1;a[i][k]!='1'&&k<=m;k++){
					l_cnt[i][j]++,lx=k;		
				}
				for (int k=j+1;k<=lx;k++){
					l_cnt[i][k]=l_cnt[i][j]-(k-j);
				}
				sum[i][j]+=l_cnt[i][j];
			}
		}
		for (int i=1;i<=m;i++){
			for (int j=1;j<=n;j++){
				if(a[j][i]=='1'){
					continue;
				}
				if(c_cnt[j][i]>0){
					continue;
				}
				c_cnt[j][i]=1;
				int cy=j;
				for (int k=j+1;a[k][i]!='1'&&k<=n;k++){
					c_cnt[j][i]++,cy=k;					
				}
				for (int k=j+1;k<=cy;k++){
					c_cnt[k][i]=c_cnt[i][j]-(k-j);
				}
			}
		}
//		for (int i=1;i<=n;i++){
//			for (int j=1;j<=m;j++){
//				printf("%d ",l_cnt[i][j]);
//			}
//			printf("\n");
//		}
//		printf("\n");
//		for (int i=1;i<=n;i++){
//			for (int j=1;j<=m;j++){
//				printf("%d ",c_cnt[i][j]);
//			}
//			printf("\n");
//		}
		for (int i=1;i<=n;i++){
			for (int j=1;j<=m;j++){
				if(a[i][j]=='1'){
					continue;
				}
				if(c_cnt[i][j]>=3&&l_cnt[i][j]>=2){
//					printf("%d %d\n",i,j);
					ans_c=(ans_c+(l_cnt[i][j]-1)*(sum[i+c_cnt[i][j]-1][j]-sum[i+1][j]-c_cnt[i][j]+2));
					if(c_cnt[i][j]>=4&&f){
						for (int k=i+2;k<=i+c_cnt[i][j]-1;k++){
							if(l_cnt[k][j]<=1){
								continue;
							}
							ans_f=(ans_f+(l_cnt[i][j]-1)*(l_cnt[k][j]-1)*(c_cnt[i][j]-(k-i+1)))%mod;
						}
					}
				}
			}
		}
		printf("%lld %lld\n",ans_c*c%mod,ans_f*f%mod);
	}
	return 0;
}
/*
5 0
6 6 0 0
000010
011000
000110
010000
011000
000000
4 3 1 1
001
010
000
000
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111
6 6 1 1
000010
011000
000110
010000
011000
000000
6 6 1 0
000010
011000
000110
010000
011000
000000
*/
