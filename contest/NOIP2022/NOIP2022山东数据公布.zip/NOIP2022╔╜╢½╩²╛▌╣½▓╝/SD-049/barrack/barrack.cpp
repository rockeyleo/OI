#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			f=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return f*x;
}
int qpow(int a,int b){
	int res=1;
	a%=mod;
	while(b){
		if(b&1){
			res=res*a%mod;
		}
		a=a*a%mod,b>>=1;
	}
	return res;
}
int n,m,ans=0;
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(),m=read();
	if(m==n-1){
		ans=(4+(n-2)*3%mod+(n-1)*(n)%mod*(2*n-1)%mod*qpow(6LL,mod-2)%mod)%mod;
		printf("%lld\n",ans);
	}
	else{
		printf("114514\n");
	}
	return 0;
}

