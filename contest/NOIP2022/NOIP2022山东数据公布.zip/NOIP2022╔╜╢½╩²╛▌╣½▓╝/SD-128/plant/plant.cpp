#include<bits/stdc++.h>
using namespace std;
#define N 1005
#define mod 998244353
long long dpc[N][N][3];
long long dpf[N][N][4];
long long t,id;
long long n,m;
char a[N][N];
long long szys[N][N];
long long c,f;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%lld%lld",&t,&id);
	while(t--)
	{
		memset(dpc,0,sizeof(dpc));
		memset(dpf,0,sizeof(dpf));
		memset(szys,0,sizeof(szys));
		memset(a,0,sizeof(a));
		scanf("%lld%lld%lld%lld",&n,&m,&c,&f);
		for(long long i=1;i<=n;i++)
			scanf("%s",a[i]+1);
		for(long long i=1;i<=n;i++)
			for(long long j=m;j>=1;j--)
				if(a[i][j]=='0')
					szys[i][j]=szys[i][j+1]+1;
		for(long long i=1;i<=n;i++)
			for(long long j=1;j<=m;j++)
				if(a[i][j]=='0')
				{
					dpc[i][j][0]=szys[i][j]-1;
					dpc[i][j][1]=(dpc[i-1][j][0]+dpc[i-1][j][1])%mod;
					dpc[i][j][2]=(dpc[i-1][j][1])*(szys[i][j]-1)%mod;
				}
		for(long long i=1;i<=n;i++)
			for(long long j=1;j<=m;j++)
				if(a[i][j]=='0')
				{
					dpf[i][j][0]=szys[i][j]-1;
					dpf[i][j][1]=(dpf[i-1][j][0]+dpf[i-1][j][1])%mod;
					dpf[i][j][2]=(dpf[i-1][j][1])*(szys[i][j]-1)%mod;
					dpf[i][j][3]=(dpf[i-1][j][2]+dpf[i-1][j][3])%mod;
				}
		long long ansc=0,ansf=0;
		for(long long i=1;i<=n;i++)	
			for(long long j=1;j<=m;j++)
				(ansc+=dpc[i][j][2])%=mod;
		for(long long i=1;i<=n;i++)
			for(long long j=1;j<=m;j++)
				(ansf+=dpf[i][j][3])%=mod;
		printf("%lld %lld\n",c*ansc%mod,f*ansf%mod);
	}
	return 0;
}
