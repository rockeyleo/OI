#include<bits/stdc++.h>
using namespace std;
#define N 250005
long long t,n,q;
unsigned long long ans=0;
long long a[N],b[N];
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%lld%lld",&t,&n);
	for(unsigned long long i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(unsigned long long i=1;i<=n;i++)
		scanf("%lld",&b[i]);
	scanf("%lld",&q);
	for(long long i=1,l,r;i<=q;i++)
	{
		scanf("%lld%lld",&l,&r);
		for(long long ll=l;ll<=r;ll++)
		{
			long long mxa=0,mxb=0;
			for(unsigned long long rr=ll;rr<=r;rr++)
			{
				mxa=max(mxa,a[rr]);
				mxb=max(mxb,b[rr]);
				ans+=((unsigned long long)mxa)*((unsigned long long)mxb);
			}
		}
		printf("%llu\n",ans);
	}
	return 0;
}
