#include<bits/stdc++.h>
using namespace std;
#define N 500005
#define mod 1000000007
vector<long long> mp[N],mpn[N];
long long esiz[N];
long long siz[N];
long long n,m;
long long dfn[N],low[N],dfncnt=0;
long long sta[N],statop=0;
long long color[N],colorcnt=0;
long long u[N<<1],v[N<<1];
long long dp[N][2][2];
long long pks=0;
long long ksm(long long x,long long k)
{
	long long ret=1;
	while(k)
	{
		if(k&1)
			ret=ret*x%mod;
		x=x*x%mod;
		k>>=1;
	}
	return ret;
}
void dfs(long long x,long long fa)
{
	long long tmpdpy=1,tmpdpn=1,tmpdpnn=1;
	for(long long i:mpn[x])
		if(i!=fa)
		{
			dfs(i,x);
			(tmpdpy*=dp[i][1][1])%=mod;
			(tmpdpn*=dp[i][1][0])%=mod;
			(tmpdpnn*=dp[i][0][0])%=mod;
		}
	if(mpn[x].size()==1&&x!=1)
	{
		dp[x][1][1]=1*(ksm(2,siz[x])-1)*(ksm(2,esiz[x]))%mod;
		dp[x][1][0]=2*(ksm(2,siz[x])-1)%mod;
		dp[x][0][0]=2*(ksm(2,esiz[x]))%mod;
		return;
	}
	dp[x][1][1]=(tmpdpy%mod+tmpdpnn%mod)*(ksm(2,siz[x])-1)%mod*ksm(2,esiz[x])%mod;
	dp[x][1][0]=(tmpdpy*(ksm(2,siz[x])-1)%mod+tmpdpn)%mod;
	(dp[x][1][0]*=ksm(2,esiz[x]+1))%=mod;
	if(x==1)
		pks=tmpdpn*ksm(2,esiz[x])%mod;
	dp[x][0][0]=(tmpdpnn)*ksm(2,esiz[x]+1)%mod;
}
void tarjan(long long x,long long fa)
{
	dfn[x]=low[x]=++dfncnt;
	sta[++statop]=x;
	for(long long i:mp[x])
	{
		if(i==fa)
			continue;
		if(dfn[i])
			low[x]=min(low[x],dfn[i]);
		else
		{
			tarjan(i,x);
			low[x]=min(low[x],low[i]);
		}
		if(low[i]>dfn[x])
		{
			++colorcnt;
			while(sta[statop]!=i)
			{
				color[sta[statop]]=colorcnt;
				statop--;
			}
			color[sta[statop]]=colorcnt;
			statop--;
		}
	}
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(long long i=1;i<=m;i++)
	{
		scanf("%lld%lld",&u[i],&v[i]);
		mp[u[i]].push_back(v[i]);
		mp[v[i]].push_back(u[i]);
	}
	tarjan(1,0);
	++colorcnt;
	while(statop)
	{
		color[sta[statop]]=colorcnt;
		statop--;
	}
	for(long long i=1;i<=n;i++)
		siz[color[i]]++;
	for(long long i=1;i<=m;i++)
		if(color[u[i]]==color[v[i]])
			esiz[color[u[i]]]++;
		else
		{
			mpn[color[u[i]]].push_back(color[v[i]]);
			mpn[color[v[i]]].push_back(color[u[i]]);
		}
	dfs(1,0);
	printf("%lld",(dp[1][1][1]+pks)%mod);
	return 0;
}
