#include<bits/stdc++.h>
using namespace std;
#define N 2000005
int n,k,m;
int t;
int a[N];
int where[N];
int ls[605];
vector<int> sta[305];
struct ANS
{
	int typ,a,b;
}ans[N<<1];
int anscnt=0;
int ont[605],dow[605];
bool dfs(int dep)
{
	vector<int> tmpsta[4];
	if(dep==m)
		if(sta[1].size()==0&&sta[2].size()==0&&sta[2].size()==0)
			return 1;
		else
			return 0;
	tmpsta[1]=sta[1];
	tmpsta[2]=sta[2];
	tmpsta[3]=sta[3];
	int tmpanscnt=anscnt;
	sta[1].push_back(a[dep+1]);
	ans[++anscnt]=(ANS){1,1};
	if(sta[1].size()&&sta[2].size())
	if(sta[1][0]==sta[2][0])
	{
		ans[++anscnt]=(ANS){2,1,2};
		sta[1].erase(sta[1].begin());
		sta[2].erase(sta[2].begin());
	}
	if(sta[1].size()&&sta[3].size())
	if(sta[1][0]==sta[3][0])
	{
		ans[++anscnt]=(ANS){2,1,3};
		sta[1].erase(sta[1].begin());
		sta[3].erase(sta[3].begin());
	}
	if(dfs(dep+1))
		return 1;
	sta[1]=tmpsta[1];
	sta[2]=tmpsta[2];
	sta[3]=tmpsta[3];	
	anscnt=tmpanscnt;
	sta[2].push_back(a[dep+1]);
	ans[++anscnt]=(ANS){1,2};
	if(sta[1].size()&&sta[2].size())
	if(sta[1][0]==sta[2][0])
	{
		ans[++anscnt]=(ANS){2,1,2};
		sta[1].erase(sta[1].begin());
		sta[2].erase(sta[2].begin());
	}
	if(sta[2].size()&&sta[3].size())
	if(sta[2][0]==sta[3][0])
	{
		ans[++anscnt]=(ANS){2,2,3};
		sta[2].erase(sta[2].begin());
		sta[3].erase(sta[3].begin());
	}
	if(dfs(dep+1))
		return 1;
	sta[1]=tmpsta[1];
	sta[2]=tmpsta[2];
	sta[3]=tmpsta[3];	
	anscnt=tmpanscnt;
	sta[3].push_back(a[dep+1]);
	ans[++anscnt]=(ANS){1,3};
	if(sta[1].size()&&sta[3].size())
	if(sta[1][0]==sta[3][0])
	{
		ans[++anscnt]=(ANS){2,1,3};
		sta[1].erase(sta[1].begin());
		sta[3].erase(sta[3].begin());
	}
	if(sta[2].size()&&sta[3].size())
	if(sta[2][0]==sta[3][0])
	{
		ans[++anscnt]=(ANS){2,2,3};
		sta[2].erase(sta[2].begin());
		sta[3].erase(sta[3].begin());
	}
	if(dfs(dep+1))
		return 1;
	return 0;
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<=m;i++)
			scanf("%d",&a[i]);
		if(m<=14&&n==3)
		{
			dfs(0);
			printf("%d\n",anscnt);
			for(int j=1;j<=anscnt;j++)
			{
				if(ans[j].typ==1)
					printf("1 %d\n",ans[j].a);
				else
					printf("2 %d %d\n",ans[j].a,ans[j].b);
			}
			continue;
		}
		anscnt=0;
		memset(ls,0,sizeof(ls));
		for(int i=1;i<=m;i++)
		{
			if(ls[a[i]])
				where[ls[a[i]]]=i;
			ls[a[i]]=i;
		}
		for(int i=1;i<=m;i++)
		{
			int zkh=1;
			for(int j=1;j<=n-1;j++)
				if(sta[j].size())
				{
					if(a[i]==a[sta[j][sta[j].size()-1]])
					{
						ans[++anscnt]=(ANS){1,j};
						sta[j].pop_back();
						goto shit;
					}
					else if(a[i]==a[sta[j][0]])
					{
						ans[++anscnt]=(ANS){1,n};
						ans[++anscnt]=(ANS){2,j,n};
						sta[j].erase(sta[j].begin());
						goto shit;
					}
				}
			for(int j=1;j<=n-1;j++)
				if(sta[j].size()<=1)
				{
					ans[++anscnt]=(ANS){1,j};
					sta[j].push_back(i);
					goto shit;
				}
			for(int j=2;j<=n-1;j++)
				if(where[sta[j][sta[j].size()-1]]>where[sta[zkh][sta[zkh].size()-1]])
					zkh=j;
		 ans[++anscnt]=(ANS){1,zkh};
			sta[zkh].push_back(i);
			shit:;
		}
		printf("%d\n",anscnt);
		for(int j=1;j<=anscnt;j++)
		{
			if(ans[j].typ==1)
				printf("1 %d\n",ans[j].a);
			else
				printf("2 %d %d\n",ans[j].a,ans[j].b);
		}
	}
	return 0;
}
/*
1
3 10 5
1 2 3 4 5 2 3 4 5 1
*/
