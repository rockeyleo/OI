#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#define INF 2147483647
//#define Mod 998244353
#define int long long
#define MAXN 100010
#define MAXM 1000010
using namespace std;
const int Mod = 1e9 + 7;
//-------------------------------------------------------
struct Node {
	int v, nxt;
} e[MAXM << 1];
//-------------------------------------------------------
int n, m, cnt = 0;
int head[MAXN];
//-------------------------------------------------------
inline int read() {
	int fla = 0, x = 0; char ch = getchar();
	while (!isdigit(ch)) fla |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return fla ? -x : x;
}
void add(int u, int v) {
	e[++cnt].v = v;
	e[cnt].nxt = head[u];
	head[u] = cnt;
}
//-------------------------------------------------------
signed main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	n = read(); m = read();
	for (int i = 1, u, v; i <= m; ++i) {
		u = read(); v = read();
		add(u, v); add(v, u);
	}
	int ans = (n * (n - 1) % Mod) >> 1;
	cout << (ans * m % Mod) * (ans * m % Mod) % Mod << endl;
	fclose(stdin); fclose(stdout);
	return 0;
}
