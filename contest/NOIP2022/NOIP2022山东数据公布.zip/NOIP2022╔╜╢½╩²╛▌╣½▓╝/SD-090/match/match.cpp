#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#define INF 2147483647
//#define Mod 998244353
#define ULL unsigned long long
#define MAXN 250010
using namespace std;
//-------------------------------------------------------

//-------------------------------------------------------
int T, n, Q;
int Log2[MAXN], tmp[2][MAXN], f[2][31][MAXN];
//-------------------------------------------------------
inline int read() {
	int fla = 0, x = 0; char ch = getchar();
	while (!isdigit(ch)) fla |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return fla ? -x : x;
}
void PreLog() {
	Log2[1] = 0;
	for (int i = 2; i <= 1024; ++i)
		Log2[i] = Log2[i - 1] + ((1 << (Log2[i - 1] + 1)) == i);
}
void Pre(int opt) {
	for (int i = 1; i <= n; ++i) f[opt][0][i] = tmp[opt][i];
	for (int i = 1; i <= Log2[n]; ++i)
		for (int j = 1; j <= n; ++j)
			f[opt][i][j] = max(f[opt][i - 1][j], f[opt][i - 1][j + (1 << (i - 1))]);
}
int Ask(int opt, int l, int r) {
	int len = Log2[r - l + 1];
	return max(f[opt][len][l], f[opt][len][r - (1 << len) + 1]);
}
ULL work(int l, int r) {
	ULL sum = 0, Max1, Max2;
	for (int i = l; i <= r; ++i)
		for (int j = i; j <= r; ++j) {
			Max1 = 1llu * Ask(0, i, j);
			Max2 = 1llu * Ask(1, i, j);
			sum += (1llu * Max1 * Max2);
		}
	return sum;
}
//-------------------------------------------------------
signed main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	T = read(); n = read();
	for (int i = 1; i <= n; ++i) tmp[0][i] = read();
	for (int i = 1; i <= n; ++i) tmp[1][i] = read();
	PreLog(); Pre(0); Pre(1);
	Q = read();
	while (Q--) {
		int l = read(), r = read();
		printf("%llu\n", work(l, r));
	}
	fclose(stdin); fclose(stdout);
//	if (system("fc match.out match2.ans")) printf("No!!!\n");
	return 0;
}
