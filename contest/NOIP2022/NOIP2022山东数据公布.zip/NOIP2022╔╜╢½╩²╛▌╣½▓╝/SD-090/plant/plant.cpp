#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#define INF 2147483647
#define Mod 998244353
#define MAXN 1010
#define int long long
using namespace std;
//-------------------------------------------------------

//-------------------------------------------------------
int T, id, n, m, C, F, ansc, ansf;
int tmp[MAXN][MAXN], prey[MAXN][MAXN], prex[MAXN][MAXN], pre[MAXN][MAXN];
char s[MAXN];
//-------------------------------------------------------
inline int read() {
	int fla = 0, x = 0; char ch = getchar();
	while (!isdigit(ch)) fla |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return fla ? -x : x;
}
void Pre() {
	for (int i = 1; i <= n; ++i)
		for (int j = m, fla = 0; j >= 1; --j) {
			if (tmp[i][j]) {
				prey[i][j] = -1;
				fla = 0;
				continue;
			}
			prey[i][j] = fla % Mod;
			fla = (fla + 1) % Mod;
		}
	for (int i = 1; i <= m; ++i)
		for (int j = n, fla = 0; j >= 1; --j) {
			if (tmp[j][i]) {
				prex[j][i] = -1;
				fla = 0;
				continue;
			}
			prex[j][i] = fla % Mod;
			fla = (fla + 1) % Mod;
		}
}
void work() {
	//---------------C------------------
	if (n < 3 || C == 0) ansc = 0;
	else {
		ansc = 0;
		for (int Y0 = 1; Y0 <= m; ++Y0)
			for (int X1 = 1; X1 <= n; ++X1) {
				if (prey[X1][Y0] <= 0) continue;
				for (int X2 = X1 + 2; X2 <= n; ++X2) {
					if (X1 + prex[X1][Y0] < X2) break;
					if (prey[X2][Y0] <= 0) continue;
					ansc = (ansc + (prey[X1][Y0] * prey[X2][Y0]) % Mod) % Mod;
				}
			}
	}
	//---------------F------------------
	if (n < 4 || F == 0) ansf = 0;
	else {
		ansf = 0;
		for (int Y0 = 1; Y0 <= m; ++Y0)
			for (int X1 = 1; X1 <= n; ++X1) {
				if (prey[X1][Y0] <= 0) continue;
				for (int X2 = X1 + 2; X2 <= n; ++X2) {
					if (X1 + prex[X1][Y0] < X2) break;
					if (prey[X2][Y0] <= 0 || prex[X2][Y0] <= 0) continue;
					ansf = (ansf + (((prey[X1][Y0] * prey[X2][Y0]) % Mod) * prex[X2][Y0]) % Mod) % Mod;
				}
			}
	}
}
//-------------------------------------------------------
signed main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T = read(); id = read();
	while (T--) {
		n = read(); m = read(); C = read(); F = read();
		for (int i = 1; i <= n; ++i) {
			cin >> s + 1;
			for (int j = 1; j <= m; ++j)
				tmp[i][j] = (s[j] == '1');
		}
		if (C == 0 && F == 0) ansc = 0, ansf = 0;
		else {
			Pre(); work();
			ansc = ansc * C % Mod; ansf = ansf * F % Mod;
		}
		printf("%lld %lld\n", ansc, ansf);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
