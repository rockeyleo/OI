#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#define INF 2147483647
#define Mod 998244353
#define LL long long
#define MAXN 4000010
using namespace std;
//-------------------------------------------------------
struct Dqu {
	vector<int> G;
	int qian, hou;
	void Build() {
		qian = 1; hou = 0;
	}
	bool Empty() {
		return qian > hou;
	}
	void Push(int x) {
		G.push_back(x);
		++hou;
	}
	int Tail() {
		return G[hou - 1];
	}
	int Head() {
		return G[qian - 1];
	}
	void Pop_tail() {
		--hou;
	}
	void Pop_head() {
		++qian;
	}
} q[3];
//-------------------------------------------------------
int T, n, m, k, op;
int s[2][MAXN], book[MAXN], optt[MAXN];
//-------------------------------------------------------
inline int read() {
	int fla = 0, x = 0; char ch = getchar();
	while (!isdigit(ch)) fla |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return fla ? -x : x;
}
void work(int x) {
	if ((q[1].Empty() && q[2].Empty()) || !book[x]) {
		q[1].Push(x);
		book[x] = 1;
		++op;
		optt[op] = 1;
		s[0][op] = 1;
		return ;
	}
	if (book[x]) {
		if (q[1].Tail() == x) {
			q[1].Pop_tail();
			++op;
			optt[op] = 1;
			s[0][op] = 1;
		}
		else {
			q[2].Push(x);
			++op;
			optt[op] = 1;
			s[0][op] = 2;
		}
	}
	while (!q[1].Empty() && !q[2].Empty()) {
		while (q[1].Head() == q[2].Head()) {
			++op; optt[op] = 2;
			s[0][op] = 1; s[1][op] = 2;
			q[1].Pop_head();
			q[2].Pop_head();
		}
	}
}
//-------------------------------------------------------
signed main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	T = read();
	while (T--) {
		n = read(); m = read(); k = read(); op = 0;
		for (int i = 1; i <= k; ++i) book[i] = 0;
		q[1].Build(); q[2].Build();
		for (int i = 1, opt; i <= m; ++i) {
			opt = read();
			work(opt);
		}
		printf("%d\n", op);
		for (int i = 1; i <= op; ++i) {
			if (optt[i] == 1) printf("1 %d\n", s[0][i]);
			else printf("2 %d %d\n", s[0][i], s[1][i]);
		}
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
