#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*=f;
}
inline void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
#define int long long
#define N 500010
#define mod 998244353
const int Mod = 1e9 + 7;
#define ls p<<1
#define rs ls|1
#define mid ((l+r)>>1)
int tot,head[N];
struct edge{
	int to,next,val;
}e[N<<1];
//inline void add(int u,int v,int w){
//	e[++tot].to=v;
//	e[tot].val=w;
//	e[tot].next=head[u];
//	head[u]=tot;
//}
inline void add(int u,int v){
	e[++tot].to=v;
	e[tot].next=head[u];
	head[u]=tot;
}
int dis[N],vis[N];
//inline void spfa(int x){
//	queue<int>q;
//	dis[x]=0;
//	vis[x]=1;
//	q.push(x);
//	while(!q.empty()){
//		int u=q.front();
//		q.pop();
//		for(int i=head[u];i;i=e[i].next){
//			int v=e[i].to;
//			if(dis[v]>dis[u]+e[i].val){
//				dis[v]=dis[u]+e[i].val;
//				if(!vis[v]){
//					vis[v]=1;
//					q.push(v)
//				}
//			}
//		}
//	}
//}
int a[N];
int sum;
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	a[0]=1;
	for(int i=1;i<=N;i++){
		a[i]=a[i-1]*i;
	}
	for(int i=1;i<=n;i++){
		sum+=i;
	}
	int ans=a[n]*a[n-1]%Mod+m*sum%Mod;
	write(ans%Mod);
	return 0;
}

