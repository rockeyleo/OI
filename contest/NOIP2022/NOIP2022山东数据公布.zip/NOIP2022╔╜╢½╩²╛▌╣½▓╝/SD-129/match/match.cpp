#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*=f;
}
inline void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
#define N 300010
int a[N],b[N];
int ans;
int maxn,maxo;
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T=read(),n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=n;i++){
		b[i]=read();
	}
	int Q=read();
	while(Q--){
		ans=0;
		int l=read(),r=read();
		for(int p=l;p<=r;p++){
			for(int q=p;q<=r;q++){
				maxn=max(maxn,max(a[p],a[q]));
				maxo=max(maxo,max(b[p],b[q]));
//				cout<<maxn<<" "<<maxo<<endl;
				ans+=maxn*maxo;
				maxn=0,maxo=0;
			}
		} 
		write(ans);
		puts("");
	}
	return 0;
}

