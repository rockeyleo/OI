#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*=f;
}
inline void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
#define int long long
#define N 1010
#define mod 998244353
const int Mod = 1e9 + 7;
#define ls p<<1
#define rs ls|1
#define mid ((l+r)>>1)
int tot,head[N];
struct edge{
	int to,next,val;
}e[N<<1];
//inline void add(int u,int v,int w){
//	e[++tot].to=v;
//	e[tot].val=w;
//	e[tot].next=head[u];
//	head[u]=tot;
//}
inline void add(int u,int v){
	e[++tot].to=v;
	e[tot].next=head[u];
	head[u]=tot;
}
int dis[N],vis[N];
//inline void spfa(int x){
//	queue<int>q;
//	dis[x]=0;
//	vis[x]=1;
//	q.push(x);
//	while(!q.empty()){
//		int u=q.front();
//		q.pop();
//		for(int i=head[u];i;i=e[i].next){
//			int v=e[i].to;
//			if(dis[v]>dis[u]+e[i].val){
//				dis[v]=dis[u]+e[i].val;
//				if(!vis[v]){
//					vis[v]=1;
//					q.push(v)
//				}
//			}
//		}
//	}
//}

//struct Tree{
//	int l,r,pos,add;
//}t[N<<2];
//inline void build(int p,int l,int r){
//	t[p].l=l,t[p].r=r;
//	if(l==r){
//		t[p].pos=a[l];
//		return;
//	}
//	build(ls,l,r);
//	build(rs,l,r);
//}
//inline void pushdown(int p){
//	if(t[p].add){
//		t[ls].pos+=t[p].add*(t[ls].r-t[ls].l+1);
//		t[rs].pos+=t[p].add*(t[rs].r-t[rs].l+1);
//		t[ls].add+=t[p].add;
//		t[rs].add+=t[p].add;
//		t[p].add=0;
//	}
//}
//inline void Add(int p,int l,int r,int v){
//	if(l<=t[p].l&&r>=t[p].r){
//		t[p].pos+=v*(t[p].r-t[p].l+1);
//		t[p].add+=v;
//		return;
//	}
//	pushdown(p);
//	int mid=(t[p].l+t[p].r)>>1;
//	if(l<=mid) Add(ls,l,r,v);
//	if(r>mid) Add(rs,l,r,v);
//	t[p].pos=t[ls].pos+t[rs].pos;
//}
//inline int Ask(int p,int l,int r){
//	if(l<=t[p].l&&r>=t[p].r){
//		return t[p].pos;
//	}
//	int ans=0;
//	int mid=(t[p].l+t[p].r)>>1;
//	if(l<=mid) ans+=Ask(ls,l,r);
//	if(r>mid) ans+=Ask(rs,l,r); 
//}
int g[N][N],dp[N][N];
int a[N][N];
char s[N][N];
char ch;
int n,m,c,f;
int ans;
inline int Ans_c(){
	int res=0;
	for(int j=1;j<=m-1;j++){
		for(int i=1;i<=n-2;i++){
			if(a[i][j]) continue;
			for(int k=2;k<=dp[i][j]-1;k++){
				res+=(g[i][j]-1)*(g[i+k][j]-1)%mod;
			}
		}
	}
	return res;
}
inline int Ans_f(){
	int res=0;
	for(int j=1;j<=m-1;j++){
		for(int i=1;i<=n-3;i++){
			if(a[i][j]) continue;
			for(int k=2;k<=dp[i][j]-2;k++){
				res+=(g[i][j]-1)*(g[i+k][j]-1)%mod*(dp[i][j]-(k+1))%mod;
			}
		}
	}
	return res;
}
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=read(),id=read();
	while(T--){
		n=read(),m=read(),c=read(),f=read();
		g[n][m]=dp[n][m]=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cin>>s[i][j];
				a[i][j]=s[i][j]-'0';
			}
		}
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=m;j++){
//				cout<<a[i][j]<<" ";
//			}
//			cout<<endl;
//		}
		for(int i=n;i>=1;i--){
			g[i][m]=1;
			for(int j=n-1;j>=1;j--){
				if(a[i][j+1]) 
					g[i][j]=1;
				else 
					g[i][j]=g[i][j+1]+1;
				if(a[i+1][j]) 
					dp[i][j]=1;
				else 
					dp[i][j]=dp[i+1][j]+1;
			}
		}
		if(!f&&!c) 
			cout<<0<<" "<<0<<endl;
		else
			cout<<c*Ans_c()<<" "<<f*Ans_f()<<endl;
	}
	return 0;
}

