#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*=f;
}
inline void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
#define int long long
#define N 100010
#define mod 998244353
const int Mod = 1e9 + 7;
int a[N],b[N],q[N];
//int down[N],top[N],qtop[N],qdown[N];
//inline void Sub1(){
//	int n=read(),m=read(),k=read();
//	int qh=qt=th=tt=1;
//	for(int i=1;i<=m;i++){
//		a[i]=read();
//		qtop[i]=qdown[i]=i;
//	}
//	for(int i=1;i<=m;i++){
//		if(!q[a[i]]){
//			cout<<1<<" ";
//			if(qh<=qt){
//				cout<<qdown[qh]<<" ";
//				down[qdown[qh]]=a[i];
//				q[a[i]]=qdown[qh++];
//			}
//			else{
//				cout<<qtop[th]<<" ";
//				top[qtop[th]]=a[i];
//				q[a[i]]=qtop[th++];
//			}
//		}
//	}
//}
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T=read();
	while(T--){
		int n=read(),m=read(),k=read();
		for(int i=1;i<=m;i++){
			a[i]=read();
			for(int j=1;j<=k;j++){
				if(a[i]==j) b[j]++;
			}
		}
		cout<<m<<endl;
		for(int p=1;p<=n;p++){
			for(int i=1;i<=k;i++){
				for(int j=1;j<=m;j++){
					if(b[i]){
						if(a[j]==a[j+1]){
							b[a[j]]--;
							b[a[j+1]]--;
							cout<<p<<" "<<p<<endl;
							cout<<p<<" "<<p<<endl;
						}
						else{
							b[a[j]]--;
							b[a[j+1]]--;
							if(p+1<=n){
								cout<<p<<" "<<p<<endl;
								cout<<p<<" "<<p+1<<endl;
							}
						}
					}
				}
			}
		}
	}	
		
	return 0;
}


