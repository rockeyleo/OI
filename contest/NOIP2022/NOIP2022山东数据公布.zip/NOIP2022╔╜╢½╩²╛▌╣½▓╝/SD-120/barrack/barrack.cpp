#include<bits/stdc++.h>
#pragma GCC optimize(2)
using namespace std;
int n,m,ans,x,y;bool tu[1005][1005];
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<m;i++){
		cin>>x>>y;
		tu[x][y]=1;
		tu[y][x]=1;
	}
	ans=n+1+m*2;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=0;k<n;k++){
				
			} 
		}
	}
	cout<<ans;
	return 0;
}
