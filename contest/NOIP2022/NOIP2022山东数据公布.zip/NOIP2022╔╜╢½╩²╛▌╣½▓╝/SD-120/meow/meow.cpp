#include<bits/stdc++.h>
#pragma GCC optimize(2)
using namespace std;
struct bz{
	bool yd;
	int a,b;	 
}bz[1005];
int n,m,k,t,cs,head[1005],tail[1005];int a[1005],d[1005][1005];
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	for(int i=0;i<t;i++){
		memset(head,0,1005);
		memset(tail,0,1005);
		cin>>n>>m>>k;cs=0;
		for(int i=0;i<n;i++){cin>>a[i];}
		for(int i=0;i<n;i++){
			for(int k=0;k<m;k++){
				if(d[head[k]][k]==0){d[head[k]][k]=a[i];tail[k]++;cs++;bz[cs].yd=0;bz[cs].a=k;
				for(int i=0;i<k;i++){if(d[head[i]][i]==d[head[k]][k]){d[tail[k]][k]=0;d[tail[i]][i]=0;head[k]++;head[i]++;cs++;bz[cs].yd=1;bz[cs].a=i;bz[cs].b=k;}}}
				if(d[tail[k]][k]==a[i]){
					cs++;d[tail[k]][k]=0;d[tail[k-1]][k-1]=0;tail[k]-=2;bz[cs].yd=0;bz[cs].a=k;
				}
			}
		}
		cout<<cs<<endl;
		for(int i=1;i<=cs;i++){
			cout<<int(bz[i].yd+1)<<" ";
			if(bz[i].yd){cout<<bz[i].a<<" "<<bz[i].b<<endl;}
			else{cout<<bz[i].a<<endl;}
		}
	}
	return 0;
}
