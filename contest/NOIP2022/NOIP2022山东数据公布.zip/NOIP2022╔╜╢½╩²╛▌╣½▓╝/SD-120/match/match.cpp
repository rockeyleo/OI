#include<bits/stdc++.h>
#pragma GCC optimize(2)
using namespace std;
int n,m,t,q,l,r,ans;int a[1005],b[1005];
int main(){
	freopen("march.in","r",stdin);
	freopen("march.out","w",stdout);
	cin>>t>>n;if(t==0){t=1;}
	for(int ai=0;ai<t;ai++){
		for(int i=1;i<=n;i++){
			cin>>a[i];
		}
		for(int i=1;i<=n;i++){
			cin>>b[i];
		}
		cin>>q;
		for(int p=0;p<q;p++){
			cin>>l>>r;
			for(int ai=l;ai<=r;ai++){
				for(int ab=ai;ab<=r;ab++){
					ans+=a[ai]*b[ab];
				}
			}
				cout<<ans;
		}

	}
	return 0;
}
