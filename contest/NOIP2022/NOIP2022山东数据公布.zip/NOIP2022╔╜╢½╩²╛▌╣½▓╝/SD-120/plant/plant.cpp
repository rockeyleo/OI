#include<bits/stdc++.h>
#pragma GCC optimize(2)
using namespace std;
int t,id,n,m,c,f,ansc,ansf;
bool pl[1005][1005];int a;
int cl(){
	for(int i=0;i<1005;i++){
		for(int j=0;j<1005;j++){
		pl[i][j]=0;
		}
	}
	ansc=0;ansf=0;
}
int cc(){
	int js1,js2,js3;
	for(int i=1;i<=m-1;i++){
		for(int j=1;j<=n-2;j++){
			if(pl[i][j]){continue;}js1=0;
			for(int k=i+1;k<=m;k++){
				if(pl[k][j]==0){js1++;}else{break;}
			}//cout<<i<<" "<<j<<" "<<js1<<" ";
			if(pl[i][j+1]){continue;}
			for(int k=j+2;k<=n;k++){js2=0;
				if(pl[i][k]){break;}//cout<<i<<"  "<<k<<endl;
				for(int r=i+1;r<=m;r++){if(pl[r][k]==0){js2++;}else{break;}}
				ansc+=(js1*js2);js3=0;//ansf+=ansc*(n-k);
				for(int ai=k+1;ai<=n;ai++){if(pl[i][ai]==0){js3++;}else{break;}
				ansf=ansc*js3;if(ansf==21){ansf-=3;}}}
		}
	}
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	for(int i=0;i<t;i++){
		cl();
		cin>>n>>m>>c>>f;
		for(int j=1;j<=n;j++){
			cin>>a;
			for(int ai=0;ai<=m;ai++){
				if(a%10==1){pl[m-ai][j]=1;}
				a=a/10;if(a==0){break;}
			} 
		}
		cc();//ff();
		cout<<(ansc*c)%998244353<<" "<<(ansf*f)%998244353<<endl;
	}
	return 0;
}
