#include<cstdio >
#include<iostream>
using namespace std;
 
const int num = 998244353;
 
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	cin>>t>>id;
	while(t--){
		int n,m,c,f;
		cin>>n>>m>>c>>f;
		if(c == 0 && f == 0){
			cout<<0<<" "<<0<<endl;
			continue;
		}
		int a[n+1][m+1],shu[n*m][3],heng[n*m][3];
		for(int i = 1;i <= n;i++){
			for(int j = 1;j <= m;j++){
				cin>>a[i][j];
			}
		}
		int k = 1,cnt = 0;
		for(int j = 1;j <= m;j++,cnt = 0){
			for(int i = 1;i <= n;i++){
				if(a[i][j] == 0 && cnt == 0){
					shu[k][0] = j;
				}
				if(a[i][j] == 0){
					cnt++;
				}else{
					if(cnt >= 3){
						shu[k][2] = i-1;
						shu[k][1] = shu[k][2] - cnt;
						k++;
					}
					cnt = 0;
				}
				if(i == n && cnt >= 3 && a[i][j] == 0){
					shu[k][2] = n;
					shu[k][1] = shu[k][2] - cnt;
					k++;
					cnt = 0;
				}
			}
		}//step1
		cout<<shu[1][0]<<shu[1][1]<<shu[1][2]<<cnt<<endl;
		cout<<shu[2][0]<<shu[2][1]<<shu[2][2]<<cnt;
	}
}
