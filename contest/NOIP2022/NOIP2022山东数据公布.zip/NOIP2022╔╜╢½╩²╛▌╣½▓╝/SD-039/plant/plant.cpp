#include <bits/stdc++.h>
using namespace std;

#define MAXN 1005
#define mod 998244353

long long c,f,n,m,T,id;
char G[MAXN][MAXN];

long long workc() {
	long long ans(0);
	//i j k
	for(int i=0; i<m; i++) {
		for(int j=i+1; j<m; j++) {
			for(int k=i+1; k<m; k++) {
				for(int l=0; l<n; l++) {
					for(int p=l+2; p<n; p++) {
						bool flag = true;
//						if(flag) cout<<flag<<endl;
						for(int s=l; s<=p; s++) if(G[s][i] == '1') flag = false;
						for(int s=i; s<=j; s++) if(G[l][s] == '1') flag = false;
						for(int s=i; s<=k; s++) if(G[p][s] == '1') flag = false;
						if(flag) ++ans;
						ans%=mod;
					}
				}
			}
		}
	}
	return ans;
}

long long workf() {
	long long ans(0);
	//i j k
	for(int i=0; i<m; i++) {
		for(int j=i+1; j<m; j++) {
			for(int k=i+1; k<m; k++) {
				for(int l=0; l<n; l++) {
					for(int p=l+2; p<n; p++) {
						for(int g=p+1; g<n; g++) {
							bool flag = true;
//							if(flag) cout<<flag<<endl;
							for(int s=l; s<=g; s++) if(G[s][i] == '1') flag = false;
							for(int s=i; s<=j; s++) if(G[l][s] == '1') flag = false;
							for(int s=i; s<=k; s++) if(G[p][s] == '1') flag = false;
							if(flag) ++ans;
							ans%=mod;
						}
					}
				}
			}
		}
	}
	return ans;
}
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);

	cin>>T>>id;
	while(T--) {
		memset(G,0,sizeof G);

		cin>>n>>m>>c>>f;
		for(int i=0; i<n; i++)cin>>G[i];
		cout<<(workc()*c)%mod<<" "<<(workf()*f)%mod<<endl;
	}
	return 0;
}
/*
1 0
4 3 1 1
001
010
000
000

*/
