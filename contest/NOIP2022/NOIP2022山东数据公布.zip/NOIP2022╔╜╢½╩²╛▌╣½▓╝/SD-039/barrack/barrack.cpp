#include <bits/stdc++.h>
using namespace std;

int main() {

	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);

	int n,m;
	cin>>n>>m;
	while(m--) {
		int u,v;
		cin>>u>>v;
	}
	cout<<1<<endl;

	return 0;
}
