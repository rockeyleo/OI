#include <bits/stdc++.h>
using namespace std;

#define MAXN 2000006
int arr[MAXN];
int n,m,k;
list<int>q1,q2;

int main() {

	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);

	int T;
	cin>>T;
	while(T--) {
		cin>>n>>m>>k;
		cout<<m<<endl;
		//for:n = 2 and k = 3
		for(int i=1; i<=m; i++) {
			int a,b;
			cin>>a>>b;
			if(!q1.empty() && q2.empty()) {
				while(q1.front() == q2.front()) {
					cout<<2<<" "<<1<<" "<<2;
					q1.pop_front(),q2.pop_front();
				}
			}
			q1.push_back(a);
			if(a==b) {
				q1.pop_back();
				cout<<1<<" "<<1<<endl;
			} else q2.push_back(b);
		}
	}
	return 0;
}
