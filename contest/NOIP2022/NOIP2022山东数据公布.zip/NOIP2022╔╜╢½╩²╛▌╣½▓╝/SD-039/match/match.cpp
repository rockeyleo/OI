#include <bits/stdc++.h>
using namespace std;

#define MAXN 250005
long long T,n,arr[MAXN],brr[MAXN],Q,l,r;

int main() {

	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);

	cin>>T>>n;
	for(int i=1; i<=n; i++) cin>>arr[i];
	for(int i=1; i<=n; i++) cin>>brr[i];
	cin>>Q;
	while(Q--) {
		long long ans = 0;
		cin>>l>>r;
		for(int i=l; i<=r; i++)
			for(int j=i; j<=r; j++) {
				long long maxa = -2147483647;
				long long maxb = -2147483647;
				for(int k=i; k<=j; k++) {
					maxa=max(maxa,arr[k]);
					maxb=max(maxb,brr[k]);
				}
				ans+=maxa*maxb;
			}
		cout<<ans<<endl;
	}
	return 0;
}
/*
0 2
2 1
1 2
1
1 2
*/
