#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int t,n,m,k,cut;
queue <int> chu;
queue <int> a;
queue <int> b;
queue <int> c;
struct node{
	int num1,num2;
}q[100010];
 void dfs()
{
	if((!chu.empty())&&(!a.empty())&&(!b.empty()))
	return ;
		if(!a.empty()&&a.back()!=chu.front())
		{
			cut++;
			int x=chu.front();
			b.push(x);
			chu.pop();
			q[cut].num1 = 1,q[cut].num2 =2;
			
		}
		if(!b.empty()&&b.back()!=chu.front())
		{   cut++;
			int x=chu.front();
			a.push(x);
			chu.pop();
			q[cut].num1 = 1,q[cut].num2 =1;
			
		}
		if(a.back()==chu.front())
		{   cut++;
			a.pop();
			chu.pop();
			q[cut].num1 = 1,q[cut].num2 =1;
			
		}
		if(b.back()==chu.front())
		{   cut++;
			b.pop();
			chu.pop();
			q[cut].num1 = 1,q[cut].num2 =2;
			
		}
		/*
		if(a.back()==b.back())
		{
			cout<<2<<" "<<1<<" "<<2<<endl;
			a.pop();
			b.pop(); 
			cut++;
		}
		*/

}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++)
		{
			int x;
			cin>>x;
			chu.push(x);
		}
		if(n==2)
		{
			int x;
			x=chu.front();
			a.push(x);
			chu.pop();
			cut=1;
			q[cut].num1 = 1,q[cut].num2 =1;
			dfs();
			cout<<cut<<endl;
			for(int i=1;i<=cut;i++)
			{
				cout<<q[i].num1<<" "<<q[i].num2<<endl;
			}
		}
	}
	return 0;
}
