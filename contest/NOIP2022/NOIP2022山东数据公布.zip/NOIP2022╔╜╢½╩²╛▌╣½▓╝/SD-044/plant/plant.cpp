#include<bits/stdc++.h>
using namespace std;
int n,m,c,f,id,vc,vf;
int t,a[500][500];
int ix[500],iy[500];
int dx[]= {-1,1};
int dy[]= {-1,1};
int cnt,cntx,cnty,cut;
bool v=1;
bool vis[500][500];
void dfs1(int x,int y,int n) {
	for(int i=0; i<2; i++) {
		int tx=x+dx[i];
		if(a[tx][y]==0&&tx>0&&tx<=n&&(!vis[tx][y])) {
			cntx++;
			vis[tx][y]=1;
			dfs1(tx,y,n++);
		}
	}
}
void dfs2(int x,int y,int n) {
	for(int i=0; i<2; i++) {
		int ty=y+dy[i];
		if(a[x][ty]==0&&ty>0&&ty<=n&&(!vis[x][ty])) {
			cnty++;
			vis[x][ty]=1;
			dfs2(x,ty,n++);
		}
	}
}
void dfs(int x,int y,int n) {
	dfs1(x,y,n);
	if(cntx<2) return ;
	dfs2(x,y,n);
	if(cnty<3) return ;

}
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--) {
		if(id==1) {
			cout<<0<<" "<<0<<endl;
		}
		if(id==2) {
			cin>>n>>m>>c>>f;
			v=1;
			cut=0;
			for(int i=1; i<=3; i++)
				for(int j=1; j<=2; j++) {
					cin>>a[i][j];
					if(a[i][j]==1) cut++;
					if (a[i][j]==1&&(i==1||i==3)) {
						cout<<0<<" "<<0<<endl;
						v=0;
					}
				}
			if(cut>1&&v) {
				cout<<0<<" "<<0<<endl;
				v=0;
			} else if(cut==1&&v) {
				cout<<1<<" "<<0<<endl;
				v=0;
			} else if(cut==0&&v) {
				cout<<2<<" "<<0<<endl;
				v=0;
			}
		}
	}
	return 0;
}


