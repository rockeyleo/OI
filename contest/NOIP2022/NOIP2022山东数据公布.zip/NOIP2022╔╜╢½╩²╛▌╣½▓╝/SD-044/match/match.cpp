#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cout<<8;
	return 0;
}
