#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int t,n,m,k;
long long a[100000];
long long dfs(long long i)
{

	a[i]=a[i-1]*2+1;
	return dfs(i-1);
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
    a[2]=5;
    a[3]=11;
    for(int i=3;i<=n;i++)
    {
    	a[i]=a[i-1]*2+1;
	}
	cout<<a[n];
	return 0;	
}
	
	
