#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=5e5+5;
int T,n,m,K;
deque<int>  q[305];
struct node
{
	int op,s1,s2;
};
node ans[N];
inline int read()
{
	int s=0,w=1;char ch=getchar();
	while(ch<'0'||ch>'9')
	{if(ch=='-') w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')
	{s=s*10+ch-'0';ch=getchar();}
	return s*w;
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read(),m=read(),K=read();
//		if(n==2)
//		{
//			return 0;
//		}
		for(int i=1;i<=n;++i)
			while(!q[i].empty())  q[i].pop_back();
		int Ans=0;
		for(int i=1;i<=m;++i)
		{
//			cout<<i<<"  "<<q[n-1].front();
			int flag=0;
			int x=read();
			for(int k=1;k<=n-1;++k)
			{
				if(!q[k].empty()&&q[k].front()==x)
				{
					Ans++;
					q[k].pop_front();
					ans[Ans].op=1;
					if(k==n-1&&n!=2)  ans[Ans].s1=1;
					else if(k==n-1&&n==2)  ans[Ans].s1=2;
 					else ans[Ans].s1=k+1;
					flag=1;
					break;
				}
			}
			if(flag)  continue;
			for(int k=1;k<=n-1;++k)
			{
				if(q[k].empty())
				{
					Ans++;
					ans[Ans].op=1;
					ans[Ans].s1=k;
					q[k].push_front(x);
					flag=1;
					break;
				}
			}
			if(flag)  continue;
//			cout<<q[n-1].back()<<endl;
			if(!q[n-1].empty()&&x==q[n-1].back())
			{
				Ans++;
				ans[Ans].op=1;
				ans[Ans].s1=n;
				Ans++;
				ans[Ans].op=2;
				ans[Ans].s1=n-1,ans[Ans].s2=n;
				q[n-1].pop_back();
				flag=1;
			}
			if(flag)  continue;
			if(!flag)  Ans++,ans[Ans].op=1,ans[Ans].s1=n-1,q[n-1].push_front(x);
		}
		printf("%d\n",Ans);
		for(int i=1;i<=Ans;++i)
		{
			if(ans[i].op==1)  printf("1 %d\n",ans[i].s1);
			else printf("2 %d %d\n",ans[i].s1,ans[i].s2);
		}
//		if(K==2*n-2)
//		{
//			printf("%d\n",3*K-n);
//			for(int i=1;i<=m;++i)
//			{
//				int x=read(),flag=0;
//				for(int i=1;i<=n;++i)
//				{
//					if(!q[i].empty()&&q[i].front()==x)
//					{
//						printf("1 %d\n",i+1);
//						flag=1;
//						break;
//					}
//				}
//				if(flag)  continue;
//				for(int i=1;i<=n;++i)
//				{
//					if(!q[i].empty())  q[i].push_front(x);
//					flag=1;
//					break;
//				}
//				if(flag)  continue;
//			}
//		}
	}
	return 0;
}
/*
2
3 10 5
1 2 3 4 5 2 3 4 5 1
2 4 2
1 2 1 2
*/
