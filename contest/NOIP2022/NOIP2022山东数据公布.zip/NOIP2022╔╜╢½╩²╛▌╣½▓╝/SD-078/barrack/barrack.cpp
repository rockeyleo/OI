#include<bits/stdc++.h>
using namespace std;
const int Mod=1e9+7;
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(time(0));
	cout<<rand()%Mod;
	return 0;
}
