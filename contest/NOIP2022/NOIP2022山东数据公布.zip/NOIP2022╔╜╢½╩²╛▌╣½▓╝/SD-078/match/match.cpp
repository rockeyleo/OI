#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
const int N=3e5+5;
const int INF=0x3f3f3f3f;
int a[N],b[N];
int T,n,q;
inline int read()
{
	int s=0,w=1;char ch=getchar();
	while(ch<'0'||ch>'9')
	{if(ch=='-') w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')
	{s=s*10+ch-'0';ch=getchar();}
	return s*w;
}
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read(),n=read();
	for(int i=1;i<=n;++i)  a[i]=read();
	for(int i=1;i<=n;++i)  b[i]=read();
	q=read();
	while(q--)
	{
		ull Ans=0;
		int l=read(),r=read();
		for(int i=l;i<=r;++i)
			for(int j=i;j<=r;++j)
			{
				int max1=0,max2=0;
				for(int o=i;o<=j;++o)  max1=max(max1,a[o]),max2=max(max2,b[o]);
				Ans+=max1*max2;
			}
		printf("%llu\n",Ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
