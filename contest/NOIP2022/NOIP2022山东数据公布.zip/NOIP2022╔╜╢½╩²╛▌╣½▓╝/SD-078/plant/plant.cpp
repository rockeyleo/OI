#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e3+5;
const int Mod=998244353;
ll T,id,n,m,c,f,Ans1,Ans2;
char s[N][N];
ll ff[N][N];
inline int read()
{
	int s=0,w=1;char ch=getchar();
	while(ch<'0'||ch>'9')
	{if(ch=='-') w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')
	{s=s*10+ch-'0';ch=getchar();}
	return s*w;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read(),id=read();
	while(T--)
	{
		n=read(),m=read(),c=read(),f=read();
		Ans1=0,Ans2=0;
		for(int i=1;i<=n;++i)	scanf("%s",s[i]+1);
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=m;++j)
			{
				int cnt=0,flag=0;
				for(int k=j;k<=m;++k)
				{
					if(s[i][k]=='0')  cnt++;
					else 
					{
						ff[i][j]=cnt,cnt=0,flag=1;
						break;
					}
				}
				if(flag==0)  ff[i][j]=cnt;
			}
		}
		if(c!=0)
		{
			for(int i=1;i<=n;++i)
			{
				for(int j=1;j<=m;++j)
				{
					if(ff[i][j]<=1)  continue;
					int F=0;
					for(int k=i+1;k<=n;++k)
					{
						if(ff[k][j]==0)  break;
						else if(!F&&ff[k][j]>=1)  F=1;
						else if(ff[k][j]>1&&F)  (Ans1+=(1ll*(ff[i][j]-1)*(ff[k][j]-1))%Mod)%=Mod;
					}
				}
			}
		}
		if(f!=0)
		{
			for(int i=1;i<=n;++i)
			{
				for(int j=1;j<=n;++j)
				{
					if(ff[i][j]<=1)  continue;
					int F=0,flag=0,pos=0;
					for(int k=i+1;k<=n;++k)
					{
						if(ff[k][j]==0)  break;
						else if(ff[k][j]>=1&&!F)  F++;
						else if(F>=1&&!flag&&ff[k][j]>1)  pos=k,F++,flag=1;
						else if(flag&&F>=2&&ff[k][j]>=1)  (Ans2+=(1ll*(ff[i][j]-1)*(ff[pos][j]-1))%Mod)%=Mod;
					}
				}
			}
		}
		printf("%lld %lld\n",Ans1*c,Ans2*f);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
