#include<bits/stdc++.h>
//#define int long long
using namespace std;
int read(){int x=0,y=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')y=-y;ch=getchar();}while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*y;}
const int N=1e5+7;//ע�����ݷ�Χ
const int mod=1e9+7;

int n,m,cnt,head[N],cntn,cntm,ans;
bool vis[N];

struct node{
	int u,v,nex;
}t[N];

void add(int u,int v)
{
	t[++cnt].u=u;
	t[cnt].v=v;
	t[cnt].nex=head[u];
}

//void dfs(int s)
//{
//	
//	vis[s]=true;
//	for(int i=head[s];i;i=t[i].nex)
//	{
//		int v=t[i].v;
//		if(vis[v]) continue;
//		
//	}
//}

signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(time(NULL));
	n=read();m=read();
	int jl=0;
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		if(!(u==v+1||u==v-1)) jl=1;
		add(u,v);
		add(v,u);
	}
	if(n==m+1)
	{
		if(!jl)
		{
			long long ans=0;
			for(int i=1;i<=n;i++)
			{
				ans+=i*i;
				ans%=mod;
			}
			cout<<ans<<endl;
		}
	}
	else 
	{
		cout<<rand()*rand()<<endl;
	}
//	dfs(0);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
long long
e��
����
sysmet("fc .out .out")
srand(time(NULL));    �������
*/

