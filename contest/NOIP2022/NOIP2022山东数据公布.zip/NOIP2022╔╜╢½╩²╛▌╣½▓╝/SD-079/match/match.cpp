#include<bits/stdc++.h>
#define int long long
using namespace std;
int read(){int x=0,y=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')y=-y;ch=getchar();}while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*y;}
const int N=1e5+7;//ע�����ݷ�Χ
const int mod=1e9+7;

int T,n,Q,a[N][23],b[N][23],lg[N];



signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();n=read();
	
	lg[0]=-1;
	for(int i=1;i<=n;i++) a[i][0]=read(),lg[i]=lg[i>>1]+1;lg[n]=lg[n>>1]+1;
	for(int i=1;i<=n;i++) b[i][0]=read();
//	for(int j=1;j<=21;j++)
//		for(int i=1;i+(1<<j)+1<=n;i++)
//		{
////			printf("i=%d,j=%d\n",i,j);
//			a[i][j]=max(a[i][j-1],a[i+(1<<(j-1))][j-1]);
//			b[i][j]=max(b[i][j-1],b[i+(1<<(j-1))][j-1]);
//		}
	Q=read();
//	if(!T) puts("8");
	while(Q--)
	{
		int i=read(),j=read();
		int tot=0;
		for(int l=i;l<=j;l++)
		{
			for(int r=i;r<=j;r++)
			{
				int mx1=0,mx2=0;
				for(int p=l;p<=r;p++)
				{
					mx1=max(a[p][0],mx1);
					mx2=max(b[p][0],mx2);
				}
				tot+=mx1*mx2;
			}
		}
		cout<<tot<<endl;
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
long long
e��
����
sysmet("fc .out .out")
srand(time(NULL));    �������
*/
/*
0 2
2 1
1 2
1
1 2
*/
