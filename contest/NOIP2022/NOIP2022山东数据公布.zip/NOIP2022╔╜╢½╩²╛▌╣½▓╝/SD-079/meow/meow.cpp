#include<bits/stdc++.h>
//#define int long long
using namespace std;
int read(){int x=0,y=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')y=-y;ch=getchar();}while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*y;}
const int N=7e5+7;//ע�����ݷ�Χ
const int mod=1e9+7;

int T,n,m,k,a[N],tot;
int zhan[301][N/100],cnt[302];


signed main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
srand(time(NULL));
	T=read();
	while(T--)
	{
		n=read();
		m=read();
		k=read();
		for(int i=1;i<=m;i++) a[i]=read();
		int l1=1,l2=1,jl=1;
		if(n==2||k==2)
		{
			printf("%d\n",m);
			for(int i=1;i<=m;i++)
			{
				if(i==1){zhan[1][l1++]=a[i];puts("1 1");continue;}
				if(zhan[1][l1-1]==a[i])
				{
//					printf("l1=%d\n",l1);
					l1--;
					puts("1 1"); continue;
				}
				if(l1==1)
				{
					zhan[1][l1++]=a[i];
					puts("1 1");
					continue;
				}
				else
				{
					zhan[2][l2++]=a[i];
					puts("1 2");
				}
			}
		}
		cout<<rand()<<endl; 
		for(int i=1;i<=n;i++)
		{
			int p=rand();
			if(p&1) printf("1 %d\n",rand());
			else printf("2 %d %d\n",rand(),rand());
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
long long
e��
����
sysmet("fc .out .out")
srand(time(NULL));    �������
*/
/*
1
2 6 3
1 2 2 3 3 1
*/
