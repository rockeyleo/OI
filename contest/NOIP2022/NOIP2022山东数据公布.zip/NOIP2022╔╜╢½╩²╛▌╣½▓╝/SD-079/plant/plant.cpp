#include<bits/stdc++.h>
//#define lc k<<1
//#define rc k<<1|1
//#define int long long
using namespace std;
int read(){int x=0,y=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')y=-y;ch=getchar();}while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*y;}
const int N=1e5+7;//ע�����ݷ�Χ
const int mod=998244353;

int T,n,m,c,f,id,pd3[1003],mapp[1002][1002];
long long C,F;

void dfsC(int x,int y)
{
	if(mapp[x][y]) return;
	int pd1=0,pd2=0,jl0=0;
	for(int i=y+1;i<=m;i++)
	{
		if(mapp[x][i]) break;
		pd1++;
	}
	if(!pd1) return;
	
	for(int i=x+1;i<=n;i++)
	{
		if(mapp[i][y]) break;
		pd2++;
		for(int j=y+1;j<=m;j++)
		{
			if(mapp[i][j]) break;
			pd3[i]++;
		}
	}
	pd2--;
	int op=0;
	for(int i=x+2;i<=x+pd2+1;i++)
	{
		op+=pd3[i];
		op%=mod;
		pd3[i]=0;
	}
	int ipp=C;
	C=(C+1ll*pd1*op)%mod;
	return;
}

void dfsF(int x,int y)
{
	if(mapp[x][y]) return;
	int pd1=0,pd2=0,pd4=0;
	for(int i=y+1;i<=m;i++)
	{
		if(mapp[x][i]) break;
		pd1++;
	}
	if(!pd1||mapp[x+3][y]) return;
	for(int i=x+1;i<=n;i++)
	{
		if(mapp[i][y]) break;
		pd2++;
		for(int j=y+1;j<=m;j++)
		{
			if(mapp[i][j]) break;
			pd3[i]++;
		}
	}
	if(!pd2) return;
	pd2--;
	int op=0;
	for(int i=x+2;i<=x+pd2+1;i++)
	{
		op+=pd3[i]*(x+pd2+1-i)%mod;
		pd3[i]=0;
	}
	op*=pd1%mod; op%=mod;
	F+=1ll*op; F%=mod;
	return;
}

signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read();id=read();
	while(T--)
	{
		n=read();m=read();c=read();f=read();
		C=0,F=0;
		for(int i=1;i<=n;i++)
		{
			string s;
			cin>>s;
			for(int j=0;j<s.size();j++)
				mapp[i][j+1]=s[j]-'0';
		}
		if(!c&&!f)
		{
			puts("0");
			continue;
		}
		for(int i=1;i<n /**/;i++)
		{
			for(int j=1;j<m-1 /**/;j++)
			{
				if(c) dfsC(i,j);
				if(f) dfsF(i,j);
			}
		}
		printf("%lld %lld\n",C*c,F*f);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

/*
long long
e��
����
sysmet("fc .out .out")
srand(time(NULL));    �������
*/
/*
1 0
4 3 1 1
001
010
000
000
*/
/*
c
*/


