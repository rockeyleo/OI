#include <iostream>
#include <deque>
#include <vector>
using namespace std ;
const int INF = 1e9 + 7 ; 	const int maxn = 2e6 + 7 ;
int read()
{
	int res = 0 , f = 1 ;
	char ch = getchar() ;
	while(ch < '0' || ch > '9' )
	{
		if(ch == '-')	f = -1 ;
		ch = getchar() ;
	}
	while(ch >= '0' && ch <= '9' )
	{
		res = res * 10 + ch - '0' ;
		ch = getchar() ;
	}
	return res * f;
}
struct node 
{
	int op , l , r ; 
} ; 
int t , n , m , cnt , ncnt , k ; 
int a[maxn] , id[620] ;
bool pd ; 
deque<int > q[310] ; 
vector<node > ans ; 
void clr()
{
	cnt = 0 , ncnt = 0 , pd = false ; 
	ans.clear() ; 
	for(int i = 1 ; i <= min(cnt + 1 , k) ; i++ )
		q[i].clear() ; 
	for(int i = 1 ; i <= k ; i++ )
		id[i] = 0 ; 
}
signed main()
{
	freopen("meow.in" , "r" , stdin ) ; 
	freopen("meow.out" , "w" , stdout ) ; 
	t = read() ; 
	while( t-- )
	{
		clr() ; 
		n = read() , m = read() , k = read() ; 
		for(int i = 1 ; i <= m ; i++ )
		{
			a[i] = read() ; 
	//	cout << id[a[i]] << ' ' ; 
			if(! id[a[i]] )
			{
		//	cout << i << ' ' ; 
				if(! pd )
				{
					id[a[i]] = ++cnt ; 
			//	cout << i << ' ' ; 
					q[cnt].push_back(a[i] ) ; 
					ans.push_back({1 , cnt , -1} ) ;// 1 << ' ' << cnt << '\n' ; 
				//	ans += 1 ; 
				}
				else 
				{
					id[a[i]] = ++ncnt ; 
					q[ncnt].push_back(a[i] ) ;
					ans.push_back({1 , ncnt , -1} ) ;//cout << 1 << ' ' << ncnt << '\n' ; 
					//ans += 1 ;
				}
			}
			else 
			{
		//	cout << i << '\n' ; 
				int nid = id[a[i]] ; 
				if(a[i] == q[nid].front() )	
				{
					ans.push_back({1 , cnt + 1 , -1} ) ;
					ans.push_back({2 , nid , cnt + 1} ) ;
					//cout << 1 << ' ' << cnt + 1 << '\n' ; 
					//cout << 2 << ' ' << nid << ' ' << cnt + 1 << '\n'  ; 
					q[nid].pop_front() ; 
					//ans += 2 ; 
				}
				else if(a[i] == q[nid].back() )
				{
					ans.push_back({1 , nid , -1} ) ;
					//cout << 1 << ' ' << nid << '\n' ; 
					q[nid].pop_back() ;
					//ans += 1 ; 
				}
				else 
				{
					ans.push_back({1 , nid} ) ;
					//cout << 1 << ' ' << nid << '\n' ; 
					q[nid].push_back(a[i] ) ; 
					//ans += 1 ; 
				}
			}
			if(cnt == n - 1 )	ncnt = 0 , pd = true ; 
		}
		
		cout << ans.size() << '\n' ; 
		for(auto i : ans )
		{
			cout << i.op << ' ' << i.l ;
			if(i.r > 0 )	cout << ' '<< i.r ;
			puts("") ; 
		}
		
	}
}
/*
1
2 4 2
1 2 1 2
*/
