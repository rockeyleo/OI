#include <iostream>
#include <vector>
#define pii pair<int , int > 
#define x first
#define y second 
using namespace std ;
const int INF = 1e9 + 7 ; 	const int maxn = 1e3 + 7 ;	const int Mod = 998244353 ;
int read()
{
	int res = 0 , f = 1 ;
	char ch = getchar() ;
	while(ch < '0' || ch > '9' )
	{
		if(ch == '-')	f = -1 ;
		ch = getchar() ;
	}
	while(ch >= '0' && ch <= '9' )
	{
		res = res * 10 + ch - '0' ;
		ch = getchar() ;
	}
	return res * f;
}
int t , n , m , id , ans , res , c ,f ; 
int sumh[1100][1100] , suml[1100][1100] , mp[1100][1100] , sum[1100][1100] ; 
vector<pii > q[1100] ; 
int now[maxn] ; 
signed main()
{
	freopen("plant.in" , "r" , stdin ) ;
	freopen("plant.out" , "w" , stdout ) ; 
	t = read() , id = read() ;   
	while( t-- )
	{
		res = 0 , ans = 0 ; 
		for(int i = 1 ; i <= n + 1 ; i++ )
			for(int j = 1 ; j <= m + 1 ; j++ )
				sum[i][j] = suml[i][j] = sumh[i][j] = 0 ;
		n = read() , m = read() , c = read() , f = read() ;  
		for(int i = 1 ; i <= n ; i++ ) 
		{
			for(int j = 1 ; j <= m ; j++ )
			{
				scanf("%1d" , &mp[i][j] ) ;
				mp[i][j] ^= 1 ;
			}
		}
		for(int j = 1 ; j <= m ; j++ )
		{
			for(int i = n ; i >= 1 ; i-- )
			{
				if(mp[i][j] == 0 )	continue ; 
				suml[i][j] = suml[i + 1][j] + mp[i][j] ; 
			}
		}
		for(int i = 1 ; i <= n ; i++ )
			for(int j = m ; j >= 1 ; j-- )
			{
				if(mp[i][j] == 0 )	continue ; 
				sumh[i][j] = sumh[i][j + 1] + mp[i][j] ; 
			}
		for(int j = 1 ; j <= m ; j++ )
		{
			for(int i = n ; i >= 1 ; i-- )
			{
				if(suml[i][j] >= 3 && sumh[i][j] > 1 )	q[j].push_back({i , suml[i][j]} ) ; 
				sum[i][j] = max(sumh[i][j] - 1 , 0) + sum[i + 1][j] ;
			}
		}
		for(int j = 1 ; j <= m ; j++ )
		{
			while(q[j].size() )
			{
				auto i = q[j].back() ;  q[j].pop_back() ; 
				int l = i.x , r = i.x + i.y ; 
				int now = sum[l][j] - sum[r][j] ; 
				ans = (ans + (max(now - sumh[l][j] + 1 , 0) * max(sumh[l][j] - 1 , 0)) % Mod) % Mod ;  
				if(i.y > 3 )
				{
					r-- ; 
					//if(r == n )	continue ;
					now = sum[l][j] - sum[r][j] ; 
					res = (res + (max(now - sumh[l][j] + 1 , 0) * max(sumh[l][j] - 1 , 0)) % Mod) % Mod ; 
				}
			}
		}
		cout << (ans * c) % Mod << ' ' << (res * f) % Mod << '\n' ; 
	}
}
/*
1 0
6 6 1 1
000010
011000
000110
010000
011000
000000

*/
/*
41 6 
*/
/*
114 109
*/
