#include <iostream>

using namespace std ;
const int INF = 1e9 + 7 ; 	const int maxn = 1e5 + 7 ;
int read()
{
	int res = 0 , f = 1 ;
	char ch = getchar() ;
	while(ch < '0' || ch > '9' )
	{
		if(ch == '-')	f = -1 ;
		ch = getchar() ;
	}
	while(ch >= '0' && ch <= '9' )
	{
		res = res * 10 + ch - '0' ;
		ch = getchar() ;
	}
	return res * f;
}
int ksm(int x , int y )
{
	int res = 1 ; 
	while( y )
	{
		if(y & 1 )	res *= x ; 
		x *= x ; 
		y >>= 1 ; 
	}
	return res ; 
}
int n , m ; 
signed main()
{ 
	freopen("barrack.in" , "r" , stdin ) ; 
	freopen("barrack.out" , "w" , stdout ) ; 
	n = read() , m = read() ; 
	cout << ksm(m , n ) ; 
}

