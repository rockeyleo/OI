#include<iostream>
#include<queue>
#include<cstdio>

using namespace std;
const int N=305;

struct que{
	int a[N],top,last;
}p[N];

int n,m,k,T;
int b[N];
int l[N],e;
pair<int,int>o[N];

void print()
{
	for(int i=1;i<=m;i++)if(o[i].first)e++;
	e+=m;
	printf("%d\n",e);
	for(int i=1;i<=m;i++)
	{
		printf("1 %d\n",l[i]);
		if(o[i].first)
		printf("2 %d %d\n",o[i].first,o[i].second);
	}
	return ;
}

bool dfs(int u)
{
	if(u>m)
	{
		bool flag=true;
		for(int i=1;i<=n;i++)
		{
			if(p[i].top>p[i].last)
			{
				flag=false;
				break;
			}
		}
		if(flag)
		{
		print();
		return true;
		}
		return false;
	}
	for(int i=1;i<=n;i++)
	{
		l[u]=i;
		p[i].a[++p[i].top]=b[u];
		if(p[i].top==1)
		{
			p[i].last=1;
			for(int j=1;j<i;j++)
			{
				if(p[i].a[p[i].last]==p[j].a[p[j].last])
				{
					p[j].last++;
					p[i].last++;
					o[u].first=i;
					o[u].second=j;
					if(dfs(u+1)==true)return true;
					p[j].last--;
					p[i].last--;
					o[u].first=0;
					break;
				}
			}
			if(dfs(u+1)==true)return true;
			p[i].top--;
		}
		else if(p[i].a[p[i].top-1]==p[i].a[p[i].top])
		{
			p[i].top-=2;
			if(dfs(u+1))return true;
			p[i].top+=2;
			p[i].top--;
		}
		else
		{
			if(dfs(u+1))return true;
			p[i].top--;
		}
	}
	return false;
}

int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	scanf("%d",&T);
	
	while(T--)
	{
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
		
		dfs(1);
	}
	
	return 0;
}
