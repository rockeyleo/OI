#include<iostream>
#include<cstdio>

using namespace std;
const int N=1e3+10,mod=998244353;

int num,cv,f,C,F,c[N][N],d[N];
int n,m,ans,mar,T,id;
char b[N][N];
int p[N],st[N],top;

int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	
	scanf("%d%d",&T,&id);
	while(T--)
	{
	scanf("%d%d%d%d",&n,&m,&cv,&f);
	
	for(int i=1;i<=n;i++) 
	{
		scanf("%s",b[i]+1);
	}
	
	if(c==0&&f==0)
	{
		printf("0 0");
		continue;
	}
	
	for(int i=1;i<=n;i++)
	{
		mar=m+1;
		for(int j=m;j>=1;j--)
		{
			num=0;
			if(b[i][j]=='1')
			{
				mar=j;
				d[j]=i;
				c[i][j]=mar-j-1;
				continue;
			}
			
			c[i][j]=mar-j-1;
			for(int k=d[j]+1;k<i-1;k++)
			{
				if(c[k][j]>0)
				{
					num+=c[k][j];
				}
			}
			C=(C+num*c[i][j])%mod;
			
			for(int k=i+1;k<=n;k++)
			{
				if(b[k][j]=='1')
				break;
				else
				{
				F=(F+num*c[i][j])%mod;
			   }
			}	
		}
	}
		printf("%d %d",cv*C,f*F);
	}		
}


