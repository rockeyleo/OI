#include<iostream>
#include<cstdio>

using namespace std;
const int N=2.5e5+10;

int f[N][21],n,m,b[N][21];
long long logs[N],ans;
int T,Q;

int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	
	scanf("%d%d",&T,&n);
	
	for(int i=1;i<=n;i++)
	scanf("%d",&f[i][0]);
	
	for(int i=1;i<=n;i++)
	scanf("%d",&b[i][0]);
	
	for(int i=2;i<=n;i++)
	logs[i]=logs[i/2]+1;
	
	for(int j=1;j<=21;j++)
	for(int i=1;i+(1<<j)-1<=n;i++)
	{
		f[i][j]=max(f[i][j-1],f[i+(1<<(j-1))][j-1]);
		b[i][j]=max(b[i][j-1],b[i+(1<<(j-1))][j-1]);
	}
	
	scanf("%d",&Q);
	
	for(int i=1;i<=Q;i++)
	{
		int L,R;
		scanf("%d%d",&L,&R);
		for(int l=L;l<=R;l++)
		{
			for(int r=R;r>=l;r--)
			{	
				int k=logs[r-l+1];
				int an=max(f[l][k],f[r-(1<<k)+1][k]);
				int an2=max(b[l][k],b[r-(1<<k)+1][k]);
				ans=(ans+(long long)an*(long long)an2);
			}
		}
		printf("%lld\n",ans);
	}	
	
	return 0;
}
