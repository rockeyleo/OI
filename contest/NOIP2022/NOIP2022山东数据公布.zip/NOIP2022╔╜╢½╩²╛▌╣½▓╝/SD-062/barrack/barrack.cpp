#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<deque>
#include<map>
#include<iomanip>
#include<cstdlib>
using namespace std;
int n,m,u,v,l;
int mod=1000000007; 
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	  cin>>u>>v;
	l=((n*2)%mod+((1<<n)-1-n)%mod)%mod;
	cout<<l<<endl;
	return 0;
}
