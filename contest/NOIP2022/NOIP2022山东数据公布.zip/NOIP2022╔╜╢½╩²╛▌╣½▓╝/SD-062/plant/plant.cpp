#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<deque>
#include<map>
#include<iomanip>
#include<cstdlib>
using namespace std;
int n,m,c,f,t,id,sc,sf;
char a[1010][1010];
const int mod=998244353;
//map<string,bool> p;
bool pd(int x,int y,int z,int q)//1��0�� 
{
	if(q)
	{
		for(int i=x;i<=y;i++)
		  if(a[i][z]=='1')
		    return 0;
		return 1;
	}
	for(int i=x;i<=y;i++)
	  if(a[z][i]=='1')
	    return 0;
	return 1;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	for(int o=1;o<=t;o++)
	{
		cin>>n>>m>>c>>f;
		sc=0;
		sf=0;
		int xq=0,yq=0;
		if(c==0&&f==0)
		{
			cout<<"0 0"<<endl;
			continue;
		}
		for(int i=1;i<=n;i++)
		  for(int j=1;j<=m;j++)
		    cin>>a[i][j];
		for(int i=1;i<n-1;i++)
			for(int j=1;j<m;j++)
				if(a[i][j]=='0')
				{
					xq=i;
					yq=j;
					for(int i1=yq+1;i1<=m;i1++)
						if(pd(yq,i1,xq,0))
							for(int j1=xq+2;j1<=n;j1++)
								if(pd(xq,j1,yq,1))
									for(int w1=yq+1;w1<=m;w1++)
										if(pd(yq,w1,j1,0))
											sc=(sc+1)%mod;
					if(i<n-2)
					{
						for(int i2=yq+1;i2<=m;i2++)
						  if(pd(yq,i2,xq,0))
						    for(int j2=xq+3;j2<=n;j2++)
						      if(pd(xq,j2,yq,1))
						        for(int e=xq+2;e<j2;e++)
						        	for(int w2=yq+1;w2<=m;w2++)
						        	  if(pd(yq,w2,e,0))
						        	    sf=(sf+1)%mod;
					}
				}
		cout<<sc%mod<<" "<<sf%mod<<endl;
	}
	return 0;
}
