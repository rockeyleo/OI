#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<deque>
#include<map>
#include<iomanip>
#include<cstdlib>
using namespace std;
long long t,n,a[3010],b[3010],q,l[3010],r[3010];
long long s,maxn;
//const long long mod=4294967296*4294967296;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(long long i=1;i<=n;i++)
	  cin>>a[i];
	for(long long i=1;i<=n;i++)
	  cin>>b[i];
	cin>>q;
	for(long long o=1;o<=q;o++)
	{
		cin>>l[o]>>r[o];
		s=0;
		for(long long i=l[o];i<=r[o];i++)
			for(long long j=i;j<=r[o];j++)
			{
				maxn=0;
				for(long long p=i;p<=j;p++)
					for(long long q=i;q<=j;q++)
						maxn=max(maxn,(long long)a[p]*b[q]);
				s+=maxn;
			}
		cout<<s<<endl;
	}
	return 0;
}
