#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<deque>
#include<map>
#include<iomanip>
#include<cstdlib>
using namespace std;
int n,op,t,m,k,a,s;
deque<int> d1,d2;
struct node
{
	int es,s1,s2;
}st[100010];
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	for(int o=1;o<=t;o++)
	{
		s=0;
		d1.clear();
		d2.clear();
		cin>>n>>m>>k;
		for(int q=1;q<=m;q++)
		{
			cin>>a;
			if(a!=d1.front()||q==1)
			{
				d1.push_back(a);
				st[++s].es=1;
				st[s].s1=1;
			}
			else
			{
				st[++s].es=1;
				st[s].s1=2;
				st[++s].es=2;
				st[s].s1=1;
				st[s].s2=2;
				d1.pop_back();
			}
		}
		cout<<s<<endl;
		for(int i=1;i<=s;i++)
			if(st[i].es==1)
			  cout<<"1 "<<st[i].s1<<endl;
			else
			  cout<<"2 "<<st[i].s1<<" "<<st[i].s2<<endl;
	}
	return 0;
}
