#include<bits/stdc++.h>
#define int long long
#define ll long long
#define re register
#define il inline
const int N = 1e3 + 5;
const int mod = 998244353;
using namespace std;
il int max(int a,int b) { return a > b ? a : b; }
il int min(int a,int b) { return a < b ? a : b; }

int lx[N][N],ly[N][N],sumlx[N][N],sumly[N][N]; int a[N][N];
int T,id;
int n,m,c,f,valc,valf,sum,cnt;

il int read()
{
	int f=0,s=0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f |= (ch=='-');
	for(;isdigit(ch);ch=getchar()) s = (s<<1) + (s<<3) + (ch^48);
	return f ? -s : s;
}

il void get_c()//70pts 
{
	for(re int i=1;i<=n;i++)//������ 
		for(re int j=1;j<=m;j++)//�� 	
		{
			if(a[i][j] == 1 || a[i+1][j] == 1) continue;
			//if(a[i+1][j] == 1) break;
			//cout << "(" << i << "," << j << ")" << " " << "(" << k << "," << j << ")" << endl;
			if(sumlx[i+2][j] == 0) continue;
			valc = ((valc%mod) + ((lx[i][j]-1)*(sumlx[i+2][j])%mod)) % mod; 
		}
}

il void get_f()
{
	for(re int i=1;i<=n;i++)//������ 
		for(re int j=1;j<=m;j++)//�� 	
		{
			if(a[i][j] == 1 || a[i+1][j] == 1) continue;
			//if(a[i+1][j] == 1) break;
			//cout << "(" << i << "," << j << ")" << " " << "(" << k << "," << j << ")" << endl;
			if(sumly[i+2][j] == 0) continue;
			valf = ((valf%mod) + ((lx[i][j]-1)*(sumly[i+2][j])%mod)) % mod; 
		}
}

il void Main()
{
	memset(lx , 0 , sizeof lx);
	memset(ly , 0 , sizeof ly);
	memset(sumlx , 0 , sizeof sumlx);
	memset(sumly , 0 , sizeof sumly);
	memset(a , 0 , sizeof a);
	n = read() , m = read() , c = read() , f = read();
	valc = 0 , valf = 0;
	for(re int i=1;i<=n;i++)
		for(re int j=1;j<=m;j++)
			scanf("%1lld",&a[i][j]);
	for(re int i=1;i<=n;i++)
	{
		sum = 0;
		for(re int j=m;j>=1;j--)
		{
			if(a[i][j] == 1) sum = 0;
			else lx[i][j] = ++sum;
		}
	}
	for(re int j=1;j<=m;j++)
		for(re int i=n;i>=1;i--)
		{
			if(a[i][j] == 1) sumlx[i][j] = 0;
			else sumlx[i][j] = sumlx[i+1][j] + lx[i][j] - 1;
		}
	for(re int j=1;j<=m;j++)
	{
		sum = 0;
		for(re int i=n;i>=1;i--)
		{
			if(a[i][j] == 1) sum = 0;
			else ly[i][j] = ++sum;
		}
	}
	for(re int i=1;i<=n;i++)
		for(re int j=m;j>=1;j--)
		{
			if(a[i][j] == 1) sumly[i][j] = 0;
			else sumly[i][j] = (ly[i][j]-1) * (lx[i][j]-1);
		}
	/*for(re int i=1;i<=n;i++)
	{
		for(re int j=1;j<=m;j++)
			cout << sumlx[i][j] << " ";
		cout << "\n";
	}*/
	if(c) get_c(); if(f) get_f();
	//cout << valc;
	cout << (valc*c) % mod << " " << (valf*f) % mod << "\n";
}

signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T = read() , id = read();
	while(T--) Main();
	return 0;
}
