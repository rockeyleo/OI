#include<bits/stdc++.h>
#define int unsigned long long
#define re register
#define il inline
const int N = 3e3 + 5;
using namespace std;
il int max(int a,int b) { return a > b ? a : b; }
il int min(int a,int b) { return a < b ? a : b; }

int Maxa[N][20],Maxb[N][20],qz[N][N],ans;
int a[N],b[N],lg[N];
int T,n,q,l,r,ma,mb;

il int read()
{
	int f=0,s=0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f |= (ch=='-');
	for(;isdigit(ch);ch=getchar()) s = (s<<1) + (s<<3) + (ch^48);
	return f ? -s : s;
}

il void init()
{
	for(re int j=1;j<=20;j++)
		for(re int i=1;i+(1<<j)-1<=n;i++)
		{
			Maxa[i][j] = max(Maxa[i][j-1],Maxa[i+(1<<(j-1))][j-1]);
			Maxb[i][j] = max(Maxb[i][j-1],Maxb[i+(1<<(j-1))][j-1]);
		}
}

signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T = read(); n = read();
	for(re int i=1;i<=n;i++) a[i] = read() , Maxa[i][0] = a[i];
	for(re int i=1;i<=n;i++) b[i] = read() , Maxb[i][0] = b[i];
	lg[1] = 0;
	for(re int i=2;i<=n;i++) lg[i] = lg[i>>1] + 1;
	init();
	for(re int len=1;len<=n;len++)
		for(re int i=1;i+len-1<=n;i++)
		{
			l = i , r = i+len-1;
			ma = max(Maxa[l][lg[len]],Maxa[r-(1<<lg[len])+1][lg[len]]);
			mb = max(Maxb[l][lg[len]],Maxb[r-(1<<lg[len])+1][lg[len]]);
			qz[l][r] = ma * mb;
		}
	q = read();
	while(q--)
	{
		int ll = read() , rr = read();
		ans = 0;
		for(re int len=1;len<=rr-ll+1;len++)
			for(re int i=ll;i+len-1<=rr;i++)
			{
				l = i , r = i+len-1;
				ans += qz[l][r];
			}
		cout << ans << "\n";
	}
	return 0;
}

