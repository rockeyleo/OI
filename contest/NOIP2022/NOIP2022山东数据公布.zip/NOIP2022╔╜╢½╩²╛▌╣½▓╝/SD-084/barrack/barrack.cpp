#include<bits/stdc++.h>
#define int long long
#define ll long long
#define re register
#define il inline
const int N = 1e2 + 5;
const int M = 1e3 + 5;
const int mod = 1e9 + 7;
using namespace std;
il int max(int a,int b) { return a > b ? a : b; }
il int min(int a,int b) { return a < b ? a : b; }

int fa[N],p[N],u[N],v[N];
bool vis[N],flag;
int n,m,ans;

il int read()
{
	int f=0,s=0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f |= (ch=='-');
	for(;isdigit(ch);ch=getchar()) s = (s<<1) + (s<<3) + (ch^48);
	return f ? -s : s;
}

il int find(int x) { return fa[x] = fa[x] == x ? x : find(fa[x]); }

il void check(int cnt)
{
	if(cnt == 1) { ans++; return ; } 
	for(re int i=1;i<=n;i++) fa[i] = i;
	for(re int i=1;i<=m;i++)
	{
		if(!vis[i]) continue;
		fa[find(v[i])] = find(u[i]);
	}
	flag = 1;
	for(re int i=1;i<=cnt-1;i++) if(find(p[i]) != find(p[i+1])) { flag = 0; break; } 
	if(flag == 1)
	{
		ans++;
		/*for(re int i=1;i<=cnt;i++) cout << p[i] << " ";
		cout << endl;
		for(re int i=1;i<=m;i++) cout << vis[i] << " ";
		cout << endl << endl;*/
	}
}

il void dfs2(int id,int cnt)
{
	if(id == m+1)
	{
		check(cnt);
		return ;
	}
	vis[id] = 1; dfs2(id+1,cnt);
	vis[id] = 0; dfs2(id+1,cnt);
}

il void dfs1(int id,int cnt)
{
	if(id == n+1)
	{
		if(cnt == 0) return ;
		dfs2(1,cnt);
		//for(re int i=1;i<=cnt;i++) cout << p[i] << " ";
		//cout << endl; 
		return ;
	}
	p[++cnt] = id; dfs1(id+1,cnt);
	cnt--; dfs1(id+1,cnt);
}

signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n = read() , m = read();
	for(re int i=1;i<=m;i++) u[i] = read() , v[i] = read();
	dfs1(1,0);
	cout << ans;
	return 0;
}

