#include<bits/stdc++.h>
//#define int long long
#define ll long long
#define re register
#define il inline
const int N = 1e3 + 5;
const int M = 2e6 + 5;
using namespace std;
il int max(int a,int b) { return a > b ? a : b; }
il int min(int a,int b) { return a < b ? a : b; }

int T,n,m,k,cnt;
int col[M];
deque <int> q[3];
struct node{
	int op,s1,s2;
}; vector <node> v;

il int read()
{
	int f=0,s=0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f |= (ch=='-');
	for(;isdigit(ch);ch=getchar()) s = (s<<1) + (s<<3) + (ch^48);
	return f ? -s : s;
}

il void Main()
{
	n = read() , m = read() , k = read();
	q[1].clear() , q[2].clear() , v.clear();
	memset(col , 0 , sizeof col); 
	for(re int i=1;i<=m;i++) col[i] = read();
	for(re int i=1;i<=m;i++)
	{
		if(q[1].empty()) q[1].push_back(col[i]) , v.push_back((node){1,1,0});
		else
		{
			if(q[1].size() == 1 && col[i] == q[1].front()) v.push_back((node){1,1,0}) , q[1].pop_back();
			else if(q[2].size() == 1 && col[i] == q[2].front()) v.push_back((node){1,2,0}) , q[2].pop_back();
			else if(q[2].empty() && q[1].front() == col[i]) v.push_back((node){1,2,0}) , v.push_back((node){2,1,2}) , q[1].pop_front();
			else if(col[i] == 1 || col[i] == 2) v.push_back((node){1,1,0}) , q[1].push_back(col[i]);
			else v.push_back((node){1,2,0}) , q[2].push_back(col[i]); 
		}
	}
	cout << v.size() << "\n";
	for(re int i=0;i<(int)v.size();i++)
	{
		cout << v[i].op << " ";
		if(v[i].op == 1) cout << v[i].s1 << "\n";
		else cout << v[i].s1 << " " << v[i].s2 << "\n";
	}
}

signed main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T = read();
	while(T--) Main();
	return 0;
}

