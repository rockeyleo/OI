#include <iostream>
#include <vector>
#include <set>
using namespace std ;

int read ( ) {
	char ch = getchar ( ) ;
	int x = 0 ;
	while ( ch < '0' || ch > '9' )
		ch = getchar ( ) ;
	while ( ch >= '0' && ch <= '9' )
		x = x * 10 + ch - 48 , ch = getchar ( ) ;
	return x ;
}

namespace gzh {

const int N = 2000005 ;
int n , m , k , emp , cnt , s1 , s2 , a[N] , id[N] , vis[N] , f1[N] , f2[N] , br[N] ;
set < int > sr1 , sr2 ;
vector < int > vb ;

void cler ( ) {
	sr1 .clear ( ) ;
	sr2 .clear ( ) ;
	cnt = 0 ;
}

struct Ans {
	int op , d1 , d2 ;
	Ans ( int _o = 0 , int _u = 0 , int _v = 0 ) :
		op ( _o ) , d1 ( _u ) , d2 ( _v ) { }
} ans[N] , res[N] ;

void mains ( ) {
	int T ;
	cin >> T ;
//cout << T << "\n" ;
	while ( T -- ) {
		cler ( ) ;
		n = read ( ) , m = read ( ) , k = read ( ) ;
		for ( int i = 1 ; i <= m ; ++ i )
			a [ i ] = read ( ) ;
		
//cout << n << " " << m << ' ' << k << '\n' ;
//for ( int i = 1 ; i <= m ; ++ i ) cout << a [ i ] << ' ' ; puts ( "" ) ;
		
		for ( int i = 1 ; i < n ; ++ i )
			sr1 .insert ( i ) , sr2 .insert ( i ) ;
		emp = n ;
		for ( int i = 1 ; i <= m ; ++ i ) {
			int u = a [ i ] ;
//			cout << "\n I : " << i << " , " << a [ i ] << " , cnt : " << cnt << " ss : " << s1 << " , " << s2 << " , emp : " << emp << "\n" ;
//			cout << "  id : " ;
//			for ( int j = 1 ; j <= k ; ++ j ) cout << id [ j ] << "  " ; puts ( "" ) ;
//			cout << " vis : " ;
//			for ( int j = 1 ; j <= k ; ++ j ) cout << vis [ j ] << "  " ; puts ( "" ) ;
			
			if ( vis [ u ] ) {
//				puts ( " Case A : " ) ;
				if ( vis [ u ] == 2 ) {
					ans [ ++ cnt ] = Ans ( 1 , emp , 0 ) ;
					ans [ ++ cnt ] = Ans ( 2 , emp , id [ u ] ) ;
//					cout << " !! Ans 1 : " << emp << "\n" ;
//					cout << " !! Ans 2 : " << emp << " , " << id [ u ] << "\n" ;
					f2 [ id [ u ] ] = f1 [ id [ u ] ] ;
					if ( f1 [ id [ u ] ] ) sr1 .insert ( id [ u ] ) , -- s1 ;
					f1 [ id [ u ] ] = 0 ;
					if ( ! f2 [ id [ u ] ] ) sr2 .insert ( id [ u ] ) , -- s2 ;
					vis [ f2 [ id [ u ] ] ] = 2 ;
					id [ u ] = vis [ u ] = 0 ;
				}
				else {
					ans [ ++ cnt ] = Ans ( 1 , id [ u ] , 0 ) ;
//					cout << " @@ Ans 1 : " << id [ u ] << "\n" ;
					sr1 .insert ( id [ u ] ) , -- s1 ;
					f1 [ id [ u ] ] = 0 ;
					id [ u ] = vis [ u ] = 0 ;
				}
				continue ;
			}
//			puts ( " Case B : " ) ;
			if ( s2 < n - 1 ) {
				int x = *sr2 .begin ( ) ;
				sr2 .erase ( x ) ;
				++ s2 ;
				f2 [ x ] = u ;
				id [ u ] = x ;
				vis [ u ] = 2 ;
				ans [ ++ cnt ] = Ans ( 1 , x , 0 ) ;
//				cout << " ! Ans 1 : " << x << "\n" ;
				continue ;
			}
			if ( s1 < n - 1 ) {
				int x = *sr1 .begin ( ) ;
				sr1 .erase ( x ) ;
				++ s1 ;
				f1 [ x ] = u ;
				id [ u ] = x ;
				vis [ u ] = 1 ;
				ans [ ++ cnt ] = Ans ( 1 , x , 0 ) ;
//				cout << " @ Ans 1 : " << x << "\n" ;
				continue ;
			}
			int ct = 0 , j = 0 ;
			int ep = emp , ep1 = ep ;
			for ( j = i + 1 ; j <= m ; ++ j ) {
				int v = a [ j ] ;
//				cout << " J : " << j << " : " << v << "\n" ;
//				cout << "  id : " ;
//				for ( int kk = 1 ; kk <= k ; ++ kk ) cout << id [ kk ] << " " ;
//				puts ( "" ) ;
//				cout << " vis : " ;
//				for ( int kk = 1 ; kk <= k ; ++ kk ) cout << vis [ kk ] << " " ;
//				puts ( "" ) ;
				if ( vis [ v ] == 1 ) {
					br [ id [ v ] ] = 1 ;
					vb .push_back ( id [ v ] ) ;
					res [ ++ ct ] = Ans ( 1 , id [ v ] , 0 ) ;
					sr1 .insert ( id [ v ] ) , -- s1 ;
					f1 [ id [ v ] ] = 0 ;
					id [ v ] = vis [ v ] = 0 ;
					continue ;
				}
				if ( vis [ v ] == 2 ) {
					if ( ! f1 [ id [ v ] ] ) {
						res [ ++ ct ] = Ans ( 1 , id [ v ] , 0 ) ;
						ans [ ++ cnt ] = Ans ( 1 , ep , 0 ) ;
//						cout << " # Ans 1 : " << emp << "\n" ;
						++ s2 ;
						f2 [ ep ] = u ;
						id [ u ] = ep ;
						vis [ u ] = 2 ;
						
						if ( sr1 .find ( id [ v ] ) != sr1 .end ( ) ) sr1 .erase ( id [ v ] ) ;
						sr1 .insert ( ep ) ;
						
						ep = id [ v ] ;
						-- s2 ;
						id [ v ] = vis [ v ] = 0 ;
						break ;
					}
					else if ( ! br [ id [ v ] ] ) {
						ans [ ++ cnt ] = Ans ( 1 , id [ v ] , 0 ) ;
//						cout << " ------- $ Ans 1 : " << id [ v ] << "\n" ;
						res [ ++ ct ] = Ans ( 1 , ep , 0 ) ;
						res [ ++ ct ] = Ans ( 2 , ep , id [ v ] ) ;
						int y = id [ v ] ;
						f2 [ y ] = f1 [ y ] , f1 [ y ] = u ;
						vis [ f2 [ y ] ] = 2 ;
						id [ u ] = y ;
						vis [ u ] = 1 ;
						id [ v ] = vis [ v ] = 0 ;
						break ;
					}
					else {
						res [ ++ ct ] = Ans ( 1 , emp , 0 ) ;
						res [ ++ ct ] = Ans ( 2 , emp , id [ v ] ) ;
//						cout << " & Ans 1 : " << emp << "\n" ;
//						cout << " & Ans 2 : " << emp << " , " << id [ v ] << "\n" ;
						f2 [ id [ v ] ] = f1 [ id [ v ] ] ;
						if ( f1 [ id [ v ] ] ) sr1 .insert ( id [ v ] ) , -- s1 ;
						f1 [ id [ v ] ] = 0 ;
						if ( ! f2 [ id [ v ] ] ) sr2 .insert ( id [ v ] ) , -- s2 ;
						vis [ f2 [ id [ v ] ] ] = 2 ;
						id [ v ] = vis [ v ] = 0 ;
						emp = id [ v ] ;
					}
				}
				if ( v == u ) {
					ans [ ++ cnt ] = Ans ( 1 , emp , 0 ) ;
//					cout << " % Ans 1 : " << emp << "\n" ;
					res [ ++ ct ] = Ans ( 1 , emp , 0 ) ;
					break ;
				}
				int x = *sr1 .begin ( ) ;
				sr1 .erase ( x ) ;
				++ s1 ;
				f1 [ x ] = v ;
				id [ v ] = x ;
				vis [ v ] = 1 ;
				res [ ++ ct ] = Ans ( 1 , x , 0 ) ;
//				cout << " res: " << v << " :: " << x << "\n" ;
				continue ;
			}
			for ( auto vv : vb ) br [ vv ] = 0 ;
			vb .clear ( ) ;
			i = j ;
			for ( int i = 1 ; i <= ct ; ++ i ) {
				ans [ ++ cnt ] = res [ i ] ;
				if ( ep1 != ep ) {
					if ( ans [ cnt ] .d1 == ep1 ) ans [ cnt ] .d1 = ep ;
					else if ( ans [ cnt ] .d1 == ep ) ans [ cnt ] .d1 = ep1 ;
					if ( ans [ cnt ] .d2 == ep1 ) ans [ cnt ] .d2 = ep ;
					else if ( ans [ cnt ] .d2 == ep ) ans [ cnt ] .d2 = ep1 ;
				}
//				if ( ans [ cnt ] .op == 1 )
//					cout << " * Ans 1 : " << ans [ cnt ] .d1 << "\n" ;
//				else
//					cout << " * Ans 2 : " << ans [ cnt ] .d1 << " , " << ans [ cnt ] .d2 << "\n" ;
			}
		}
		cout << cnt << '\n' ;
		for ( int i = 1 ; i <= cnt ; ++ i ) {
			if ( ans [ i ] .op == 1 )
				cout << ans [ i ] .op << ' ' << ans [ i ] .d1 << '\n' ;
			else
				cout << ans [ i ] .op << ' ' << ans [ i ] .d1 << ' ' << ans [ i ] .d2 << '\n' ;
		}
	}
}
} ;

int main ( ) {
//	freopen ( "data.in" , "r" , stdin ) ;
//	freopen ( "data.out" , "w" , stdout ) ;
	freopen ( "meow.in" , "r" , stdin ) ;
	freopen ( "meow.out" , "w" , stdout ) ;
	gzh :: mains ( ) ;
	return 0 ;
}
