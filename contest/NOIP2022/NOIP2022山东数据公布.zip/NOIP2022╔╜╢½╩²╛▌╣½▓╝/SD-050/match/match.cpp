#include <iostream>
#include <algorithm>
using namespace std ;

#define int unsigned long long
int read ( ) {
	char ch = getchar ( ) ;
	int x = 0 ;
	while ( ch < '0' || ch > '9' )
		ch = getchar ( ) ;
	while ( ch >= '0' && ch <= '9' )
		x = x * 10 + ch - 48 , ch = getchar ( ) ;
	return x ;
}

namespace gzh {

const int N = 250005 ;
int n , m , a[N] , b[N] , ff[N] , ans[N] ;

struct Qur {
	int l , r , id ;
} p[N] ;

bool cmp ( Qur a , Qur b ) {
	return a .r < b .r ;
}

void std1 ( ) {
	for ( int i = 1 ; i <= m ; ++ i ) {
		int l = read ( ) , r = read ( ) ;
		for ( int j = l ; j <= r ; ++ j ) {
//			int ma = a [ j ] , mb = b [ j ] , sum = 0 , res = 0 ;
		}
	}
}

void mains ( ) {
	int Td ;
	cin >> Td >> n ;
	for ( int i = 1 ; i <= n ; ++ i )
		a [ i ] = read ( ) ;
	for ( int i = 1 ; i <= n ; ++ i )
		b [ i ] = read ( ) ;
	m = read ( ) ;
//	if ( m <= 5 ) {
//		std1 ( ) ;
//		return 0 ;
//	}
	for ( int i = 1 ; i <= m ; ++ i )
		p [ i ] .l = read ( ) , p [ i ] .r = read ( ) , p [ i ] .id = i ;
	sort ( p + 1 , p + 1 + m , cmp ) ;
	int now = 1 ;
	for ( int i = 1 ; i <= n ; ++ i ) {
		int ma = a [ i ] , mb = b [ i ] , sum = 0 ;
		for ( int j = i ; j ; -- j ) {
			ma = max ( ma , a [ j ] ) ;
			mb = max ( mb , b [ j ] ) ;
			sum += ma * mb ;
			ff [ j ] += sum ;
		}
		while ( p [ now ] .r == i )
			ans [ p [ now ] .id ] = ff [ p [ now ] .l ] , ++ now ;
	}
	for ( int i = 1 ; i <= m ; ++ i )
		cout << ans [ i ] << "\n" ;
}
} ;

signed main ( ) {
	freopen ( "match.in" , "r" , stdin ) ;
	freopen ( "match.out" , "w" , stdout ) ;
	gzh :: mains ( ) ;
	return 0 ;
}

