#include <iostream>
using namespace std ;

#define int long long
int read ( ) {
	char ch = getchar ( ) ;
	int x = 0 ;
	while ( ch < '0' || ch > '9' )
		ch = getchar ( ) ;
	while ( ch >= '0' && ch <= '9' )
		x = x * 10 + ch - 48 , ch = getchar ( ) ;
	return x ;
}

namespace gzh {

const int N = 1005 , M = 998244353 ;
int n , m , cc , ff , f[N][N] , g[N][N] , ans1 , ans2 ;
char a[N] , b[N] ;

inline int ct ( int x ) { return x >= M ? x - M : x ; }

void mains ( ) {
	int T , Td ;
	cin >> T >> Td ;
	while ( T -- ) {
		n = read ( ) , m = read ( ) , cc = read ( ) , ff = read ( ) ;
		ans1 = ans2 = 0 ;
		for ( int i = 0 ; i <= n ; ++ i )
			for ( int j = 0 ; j <= m ; ++ j )
				f [ i ] [ j ] = g [ i ] [ j ] = 0 ;
		for ( int i = 1 ; i <= n ; ++ i ) {
			cin >> ( a + 1 ) ;
			int la = m + 1 ;
			for ( int j = m ; j ; -- j ) {
				if ( a [ j ] == '1' ) {
					la = j ;
					g [ i ] [ j ] = f [ i ] [ j ] = 0 ;
					continue ;
				}
				g [ i ] [ j ] = g [ i - 1 ] [ j ] ;
				ans2 = ct ( ans2 + g [ i ] [ j ] % M ) ;
				g [ i ] [ j ] = ct ( g [ i ] [ j ] + ( b [ j ] == '1' ? 0 : f [ i - 2 ] [ j ] * ( la - j - 1 ) % M ) ) ;
				f [ i ] [ j ] = f [ i - 1 ] [ j ] ;
				if ( b [ j ] == '0' )
					ans1 = ct ( ans1 + ( la - j - 1 ) * f [ i - 2 ] [ j ] % M ) ;
				f [ i ] [ j ] = ct ( f [ i ] [ j ] + ( la - j - 1 ) ) ;
			}
			for ( int j = 1 ; j <= m ; ++ j )
				b [ j ] = a [ j ] ;
		}
		cout << ans1 * cc % M << ' ' << ans2 * ff % M << '\n' ;
	}
}
} ;

signed main ( ) {
//	freopen ( "data.in" , "r" , stdin ) ;
	freopen ( "plant.in" , "r" , stdin ) ;
	freopen ( "plant.out" , "w" , stdout ) ;
	gzh :: mains ( ) ;
	return 0 ;
}

