#include <iostream>
#include <map>
using namespace std ;

#define int long long
int read ( ) {
	char ch = getchar ( ) ;
	int x = 0 ;
	while ( ch < '0' || ch > '9' )
		ch = getchar ( ) ;
	while ( ch >= '0' && ch <= '9' )
		x = x * 10 + ch - 48 , ch = getchar ( ) ;
	return x ;
}

namespace gzh {

const int N = 1000005 , M = 1e9 + 7 ;
#define fi first
#define se second
int n , m , tot , dfn[N] , low[N] , st[N] , dep , top , vis[N] , nt[N] , et[N] , clr[N] , f[N][2] , ans ;
pair < int , int > pt[N] ;
map < pair < int , int > , bool > mp ;

int qpow ( int x , int y ) {
	int res = 1 ;
	while ( y ) {
		if ( y & 1 ) res = res * x % M ;
		x = x * x % M ;
		y >>= 1 ;
	}
	return res ;
}

struct Edge {
	int nxt , to ;
} edge[N<<1] ;

int cnt = 1 , head[N] ;
void insert ( int u , int v ) {
	edge [ ++ cnt ] = { head [ u ] , v } ;
	head [ u ] = cnt ;
	edge [ ++ cnt ] = { head [ v ] , u } ;
	head [ v ] = cnt ;
}

void tarjan ( int x , int la ) {
	dfn [ x ] = low [ x ] = ++ dep ;
	st [ ++ top ] = x ;
	vis [ x ] = 1 ;
//	cout << " tarjan: " << x << " , " << la << "\n" ;
	for ( int i = head [ x ] ; i ; i = edge [ i ] .nxt ) {
		int y = edge [ i ] .to ;
		if ( ! dfn [ y ] ) {
			tarjan ( y , x ) ;
			low [ x ] = min ( low [ x ] , low [ y ] ) ;
			if ( low [ y ] > dfn [ x ] ) {
//				eis [ i ] = eis [ i ^ 1 ] = 1 ;
				int k = st [ top -- ] ;
				++ tot ;
//				cout << " tot : " << tot << " :: " ;
				while ( k != y ) {
					vis [ k ] = 0 ;
					clr [ k ] = tot ;
					++ nt [ tot ] ;
//					cout << k << " , " ;
					k = st [ top -- ] ;
				}
//				cout << k << "\n" ;
				vis [ y ] = 0 ;
				clr [ y ] = tot ;
				++ nt [ tot ] ;
			}
		}
		else if ( y != la )
			low [ x ] = min ( low [ x ] , dfn [ y ] ) ;
	}
}

inline int ct ( int x ) { return x >= M ? x - M : x ; }

void dfs ( int x , int la ) {
	f [ x ] [ 1 ] = ct ( M + qpow ( 2 , nt [ x ] ) - 1 ) * qpow ( 2 , et [ x ] ) % M ;
	f [ x ] [ 0 ] = qpow ( 2 , et [ x ] ) ;
//	cout << " f : " << x << " , " << la << " : " << f [ x ] [ 1 ] << " , " << f [ x ] [ 0 ] << "\n" ;
	for ( int i = head [ x ] ; i ; i = edge [ i ] .nxt ) {
		int y = edge [ i ] .to ;
		if ( y == la ) continue ;
		dfs ( y , x ) ;
		f [ x ] [ 1 ] = f [ x ] [ 1 ] * ct ( f [ y ] [ 0 ] * 2 + f [ y ] [ 1 ] ) % M ;
		f [ x ] [ 0 ] = f [ x ] [ 0 ] * ct ( f [ y ] [ 0 ] * 2 ) % M ;
	}
}

void dfs2 ( int x , int la , int val ) {
//	cout << " dfs2 : " << x << " , " << la << " , " << val << '\n' ;
//	cout << " F : " << f [ x ] [ 0 ] << " , " << f [ x ] [ 1 ] << "\n" ;
	ans = ct ( ans + f [ x ] [ 1 ] * val * 2 % M ) ;
	f [ x ] [ 0 ] = f [ x ] [ 0 ] * ct ( val * 2 ) % M ;
	for ( int i = head [ x ] ; i ; i = edge [ i ] .nxt ) {
		int y = edge [ i ] .to ;
		if ( y == la ) continue ;
//		cout << " qpow : " << ct ( f [ y ] [ 0 ] * 2 ) << " , " << qpow ( ct ( f [ y ] [ 0 ] * 2 ) , M - 2 ) << "\n" ;
		dfs2 ( y , x , f [ x ] [ 0 ] * qpow ( ct ( f [ y ] [ 0 ] * 2 ) , M - 2 ) % M ) ;
	}
}

void mains ( ) {
	cin >> n >> m ;
	for ( int i = 1 ; i <= m ; ++ i ) {
		int u = read ( ) , v = read ( ) ;
		pt [ i ] = { u , v } ;
		insert ( u , v ) ;
	}
	tarjan ( 1 , 0 ) ;
	int k = st [ top -- ] ;
	++ tot ;
//	cout << " tot : " << tot << " :: " ;
	while ( k != 1 ) {
		vis [ k ] = 0 ;
		clr [ k ] = tot ;
		++ nt [ tot ] ;
//		cout << k << " , " ;
		k = st [ top -- ] ;
	}
//	cout << k << "\n" ;
	vis [ 1 ] = 0 ;
	clr [ 1 ] = tot ;
	++ nt [ tot ] ;
	
	cnt = 1 ;
	for ( int i = 1 ; i <= n ; ++ i ) head [ i ] = 0 ;
	for ( int i = 1 ; i <= m ; ++ i ) {
		int u = pt [ i ] .fi , v = pt [ i ] .se ;
		if ( clr [ u ] == clr [ v ] ) {
			++ et [ clr [ u ] ] ;
			continue ;
		}
		if ( mp .find ( { clr [ u ] , clr [ v ] } ) != mp .end ( ) ) continue ;
		mp [ { clr [ u ] , clr [ v ] } ] = mp [ { clr [ v ] , clr [ u ] } ] = 1 ;
		insert ( clr [ u ] , clr [ v ] ) ;
//		cout << " insert : " << clr [ u ] << " , " << clr [ v ] << "\n" ;
	}
	dfs ( 1 , 0 ) ;
//	for ( int i = 1 ; i <= tot ; ++ i )
//		cout << f [ i ] [ 0 ] << " , " << f [ i ] [ 1 ] << "\n" ;
	dfs2 ( 1 , 0 , qpow ( 2 , M - 2 ) ) ;
	cout << ans << "\n" ;
}
} ;

signed main ( ) {
	freopen ( "barrack.in" , "r" , stdin ) ;
	freopen ( "barrack.out" , "w" , stdout ) ;
	gzh :: mains ( ) ;
	return 0 ;
}
