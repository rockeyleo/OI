#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
using namespace std;
inline int read()
{
	int s=0,w=1;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-')
		w=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		s=(s<<1)+(s<<3)+(c^48);
		c=getchar();
	}
	return s*w;
}
const int MAXN=11223;
unsigned long long st1[MAXN][20],st2[MAXN][20],ans;
int n,T,in1[MAXN],in2[MAXN];
int loog(int po)
{
	int k=1,t=0;
	while(k<=po)
	{
		++t;
		k<<=1;
	}
	if(k/2==po)
	return t-1;
	else
	return t;
}
void make_st1()
{
	for(int i=1;i<=n;++i)
		st1[i][0]=in1[i];
	
	for(int j=1;j<=loog(n)-1;++j)
		for(int i=1;i<=n-(j<<1)+1;++i)
			st1[i][j]=max(st1[i][j-1],st1[i+(1<<(j-1))][j-1]);
}
int getmax1(int l,int r)
{
	int len=r-l+1;
	if(len==1)
	return st1[l][0];
	else
	return max(st1[l][loog(len)-1],st1[r-(1<<(loog(len)-1))+1][loog(len)-1]);
}
void make_st2()
{
	for(int i=1;i<=n;++i)
		st2[i][0]=in2[i];
	
	for(int j=1;j<=loog(n)-1;++j)
		for(int i=1;i<=n-(j<<1)+1;++i)
			st2[i][j]=max(st2[i][j-1],st2[i+(1<<(j-1))][j-1]);
}
int getmax2(int l,int r)
{
	int len=r-l+1;
	if(len==1)
	return st2[l][0];
	else
	return max(st2[l][loog(len)-1],st2[r-(1<<(loog(len)-1))+1][loog(len)-1]);
}
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read(),n=read();
	for(int i=1;i<=n;++i)
	{
		in1[i]=read();
	}
	for(int i=1;i<=n;++i)
	{
		in2[i]=read();
	}
	make_st1();
	make_st2();
	int q=read();
	for(int i=1;i<=q;++i)
	{
		int l=read(),r=read();
		for(int i=l;i<=r;++i)
		{
			for(int j=i;j<=r;++j)
			{
				ans=(ans+(getmax1(i,j)*getmax2(i,j)));
			}
		}
		cout<<ans;
		printf("\n");
		ans=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
