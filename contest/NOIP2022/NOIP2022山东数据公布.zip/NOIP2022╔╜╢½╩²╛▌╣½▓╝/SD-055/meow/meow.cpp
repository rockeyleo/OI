#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
inline int read()
{
	int s=0,w=1;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-')
		w=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		s=(s<<1)+(s<<3)+(c^48);
		c=getchar();
	}
	return s*w;
}
int main()
{
	freopen("meow.out","w",stdout);
	printf("I like OI.Thanke you!See you!\n");
	fclose(stdout);
	return 0;
}

