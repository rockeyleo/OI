#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
inline int read()
{
	int s=0,w=1;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-')
		w=-1;
		c=getchar();
	}
	if(isdigit(c))
	return c^48;
}
const int MAXN=1223,MAXM=1001223;
struct node{
	int x,y;
}point[MAXM];
long long n,m,c,f,mapp[MAXN][MAXN],H[MAXN][MAXN],L[MAXN][MAXN],tot,ansf=0,ansc=0;
int T,id;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read();
	id=read();
	for(int likecjw=1;likecjw<=T;++likecjw)
	{
		scanf("%lld %lld %lld %lld",&n,&m,&c,&f);
		if(c==0&&f==0)
		{
			printf("0 0\n");
			continue;
		}
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=m;++j)
			{
				mapp[i][j]=read();
			}
		}
		for(int i=n;i>=1;--i)
		{
			for(int j=m;j>=1;--j)
			{
				if(mapp[i][j]==0)
				{
					H[i][j]=H[i][j+1]+1;
					L[i][j]=L[i+1][j]+1;
				}
				else
				{
					H[i][j]=0;
					L[i][j]=0;
				}
			}
		}
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=m;++j)
			{
				if(H[i][j]>=2&&L[i][j]>=3)
				{
					node p;
					p.x=i;
					p.y=j;
					point[++tot]=p;
				}
			}
		}
		for(int i=1;i<=tot;++i)
		{
			int x=point[i].x,y=point[i].y,h=H[x][y]-1;
			for(int j=x+2;j<=x+L[x][y]-1;++j)
			{
				int k=h*(H[j][y]-1);
				ansc=(ansc+k)%998244353;
				if(L[j][y]>1)
				ansf=(ansf+k*(L[j][y]-1))%998244353;
			}
		}
		printf("%lld %lld\n",c*ansc,f*ansf);
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				mapp[i][j]=H[i][j]=L[i][j]=0;
		n=m=c=f=ansc=ansf=tot=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

