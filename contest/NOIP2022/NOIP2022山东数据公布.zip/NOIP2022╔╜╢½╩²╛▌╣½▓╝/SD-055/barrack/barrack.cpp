#include<iostream>
#include<cstdio>
#include<cstring>
#define int long long
using namespace std;
inline int read()
{
	int s=0,w=1;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-')
		w=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		s=(s<<1)+(s<<3)+(c^48);
		c=getchar();
	}
	return s*w;
}
const int MAXN=201223,MOD=1000000007;
long long bow(long long x,long long k)
{
	long long ans=1;
	while(k!=0)
	{
		if(k&1)
		ans=(ans*x)%MOD;
		x=(x*x)%MOD;
		k>>=1;
	}
	return ans;
}
int n,m;
signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(),m=read();
	printf("%lld",(((n*(n+3)/2)%MOD)*bow(2,n-2))%MOD);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

