#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;

const int N = 1005;
const int M = 998244353;
int n, m, c, f;
char g[N][N];
int ans_c = 0, ans_f = 0;

int dfs_c (int x, int y, int limit) {
	// limit = 0 -> ��ʼ�� 
	// limit = 1 -> ����������
	// limit = 2 -> ����߹���
	
	if (limit == 0) {
		int heng = 0, shu = 0;
		int yy = y + 1;
		if (g[x][yy] == '0') heng = dfs_c (x, yy, 2);
		int xx = x + 2;
		if (g[x+1][y] == '0' && g[xx][y] == '0') shu = dfs_c (xx, y, 1);
		return heng * shu;
	}
	
	if (limit == 2) {
		int yy = y + 1;
		if (g[x][yy] == '0') return dfs_c (x, yy, 2) + 1;
		else return 1;
	}
	
	if (limit == 1) {
		int xx = x + 1;
		int yy = y + 1;
		int h = 0, s = 0;
		if (g[x][yy] == '0') h = dfs_c (x, yy, 2);
		if (g[xx][y] == '0') s = dfs_c (xx, y, 1);
		return h + s;
	}
}

int dfs_f (int x, int y, int limit) {
	// limit = 0 -> ��ʼ�� 
	// limit = 1 -> ����������
	// limit = 2 -> ����߹���
	// limit = 3 -> ��������һ���м��� 
	
	if (limit == 0) {
		int heng = 0, shu = 0;
		int yy = y + 1;
		if (g[x][yy] == '0') heng = dfs_f (x, yy, 2);
		int xx = x + 2;
		if (g[x+1][y] == '0' && g[xx][y] == '0') shu = dfs_f (xx, y, 1);
		return heng * shu;
	}
	
	if (limit == 2) {
		int yy = y + 1;
		if (g[x][yy] == '0') return dfs_f (x, yy, 2) + 1;
		else return 1;
	}
	
	if (limit == 1) {
		int xx = x + 1;
		int yy = y + 1;
		int h = 0, s = 0;
		if (g[x][yy] == '0') h = dfs_f (x, yy, 2);
		if (g[xx][y] == '0') s = dfs_f (xx, y, 3);
		return h * s;
	}
	
	if (limit == 3) {
		int xx = x + 1;
		if (g[xx][y] == '0') {
			return dfs_f (xx, y, 3) + 1;
		}
		else return 1;
	}
}

int main () {
	freopen ("plant.in", "r", stdin);
	freopen ("plant.out", "w", stdout);
	int T, id;
	scanf ("%d%d", &T, &id);
	while (T --) {
		memset (g, -1, sizeof g);
		ans_c = 0, ans_f = 0;
		scanf ("%d%d%d%d", &n, &m, &c, &f);
		for (int i = 1; i <= n; i ++) {
			for (int j = 1; j <= m; j ++) {
				cin >> g[i][j];
			}
		}
		
		if (id == 1) {
			puts("0 0");
			return 0;
		}
		
		for (int i = 1; i <= n; i ++) {
			for (int j = 1; j <= m; j ++) {
				if (g[i][j] == '0') {
					ans_c += dfs_c (i, j, 0) % M;
					ans_f += dfs_f (i, j, 0) % M;
					ans_c %= M, ans_f %= M;
				}
			}
		}
		if (id == 15) printf ("%d 0\n", (ans_c * c) % M);
		else printf ("%d %d\n", (ans_c * c) % M, (ans_f * f) %M);
	}
	return 0;
}
