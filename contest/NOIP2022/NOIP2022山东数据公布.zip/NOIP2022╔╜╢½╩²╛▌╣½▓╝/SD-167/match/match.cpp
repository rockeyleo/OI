#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;

struct node {
	int l, r;
	int maxx;
};

const int N = 250005;

node a[N * 4], b[N * 4];
int T, n, Q;
int A[N], B[N];

void pushup (int p) {
	a[p].maxx = max (a[p << 1].maxx, a[p << 1 | 1].maxx);
	b[p].maxx = max (b[p << 1].maxx, b[p << 1 | 1].maxx);
}

void build (int l, int r, int p) {
	a[p].l = l, a[p].r = r;
	b[p].l = l, b[p].r = r;
	if (l == r) {
		a[p].maxx = A[l];
		b[p].maxx = B[l];
		return;
	}
	int mid = (l + r) >> 1;
	build (l, mid, p << 1);
	build (mid + 1, r, p << 1 | 1);
	a[p].maxx = max (a[p << 1].maxx, a[p << 1 | 1].maxx);
	b[p].maxx = max (b[p << 1].maxx, b[p << 1 | 1].maxx);
}

ll query_a (int l, int r, int p) {
	if (a[p].l >= l && a[p].r <= r) return a[p].maxx;
	int mid = (a[p].l + a[p].r) >> 1;
	ll res = 0;
	if (l <= mid) res = query_a (l, r, p << 1);
	if (r > mid) res = max (res, query_a (l, r, p << 1 | 1));
	return res;
}

ll query_b (int l, int r, int p) {
	if (b[p].l >= l && b[p].r <= r) return b[p].maxx;
	int mid = (b[p].l + b[p].r) >> 1;
	ll res = 0;
	if (l <= mid) res = query_b (l, r, p << 1);
	if (r > mid) res = max (res, query_b (l, r, p << 1 | 1));
	return res;
}

int main () {
	freopen ("match.in", "r", stdin);
	freopen ("match.out", "w", stdout);
	scanf ("%d%d", &T, &n);
	for (int i = 1; i <= n; i ++) {
		scanf ("%d", &A[i]);
	}
	for (int i = 1; i <= n; i ++) {
		scanf ("%d", &B[i]);
	}
	build (1, n, 1);
	scanf ("%d", &Q);
	while (Q --) {
		int l, r;
		scanf ("%d%d", &l, &r);
		ll sum = 0;
		for (int i = l; i <= r; i ++) {
			for (int j = i; j <= r; j ++) {
				sum += query_a (i, j, 1) * query_b (i, j, 1);
			}
		}
		printf ("%lld\n", sum);
	}
	return 0;
}
