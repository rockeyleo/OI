#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <deque>
using namespace std;
typedef long long ll;

const int N = 2000005;
int s[N][3];
int idx = 0;
int n, m, k;
int a[N];
bool f[N];

int main () {
	freopen ("meow.in", "r", stdin);
	freopen ("meow.out", "w", stdout);
	int T;
	scanf ("%d", &T);
	for (int o = 1; o <= T; o ++) {
		scanf ("%d%d%d", &n, &m, &k);
		idx = 0;
		if (T % 10 == 2) {
			deque<int> q1, q2;
			memset (f, 0, sizeof f);
			for (int i = 1; i <= m; i ++) {
				scanf ("%d", &a[i]);
				if (a[i - 2] == a[i]) {
					f[i - 1] = 1;
				}
			}
			
			for (int i = 1; i <= m; i ++) {
				if (q1.empty() && q2.empty()) {
					q1.push_back(a[i]);
					s[++ idx][0] = 1, s[idx][1] = 1;
					continue;
				}
				if (!q1.empty()) {
					if (q1.back() == a[i]) {
						q1.pop_back();
						s[++ idx][0] = 1, s[idx][1] = 1;
						continue;
					}
					if (q1.front() == a[i] && q2.empty()) {
						q1.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 2;
						s[++ idx][0] = 2, s[idx][1] = 1, s[idx][2] = 2;
						continue;
					}
				}
				if (!q2.empty()) {
					if (q2.back() == a[i]) {
						q2.pop_back();
						s[++ idx][0] = 1, s[idx][1] = 2;
						continue;
					}
					if (q2.front() == a[i] && q1.empty()) {
						q2.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 1;
						s[++ idx][0] = 2, s[idx][1] = 1, s[idx][2] = 2;
						continue;
					}
				}
				if (f[i] == 1) {
					q2.push_back(a[i]);
					s[++ idx][0] = 1, s[idx][1] = 2;
					continue;
				}
				else {
					q1.push_back(a[i]);
					s[++ idx][0] = 1, s[idx][1] = 1;
				}
			}
			printf ("%d\n", idx);
			for (int i = 1; i <= idx; i ++) {
				if (s[i][0] == 1) {
					printf ("%d %d\n", s[i][0], s[i][1]);
				}
				else printf ("%d %d %d\n", s[i][0], s[i][1], s[i][2]);
			}
		}
		if (T % 10 == 3 || T % 10 == 4) {
			deque<int> q1, q2, q3;
			for (int i = 1; i <= m; i ++) {
				scanf ("%d", &a[i]);
				if (a[i] == a[i - 2]){
					f[i - 1] = 1; 
				} 
				if (a[i] == a[i - 3]) {
					f[i - 1] = 1;
					f[i - 2] = 1;
				}
			}
			for (int i = 1; i <= m; i ++) {
				if (q1.empty() && q2.empty() && q3.empty()) {
					q1.push_back(a[i]);
					s[++ idx][0] = 1, s[idx][1] = 1;
					continue;
				}
				if (!q1.empty()) {
					if (q1.back() == a[i]) {
						q1.pop_back();
						s[++ idx][0] = 1, s[idx][1] = 1;
						continue;
					}
					if (q1.front() == a[i] && q2.empty()) {
						q1.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 2;
						s[++ idx][0] = 2, s[idx][1] = 1, s[idx][2] = 2;
						continue;
					}
					if (q1.front() == a[i] && q3.empty()) {
						q1.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 3;
						s[++ idx][0] = 2, s[idx][1] = 1, s[idx][2] = 3;
						continue;
					}
				}
				if (!q2.empty()) {
					if (q2.back() == a[i]) {
						q2.pop_back();
						s[++ idx][0] = 1, s[idx][1] = 2;
						continue;
					}
					if (q2.front() == a[i] && q1.empty()) {
						q2.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 1;
						s[++ idx][0] = 2, s[idx][1] = 1, s[idx][2] = 2;
						continue;
					}
					if (q2.front() == a[i] && q3.empty()) {
						q2.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 3;
						s[++ idx][0] = 2, s[idx][1] = 2, s[idx][2] = 3;
						continue;
					}
				}
				if (!q3.empty()) {
					if (q3.back() == a[i]) {
						q3.pop_back();
						s[++ idx][0] = 1, s[idx][1] = 3;
						continue;
					}
					if (q3.front() == a[i] && q1.empty()) {
						q3.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 1;
						s[++ idx][0] = 2, s[idx][1] = 1, s[idx][2] = 3;
						continue;
					}
					if (q3.front() == a[i] && q2.empty()) {
						q3.pop_front();
						s[++ idx][0] = 1, s[idx][1] = 2;
						s[++ idx][0] = 2, s[idx][1] = 2, s[idx][2] = 3;
						continue;
					}
				}
				if (f[i] == 1) {
					q2.push_back(a[i]);
					s[++ idx][0] = 1, s[idx][1] = 2;
				}
				else {
					q1.push_back(a[i]);
					s[++ idx][0] = 1, s[idx][1] = 1;
				}
			} 
			printf ("%d\n", idx);
			for (int i = 1; i <= idx; i ++) {
				if (s[i][0] == 1) {
					printf ("%d %d\n", s[i][0], s[i][1]);
				}
				else printf ("%d %d %d\n", s[i][0], s[i][1], s[i][2]);
			}
		}
	}
	return 0;
}
