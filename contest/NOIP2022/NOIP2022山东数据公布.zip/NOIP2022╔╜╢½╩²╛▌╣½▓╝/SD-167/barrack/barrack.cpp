#include <cstdio>
#include <iostream>
using namespace std;

int main () {
	freopen ("barrack.in", "r", stdin);
	freopen ("barrack.out", "w", stdout);
	puts("0");
	return 0;
}
