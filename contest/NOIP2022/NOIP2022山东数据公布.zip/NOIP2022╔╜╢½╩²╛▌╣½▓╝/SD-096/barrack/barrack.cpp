# include <bits/stdc++.h>
using namespace std;
const int D = 20;
const int mod = 1e9 + 7;
inline int read () {
	int x = 0, f = 1; char c = getchar ();
	while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar ();}
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar ();}
	return x * f;
}
int n, m, cnt;
int head[D];
bool vis[D], edg[D], pos[D];
struct edge {
	int nxt, to, id;
}line[D << 1];
void add (int u, int v, int id) {
	line[++ cnt].nxt = head[u];
	line[cnt].to = v;
	line[cnt].id = id;
	head[u] = cnt;
}
void dfs (int x, int l) {
	vis[x] = 1;
	for (int i = head[x]; i; i = line[i].nxt) {
		int y = line[i].to;
		if (line[i].id == l) continue;
		if (vis[y]) continue;
		dfs (y, l);
	}
}
int main () {
	freopen ("barrack.in","r",stdin);
	freopen ("barrack.out","w",stdout);
	n = read (), m = read ();
	for (int i = 1; i <= m; ++ i) {
		int x = read (), y = read ();
		add (x, y, i);
		add (y, x, i);
	}
	int ans = 0;
	for (int i = 1; i < (1 << n); ++ i) {
		for (int j = 0; j < (1 << m); ++ j) {
			memset (vis, 0, sizeof vis);
			memset (pos, 0, sizeof pos);
			memset (edg, 0, sizeof edg);
			int p;
			for (int k = 1; k <= n; ++ k) {
				if ((i >> (k - 1)) & 1) pos[k] = 1, p = k;
			}
			for (int k = 1; k <= m; ++ k) {
				if ((j >> (k - 1)) & 1) edg[k] = 1;
			}
			bool bz = 0;
			for (int k = 1; k <= m; ++ k) {
				if (edg[k]) continue;
				memset (vis, 0, sizeof vis);
				dfs (p, k);
				for (int l = 1; l <= n; ++ l) {
					if (!pos[l]) continue;
					if (!vis[l]) {
						bz = 1;
						break;
					}
				}
				if (bz) break;
			}
			if (!bz) ans = (ans + 1) % mod;
		}
	}
	cout << ans;
}
