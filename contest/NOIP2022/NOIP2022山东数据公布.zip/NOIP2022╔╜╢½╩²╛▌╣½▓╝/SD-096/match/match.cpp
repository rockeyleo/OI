# include <bits/stdc++.h>
using namespace std;
inline int read () {
	int x = 0, f = 1; char c = getchar ();
	while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar ();}
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar ();}
	return x * f;
}
const int D = 3007;
int t, n, q;
int a[D], b[D], t1[D << 2], t2[D << 2];
void build (int now, int l, int r) {
	if (l == r) {
		t1[now] = a[l];
		t2[now] = b[l];
		return;
	}
	int mid = l + r >> 1;
	build (now << 1, l, mid);
	build (now << 1 | 1, mid + 1, r);
	t1[now] = max (t1[now << 1], t1[now << 1 | 1]);
	t2[now] = max (t2[now << 1], t2[now << 1 | 1]);
}
int query1 (int now, int l, int r, int L, int R) {
	if (L <= l && R >= r) return t1[now];
	int mid = (l + r) >> 1, re = INT_MIN;
	if (L <= mid) re = max (re, query1 (now << 1, l, mid, L, R));
	if (R >= mid + 1) re = max (re, query1 (now << 1 | 1, mid + 1, r, L, R));
	return re;
}
int query2 (int now, int l, int r, int L, int R) {
	if (L <= l && R >= r) return t2[now];
	int mid = (l + r) >> 1, re = INT_MIN;
	if (L <= mid) re = max (re, query2 (now << 1, l, mid, L, R));
	if (R >= mid + 1) re = max (re, query2 (now << 1 | 1, mid + 1, r, L, R));
	return re;
}
int main () {
	freopen ("match.in","r",stdin);
	freopen ("match.out","w",stdout);
	t = read (), n = read ();
	for (int i = 1; i <= n; ++ i) a[i] = read ();
	for (int i = 1; i <= n; ++ i) b[i] = read ();
	build (1, 1, n);
	q = read ();
	while (q --) {
		int l = read (), r = read ();
		int ans = 0;
		for (int p = l; p <= r; ++ p) {
			for (int q = p; q <= r; ++ q) {
				int mx1 = query1 (1, 1, n, p, q);
				int mx2 = query2 (1, 1, n, p, q);
				ans += mx1 * mx2;
			}
		}
		cout << ans << "\n";
	}
}
