# include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod = 998244353;
const int D = 1007;
inline ll read () {
	int x = 0, f = 1; char c = getchar ();
	while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar ();}
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar ();}
	return x * f;
}
ll n, m, c, f;
char a[D][D];
ll num1[D][D], num2[D][D]; 
int main () {
	freopen ("plant.in","r",stdin);
	freopen ("plant.out","w",stdout);
	int t = read (), id = read ();
	while (t --) {
		memset (num1, 0, sizeof num1);
		memset (num2, 0, sizeof num2);
		n = read (), m = read (), c = read (), f = read ();
		for (int i = 1; i <= n; ++ i) cin >> a[i];
		ll ans1 = 0, ans2 = 0;
		for (int j = m; j; -- j) {
			ll xia = 0, res = 0, res1 = 0;
			for (int i = n; i; -- i) {
				if (a[i][j - 1] == '1') {
					res = 0;
					res1 = 0;
					continue;
				}
				num1[i][j] = num1[i][j + 1] + 1;
				num2[i][j] = num2[i + 1][j] + 1;
				if (num1[i][j] == 1) continue;
				if (num2[i][j] >= 2 && num1[i + 1][j] > 1) ans1 = (ans1 + (num1[i][j] - 1) * ((res - num1[i + 1][j] + 1 + mod) % mod) % mod) % mod;
				else ans1 = (ans1 + (num1[i][j] - 1) * res % mod) % mod;
				if (num2[i][j] >= 2 && num1[i + 1][j] > 1) ans2 = (ans2 + (num1[i][j] - 1) * ((res1 - (num1[i + 1][j] - 1) * (num2[i + 1][j] - 1) % mod + mod) % mod) % mod) % mod;
				else ans2 = (ans2 + (num1[i][j] - 1) * res1 % mod) % mod;
				res = (res + (num1[i][j] - 1) % mod) % mod;
				res1 = (res1 + (num1[i][j] - 1) * (num2[i][j] - 1) % mod) % mod;
			}
		}
		cout << ((ans1 * c) % mod) << ' ' << ((ans2 * f) % mod) << '\n';
	}
}
