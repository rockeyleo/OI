# include <bits/stdc++.h>
using namespace std;
inline int read () {
	int x = 0, f = 1; char c = getchar ();
	while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar ();}
	while (c >= '0' && c <= '9') {x = x * 10 + c - '0'; c = getchar ();}
	return x * f;
}
int s1[307], s2[307], a[307];
int h1, t1, h2, t2;
int main () {
	freopen ("meow.in","r",stdin);
	freopen ("meow.out","w",stdout);
	int t = read ();
	while (t --) {
		int n = read (), m = read (), k = read ();
		for (int i = 1; i <= m; ++ i) a[i] = read ();
		h1 = 1, t1 = 0; h2 = 1, t2 = 0;
		for (int i = 1; i <= m; ++ i) {
			if (h1 <= t1 && s1[t1] == a[i]) {
				cout << 1 << ' ' << 1 << '\n';
				-- t1;
			}
			else if (h1 <= t1 && s1[h1] == a[i]) {
				cout << 1 << ' ' << 2 << '\n';
				cout << 2 << ' ' << 1 << ' ' << 2 << '\n';
				++ h1;
			}
			else {
				s1[++ t1] = a[i];
				cout << 1 << ' ' << 1 << '\n';
			}
		}
	}
}
