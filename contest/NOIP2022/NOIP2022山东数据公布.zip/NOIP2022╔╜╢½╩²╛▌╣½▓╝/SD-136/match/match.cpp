#include<iostream>
#include<cstdio>
#include<algorithm>
#define NUM 250010
#define ll unsigned long long
#define FOR( a,b,c ) for( int a = b;a <= c;a++ )
using namespace std;

int t; 
int n,q;
int a[NUM],b[NUM];
int sta[NUM][20],stb[NUM][20];
ll d[NUM];

inline int read(){
	int x,fu = -1;
	char c = getchar();
	while( c < '0' || c > '9' ){
		if( c == '-' ) fu *= -1;
		c = getchar();
	}
	while( c >= '0' && c <= '9' ){
		x = (x<<1)+(x<<3)+(c-'0');
		c = getchar();
	}
	return x*fu;
}

signed main(){
	
	freopen( "match.in","r",stdin );
	freopen( "match.out","w",stdout );
	cin >> t;
	ll ans = 0;//�ܵĴ� 
	
	cin >> n;
	d[0] = 1;
	int p = 0;
	FOR( i,1,20 ){
		d[i] = d[i-1] << 1;
		p = i;
		if( d[i] > n ) break;
	}
//	printf( "p = %d\n",p );
	FOR( i,1,n ){
		cin >> a[i];
		sta[i][0] = a[i];
	}
	FOR( i,1,n ){
		cin >> b[i];
		stb[i][0] = b[i];
	}

//	printf( "????" );
	FOR( i,1,p-1 ){
//		printf( "i = %d�������Ե�%d\n",i,n-d[i] );
//		printf( "n - d[i] = %d\n",n - d[i] );
//		printf( "�в��ɣ�����\n" );
		ll jyq = 0;
		FOR( j,1,max( n-d[i]+1,jyq ) ){
//			printf( "j = %d������\n",j );
			sta[j][i] = max( sta[j][i-1],sta[j+d[i-1]][i-1] );
			stb[j][i] = max( stb[j][i-1],stb[j+d[i-1]][i-1] );
		}
	}
	FOR( i,0,p-1 ){
		FOR( j,1,max( n-d[i]+1,(ll)0 ) ){
//			printf( "i = %d,��%d��ʼ����%d�����֣�a��ST����%d��b��ST����%d\n",i,j,d[i],sta[j][i],stb[j][i] );
		}
	}
	cin >> q;
	int x,y,l,r;
	int aa,bb,ww,dis;
	int cha;
	
	FOR( fi,1,q ){
		cin >> l >> r;//ö�ٷ�Χ
		FOR( x,l,r ) {
			FOR( y,x,r ){
				cha = y-x+1;//����ʱ��֪��Ҫ��Ҫ��һ 
				FOR( i,0,p-1 ){
					ww = i;
					if( d[i] >= cha ) break;
				}
				dis = d[ww];
				if( dis > cha ){
					ww--;
					dis = d[ww];
				}
				aa = max( sta[x][ww],sta[y-dis+1][ww] );
				bb = max( stb[x][ww],stb[y-dis+1][ww] );
//				printf( "x = %d,y = %d,aa = %d,bb = %d\n",x,y,aa,bb );
//				printf( "��Ϊ%d���ѵ��ľ���Ϊ%d,ww = %d\n",cha,dis,ww );
				ans += (ll) aa*bb;
		//		ans %= MOD;
			}
		}
		
	} 
	cout << ans;

	return 0;
}
























