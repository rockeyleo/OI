#include<iostream>
#include<cstdio>
#define NUM 1010
#define FOR( a,b,c ) for( int a = b;a <= c;a++ )
using namespace std;

int n;
struct bian{
	int to,next;
	long long zhi;
};
bian e[NUM<<3];
int head[NUM];
int cnt;

void add( int x,int y,long long w ){
	e[++cnt].next = head[x];
	e[cnt].to = y;
	e[cnt].zhi = w;
	head[x] = cnt;
}
inline int read(){
	int x,fu = -1;
	char c = getchar();
	while( c < '0' || c > '9' ){
		if( c == '-' ) fu *= -1;
		c = getchar();
	}
	while( c >= '0' && c <= '9' ){
		x = (x<<1)+(x<<3)+(c-'0');
		c = getchar();
	}
	return x*fu;
}

int main(){

	cin >> n;
	FOR( i,1,n )
		cin >> ;



	return 0;
}
























