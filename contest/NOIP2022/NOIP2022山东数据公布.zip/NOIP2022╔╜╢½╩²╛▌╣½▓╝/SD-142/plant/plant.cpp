#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<vector>
#include<map>
#define int long long
using namespace std;
const int mod = 998244353;
const int N = 1010;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch);ch=getchar()) x=(x<<3)+(x<<1)+ch-'0';
	return x*f;
}
int n,m,c,f;
char str[N];
int a[N][N];
int L[N][N],R[N][N],down[N][N];
int cnt_c,cnt_f;
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T = read() , id = read();
	while(T--){
		n = read() , m = read() , c = read() , f = read();
		cnt_c = 0 , cnt_f = 0;
		if(c == 0 && f == 0){
			cout<<"0\n";
			continue;
		}
		for(int i=1;i<=n;i++){
			scanf("%s",str+1);
			for(int j=1;j<=m;j++){
				if(str[j] == '1') a[i][j] = 1;
				else a[i][j] = 0;
				L[i][j] = R[i][j] = down[i][j] = 0;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=m-1;j>=1;j--){
				if(a[i][j] == 0 && a[i][j+1] == 0){
					R[i][j] = R[i][j+1] + 1;
				}
			}
		}
		for(int j=1;j<=m;j++){
			for(int i=n-1;i>=1;i--){
				if(a[i][j] == 0 && a[i+1][j] == 0){
					down[i][j] = down[i+1][j] + 1;
				}
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i+1][j] == 1 || a[i][j] == 1) continue;
				for(int k=i+2;k<=n;k++){
					if(a[k][j] == 1) break;
					cnt_c += (R[i][j] * R[k][j]) % mod;
					cnt_c %= mod;
					if(down[k][j] != 0){
						cnt_f += (R[i][j] * R[k][j] * down[k][j]) % mod;
						cnt_f %= mod;
					}
				}
			}
		}
		cout<<(c * cnt_c) % mod<<" "<<(f * cnt_f) % mod<<"\n";
	}
	return 0;
}
/*
3 0
6 6 1 1
000010
011000
000110
010000
011000
000000

4 3 1 1
001
010
000
000

16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

114 514
*/
