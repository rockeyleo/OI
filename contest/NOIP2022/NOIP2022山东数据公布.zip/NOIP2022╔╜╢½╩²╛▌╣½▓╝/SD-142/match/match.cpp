#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<vector>
#include<map>
#define int unsigned long long
using namespace std;
const int N = 1e5 + 10; 
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch);ch=getchar()) x=(x<<3)+(x<<1)+ch-'0';
	return x*f;
}
int a[N],b[N];
struct Tree{
	int l,r,mx;
}tr1[N<<2],tr2[N<<2];
void push_up1(int p){
	tr1[p].mx = max(tr1[p<<1].mx,tr1[p<<1|1].mx);
}
void build1(int p,int l,int r){
	tr1[p].l = l , tr1[p].r = r;
	if(l == r){
		tr1[p].mx = a[l];
		return;
	}
	int mid = l + r >> 1;
	build1(p<<1,l,mid) , build1(p<<1|1,mid+1,r);
	push_up1(p);
}
int query1(int p,int l,int r){
	if(l <= tr1[p].l && tr1[p].r <= r){
		return tr1[p].mx;
	}
	int res = 0;
	int mid = tr1[p].l + tr1[p].r >> 1;
	if(l <= mid) res = max(res,query1(p<<1,l,r));
	if(r >  mid) res = max(res,query1(p<<1|1,l,r));
	return res;
}
void push_up2(int p){
	tr2[p].mx = max(tr2[p<<1].mx,tr2[p<<1|1].mx);
}
void build2(int p,int l,int r){
	tr2[p].l = l , tr2[p].r = r;
	if(l == r){
		tr2[p].mx = b[l];
		return;
	}
	int mid = l + r >> 1;
	build2(p<<1,l,mid) , build2(p<<1|1,mid+1,r);
	push_up2(p);
}
int query2(int p,int l,int r){
	if(l <= tr2[p].l && tr2[p].r <= r){
		return tr2[p].mx;
	}
	int res = 0;
	int mid = tr2[p].l + tr2[p].r >> 1;
	if(l <= mid) res = max(res,query2(p<<1,l,r));
	if(r >  mid) res = max(res,query2(p<<1|1,l,r));
	return res;
}
int ans = 0;
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T = read() , n = read();
	for(int i=1;i<=n;i++) a[i] = read();
	for(int i=1;i<=n;i++) b[i] = read();
	build1(1,1,n);build2(1,1,n);
	int q = read();
	while(q--){
		ans = 0;
		int L = read() , R = read();
		for(int i=L;i<=R;i++){
			for(int j=i;j<=R;j++){
//				cout<<i<<" "<<j<<" "<<query1(1,i,j)<<" "<<query2(1,i,j)<<"\n";
				ans += query1(1,i,j) * query2(1,i,j);
			}
		}
		cout<<ans<<"\n";
	}
	return 0;
}
/*
0 2
2 1
1 2
1
1 2

8
*/
