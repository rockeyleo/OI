#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<deque>
#include<vector>
#include<map>
using namespace std;
const int N = 1010;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch);ch=getchar()) x=(x<<3)+(x<<1)+ch-'0';
	return x*f;
}
struct Node{
	int val;
};
deque<Node> q[N];
int a[N];
int cnt = 0;
bool F;
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int n = read() , m = read() , k = read();
	cnt = n;
	
	for(int i=1;i<=m;i++){
		a[i] = read();
	}
	for(int i=1;i<=n;i++) q[i].push_back({0});
	for(int i=1;i<=m;i++){
		F = false;
		for(int j=1;j<=n;j++){
			if(q[j].back().val == a[i]){
				cout<<"1 "<<j<<"\n";
				q[j].pop_back();
				F = true;
				break;
			}
			if(q[j].front().val == a[i] && q[cnt].back().val == 0){
				cout<<"1 "<<cnt<<"\n";
				cout<<"2 "<<i<<" "<<cnt<<"\n";
				cnt--;
			}
		}
		if(F == true) continue;
		q[cnt].push_back({a[i]});
		cnt--;
	}
	return 0;
}
/*
1
2 4 2
1 2 1 2

*/
