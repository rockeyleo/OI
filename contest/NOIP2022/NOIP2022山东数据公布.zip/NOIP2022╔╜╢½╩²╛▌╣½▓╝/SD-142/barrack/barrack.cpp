#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<vector>
#include<map>
#define int long long
using namespace std;
const int N = 5e5 + 10;
const int mod = 1e9 + 7;
inline int read(){
	int x=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') f=-1;
	for(; isdigit(ch);ch=getchar()) x=(x<<3)+(x<<1)+ch-'0';
	return x*f;
}
int qpow(int n,int k){
	int res = 1;
	while(k > 0){
		if(k & 1) res = (res * n) % mod;
		n = (n * n) % mod;
		k >>= 1;
	}
	return res;
}
int ans,fac[N];
int C(int n,int m){
	if(n == m) return 1;
	int res1 = (fac[n] * qpow(fac[m],mod-2)) % mod;
	return (res1 * qpow(fac[n-m],mod-2)) % mod;
//	return ((fac[n] * qpow(fac[m],mod-2)) % mod * qpow(fac[n-m],mod-2)) % mod;
}
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n = read() , m = read();
	fac[0] = 1;
	for(int i=1;i<=n;i++) fac[i] = (fac[i-1] * i) % mod;
//	for(int i=1;i<=n;i++){
//		cout<<C(n,i)<<"\n";
//	}
//	cout<<"\n";
//	cout<<C(2,2)<<"\n";
	for(int i=1;i<=m;i++){
		int a = read() , b = read(); 
	}
	if(m == n - 1){
		ans += n * qpow(2,m);
		for(int i=2;i<=n;i++){
			ans += C(n,i);
		}
		cout<<ans<<"\n";
		return 0;
	}
	if(m == n){
		ans += n * qpow(2,m);
		for(int i=2;i<=n;i++){
			ans += i * C(n,i);
//			cout<<i<<" "<<C(n,i)<<" ";
		}
		cout<<ans<<"\n";
		return 0;
	}
	else{
		
	}
	return 0;
}

/*
4 4
1 2
2 3
3 1
1 4

184
*/
