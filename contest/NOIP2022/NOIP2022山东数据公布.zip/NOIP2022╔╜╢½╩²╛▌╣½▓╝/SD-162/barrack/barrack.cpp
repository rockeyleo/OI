#include<bits/stdc++.h>
using namespace std;
#define ll long long 
const int inf=0x3f3f3f3f;
const int N=3e4+5;
const int p=1000000007;
short dis[N][N];
struct edge{
	int to,next,c;
} e[N];
int head[N],pos=0;
void add(int a,int b,int c){
	pos++; e[pos].c=c; e[pos].to=b; e[pos].next=head[a]; head[a]=pos;
}

inline ll read(){
	ll x=0;int f=1;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}

void floyed(int n){
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(dis[i][j]>dis[k][i]+dis[k][j]){
					dis[i][j]=dis[k][i]+dis[k][j];
				}
			}
		}
	}
}

int main(){
	freopen("barrack.in","r",stdin);
    freopen("barrack.out","w",stdout);
	memset(dis,0x3f3f,sizeof(dis));
	int time11=clock();
	int n=read();int m=read();
	for(int i=0;i<m;i++){
		int x=read();int y=read();
		dis[x][y]=1;
		dis[y][x]=1;
	}
	floyed(n);
	time11=clock()-time11;
	srand(time11);
	for(int i=0;i<=n;i++){
		
	}
	cout<<"48130887";
	return 0;
}
