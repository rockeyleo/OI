#include<bits/stdc++.h>
using namespace std;
#define ll long long 
const int inf=0x3f3f3f3f;
const int N=1e4+5;
const int p=998244353; 
char a[N][N];
int sum[N][N][3];
ll ansc=0,ansf=0;

inline ll read(){
	ll x=0;int f=1;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}

void initx(int n,int m){
	for(int i=0;i<n;i++){
		int tem=0;
		for(int j=m-1;j>=0;j--){
			if(a[i][j]=='0') tem++;
			else tem=0;
			sum[i][j][1]=tem;
		}
	}
}
void inity(int n,int m){
	for(int i=0;i<m;i++){
		int tem=0;
		for(int j=n-1;j>=0;j--){
			if(a[j][i]=='0') tem++;
			else tem=0;
			sum[j][i][2]=tem;
		}
	}
}

ll f_c(int n,int m,int t){
	for(int i=0;i<m-1;i++){
		for(int j=0;j<n-2;j++){
			if(sum[j][i][2]>=3){
				for(int xx=j;xx<(j+sum[j][i][2]-2);xx++){
					j++;
					for(int yy=xx+2;yy<(j+sum[j][i][2]);yy++){
						if((sum[xx][i][1]>=2)&&(sum[yy][i][1]>=2)){
							ansc+=((sum[xx][i][1]-1)%p*((sum[yy][i][1]-1)%p))%p;
							int tep=j+sum[j][i][2]-yy;
							if(tep>=2){
								ansf+=(((sum[xx][i][1]-1)%p)*((sum[yy][i][1]-1)%p)*((tep-1)%p))%p;
							}
						}
					}
				}
				//cout<<j<<" "<<i<<" "<<ttmp<<" "<<endl;
			}else j+=sum[j][i][2];
		}
	}
	return ansc%p;
} 

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=read();int id=read();
	for(int tt=1;tt<=T;tt++){
	int n,m,c,f;
	n=read();m=read(),c=read(),f=read();
	if(c==0&&f==0){
		cout<<"0 0";
		continue;
	}
	for(int i=0;i<n;i++){
		cin>>a[i];
	} 
	initx(n,m);
	inity(n,m);
	ansc=ansf=0;
	f_c(n,m,tt);
	/*for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cout<<sum[i][j][2]<<" ";
		}
		cout<<endl;
	}*/
	cout<<(c*ansc)%p<<" "<<(f*ansf)%p<<endl;
	}
}

