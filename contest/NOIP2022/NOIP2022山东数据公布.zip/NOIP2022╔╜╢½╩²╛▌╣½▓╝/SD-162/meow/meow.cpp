#include<bits/stdc++.h>
#include<deque>
using namespace std;
#define ll long long 
const int inf=0x3f3f3f3f;
const int N=2e6+5;
int a[N];
deque<int> q[305];
inline ll read(){
	ll x=0;int f=1;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}

void print(int tmp[],int pos){
	for(int i=0;i<pos;i++){
		if(tmp[i]==1) cout<<"1 1"<<endl;
		if(tmp[i]==2) cout<<"1 2"<<endl;
		if(tmp[i]==3) cout<<"2 1 1"<<endl;
	}
} 

int dfs2(int m,int cnt,int tmp[],int pos){
	while((q[1].back()==q[2].back())&&q[1].size()&&q[2].size()){
		q[1].pop_back();q[2].pop_back();
		tmp[pos++]=3;
	}
	if(cnt==m&&q[1].size()&&q[2].size())print(tmp,pos);
	if(a[cnt]==q[1].front()&&q[1].size()){
		q[1].pop_front();
		tmp[pos+1]=1;
		dfs2(m,cnt+1,tmp,pos);
		q[1].push_front(a[cnt]);
	}else if(a[cnt]==q[2].front()&&q[2].size()){
		q[2].pop_front();
		tmp[pos+1]=2;
		dfs2(m,cnt+1,tmp,pos);
		q[2].push_front(a[cnt]);
	}else{
		q[1].push_front(a[cnt]);
		tmp[pos+1]=1;
		dfs2(m,cnt+1,tmp,pos);
		q[1].pop_front();
		q[2].push_front(a[cnt]);
		tmp[pos+1]=2;
		dfs2(m,cnt+1,tmp,pos);
		q[2].pop_front();
	}
}

int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T=read();
	for(int tt=1;tt<=T;tt++){
		int n=read(),m=read(),k=read();
		for(int i=0;i<m;i++){
			a[i]=read();
		}
		int tmp[10000];
		dfs2(m,0,tmp,0);
	} 
	return 0;
}


	/*while((q[1].back()==q[2].back())&&q[1].size()&&q[2].size()){
		q[1].pop_back();q[2].pop_back();
	}*/
