#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
#define ll long long
ll min(ll x,ll y){return x<y?x:y;}
ll max(ll x,ll y){return x<y?y:x;}
inline ll read(){
	ll s=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*w;
}
const int MAXN = 1e6;
long long Q,T,n,a[MAXN],b[MAXN],l,r,A[3030][3030],B[3030][3030];
long long work_fi(long long p,long long q){
	if(Q>3001){
		return a[q]*b[q];
	}
	int maxa=-1,maxb=-1;
	if(A[p][q]&&B[p][q]){
		return A[p][q]*B[p][q];
	}
	else{
		for(int i=p;i<=q;i++){
		maxa=max(maxa,a[i]);
		maxb=max(maxb,b[i]);
		A[p][q]=maxa;
		B[p][q]=maxb;
		}
	}
	return maxa*maxb;
}
//clock_t s,t;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
//	s=clock();
	T=read(),n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int j=1;j<=n;j++) b[j]=read();
	Q=read();
	while(Q--){
		long long sum=0;
		l=read(),r=read();
		for(int p=l;p<=r;p++){
			for(int q=l;q<=r;q++){
				if(p<=q){
					sum+=work_fi(p,q);
//					cout<<p<<" "<<q<<" "<<sum<<endl;
				}
			}
		}
		printf("%lld\n",sum);
	}
//	t=clock();
//	cout<<(double)(t-s)/CLOCKS_PER_SEC;
	return 0;
}


/*
0 2
2 1
1 2
1
1 2
*/






