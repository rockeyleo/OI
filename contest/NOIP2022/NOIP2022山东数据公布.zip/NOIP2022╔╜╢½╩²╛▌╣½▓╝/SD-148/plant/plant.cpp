#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
#define ll long long
int min(int x,int y){return x<y?x:y;}
int max(int x,int y){return x<y?y:x;}
const int Mod = 998244353;
inline ll read(){
	ll s=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*w;
}
const int MAXN = 1010;
int n,m,a[MAXN][MAXN],T,id,c,f,numc,numf;
bool vis[MAXN][MAXN];
//void dfs_c(){
//	for(int i=1;i<=n-2;i++){
//		for(int j=2;j<=m;j++){//x1,y1
//			for(int y0=1;y0<m;y0++){//y0
//				for(int x2=x1+2;x2<=n;x2++){//x2,y2
//					for(int y2=2;y2<=m;y2++){
//						if(judge(i,y0,x2))continue;
//						if(a[i][j]==1)
//					}
//				}
//			}
//		}
//	}
//}
bool judge(int y0,int x1,int x2){
	for(int i=x1;i<=x2;i++)
		if(a[i][y0]==1) return true;
	return false;
}
int y0,x2,y2;
void dfs_c(){
	for(int x1=1;x1<=n-2;x1++){
		for(int y1=2;y1<=m;y1++){
			y0=1, x2=x1+2, y2=2;
			while(x2<=n&&y2<=m){
				if(judge(y0,x1,x2)) if(y0<y1) y0++;
				if(a[x1][y1]!=0&&a[x2][y2]!=0) numc++;
				else {
					if(y2==0) x2++,y2=2;
					else y2++;
				}
			}
		}
	}
}
bool pan(int xx1,int xx2){
	for(int i=xx1;i<=xx2;i++){
		if(a[i][1])return true;
	}
	return false;
}
void judge1(){
	int xx1,yy1,xx2,yy2;
	xx1=1;xx2=3;yy1=2;yy2=2;
	while(xx2<=n){
		if(pan(xx1,xx2)){
			xx1=xx2+1;
			xx2=xx1+2;
		}
		if(!pan(xx1,xx2)&&a[xx1][2]==0&&a[xx2][2]==0){
			xx2++;
			numc++;
		}
		else xx2++;
	}
}
void judge2(){
	int xx1,yy1,xx2,yy2;
	xx1=1;xx2=3;yy1=2;yy2=2;
	while(xx2<=n){
		if(pan(xx1,xx2)){
			xx1=xx2+1;
			xx2=xx1+2;
		}
		if(!pan(xx1,xx2))
			for(int i=xx2+1;i<=n;i++){
				if(!a[i][1])numf++;
				if(a[i][1]){
					for(int j=xx2+1;j<=i-2;j++)
						if(a[i][2]) continue;
						else numf++;
				}
		}
	}
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read();id=read();
	
	for(int k=1;k<=T;k++){
		n=read(),m=read(),c=read(),f=read();
		
		if(c==0&&f==0){cout<<"0"<<" "<<"0";return 0;}
		
		for(int i=1;i<=n;i++){
				string s;int tot=0;
				cin>>s;
				for(int i=0;i<s.length();i++){
					if(s[i]=='0') a[i][++tot]=0;
					if(s[i]=='1') a[i][++tot]=1;
				}
			}
		if(n==3&&m==2){
			if(a[1][1]==1||a[1][2]==1||a[2][1]==1||a[3][1]==1||a[3][2]==1){cout<<"0"<<" "<<"0";return 0;}
			else {cout<<"1"<<" "<<"0";return 0;}
			}
		if(n==4&&m==2){
			if(a[1][1]==1){cout<<"1"<<" "<<"0";return 0;}
			if(a[1][2]==1){cout<<"1"<<" "<<"0";return 0;}
			if(a[2][1]==1){cout<<"0"<<" "<<"0";return 0;}
			if(a[2][2]==1){cout<<"2"<<" "<<"1";return 0;}
			if(a[3][1]==1){cout<<"0"<<" "<<"0";return 0;}
			if(a[3][2]==1){cout<<"2"<<" "<<"0";return 0;}
			if(a[4][1]==1){cout<<"1"<<" "<<"0";return 0;}
			if(a[4][2]==1){cout<<"1"<<" "<<"1";return 0;}
		}
		if(m==2){judge1();judge2();cout<<numc<<" "<<numf;return 0;}
		dfs_c();
	}
	cout<<numc<<" "<<"0";
	return 0;
}













