#include<iostream>
#include<cstdio> 
#include<algorithm>
#include<cmath>

using namespace std;

unsigned long long P;
int T,n,Q;
int a[250005],b[250005];
int l[250005],r[250005];
struct node
{
	int l,r;
	int dt;
}t1[10000005],t2[10000005];
void build1(int L,int R,int k)
{
	t1[k].l=L;
	t1[k].r=R;
	if(L==R)
	{
		t1[k].dt=a[L];
		return;
	}
	int mid=(L+R)>>1;
	build1(L,mid,k<<1);
	build1(mid+1,R,k<<1|1);
	t1[k].dt=max(t1[k<<1].dt,t1[k<<1|1].dt);
}
void build2(int L,int R,int k)
{
	t2[k].l=L;
	t2[k].r=R;
	if(L==R)
	{
		t2[k].dt=b[L];
		return;
	}
	int mid=(L+R)>>1;
	build2(L,mid,k<<1);
	build2(mid+1,R,k<<1|1);
	t2[k].dt=max(t2[k<<1].dt,t2[k<<1|1].dt);
}
int ans=0;
void ask1(int L,int R,int k)
{
	if(L<=t1[k].l&&R>=t1[k].r)
	{
		ans=max(ans,t1[k].dt);
		return;
	}
	int mid=(t1[k].l+t1[k].r)>>1;
	if(L<=mid)
	{
		ask1(L,R,k<<1);
	}
	if(R>mid)
	{
		ask1(L,R,k<<1|1);
	}
}
void ask2(int L,int R,int k)
{
	if(L<=t2[k].l&&R>=t2[k].r)
	{
		ans=max(ans,t2[k].dt);
		return;
	}
	int mid=(t2[k].l+t2[k].r)>>1;
	if(L<=mid)
	{
		ask2(L,R,k<<1);
	}
	if(R>mid)
	{
		ask2(L,R,k<<1|1);
	}
}
unsigned long long ct=0;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	P=1;
	for(int i=1;i<=63;i++)
	{
		P*=2;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	cin>>Q;
	for(int i=1;i<=Q;i++)
	{
		cin>>l[i]>>r[i];
	}
	build1(1,n,1);
	build2(1,n,1);
	
	for(int i=1;i<=Q;i++)
	{
		for(int p=l[i];p<=r[i];p++)
		{
			for(int q=p;q<=r[i];q++)
			{
				int ma,mb;
				ans=0;
				ask1(p,q,1);
				ma=ans;
				ans=0;
				ask2(p,q,1);
				mb=ans;
				ct+=(1ll*ma*mb)%P;
			}
		}
		cout<<ct<<endl;
		ct=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
0 30
9 30 25 18 7 3 29 15 12 16 14 26 24 5 1 8 13 28 6 17 2 22 4 23 27 10 11 19 20 21
27 24 11 26 7 3 8 15 25 10 1 4 18 14 20 23 9 22 29 30 13 28 19 17 2 21 6 12 5 16
30
1 30
1 30
6 30
3 26
4 26
6 28
1 24
4 30
7 29
3 24
7 30
3 26
4 26
2 29
4 30
6 21
8 29
11 14
15 19
19 20
7 30
25 30
7 9
19 30
7 26
13 26
5 30
15 24
18 21
23 29

*/
