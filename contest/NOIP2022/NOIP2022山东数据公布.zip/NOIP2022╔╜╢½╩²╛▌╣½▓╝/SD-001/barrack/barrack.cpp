#include<bits/stdc++.h>

using namespace std;

const int P = 1000000007;
const int N = 1000005;
int hd[N],nx[N],to[N],tot,f[N];
int n,m;
void add(int x,int y)
{
	nx[++tot]=hd[x];
	hd[x]=tot;
	to[tot]=y;
}
long long ans=0; 
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		add(a,b);
		add(b,a);
	}
	srand(time(NULL));
	ans=rand()%P;
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
