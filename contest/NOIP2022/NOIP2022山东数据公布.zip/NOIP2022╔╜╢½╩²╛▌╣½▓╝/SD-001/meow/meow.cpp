#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

int T;
int n,m,k;
int a[1000005];
int q[305][10005],h[305],t[305];
int ans[300005][3];
int ys=1;
void pr(int sum)
{
	for(int i=1;i<=sum;i++)
	{
		cout<<ans[i][0]<<" ";
		cout<<ans[i][1];
		if(ans[i][0]==2)cout<<" "<<ans[i][2];
		cout<<endl;
	}
	ys=0;
}
void dfs(int ct,int ind)
{
	if(ct>2*m+1)return;
	if(ind==m+1)
	{
		int ff=0;
		for(int i=1;i<=n;i++)
		{
			if(h[i]<=t[i])ff=1; 
		}
		if(!ff)pr(ct-1);
		return;
	}
 	for(int i=1;i<=n&&ys;i++)
	{
 		int x=q[i][t[i]],fg=0;
		if(a[ind]==x)
		{
			q[i][t[i]]=0;
			t[i]--;
		}
		else 
		{
			fg=1;
			t[i]++;
			q[i][t[i]]=a[ind];
		}
		ans[ct][0]=1;
		ans[ct][1]=i;
		dfs(ct+1,ind+1);
		if(!fg)
		{
			t[i]++;
			q[i][t[i]]=x;
		}
		else 
		{
			q[i][t[i]]=0;
			t[i]--;
		}
	}
	for(int i=1;i<=n&&ys;i++)
	{
		for(int j=i+1;j<=n&&ys;j++)
		{
			if(q[i][h[i]]==q[j][h[j]]!=0)
			{
				int x=q[i][h[i]],y=q[j][h[j]];
				q[i][h[i]]=0;
				q[j][h[j]]=0;
				ans[ct][0]=2;
				ans[ct][1]=i;
				ans[ct][2]=j;
				h[i]++;
				h[j]++;
				dfs(ct+1,ind);
				h[i]--;
				h[j]--;
				q[i][h[i]]=x;
				q[j][h[j]]=y;
			}
		}
	}
}
void solve()
{
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)h[i]=1;
	dfs(1,1);
	ys=1;
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout); 
	cin>>T;
	while(T--)
	{
		solve();
	}
	fclose(stdin);
	fclose(stdout);
} 
/*
2
2 8 5
1 2 3 4  5 1 2 3 4 5 
*/ 
