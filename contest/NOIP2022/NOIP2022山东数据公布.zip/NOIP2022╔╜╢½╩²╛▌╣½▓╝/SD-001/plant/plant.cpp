#include<iostream>
#include<algorithm>
#include<cstdio>

using namespace std;

const int P = 998244353;

int T,id;
int n,m,c,f;
int a[1005][1005],s[1005][1005];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	if(id==1)
	{
		for(int k=1;k<=T;k++)
		{
			cin>>n>>m>>c>>f;
			for(int i=1;i<=n;i++)
			{
				string s;
				cin>>s;
			}
		}
		for(int i=1;i<=T;i++)
		{
			cout<<0<<" "<<0<<endl;
		}
	}
	if(id==2)
	{
		for(int i=1;i<=T;i++)
		{
			cin>>n>>m>>c>>f;
			for(int j=1;j<=n;j++)
			{
				string s;
				cin>>s;
				for(int k=0;k<m;k++)
				{
					a[j][k+1]=s[k]-'0';
				}
			}
			if(a[1][1]||a[1][2]||a[2][1]||a[3][1]||a[3][2])
			{
				cout<<0<<" ";
			}
			else cout<<1<<" ";
			cout<<0<<endl; 
		}
	}
	if(id==3||id==4)
	{
		for(int w=1;w<=T;w++)
		{
			cin>>n>>m>>c>>f;
			for(int j=1;j<=n;j++)
			{
				string s;
				cin>>s;
				for(int k=0;k<m;k++)
				{
					a[j][k+1]=s[k]-'0';
				}
			}
			int vc=0,vf=0;
			for(int i=1;i<=n;i++)
			{
				int fg=1;
				for(int j=1;j<=m;j++)
				{
					if(a[i][j])fg=0;
				}
				if(fg)
				{
					if(!a[i+1][1])
					for(int k=i+2;k<=n;k++)
					{
						if(a[k][1])break;
						int fg2=1;
						for(int l=1;l<=m;l++)
						{
							if(a[k][l])fg2=0;
						}
						if(fg2)
						{
							vc++;
							for(int p=k+1;p<=n;p++)
							{
								if(!a[p][1])vf++;
								else break;
							}
						}
					}
					
				}
			}
			cout<<(vc*c)%P<<" "<<(vf*f)%P<<endl;
		}
	}
	else 
	{
		for(int w=1;w<=T;w++)
		{
			long long vc=0,vf=0;
			cin>>n>>m>>c>>f;
			for(int i=1;i<=n;i++)
			{
				string s;
				cin>>s;
				for(int j=1;j<=m;j++)
				{
					a[i][j]=s[j-1]-48;
				}
			}
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=m;j++)
				{
					s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
				}
			}
			for(int i=1;i<=n;i++)
			{
				for(int st=1;st<=m-1;st++)
				{
					if(a[i][st]||a[i+1][st])continue;
					int dd=m;
					for(int j=st;j<=m;j++)
					{
						if(a[i][j])
						{
							dd=j-1;
							break;
						}
					}
					if(a[i+1][st])continue;
					for(int h=i+2;h<=n;h++)
					{
						if(a[h][st])break;
						int d2=m;
						for(int l=st;l<=m;l++)
						{
							if(a[h][l])
							{
								d2=l-1;
								break;
							}
						}
						vc=(vc+1ll*(dd-st)*(d2-st)%P)%P;
						int ff=0;
						for(int o=h+1;o<=n;o++)
						{
							if(!a[o][st])ff++;
							else break;
						}
						vf=(vf+1ll*(dd-st)*(d2-st)*ff%P)%P;
					}
				}
			}
			cout<<(vc*c)%P<<" "<<(vf*f)%P<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111
*/ 
