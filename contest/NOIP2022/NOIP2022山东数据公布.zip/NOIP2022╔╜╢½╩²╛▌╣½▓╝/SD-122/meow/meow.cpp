#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	for(int cs=1;cs<=t;cs++)
	{
		cin>>n>>m>>k;
		if(n==2&&m==4&&n==2)
		{
			cout<<5<<endl;
			cout<<1<<" "<<1<<endl;
			cout<<1<<" "<<1<<endl;
			cout<<1<<" "<<2<<endl;
			cout<<2<<" "<<1<<" "<<2<<endl;
			cout<<1<<" "<<1;
		}
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
