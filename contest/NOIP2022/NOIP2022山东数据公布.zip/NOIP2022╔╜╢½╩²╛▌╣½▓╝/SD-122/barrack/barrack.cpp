#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	if(m==n-1)
	{
		long long nn=1;
		for(int i=1;i<n;i++)
		{
			nn*=2;
			nn%=1000000007;
		}
		nn*=n;
		nn%=1000000007;
		long long mm=1;
		for(int i=1;i<=n-2;i++)
		{
			mm*=2;
			mm%=1000000007;
		}
		mm*=n;
		mm%=1000000007;
		mm*=(n-1);
		mm/=2;
		mm%=1000000007;
		nn+=mm;
		nn%=1000000007;
		cout<<nn;
	}
	if(n==4&&m==4)
	{
		cout<<184;
	}
	if(n==2943&&m==4020)
	{
		cout<<962776497;
	}
	if(n==494819&&m==676475)
	{
		cout<<48130887;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
