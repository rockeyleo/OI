#include<bits/stdc++.h>
using namespace std;
unsigned long long ajc,bjc,jcd,zjc;
int t,n,sta[250001][20],stb[250001][20];
int q,l,r,ccs;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(int i=1;i<=n;i++)
		cin>>sta[i][0];
	for(int i=1;i<=n;i++)
		cin>>stb[i][0];
	int p=log(n*1.0)/log(2.0);
	for(int i=1;i<=p;i++)
	{
		for(int j=1;j<=n-(1<<i)+1;j++)
		{
			sta[j][i]=max(sta[j][i-1],sta[j+(1<<(i-1))][i-1]);
			stb[j][i]=max(stb[j][i-1],stb[j+(1<<(i-1))][i-1]);
		}
	}
	cin>>q;
	for(int cs=1;cs<=q;cs++)
	{
		zjc=0;
		cin>>l>>r;
		for(int i=1;i<=r-l+1;i++)
		{
			int p=log(i*1.0)/log(2.0);
			for(int j=l;j<=r-i+1;j++)
			{
				ajc=max(sta[j][p],sta[j+i-(1<<p)][p]);
				bjc=max(stb[j][p],stb[j+i-(1<<p)][p]);
				jcd=ajc*bjc;
				zjc+=jcd;
				if(zjc>=(1ULL<<63));
				{
					zjc-=(1ULL<<63);
					ccs++;
				}
			}
		}
		if(ccs%2==1)	cout<<zjc+(1ULL<<63)<<endl;
		else	cout<<zjc<<endl;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
