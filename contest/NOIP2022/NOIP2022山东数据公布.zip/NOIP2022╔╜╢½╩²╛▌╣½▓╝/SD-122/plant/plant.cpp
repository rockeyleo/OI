#include<bits/stdc++.h>
using namespace std;
int t,id,n,m,nn,mm,c,f,num,cs1,cs2,cs3,zgs;
string str[2001];
int stf[2001][2001],yb[2001][2001],xb[2001][2001];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	for(int cs=1;cs<=t;cs++)
	{
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++)
		{
			cin>>str[i];
			for(int j=1;j<=m;j++)
			{
				if(str[i][j-1]=='0')	stf[i][j]=1;
				else	stf[i][j]=0;
			}
		}
		for(int i=1;i<=m-1;i++)
		{
			for(int j=1;j<=n;j++)
			{
				nn=j;
				num=0;
				while(stf[j][i]==1)
				{
					num++;
					xb[j][i]=num;
					j++;
				}
				mm=j;
				for(j=nn;j<mm;j++)
					xb[j][i]=num-xb[j][i];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m-1;j++)
			{
				nn=j;
				num=0;
				while(stf[i][j]==1)
				{
					num++;
					yb[i][j]=num;
					j++;
				}
				mm=j;
				for(j=nn;j<mm;j++)
					yb[i][j]=num-yb[i][j];
			}
		}
		if(c==1)
		{
			for(int h=1;h<m;h++)
			{
				for(int i=1;i<n;i++)
				{
					if(xb[i][h]<2) continue;
					for(int j=i+2;j<=n;j++)
					{
						zgs+=yb[i][h]*yb[j][h];
						zgs%=998244353;
						if(xb[j][h]==0) break;
					}
				}
			}
			cout<<zgs<<" ";
		}
		else cout<<0<<" ";
		zgs=0;
		if(f==1)
		{
			for(int h=1;h<m;h++)
			{
				for(int i=1;i<n;i++)
				{
					if(xb[i][h]<3) continue;
					for(int j=i+2;j<=n;j++)
					{
						zgs+=yb[i][h]*yb[j][h]*xb[j][h];
						zgs%=998244353;
						if(xb[j][h]==1) break;
					}
				}
			}
			cout<<zgs<<" ";
		}
		else cout<<0<<" ";
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
