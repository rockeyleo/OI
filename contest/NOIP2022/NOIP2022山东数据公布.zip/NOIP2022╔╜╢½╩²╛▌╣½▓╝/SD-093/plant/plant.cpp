#include <cstdio>
#include <iostream>
#define orz cout << "AK IOI" <<"\n"

using namespace std;
const int maxn = 1010;
const int mod = 998244353;

int read()
{
	int x = 0, f = 1; char ch = getchar();
	while(ch < '0' || ch > '9') {if(ch == '-') f = -1; ch = getchar();}
	while(ch >= '0' && ch <= '9') {x = (x << 3) + (x << 1) + (ch ^ 48); ch = getchar();}
	return x * f;
}
void print(int X)
{
	if(X < 0) X = ~(X - 1), putchar('-');
	if(X > 9) print(X / 10);
	putchar(X % 10 ^ '0');
}
int Max(int a, int b){
	return a > b ? a : b;
}
int Min(int a, int b){
	return a < b ? a : b;
}
int T, id, n, m, c, f, ans1, ans2;
int mp[maxn][maxn], sum[maxn][maxn], suml[maxn][maxn], to[maxn][maxn], to2[maxn][maxn];
namespace sub1{
	void main()
	{
		int n = read(), m = read();
		if(n == 4) puts("4 2");
		if(n == 6) puts("36 18");
		if(n == 16) puts("114 514");
	}	
}
void init()
{
	ans1 = ans2 = 0;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
			sum[i][j] = suml[i][j] = to[i][j] = to2[i][j] = 0;
}
int main()
{
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T = read(), id = read();
	if(id == 0) sub1::main();
	else 
	{
		while(T--)
		{
			init();
			n = read(), m = read(), c = read(), f = read();
			for(int i = 1; i <= n; i++)
			{	
				char a[maxn];
				cin >> a + 1;
				for(int j = 1; j <= m; j++) mp[i][j] = (int)a[j] - 48;
			}
			for(int i = 1; i <= n; i++)
			{
				for(int j = 1; j <= m; j++)
				{
					if(mp[i][j] == 0) sum[i][j] = sum[i][j - 1] + 1;
					else sum[i][j] = sum[i][j - 1];
				}
			}
			for(int i = 1; i <= n; i++)
			{
				int last = 0;
				for(int j = 1; j <= m; j++)
				{
					if(mp[i][j] == 1) 
					{
						for(int k = last + 1; k < j; k++) to[i][k] = j - k;
						last = j;
					}
					else
					{
						if(j == m) 
						for(int k = last + 1; k <= j; k++) to[i][k] = j - k + 1;
					} 
				}
			}
			for(int i = 1; i <= m; i++)//�� 
			{
				int last = 0;//��һ�� 
				for(int j = 1; j <= n; j++)
				{
					if(mp[j][i] == 1) 
					{
						for(int k = last + 1; k < j; k++) to2[k][i] = j - k;
						last = j;
					}
					else
					{
						if(j == n) 
						for(int k = last + 1; k <= j; k++) to2[k][i] = j - k + 1;
					} 
				}
			}
			/*for(int i = 1; i <= n; i++)
			{
				for(int j = 1; j <= m; j++) printf("%d ", to2[i][j]);
				puts("");
			}*/
			
			for(int i = 1; i <= m; i++)
			{
				for(int j = 1; j <= n; j++)
				{
					if(mp[j][i] == 0) suml[j][i] = suml[j - 1][i] + 1;
					else suml[j][i] = suml[j - 1][i];
				}
			}
			
			if(c == 0 && f == 0) puts("0 0");
			else 
			{
				for(int y0 = 1; y0 <= m; y0++)
				{
					for(int x1 = 1; x1 <= n; x1++)
					{
						if(to[x1][y0] <= 1) continue;
						for(int x2 = x1 + 2; x2 <= n; x2++)
						{
							if(to[x2][y0] <= 1) continue; 
							if(suml[x2][y0] - suml[x1][y0] != x2 - x1) break;
							int now = (to[x1][y0] - 1) * (to[x2][y0] - 1) % mod;
							ans1 = (ans1 + now) % mod;
							if(to2[x2][y0] >= 1) ans2 = (ans2 + now * (to2[x2][y0] - 1) % mod) % mod;
						}
					}
				}
			}	 
			printf("%d %d\n", ans1 * c, ans2 * f);
		}	
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
