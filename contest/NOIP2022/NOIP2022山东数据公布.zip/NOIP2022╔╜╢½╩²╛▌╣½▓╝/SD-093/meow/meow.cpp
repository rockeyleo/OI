#include <cstdio>
#include <iostream>
#define orz cout << "AK IOI" <<"\n"

using namespace std;
const int maxm = 2e6 + 10;

int read()
{
	int x = 0, f = 1; char ch = getchar();
	while(ch < '0' || ch > '9') {if(ch == '-') f = -1; ch = getchar();}
	while(ch >= '0' && ch <= '9') {x = (x << 3) + (x << 1) + (ch ^ 48); ch = getchar();}
	return x * f;
}
void print(int X)
{
	if(X < 0) X = ~(X - 1), putchar('-');
	if(X > 9) print(X / 10);
	putchar(X % 10 ^ '0');
}
int Max(int a, int b){
	return a > b ? a : b;
}
int Min(int a, int b){
	return a < b ? a : b;
}
int T, n, m, k, a[maxm], vis[maxm];
void init()
{
	for(int i = 1; i <= m; i++) vis[i] = 0;
}
void dfs(int now)
{
	if(now == m + 1) { return ;}
	vis[now] = 0;
	dfs(now + 1);
	vis[now] = 1;
	dfs(now + 1);
}
int main()
{
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	T = read();
	while(T--)
	{
		init();
		n = read(), m = read(), k = read();
		for(int i = 1; i <= m; i++) a[i] = read();
		dfs(1);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
1
2 4 2
1 2 1 2
*/
