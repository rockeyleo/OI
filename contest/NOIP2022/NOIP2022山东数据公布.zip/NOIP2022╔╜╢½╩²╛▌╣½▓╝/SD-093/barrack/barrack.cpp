#include <cstdio>
#include <iostream>
#define orz cout << "AK IOI" <<"\n"

using namespace std;
const int maxn = 5e5 + 10;
const int maxm = 1e6 + 10;
const int mod = 1e9 + 7;

int read()
{
	int x = 0, f = 1; char ch = getchar();
	while(ch < '0' || ch > '9') {if(ch == '-') f = -1; ch = getchar();}
	while(ch >= '0' && ch <= '9') {x = (x << 3) + (x << 1) + (ch ^ 48); ch = getchar();}
	return x * f;
}
void print(int X)
{
	if(X < 0) X = ~(X - 1), putchar('-');
	if(X > 9) print(X / 10);
	putchar(X % 10 ^ '0');
}
int Max(int a, int b){
	return a > b ? a : b;
}
int Min(int a, int b){
	return a < b ? a : b;
}
int n, m;
struct node{
	int u, v, nxt;
}e[maxm << 1];
int js, head[maxn];
void add(int u, int v)
{
	e[++js] = (node){u, v, head[u]};
	head[u] = js;
}
namespace sub1{
	int power[maxn], ans = 0;
	void init()
	{
		power[0] = 1;
		for(int i = 1; i <= n; i++) power[i] = (power[i - 1] * 2) % mod;
	}
	void main()
	{
		init();
		int ans = 0;
		for(int i = 1; i <= n; i++)
		{
			ans = (ans + 1 * power[n - i] * (i + 1) % mod)% mod;
		}
		print(ans);
	}
}
int main()
{
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	n = read(), m = read();
	for(int i = 1; i <= m; i++)
	{
		int u = read(), v = read();
		add(u, v), add(v, u);
	}
	sub1::main();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
5 4
*/
