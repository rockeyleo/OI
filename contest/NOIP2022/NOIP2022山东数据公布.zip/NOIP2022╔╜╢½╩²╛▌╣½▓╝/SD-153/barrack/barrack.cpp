#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=500010;
const int Mod=1e9+7;
int n,m;
int h[N],e[2*N],ne[2*N],idx;
int cnt;
void add(int a,int b)
{
	e[idx]=b,ne[idx]=h[a],h[a]=idx++;
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		add(a,b);
		add(b,a);
		cnt++;
	}
	cout<<cnt*n*m<<"\n";
	return 0;
}
