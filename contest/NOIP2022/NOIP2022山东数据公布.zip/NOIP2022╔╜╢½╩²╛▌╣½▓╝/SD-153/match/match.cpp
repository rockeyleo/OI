#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=250010;
const LL Mod=1e9+7;
int T;
int n;
int a[N],b[N];
int Q;
int l,r;
LL ans;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	cin>>Q;
	while(Q--)
	{
		cin>>l>>r;
		for(int i=l;i<=r;i++)
			for(int j=i;j<=r;j++)
			{
				int maxa=-1,maxb=-1;
				for(int k=i;k<=j;k++)
				{
					maxa=max(maxa,a[k]);
					maxb=max(maxb,b[k]);
				}
				ans=ans%Mod+maxa*maxb%Mod;
			}
	}
	cout<<ans<<"\n";
}
