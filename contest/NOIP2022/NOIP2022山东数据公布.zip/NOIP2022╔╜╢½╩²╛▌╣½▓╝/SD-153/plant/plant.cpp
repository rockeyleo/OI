#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=1010;
const int Mod=998244353;
int T,id;
int n,m,c,f;
char a[N][N];
int b[N][N];
LL C,F;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	while(T--)
	{
		cin>>n>>m>>c>>f;
		memset(a,'0',sizeof a);
		memset(b,0,sizeof b);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				cin>>a[i][j];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				if(a[i][j]=='0')
					for(int k=j+1;k<=m;k++)
					{
						if(a[i][k]=='0')
							b[i][j]++;
						else break;
					}
		for(int i=1;i<=m;i++)
			for(int j=1;j<=n;j++)
			{
				if(a[j][i]=='0'&&a[j+1][i]=='0'&&j+1<=n)
				{
					for(int k=j+2;k<=n;k++)
					{
						if(a[k][i]=='0')
							C=(C+(LL)b[j][i]*b[k][i])%Mod;
						else break;
					}
				}
				if(a[j][i]=='0'&&a[j+1][i]=='0'&&a[j+2][i]=='0'&&j+2<=n)
				{
					for(int k=j+3;k<=n;k++)
					{
						if(a[k][i]=='0')
							F=(F+(LL)b[j][i]*b[j+2][i])%Mod;
						else break;
					}
				}
			}
		cout<<(C*c)%Mod<<" "<<(F*f)%Mod<<"\n";
	}
	return 0;
} 
