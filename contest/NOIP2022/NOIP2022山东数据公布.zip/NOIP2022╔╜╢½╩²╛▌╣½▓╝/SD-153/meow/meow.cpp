#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> PII;
const int N=310,M=1000010;
int T;
int n,m,k;
int a[M],t,h=1;
int s[N][M],tt[N],hh[N];
int cnt;
int sum;
struct answer
{
	int op;
	int s1,s2;
}ans[2*M];
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>T;
	while(T--)
	{
		cin>>n>>m>>k;
		memset(hh,1,sizeof hh);
		for(int i=1;i<=m;i++)
		{
			cin>>a[++t];
		}
		for(int i=1;i<=m;i++)
		{
			bool flag=false;
			for(int j=1;j<=n;j++)
				for(int k=j+1;k<=n;k++)
				{
					if(s[j][hh[j]]==s[k][hh[k]]&&s[j][hh[j]]!=0)
					{
						hh[j]++;
						hh[k]++;
						ans[++sum].op=2;
						ans[sum].s1=j;
						ans[sum].s2=k;
					}
				}
			for(int j=1;j<=n;j++)
				if(s[j][tt[j]]==a[t])
				{
					tt[j]--;
					t--;
					ans[++sum].op=1;
					ans[sum].s1=j;
					flag=true;
					break;
				}
			if(!flag)
				if(++cnt<=n)
				{
					s[cnt][++tt[cnt]]=a[t--];
					ans[++sum].op=1;
					ans[sum].s1=cnt;
				}
				else
				{
					cnt=1;
					s[cnt][++tt[cnt]]=a[t--];
					ans[++sum].op=1;
					ans[sum].s1=cnt;
				}
		}
		cout<<sum<<"\n";
		for(int i=1;i<=sum;i++)
		{
			if(ans[i].op==1)
				cout<<ans[i].op<<" "<<ans[i].s1<<"\n";
			else cout<<ans[i].op<<" "<<ans[i].s1<<" "<<ans[i].s2<<"\n";
		}
	}
	return 0;
}
