#include<bits/stdc++.h>
#define int long long
using namespace std;

int read() {
  int x = 0, f = 1; char c = getchar();
  while(c < '0' || c > '9') {if(c == '-') f = -1;c = getchar();}
  while(c >= '0' && c <= '9') {x = x * 10 + c - '0';c = getchar();}
  return x * f;
}
int T, n, Q, f[3010][20], F[3010][20], Ans;
int query(int l, int r) {
  int len = log2(r - l + 1);
  return max(f[l][len], f[r - (1 << len) + 1][len]);
}
int Query(int l, int r) {
  int len = log2(r - l + 1);
  return max(F[l][len], F[r - (1 << len) + 1][len]);
}
signed main() {
  freopen("match.in", "r", stdin);
  freopen("match.out", "w", stdout);  
  T = read(), n = read();
  for (int i = 1; i <= n; i++) f[i][0] = read();
  for (int i = 1; i <= n; i++) F[i][0]= read(); 
  for (int j = 1; j <= 20; j++) 
    for (int i = 1; i + (1 << j) - 1 <= n; i++)
     f[i][j] = max(f[i][j - 1], f[i + (1 << j - 1)][j - 1]);
  for (int j = 1; j <= 20; j++) 
    for (int i = 1; i + (1 << j) - 1 <= n; i++)
     F[i][j] = max(F[i][j - 1], F[i + (1 << j - 1)][j - 1]);
  Q = read();
  for (int i = 1; i <= Q; i++) {
   int l = read(), r = read();
   Ans = 0;
   for(int p = l; p <= r; p++) {
   	 for (int q = p; q <= r; q++) {
   	    int ret = query(p, q), Ret = Query(p, q);
   	    Ans += ret * Ret;
	  }
   }
   cout<<Ans<<"\n";
  }
  
  return 0;
}
/*
0 2
2 1
1 2
1
1 2
*/
