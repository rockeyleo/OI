#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1e5 + 5;
int read() {
  int x = 0, f = 1; char c = getchar();
  while(c < '0' || c > '9') {if(c == '-') f = -1;c = getchar();}
  while(c >= '0' && c <= '9') {x = x * 10 + c - '0';c = getchar();}
  return x * f;
}
int T, n, m, k, a[MAXN], st[4][MAXN], top[4], ed[4], cnt, suc, num[MAXN];
struct Node{int fag, A, B;}p[MAXN];
void dfs(int x) {
  if(suc) return ;
  if(x == m + 1) {
  	memset(st, 0, sizeof st);
  	memset(top, 0, sizeof top);
  	memset(ed, 0, sizeof ed);
  	memset(p, 0, sizeof p);
    cnt = 0;
    for (int i = 1; i <= m; i++) {
      p[++cnt].fag = 1;
      p[cnt].A = num[i];
      if(st[num[i]][top[num[i]]] == a[i] && top[num[i]] >= ed[num[i]]) {
      	 top[num[i]]--;	
      	 continue;
	  } 
	  else {
	    if(top[num[i]] == 0) {
	       top[num[i]] = ed[num[i]] = 1;
	       st[num[i]][1] = a[i];
		   	
		}
		else if(ed[num[i]] > top[num[i]]) {
		   ed[num[i]]--;
		   st[num[i]][ed[num[i]]] = a[i];
		}
	  int f = 1;
	  while(f == 1) {
	  	f = 0;
	  	for (int j = 1; j <= 3; j++) 
		  for (int k = j + 1; k <= 3; k++) {
		  	if(st[j][ed[j]] == st[k][ed[k]] && (top[j] >= ed[j]) && (top[k] >= ed[k]) && top[k] != 0 && top[j] != 0) {
			  ed[j]++, ed[k]++;
			  p[++cnt].fag = 2;
			  p[cnt].A = j, p[cnt].B = k;
			  f = 1;
			  break;
		    }
	  	  }
	    } 
	  }	
    } 
	for (int i = 1; i <= 3; i++) if(top[i] >= ed[i]) return ;
	suc = 1;
  	return ;
  }
  for (int i = 1; i <= 3; i++) {
  	 num[x] = i;
  	 dfs(x + 1);
  }
}
int main() {
  freopen("meow.in", "r", stdin);
  freopen("meow.out", "w", stdout);
  T = read();
  while(T--) {
  	n = read(), m = read(), k = read();
  	for (int i = 1; i <= m; i++) a[i] = read();
  	dfs(1);
  	for (int i = 1; i <= cnt; i++) {
  	  if(p[i].fag == 1) {
  	    cout<<p[i].fag<<" "<<p[i].A<<"\n";	 
	  }	
      else cout<<p[i].fag<<" "<<p[i].A<<" "<<p[i].B<<"\n";
	}
  }
  return 0;
}
/*
1
3 6 3 
1 2 3 2 3 1
*/
