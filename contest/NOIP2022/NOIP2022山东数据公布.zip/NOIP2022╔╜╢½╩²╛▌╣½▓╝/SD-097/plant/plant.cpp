#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1010;
const int mod = 998244353;
int read() {
  int x = 0, f = 1; char c = getchar();
  while(c < '0' || c > '9') {if(c == '-') f = -1;c = getchar();}
  while(c >= '0' && c <= '9') {x = x * 10 + c - '0';c = getchar();}
  return x * f;
}
int T, id, n, m, c, f;
int a[MAXN][MAXN], sum[MAXN][MAXN], Sum[MAXN][MAXN], lsum[MAXN][MAXN], rsum[MAXN][MAXN];
char s[MAXN];
int main() {
  freopen("plant.in", "r", stdin);
  freopen("plant.out", "w", stdout);
  T = read(), id = read();
  while(T--) {
  	memset(sum, 0, sizeof sum);
  	memset(Sum, 0, sizeof Sum);
  	memset(lsum, 0, sizeof lsum);
  	memset(rsum, 0, sizeof rsum);
  	memset(a, 0, sizeof a);
  	n = read(), m = read(), c = read(), f = read();
    for (int i = 1; i <= n; i++) {
      scanf("%s", s + 1);
      for (int j = 1; j <= m; j++) {
      	 if(s[j] == '0') a[i][j] = 0;
      	 else a[i][j] = 1;
	  }
	}
    for (int i = 1; i <= n; i++) {
      for (int j = m; j >= 1; j--) {
      	 if(a[i][j] == 1) sum[i][j] = 0;
      	 else sum[i][j] = sum[i][j + 1] + 1;
	  }
	}
	for (int j = 1; j <= m; j++) {
	  for (int i = n; i >= 1; i--) {
	     if(sum[i][j]) Sum[i][j] = Sum[i + 1][j] + sum[i][j] - 1;
	     else Sum[i][j] = 0;
	     if(j == m) Sum[i][j] = 0;
	  }
    }
    int Ans = 0;
    for (int j = 1; j < m; j++) {
      for (int i = n; i >= 1; i--) {
      	 if(a[i + 1][j] == 0 && i <= n - 2 && sum[i][j] >= 2) {
      	 	Ans = (Ans + (Sum[i + 2][j] * (sum[i][j] - 1) % mod * c)) % mod;
		 }
	  }
	}
	cout<<Ans<<" ";
	Ans = 0;
	for (int j = 1; j <= m; j++) {
	  for (int i = n; i >= 1; i--) {
	    if(a[i][j] == 1) lsum[i][j] = 0;
	    else lsum[i][j] = lsum[i + 1][j] + 1;
	  }
	}
    for (int j = 1; j < m; j++) {
      for (int i = n - 1; i >= 1; i--) {
      	if(sum[i][j] && lsum[i][j]) {
      	   rsum[i][j] = (rsum[i + 1][j] + ((sum[i][j] - 1) * (lsum[i][j] - 1)) % mod) % mod;		
		 }
	  }
	}
	for (int j = 1; j < m; j++) {
      for (int i = n; i >= 1; i--) {
      	 if(a[i + 1][j] == 0 && i <= n - 2 && sum[i][j] >= 2 && lsum[i][j] >= 2) {
      	 	Ans = (Ans + (rsum[i + 2][j] * (sum[i][j] - 1) % mod * f)) % mod;
		 }
	  }
	}
	cout<<Ans<<"\n";
  }
  return 0;
}
