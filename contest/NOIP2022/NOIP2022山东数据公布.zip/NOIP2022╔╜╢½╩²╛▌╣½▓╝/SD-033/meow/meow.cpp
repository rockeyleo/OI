#include<bits/stdc++.h>
using namespace std;
int t,n,m,k,op,c=2,s1,s2,s,a[2000001];
int q[2000010],h,e;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n>>m>>k;
		op=3*k;
		for(int i=1;i<=m;i++)
			cin>>a[i];
		cout<<op<<endl;
		h=1,e=1;
		q[e]=a[1];
		e++;
		cout<<"1 1"<<endl;
		while(c!=m+1){
			while(a[c]!=q[h]){
				q[e]=a[c];
				c++;
				e++;
				cout<<"1 1"<<endl;
				//cout<<c<<" "<<e<<endl;
			}
			h++;
			c++;
			e++;
			//cout<<'c'<<c<<"e"<<e<<endl;
			cout<<"1 2"<<endl;
			cout<<"2 1 2"<<endl;
			
		}
	}
	return 0;
}
