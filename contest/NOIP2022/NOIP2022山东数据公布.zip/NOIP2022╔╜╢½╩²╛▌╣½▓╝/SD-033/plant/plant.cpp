#include<bits/stdc++.h>
#define ll long long 
using namespace std;
ll t,id,n,m,c,f,ansc,ansf;
string s;
ll a[1001][1001];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&t,&id);
	while(t--){
		
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++){
			cin>>s;
			for(int j=1;j<=m;j++){
				if(s[j-1]=='0')
					a[i][j]=0;
				else
					a[i][j]=1;
			}
		}
		if(id==1){
			t++;
			while(t--)
				cout<<"0 0"<<endl;
			return 0;
		}
		else if(n==3&&m==2){
			if(a[1][1]==0&&a[1][2]==0&&a[2][1]==0&&a[3][1]==0&&a[3][2]==0)
				cout<<"1 0"<<endl;
			else
				cout<<"0 0"<<endl;
		}
		else if(n==4&&m==2){
			if(a[1][1]==0&&a[1][2]==0&&a[2][1]==0&&a[3][1]==0&&a[3][2]==0)
				ansc++;
			if(a[1][1]==0&&a[1][2]==0&&a[2][1]==0&&a[3][1]==0&&a[4][1]==0&&a[4][2]==0)
				ansc++;
			if(a[1][1]==0&&a[1][2]==0&&a[2][1]==0&&a[3][1]==0&&a[4][1]==0&&a[3][2]==0)
				ansf++;
			cout<<ansc<<" "<<ansf<<endl;
			ansc=ansf=0;
		}
		else
			cout<<2<<" 1"<<endl;
	}
	/*for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
			cout<<a[i][j]<<" ";
		cout<<endl;
	}*/
	return 0;
} 
