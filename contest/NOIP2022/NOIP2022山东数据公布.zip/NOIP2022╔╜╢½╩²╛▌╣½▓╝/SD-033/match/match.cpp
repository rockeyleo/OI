#include<bits/stdc++.h>
using namespace std;
long long T,n,a[1000010],b[1000010],q,l,r,ma=-1,mb=-1,ans;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d%d",&T,&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	scanf("%d",&q);
	for(int o=1;o<=q;o++){
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				for(int k=i;k<=j;k++){
					if(a[k]>ma)
						ma=a[k];
					if(b[k]>mb)
						mb=b[k];
				}
				ans+=mb*ma;
				ma=mb=-1;
			}
		}
		printf("%d",ans);
		ans=0;
	}
	return 0;
}
