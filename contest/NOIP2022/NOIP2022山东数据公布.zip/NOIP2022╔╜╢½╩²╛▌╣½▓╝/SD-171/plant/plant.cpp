#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
bool a[1010][1010];
ll f[1010][1010];
ll f2[1010][1010];
ll f3[1010][1010];
const ll MOD = 998244353;
void main_arr(){
	memset(f,0,sizeof(f));
	memset(a,0,sizeof(a));
	memset(f2,0,sizeof(f2));
	memset(f3,0,sizeof(f3));
	ll n,m,c,ft;
	cin>>n>>m>>c>>ft;
	for(ll i=1;i<=n;i++){
		string s;
		cin>>s;
		ll l=s.length();
		for(ll j=0;j<l;j++){
			if(s[j]=='1') a[i][j+1]=0;
			else a[i][j+1]=1; 
		}
	}
	if(c==1){
		ll ans=0;
		for(ll i=1;i<=n;i++){
			f2[i][m]=a[i][m];
			f[i][m]=f2[i][m];
			for(ll j=m-1;j>=1;j--){
				if(a[i][j+1]==1&&a[i][j]==1){
					f2[i][j]=f2[i][j+1]+1;
				}else f2[i][j]=a[i][j];
				f[i][j]=f2[i][j];
			}
		}
		for(ll j=1;j<=m;j++){
			f[n][j]--;
			for(ll i=n-1;i>=1;i--){
				if(a[i+1][j]&&a[i][j]){
					f[i][j]+=f[i+1][j]-1;
				}else if(f[i][j]){
					f[i][j]--;
				}else f[i][j]=0;
			}
		}	
		for(ll j=1;j<m;j++){
			for(ll i=1;i<=n-2;i++){
				if(a[i][j]&&a[i+1][j]) ans+=((f[i+2][j]%MOD)*((f2[i][j]-1)%MOD)%MOD),ans%=MOD;
			}
		}
		cout<<ans<<' ';
	}else cout<<0<<' ';
	
	memset(f,0,sizeof(f));
	memset(f2,0,sizeof(f2));
	memset(f3,0,sizeof(f3));
	
	if(ft==1){
		ll ans=0;
		for(ll i=1;i<n;i++){
			f2[i][m]=a[i][m];
			for(ll j=m-1;j>=1;j--){
				if(a[i][j+1]==1&&a[i][j]==1){
					f2[i][j]=f2[i][j+1]+1;
				}else f2[i][j]=a[i][j];
			}
		}
		for(ll j=1;j<m;j++){
			f3[n][j]=a[n][j];
			for(ll i=n-1;i>=1;i--){
				if(a[i+1][j]&&a[i][j]){
					f3[i][j]=f3[i+1][j]+1;
				}else f3[i][j]=a[i][j];
			}
		}
		for(ll j=1;j<=m;j++){
			f[n-1][j]=f2[n-1][j]-1;
			for(ll i=n-2;i>=1;i--){
				if(a[i][j]&&a[i+1][j]){
					f[i][j]=f[i+1][j]+(f2[i][j]-1)*(f3[i][j]-1);
				}else f[i][j]=0;
			}
		}
		for(ll j=1;j<m;j++){
			for(ll i=1;i<=n-3;i++){
				if(a[i][j]&&a[i+1][j]){
					ans+=((f[i+2][j]%MOD)*((f2[i][j]-1)%MOD)%MOD),ans%=MOD;
				}
			}
		}
		cout<<ans<<endl;
		//cal c no line last
	}else cout<<0<<endl;//pts pts more pts
}
ll main_run(){
	ll T,id;
	cin>>T>>id;
	while(T--){
		if(id==0){//get pts
			ll n,m,c,f;
			cin>>n>>m>>c>>f;
			if(n==4){
				string s;
				for(ll i=1;i<=n;i++) cin>>s;
				cout<<"4 2"<<endl;
			}else if(n==6){
				string s;
				for(ll i=1;i<=n;i++) cin>>s;
				cout<<"36 18"<<endl;
			}else{
				string s;
				for(ll i=1;i<=n;i++) cin>>s;
				cout<<"114 514"<<endl;
			}
		}else{
			main_arr();
		}
	}
	return 0;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	main_run();
}
/*
1 0
6 6 1 1
000010
011000
000110
010000
011000
000000*/


