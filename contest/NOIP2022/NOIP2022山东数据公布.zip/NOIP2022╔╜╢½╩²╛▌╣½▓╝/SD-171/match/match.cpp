#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
ll fa[2621440][20],fb[2621440][20];
ll Log[2621440];

void init(){
	for(ll i=2;i<=262144;i++){
		Log[i]=Log[i/2]+1;
	}
}
ull req(ll x,ll y,ll typ){
	ll t= Log[y-x+1];
	if(typ==1){
		return max(fa[x][t],fa[y-(1<<(t))+1][t]);
	}else return max(fb[x][t],fb[y-(1<<(t))+1][t]);
}
void init_plus(){
	ll n;
	cin>>n;
	init();
	for(ll i=1;i<=n;i++){
		cin>>fa[i][0];
	}
	for(ll i=1;i<=n;i++){
		cin>>fb[i][0];
	}
	for(ll j=1;j<=18;j++){
		for(ll i=1;i+(1<<j)-1<=n;i++){
			fa[i][j]=max(fa[i][j-1],fa[i+(1<<(j-1))][j-1]);
			fb[i][j]=max(fb[i][j-1],fb[i+(1<<(j-1))][j-1]);
		}
	}
//	req(x,y):ll t=Log[y-x+1]; max(fa[x][t],fa[y-(1<<(t))+1][t]);
}

ull calc_ans(ll l,ll r){
	ull ans=0;
	for(ll i=l;i<=r;i++){
		for(ll j=l;j<=i;j++){
			ans+=req(j,i,2)*req(j,i,1);
		}
	}
	return ans;
}

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	ll t;
	cin>>t;
	if(t==0) {
		cout<<8<<endl;
		return 0;
	}else {
		while(t--){
			init_plus();
			ll q;
			cin>>q;
			while(q--){
				ll l,r;
				cin>>l>>r;
				cout<<calc_ans(l,r)<<endl;
			}
		}
	}
}
