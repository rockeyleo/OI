#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll MOD= 1000000007;
ll ppow(ll k){
	if(k==1) return 2;
	if(k==0) return 1;
	if(k%2) return 2*((ppow(k/2)%MOD)*(ppow(k/2)%MOD))%MOD;
}

int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n,m;
	ll ans=0;
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
	}
	for(int i=1;i<n;i++){
		//i+1 points
		ans+=((ppow(i+1)-1)%MOD)*(((n-1-i+1))%MOD);
		ans%=MOD;	
	}
	ans+=n;
	ans%=MOD:
	cout<<ans%MOD;
}
