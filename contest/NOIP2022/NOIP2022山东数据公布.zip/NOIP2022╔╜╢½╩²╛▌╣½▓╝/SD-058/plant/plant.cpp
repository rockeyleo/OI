#include<bits/stdc++.h>
using namespace std;
const int N=1005,mod=998244353;
char s[N];
int a[N][N],n,m,c,f;
int pre[N][N],suf[N][N];
int ans1,ans2;
inline int pls(int x,int t) {
	x+=t;if(x>=mod) x-=mod;
	return x;
}
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id; scanf("%d%d",&T,&id);
	while(T--) {
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++) suf[i][j]=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++) pre[i][j]=0;
		ans1=ans2=0;
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++) {
			scanf("%s",s+1);
			for(int j=1;j<=m;j++)
				a[i][j]=s[j]-'0';
		}
		for(int i=1;i<=n;i++) {
			for(int j=m;j>=1;j--) {
				if(a[i][j]) continue;
				suf[i][j]=suf[i][j+1]+1;
			}
		}
		for(int i=n;i>=1;i--) {
			for(int j=1;j<=m;j++) {
				if(a[i][j]) continue;
				pre[i][j]=pre[i+1][j]+1;
			}
		}
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				if(suf[i][j]==0) continue;
				suf[i][j]-=1;int nw=suf[i][j];
				if(suf[i-1][j]==0) continue;
				int a1=suf[i-2][j],a2=pre[i][j]-1;
				suf[i][j]=suf[i-1][j]+suf[i][j];
				a1=(1ll)*a1*nw%mod;
				ans1=pls(ans1,a1);
				ans2=(ans2+(1ll)*a1*a2)%mod;
			}
		}
		cout<<ans1*c<<" "<<ans2*f<<"\n";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
3 0
4 3 1 1
001
010
000
000
6 6 1 1
000010
011000
000110
010000
011000
000000
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

*/
