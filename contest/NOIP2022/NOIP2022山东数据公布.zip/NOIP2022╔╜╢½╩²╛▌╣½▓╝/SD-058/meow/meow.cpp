#include<bits/stdc++.h>
using namespace std;
const int N=305,M=2e6+10;
struct nd {int ps,cl;}st[M];
vector<nd> dc[N*2];
int n,m,k,tp,a[M],sm[N*2];
int vis[N*2],nm[N*2];
int read() {
	int w=0; char x=getchar();
	while(x>'9' || x<'0') x=getchar();
	while(x<='9' && x>='0') w=w*10+x-48,x=getchar();
	return w;
}

void solve() {
	int tot=0;
	for(int i=m;i>=1;i--)
		if(!vis[a[i]]) nm[a[i]]=++tot,vis[a[i]]=1;
	for(int i=1;i<=m;i++) a[i]=nm[a[i]];
}
struct sss {int opt,x,y;};
vector<sss> ans;
int main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T=read();
	while(T--) {
		tp=0; ans.clear();
		for(int i=1;i<=n;i++) dc[i].clear();
		n=read();m=read();k=read();
		for(int i=1;i<=m;i++) {
			int x=read();a[i]=x; vis[a[i]]=0;
		}
		if(k==2*n-1) solve();
		for(int i=1;i<=m;i++) {
			int x=a[i];
			dc[(x+1)/2].push_back((nd){i,x});
		}
		for(int i=1;i<=n;i++) {
			int len=dc[i].size();
			for(int j=0;j<len;j++) {
				if(tp && dc[i][j].cl==st[tp].cl) tp--;
				else st[++tp]=dc[i][j];
			}
			if(tp==0) sm[i]=m+1;
			else sm[i]=st[tp/2+1].ps;
		}
		for(int i=1;i<=m;i++) {
			int x=a[i],id=(x+1)/2;
			if(i<sm[id]) ans.push_back((sss){1,id,0});
			else {
				ans.push_back((sss){1,n,0});
				ans.push_back((sss){2,id,n});
			}
		}
		cout<<ans.size()<<"\n";
		for(auto w:ans) {
			int o=w.opt;
			if(o==1) cout<<w.opt<<" "<<w.x<<"\n";
			else cout<<w.opt<<" "<<w.x<<" "<<w.y<<"\n";
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
