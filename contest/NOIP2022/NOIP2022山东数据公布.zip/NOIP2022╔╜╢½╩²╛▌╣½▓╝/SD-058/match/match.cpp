#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
const int N=3e5+10;
int T,n,m,q,a[N],b[N];
vector<int> dc,tc;
int sta[N],tpa,stb[N],tpb;
struct nd {ull cov,len,sm;}tr[N<<2];
void update(int p) {
	tr[p].sm=tr[p<<1].sm+tr[p<<1|1].sm;
}
void build(int p,int l,int r) {
	tr[p].len=r-l+1;tr[p].sm=0; tr[p].cov=-1;
	if(l==r) return;
	int mid=(l+r)>>1;
	build(p<<1,l,mid);
	build(p<<1|1,mid+1,r);
}
void cover(int p,int t) {
	tr[p].cov=t;tr[p].sm=tr[p].len*t;
}
void spread(int p,int l,int r) {
	if(tr[p].cov==-1) return;
	cover(p<<1,tr[p].cov);
	cover(p<<1|1,tr[p].cov);
	tr[p].cov=-1;
}
void change(int p,int l,int r,int x,int y,int t) {
	if(x<=l && r<=y) {cover(p,t);return;}
	spread(p,l,r);int mid=(l+r)>>1;
	if(x<=mid) change(p<<1,l,mid,x,y,t);
	if(y>mid) change(p<<1|1,mid+1,r,x,y,t);
	update(p);
}
ull ask(int p,int l,int r,int x,int y) {
//	cout<<p<<" "<<l<<" "<<r<<" "<<x<<" "<<y<<"\n";
	if(x<=l && r<=y) return tr[p].sm;
	spread(p,l,r);int mid=(l+r)>>1;ull ans=0;
	if(x<=mid) ans+=ask(p<<1,l,mid,x,y);
	if(y>mid) ans+=ask(p<<1|1,mid+1,r,x,y);
	return ans;
}
ull solve(int n) {
	ull ans=0;
	build(1,1,n);
	tpa=tpb=0;
	for(int i=1;i<=n;i++) {
	//	cout<<i<<"\n";
		while(tpa && dc[i]>dc[sta[tpa]]) tpa--;
		change(1,1,n,sta[tpa]+1,i,dc[i]); sta[++tpa]=i; 
	//	cout<<"!@#";
		while(tpb && tc[i]>tc[stb[tpb]]) tpb--;
		stb[++tpb]=i;
	//	cout<<"#@$@#$%";
		for(int j=1;j<=tpb;j++) {
	//		if(stb[j-1]+1>stb[j]) cout<<"!@#";
			ans+=(ull)(tc[stb[j]])*ask(1,1,n,stb[j-1]+1,stb[j]);
		}
			
	}
	return ans;
}
int main() {
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d%d",&T,&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int j=1;j<=n;j++) scanf("%d",&b[j]);
	scanf("%d",&q);
	for(int i=1;i<=q;i++) {
		int l,r;scanf("%d%d",&l,&r);
//		cout<<l<<" "<<r<<"  ";
	//	cout<<"-----------------";
		dc.clear();tc.clear();
		dc.push_back(0);tc.push_back(0);
		for(int j=l;j<=r;j++) dc.push_back(a[j]);
		for(int j=l;j<=r;j++) tc.push_back(b[j]);
		cout<<solve(r-l+1)<<"\n";
//		cout<<l<<" "<<r<<"\n";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
