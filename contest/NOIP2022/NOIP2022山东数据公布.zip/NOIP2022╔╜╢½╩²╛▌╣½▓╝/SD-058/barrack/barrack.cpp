#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10,mod=1e9+7;
int fir[N],ne[N<<2],to[N<<2],cnt=1;
int Fir[N],Ne[N<<2],To[N<<2],Cnt;
int n,m,sm,pw[N*2];
int read() {
	int w=0; char x=getchar();
	while(x>'9' || x<'0') x=getchar();
	while(x<='9' && x>='0') w=w*10+x-48,x=getchar();
	return w;
}
inline int Min(int x,int y) { return x<y?x:y; }
inline int Max(int x,int y) { return x>y?x:y; }
inline int pls(int x,int t) {
	x+=t;if(x>=mod) x-=mod;
	return x;
}
void add(int x,int y) {
	ne[++cnt]=fir[x];
	fir[x]=cnt;
	to[cnt]=y;
}
void Add(int x,int y) {
//	cout<<x<<" "<<y<<" "<<Cnt<<"\n";
	Ne[++Cnt]=Fir[x];
	Fir[x]=Cnt;
	To[Cnt]=y;
}
int low[N],dfn[N],tg[N<<2],tot;
int w[N<<2];
void dfs(int x) {
	low[x]=dfn[x]=++tot;
	for(int i=fir[x];i;i=ne[i]) {
		int y=to[i];
		if(w[i]) continue;
		w[i]=w[i^1]=1;
		if(!dfn[y]) {
			dfs(y);low[x]=Min(low[x],low[y]);
			if(low[y]>dfn[x]) {
				tg[i]=tg[i^1]=1;
			}
		} else low[x]=Min(low[x],dfn[y]);
	}
}
int cl[N],siz[N];
void Dfs(int x) {
	cl[x]=sm;siz[sm]++;
	for(int i=fir[x];i;i=ne[i]) {
		int y=to[i];
		if(tg[i] || cl[y]) continue;
		Dfs(y);
	}
}
int fa[N],f[N][2],ans,sz[N];
void solve(int x) {
	f[x][1]=pw[siz[x]]-1;f[x][0]=1;
	sz[x]=1;
	int nw=f[x][1],val=1,pl=1;
	for(int i=Fir[x];i;i=Ne[i]) {
		int y=To[i];
		if(y==fa[x]) continue;
		fa[y]=x;solve(y);sz[x]+=sz[y];
		f[x][1]=pls((2ll)*f[x][1]*f[y][0]%mod,(1ll)*f[x][1]*f[y][1]%mod);
		nw=pls((2ll)*nw*f[y][0]%mod,(1ll)*nw*f[y][1]%mod);
		nw=pls(nw,(1ll)*f[y][1]*val%mod);
		nw=pls(nw,mod-(1ll)*f[y][1]*pl%mod);
		val=(1ll)*val*pls(f[y][1],pls(f[y][0],f[y][0]))%mod;
		pl=(1ll)*pl*pls(f[y][0],f[y][0])%mod;
//		if(x==1) cout<<f[x][1]<<" "<<f[y][0]<<" "<<f[y][1]<<"\n";
		f[x][1]=pls(f[x][1],(1ll)*f[x][0]*f[y][1]%mod);
		f[x][0]=(2ll)*f[x][0]*f[y][0]%mod;
	}
//	cout<<"!   "<<nw<<" "<<pw[sm-sz[x]]<<"\n";
//	cout<<"!            "<<nw<<"  "<<f[x][1]<<" "<<sm-sz[x]<<"\n";
	ans=pls(ans,(1ll)*nw*pw[sm-sz[x]]%mod);
}
int main() {
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read();m=read();
//	cout<<n<<" "<<m<<"\n";
	pw[0]=1;for(int i=1;i<=m;i++) pw[i]=pls(pw[i-1],pw[i-1]);
	for(int i=1;i<=m;i++) {
		int x,y;x=read();y=read();
		add(x,y);add(y,x);
	}
	dfs(1);	
	for(int i=1;i<=n;i++) if(!cl[i]) sm++,Dfs(i);
	for(int x=1;x<=n;x++)
		for(int i=fir[x];i;i=ne[i])
			if(cl[x]!=cl[to[i]]) Add(cl[x],cl[to[i]]);
	solve(1);
	cout<<(1ll)*ans*pw[m-sm+1]%mod<<"\n";
	fclose(stdin);
	fclose(stdout);
//	cout<<(1ll)*f[1][1]<<"  "<<pw[m-sm+1]%mod<<"\n";
	return 0;
}
