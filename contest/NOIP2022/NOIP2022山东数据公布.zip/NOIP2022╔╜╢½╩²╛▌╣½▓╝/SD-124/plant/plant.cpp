#include<bits/stdc++.h>
using namespace std;
char s[1010][1010];
int t,n,m,c,f,xx,yy,id,jis,sum;
int xia[1010][1010],you[1010][1010],jl[1010][1010],jl1[1010][1010];
void so1()
{	
		scanf("%d%d%d%d%",&n,&m,&c,&f);
		for(int i=0;i<=n+1;i++)
		{	
			for(int j=0;j<=m+1;j++)
			{
				if(i==0||j==0||i==n+1||j==m+1)
				{
					s[i][j]='1';
				}
				else cin>>s[i][j];
			}
		}
		for(int j=1;j<=m;j++)
		{
			for(int i=0;i<=n+1;i++)
			{
				if(s[i][j]=='1')
				{
					xx=i+1;
					continue;
				}
				xia[xx][j]++;				
			}
		}
		for(int j=1;j<=m;j++)
		{		
			for(int i=0;i<=n;i++)
			{
				if(s[i][j]=='1') 
				{
					xx=i+1; continue;	
				}
				if(xia[xx][j]<3)continue;				
				for(int k=j;k<=m;k++)
				{	
					if(s[i][k]=='1')break;
					you[i][j]++;	
				}
			}
		}	
		for(int j=1;j<=m;j++)
		{
			for(int i=0;i<=n;i++)
			{
				if(s[i][j]=='1') 
				{
					xx=i+1; continue;	
				}
				if(xia[xx][j]<3)continue;
				if(you[xx][j]<2)continue;
				if(you[xx][j-1]>you[xx][j])continue; 
				jl[i][j]=you[i][j]-1;
			}
		}				
	for(int j=1;j<=m;j++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int ll=i+2;ll<=n;ll++)
			{
				sum+=(jl[ll][j]*jl[i][j]);
			}
		}
	}
	for(int j=1;j<=m;j++)
	{
		for(int i=0;i<=n;i++)
		{
			if(s[i][j]=='1') 
			{
				xx=i+1; continue;	
			}
			if(xia[xx][j]<4)continue;
			if(you[xx][j]<2)continue;
			if(you[xx][j-1]>you[xx][j])continue; 
			jl1[i][j]=you[i][j]-1;
		}
	}
	for(int j=1;j<=m;j++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int ll=i+2;ll<=n;ll++)
			{
				for(int lll=ll+1;lll<=n;lll++)
				{
					if(jl1[lll][j]=='1')continue;
					jis+=(jl1[ll][j]*jl1[i][j]);	
				}					
			}		
		}		
	}			
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&t,&id);
		
	for(int tt=1;tt<=t;tt++)
	{	
		if(id==1)
		{
			cout<<"0";
		}
		else 
		{
			so1();cout<<c*sum<<" "<<f*jis;	
		}
	}
	fclose(stdin);
	fclose(stdout);	
	return 0;
 } 
