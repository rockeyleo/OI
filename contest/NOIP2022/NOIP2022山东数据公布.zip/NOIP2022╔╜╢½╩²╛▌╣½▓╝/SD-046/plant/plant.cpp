#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll  n,m,c,f,T,id;
int a[1010][1010],b=0,ans=0;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	cin>>n>>m>>c>>f;
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=m;j++)
	{
		cin>>a[i][j];
	}
	
	for(int i=1;i<=n;i++)
		{
			while(a[i][j]=0)
			b++;
		}
	if(b>=2&&a[i+1][j+1]!=1)
		{
			(j=1;j<=m;j++)
			while(a[i][j]=0)
			{
				ans=ans+(i-1)*(j-1);
			}
		}
	
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	
	return 0;
	
}
