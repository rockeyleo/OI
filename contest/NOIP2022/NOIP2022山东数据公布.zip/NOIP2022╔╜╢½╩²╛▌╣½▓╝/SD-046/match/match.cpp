#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll  T,n,Q,ans=0,a[100005],b[100005],c[1000];
int main()
{
	cin>>T>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int j=1;j<=n;j++)
	{
		cin>>b[j];
	}
	cin>>Q;
	for(int h=1;h<=Q;h++)
	{
		cin>>c[h];
	}
	
	return 0;
}
