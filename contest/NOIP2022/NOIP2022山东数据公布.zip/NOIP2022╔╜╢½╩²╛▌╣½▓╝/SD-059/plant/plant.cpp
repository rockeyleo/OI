// Pts 64
// sto lixp orz
#include <bits/stdc++.h>
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#define int long long
#define MOD 998244353
#define MAX_SIZE (int)1.1e3
using namespace std;
namespace Larry76{
	bool orimap[MAX_SIZE][MAX_SIZE];
	signed C[MAX_SIZE][MAX_SIZE];
	signed F[MAX_SIZE][MAX_SIZE];
	int n,m,c,f;
	typedef pair<int,int> pii;
	void prepare(){
		for(int i=1;i<=n;i++)
			for(int j=m;j>=1;j--)
				if(orimap[i][j])
					C[i][j] = C[i][j+1] + orimap[i][j];

		for(int i=n;i>=1;--i)
			for(int j=1;j<=m;j++)
				if(orimap[i][j])
					F[i][j] = F[i+1][j] + orimap[i][j];
	}
	pii getans(){
		int ans = 0,cans = 0,Cans = 0,Fans = 0;
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				cans ^= cans;
				if(C[i][j]>1){
					if(!C[i+1][j]||i+1==n)
						continue;
					for(int k=i+2;k<=n;++k){
						if(!C[k][j])
							break;
						if(C[k][j]==1)
							continue;
						if(C[k][j]>=2)
							cans += ((C[i][j]-1)%MOD) * ((C[k][j]-1)%MOD) %MOD;
						ans += cans%MOD * ((F[k][j]-1)%MOD) %MOD;
						ans %= MOD;
						Cans += cans;
						Cans %= MOD;
						cans ^= cans;
					}
				}
			}
		}
		Fans = ans;
		return {Cans,Fans};
	}
	void work(){
		memset(C,0,sizeof(C));
		scanf("%lld%lld%lld%lld",&n,&m,&c,&f);
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				char buffer;
				scanf("%c",&buffer);
				if(buffer=='\n'){
					--j;
					continue;
				}
				bool buf = buffer - '0';
				orimap[i][j] = !buf;
			}
		}
		prepare();
		pii ans = getans();
		printf("%lld %lld\n",ans.first*c,ans.second*f);
	}
	int main(){
		//Code Here
		int T,id;
		scanf("%lld%lld",&T,&id);
		if(id==1){
			while(T--)
				cout<<0<<' '<<0<<endl;
			return 0;
		} else if(id==6){
			int n,m,c,f;
			int cans;
			char buffer = 0;
			while(T--){
				cans ^= cans;
				scanf("%lld%lld%lld%lld",&n,&m,&c,&f);
				for(int i=1;i<=n;++i)
					for(int j=1;j<=m+1;++j)
						scanf("%c",&buffer);
				for(int i=1;i<=n-n%4;i+=4){
					for(int j=m;j>=1;--j){
						cans += (j-1)%MOD * ((j-1)%MOD) %MOD;
						cans %= MOD;
					}
				}
				printf("%lld 0\n",cans%MOD*c);
			}
			return 0;
		}
		while(T--)
			work();
		return 0;
	}
}
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
#ifdef LOCAL
	freopen("in.in","r",stdin);
	freopen("out.out","w",stdout);
	time_t cs = clock();
#endif
/////////////////////////////////////
	int retcode = Larry76::main();
/////////////////////////////////////
#ifdef LOCAL
	time_t ce = clock();
	cerr<<"The Main Program Used Time: "<<ce-cs<<" ms."<<endl;
	return retcode;
#endif
	return 0;
}

