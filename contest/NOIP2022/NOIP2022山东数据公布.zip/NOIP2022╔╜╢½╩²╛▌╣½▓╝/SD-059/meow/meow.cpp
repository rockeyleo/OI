#include <bits/stdc++.h>
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#define int long long
#define MAX_SIZE (int)2.1e6
#define MAX_RANGE (int)700 
using namespace std;
namespace Larry76{
	int seq[MAX_SIZE];
	int n,m,k;
	int wm[MAX_RANGE];
	bool matched[MAX_SIZE];
	int matchpos[MAX_SIZE];
	void getMatch(){
		int now = 0;
		for(int i=1;i<=m;++i){
			now = seq[i];
			if(!(~wm[now])){
				wm[now] = i;
			} else {
				matched[i] = true;
				matchpos[wm[now]] = i;
				wm[now] = -1;
			}
		}
	}
	deque <int> sta[4];
	short where[MAX_RANGE];
	vector<string>ans;
	void getOperator(){
		int now = 1;
		bool xiao = 0;
		ostringstream oss;
		for(int i=2;i<=m;++i){
			if(!matched[i]){
				if(xiao){
					oss<<1<<' '<<now;
					ans.push_back(oss.str());
					oss.str("");
//					printf("1 %lld\n",now);
					sta[now].push_front(i);
					where[seq[i]] = now;
					continue;
				}
				int top = sta[now].front();
				if(matchpos[top]<matchpos[i]){
					now ++;
					if(now>2)
						now %= 2;
				}
				oss<<1<<' '<<now;
				ans.push_back(oss.str());
				oss.str("");
				where[seq[i]] = now;
				sta[now].push_front(i);
				continue;
			} else {
				int w = where[seq[i]];
				now = w;
				xiao = true;
				int top = sta[w].front();
				int bottom = sta[w].back();
				
				if(seq[top]==seq[i]){
					oss<<1<<' '<<now;
					ans.push_back(oss.str());
					oss.str("");
					sta[w].pop_front();
				} else if(seq[bottom] == seq[i]) {
					oss<<1<<' '<<3;
					ans.push_back(oss.str());
					oss.str("");
					oss<<2<<' '<<w<<' '<<3;
					ans.push_back(oss.str());
					oss.str("");
					sta[w].pop_back();
				} else{
					fprintf(stderr,"error");
					assert(1!=1);
				}
			}
		}
	}
	void work(){
		memset(wm,-1,sizeof(wm));
		memset(matchpos,0,sizeof(matchpos));
		ans.clear();
		scanf("%lld%lld%lld",&n,&m,&k);
		for(int i=1;i<=m;++i)
			scanf("%lld",&seq[i]);
		getMatch();
		if(k==2){
			printf("%lld\n",m);
			for(int i=1;i<=m;++i)
				printf("1 %lld\n",seq[i]);
			return;
		} else if(k==3){
			for(int i=1;i<=m;++i){
				if(!matched[i]){
					ans.push_back("1 1");
					sta[1].push_front(seq[i]); 
				} else {
					if(sta[1].front() == seq[i]){
						ans.push_back("1 1");
						sta[1].pop_front();
					}
					else{
						ans.push_back("1 2");
						ans.push_back("2 1 2");
						sta[1].pop_back();
					}
				}
			}
			printf("%lld\n",ans.size());
			for(auto s:ans)
				printf("%s\n",s.c_str());
			return;
		}
		sta[1].push_front(1);
		ans.push_back("1 1");
		where[seq[1]] = 1;
		getOperator();
		printf("%lld\n",ans.size());
		for(auto s:ans){
			printf("%s\n",s.c_str());
		}
	}
	int main(){
		//Code Here
		int T;
		scanf("%lld",&T);
		while(T--)
			work();
		return 0;
	}
}
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
#ifdef LOCAL
	freopen("in.in","r",stdin);
	freopen("out.out","w",stdout);
	time_t cs = clock();
#endif
/////////////////////////////////////
	int retcode = Larry76::main();
/////////////////////////////////////
#ifdef LOCAL
	time_t ce = clock();
	cerr<<"The Main Program Used Time: "<<ce-cs<<" ms."<<endl;
	return retcode;
#endif
	return 0;
}

/*
1
4 20 7
1 1 2 3 7 2 1 4 3 5 3 2 4 7 2 6 3 6 1 5
*/

