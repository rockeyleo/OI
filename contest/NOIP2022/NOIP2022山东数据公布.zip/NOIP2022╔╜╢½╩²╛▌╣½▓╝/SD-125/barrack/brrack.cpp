#include<iostream>

using namespace std;

int main()
{
	int n,m;
	int t;
	cin >>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin >> t;
		t+=t;
	}
	cout << (t+1)/2;
	return 0;
}
