#include<iostream>
#include<cstring>
#include<cstdio>

using namespace std;

int t,id,n,m,c,f;
int a[1001][1001];
int ans;

string lin;

int isc(int a[1001][1001])
{
	int cs=0;
	int l1=0;
	int l2=0;
	
	for(int x=1;x<m;x++)
	{
		int y1=1;
		int y2=3;
		for(int h=3;y1+h-1<n;h++)
		{
			bool lt = false;
			for(;y1<n;)
			{
				if(a[x+1][y1]==0) l1++;
				y1++;
			}
			for(;y2<=n;)
			{
				if(a[x+1][y2+h]==0) l2++;
				y2++;
			}
			for(int p=y1;p<=y2+h;p++)
			{
				if(a[x][p]==1) break;
				else
				{
					lt = true;
				}
			}
			if(lt)
			{
				cs += (l1-l2)*l2;
			}
		}
	}

	return cs;
}

int main()
{
	memset(a,0,sizeof(a));
	
	cin >> t >> id;
	for(int i=0;i<t;i++)
	{
		cin >> n >> m >> c >> f;
		for(int i=1;i<=n;i++)
		{
			cin >> lin;
			for(int j=1;j<=m;j++)
		 	{
		 		a[i][j] = lin[j-1]-'0'-0;
		 	}
		}
	}
	
	ans = (isc(a) * c)%998244353;
	cout << ans;
	return 0;
}
