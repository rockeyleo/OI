#include<bits/stdc++.h>
#define maxn 1010
#define ll long long
#define lson k << 1
#define rson k << 1 | 1
using namespace std;
const int mod = 998244353;
int read(){
	int x = 0, f = 1; char c = getchar();
	while(c > '9' || c < '0'){if(c == '-')f = -1; c = getchar();}
	while(c >= '0' && c <= '9'){x = x * 10 + (c - '0'); c = getchar();}
	return x * f;
}
int T, id, n, m, c, f, xia[maxn][maxn], you[maxn][maxn], sum[maxn][maxn], cnt[maxn][maxn], ansc, ansf;
char a[maxn][maxn];
int main(){
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T = read(), id = read();
	while(T --){
		n = read(), m = read(), c = read(), f = read();
		for(int i = 1; i <= n; i ++){
			cin >> a[i] + 1;
			for(int j = m; j >= 1; j --){
				if(a[i][j] == '1')you[i][j] = 0;
				else {
					if(j == m || a[i][j + 1] == '1')you[i][j] = 0;
					else you[i][j] = you[i][j + 1] + 1;
				}
			}
		}
		for(int i = 1; i <= m; i ++){
			for(int j = n; j >= 1; j --){
				if(a[j][i] == '1')xia[j][i] = 0;
				else {
					if(j == n || a[j + 1][i] == '1')xia[j][i] = 0;
					else xia[j][i] = xia[j + 1][i] + 1;
				}
			}
			for(int j = 1; j <= n; j ++){
//				if(you[j][i] == 0)continue;
				sum[j][i] = sum[j - 1][i] + you[j][i]; 
//				if(xia[j][i] == 0)continue;
				cnt[j][i] = (cnt[j - 1][i] + (you[j][i] * xia[j][i])) % mod;
			}
		}
		for(int i = 1; i <= n; i ++){
			for(int j = 1; j <= m; j ++){
				if(xia[i][j] < 2 )continue;
				ansc = (ansc + you[i][j] * (sum[i + xia[i][j]][j] - sum[i + 1][j])) % mod;
				ansf = (ansf + you[i][j] * (cnt[i + xia[i][j]][j] - cnt[i + 1][j])) % mod;
//				ansf += you[i][j] * (sum[i + xia[i][j]][j] / max(sum[i + 1][j], 1)) * xia[i][j];
			}
		} 
		if(!c)ansc = 0;
		if(!f)ansf = 0;
		cout << (ansc + mod) % mod << " " << (ansf + mod) % mod << '\n'; 
	}
	return 0;
}
/*
1 0
4 3 1 1
001
010
000
000
*/
