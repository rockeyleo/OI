#include<bits/stdc++.h>
#define maxn 1010
#define ll long long
#define lson k << 1
#define rson k << 1 | 1
using namespace std;
int read(){
	int x = 0, f = 1; char c = getchar();
	while(c > '9' || c < '0'){if(c == '-')f = -1; c = getchar();}
	while(c >= '0' && c <= '9'){x = x * 10 + (c - '0'); c = getchar();}
	return x * f;
}
int T, n, m, k, a[maxn];
int main(){
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	T = read();
	while(T --){
		n = read(), m = read(), k = read();
		for(int i = 1; i <= m; i ++){
			a[i] = read();
		}
		if(m <= 14 && T == 3){
			int d[maxn], vis[maxn], sum[100], cnt[300]; 
			for(int i = 1; i <= m; i ++){
				sum[a[i]] ++;
			}
			int tot = 0;
			for(int i = 1; i <= k; i ++){
				if(sum[i])cnt[++ tot] = i;				
			}
			if(tot == 1){
				for(int i = 1; i <= m; i ++){
					cout << 1 << " " << 1 << '\n';
				}
			}
			if(tot == 2){
				for(int i = 1; i <= m; i ++){
					if(a[i] == cnt[1]){
						cout << 1 << " " << 1 <<'\n';
					}
					else cout << 1 << " " << 2 << '\n';
				}
			}
			if(tot == 3){
				for(int i = 1; i <= m; i ++){
					if(a[i] == cnt[1]){
						cout << 1 << " " << 1 <<'\n';
					}
					else if(a[i] == 2)cout << 1 << " " << 2 << '\n';
					else cout << 1 << " " << 3 << '\n';
				}
			}
		} 
		else if(n == 2 && k == 3 || n == 3){
			int i = 1;
			int yi[maxn], er[maxn], h1, t1, h2, t2;
			for(int i = 1; i <= m; i ++){
				if(a[i] == yi[t1]){
					cout << 1 << " " << 1 << '\n';
					t1 --;
				}
				else if(a[i] == er[t2]){
					cout << 1 <<" " << 2 << '\n';
					t2 --;
				}
				else {
					if(t1 - h1 < t2 - h2){
						yi[++ t1] = a[i];
					}
					else er[++ t2] = a[i];
				}
				if(yi[h1] == er[h2] && h1 && h2){
					cout << 2 << " " << 1 << " " << 2 << '\n';
					h1 ++, h2 ++;
				} 
			}
		}
	}
//	cout << n; 
	return 0;
}

