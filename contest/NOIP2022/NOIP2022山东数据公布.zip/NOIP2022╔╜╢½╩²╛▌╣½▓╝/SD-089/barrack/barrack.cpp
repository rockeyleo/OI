#include<bits/stdc++.h>
#define maxn 1000010
#define ll long long
#define lson k << 1
#define rson k << 1 | 1
using namespace std;
const int mod = 1e9 + 7;
int read(){
	int x = 0, f = 1; char c = getchar();
	while(c > '9' || c < '0'){if(c == '-')f = -1; c = getchar();}
	while(c >= '0' && c <= '9'){x = x * 10 + (c - '0'); c = getchar();}
	return x * f;
}
int n, m, head[maxn], tot, ans, vis[maxn], vm[maxn], all, flag = 1;
struct node{
	int t, nex;
}e[maxn << 1];
void add(int u, int v){
	e[++ tot].t = v;
	e[tot].nex = head[u];
	head[u] = tot;
}
void jia(int u, int fa, int sum){
	if(!flag)return ;
	if(all == sum){
		ans ++;
		flag = 0;
		return ;
	} 
	for(int i = head[u]; i; i = e[i].nex){
		if(! vm[i])continue;
		int v = e[i].t;
		if(v == fa)continue;
		if(vis[v])all ++;
		if(all == sum){
			ans ++;
			flag = 0;
			return ;
		}
		jia(v, u, sum);
		if(!flag) return ;
	}
} 
void check(int sum){
	all = 0;
	for(int i = 1; i <= n; i ++){
		if(vis[i] && !head[i])all ++;
	}
	for(int i = 1; i <= n; i ++){
		if(vis[i]){
			all ++;
			flag = 1;
			jia(i, 0, sum);
			return;
		}
	}
}
void dfsbian(int sum, int dian, int bian){
	if(bian == sum){
		check(dian);
		return ; 
	}
	for(int i = 1; i <= tot; i += 2){
		if(!vm[i]){
			vm[i] = vm[i + 1] = 1;
			dfsbian(sum, dian, bian + 1);
			vm[i] = vm[i + 1] = 0;
		}
	}
} 
void dfsdian(int sum, int dian){
	if(sum == dian){
		for(int i = 1; i <= n; i ++){
			if(vis[i])cout << i << " ";
		}
		puts(" ");
		for(int i = 0; i * 2 <= tot; i += 2){
			dfsbian(i, sum, 0);
			ans %= mod;
		}
		return ;
	}
	for(int i = 1; i <= n; i ++){
		if(!vis[i]){
			vis[i] = 1;
			dfsdian(sum, dian + 1);
			vis[i] = 0;
		}
		if(i == n)return ;
	}
	return ;
} 
int main(){
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	n = read(), m = read();
//	tot = n;
	for(int x, y, i = 1; i <= m; i ++){
		x = read(), y = read();
		add(x, y);
		add(y, x);
	}
	for(int i = 1; i < n; i ++){
//		for(int j = 0; j * 2 <= tot; j ++){
			dfsdian(i, 0);
//		}
	}
//	puuts("dskfhlas")
	cout << ans + 1; 
	return 0;
}

