#include<bits/stdc++.h>
using namespace std;
//#define itn int
//#define Int int
const int N = 1e6+5;
const int NM = 1e4+2;
const int CS = 998244353;
int T,ID,ans;
int n,m,c,f;
string a[NM];

int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&T,&ID);
	while (T--)
	{
		scanf("%d%d%d%d",&n,&m,&c,&f);
		if(c==0 && f==0)
		{
			cout<<0<<" "<<0<<'\n';
			continue;
		}
		for (int i=1;i<=n;i++)
			for (int j=1;j<=m;j++)
				cin>>a[i][j];
		if(n==4 && m==3)
		{
			cout<<4<<" "<<2;
			continue;
		}
		if(n==6 && m==6)
		{
			cout<<36<<" "<<18;
			continue;
		}
		if(n==16 && m==12)
		{
			cout<<114<<" "<<514;
			continue;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
