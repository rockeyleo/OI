#include<bits/stdc++.h>
using namespace std;
const int N = 1e6+5;
int T,n,m,k;
int A[N];
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d%d%d",&n,&m,&k);
		for (int i=1;i<=m;i++)
			scanf("%d",&A[i]);
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
