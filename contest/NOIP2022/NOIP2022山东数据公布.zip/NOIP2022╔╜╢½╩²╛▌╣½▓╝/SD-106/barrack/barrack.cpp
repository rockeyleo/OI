#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <vector>
#include <stack>
#include <queue>
#include <set>
using namespace std;

void fre1(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
}
void fre2(){
	fclose(stdin);
	fclose(stdout);
}
int n,m;
int dnf[501];
int low[501];
int pp;
vector<int> A[501000];
int root=1;
bool biao[501000];
int ge;
int l;
int qw=1000000007;
void dfs(int x,int w){
	pp++;
	dnf[x]=pp;
	low[x]=pp;
	
	for(unsigned i=0;i<A[x].size();i++){
		int y=A[x][i];
		if(y==w) continue;
		
		if(!dnf[y]){
			dfs(y,x);
			low[x]=min(low[x],low[y]);
		}
		else {
			low[x]=min(low[x],dnf[y]);

		}
		if(low[y]>low[x]){
			l+=1;
		}	
	
	}
}
int kuai(int x,int y){
	int f=1;
	while(y>1){
		if(y%2!=0) f=f*x;
		y=y/2;
		x=x*x;
	}
	return x*f;
}
int FF[200][200][150];
int ddd(int x,int y,int p){
	if(p==0){
		FF[x][y][p]=(kuai(2,y)*(kuai(2,x)-1))%qw;
		return FF[x][y][p]%qw;
	}
	return FF[x][y][p]=(ddd(x,y,p-1)-ddd(x-1,y-1,p-1))%qw;
}

void suan(){
	int zong=0;

	cout<<ddd(n,m,l)<<endl;
	return;
}

int main(){
	fre1();
	
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int a,b;
		cin>>a>>b;
		A[a].push_back(b);
		A[b].push_back(a);
	}
	dfs(1,0);
	suan();
	
	fre2();
	return 0;
}
