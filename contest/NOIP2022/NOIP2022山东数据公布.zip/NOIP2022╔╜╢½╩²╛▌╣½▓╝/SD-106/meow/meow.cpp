#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <vector>
#include <stack>
#include <queue>
#include <set>
using namespace std;

void fre1(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
}
void fre2(){
	fclose(stdin);
	fclose(stdout);
}






int t;
int n,m,k;
int A[3000];
int B[3000];
int Q[3000];
int hq;
int tq;
int ha,ta,hb,tb;
int biao[3000];
vector<int> F;
int main(){
	fre1();
	
	cin>>t;
	for(int i=1;i<=t;i++){
		
		cin>>n>>m>>k;
		hq=1;
		tq=m;
		cout<<m<<endl;
		int l=0;
		for(int o=1;o<=m;o++){
			cin>>Q[o];
			if(Q[o]==1){
				cout<<"1 1"<<endl;
			}
			if(Q[o]==2){
				cout<<"1 2"<<endl;
			}
			if(Q[o]==3){
				l++;
				l=l%2;
				cout<<"1 "<<l<<endl;
			}
			
		}
	
		
		
		
	}
	
	
	fre2();
	return 0;
}
