#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <vector>
#include <stack>
#include <queue>
#include <set>
using namespace std;

void fre1(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
}
void fre2(){
	fclose(stdin);
	fclose(stdout);
}

int A[1010][1010];
int B[1010][1010];
char book[1010][1010];
long long int n,m;
long long int c1,f1;
long long int che;
long long int fhe;
void dfs(int x,int y){
	
	for(int o=x;o<n;o++){
		if(book[o][y]=='1')continue;
		if(book[o+1][y]=='1') continue;
		for(int i=o+2;i<=n;i++){
			if(book[i][y]=='1')break;
			long long int l=((A[o][y]-1)%998244353)*((A[i][y]-1)%998244353)%998244353;
			che=(che+l)%998244353;
			fhe=(fhe+l*((B[i][y]-1)%998244353)%998244353)%998244353;
		}
			
	}

	
}
long long int t,id;

int main(){
	
	fre1();
	cin>>t>>id;
	
	for(int q=1;q<=t;q++){
		cin>>n>>m>>c1>>f1;
		che=0;
		fhe=0;
		for(int i=1;i<=n+1;i++) {
			for(int o=1;o<=m+1;o++){
				A[i][o]=0;
				B[i][o]=0;
			}
		}
		
		
		for(int i=1;i<=n;i++){
			for(int o=1;o<=m;o++){
				cin>>book[i][o];
				if(book[i][o]=='0') continue;
				for(int p=o-1;p>=1;p--){
					if(book[i][p]=='1')break;
					A[i][p]=1+A[i][p+1];
				}
				for(int p=i-1;p>=1;p--){
					if(book[p][o]=='1')break;
					B[p][o]=B[p+1][o]+1;
				}
			}
		}
		for(int i=1;i<=m;i++){
			for(int p=n;p>=1;p--){
				if(book[p][i]=='1') break;
				B[p][i]=B[p+1][i]+1;
			}
		}
		for(int i=1;i<=n;i++){
			for(int o=m;o>=1;o--){
				if(book[i][o]=='1')break;
				A[i][o]=A[i][o+1]+1;
			}
		}	
//		for(int i=1;i<=n;i++){
//		for(int o=1;o<=m;o++){
//			cout<<A[i][o]<<" ";
//		}
//		cout<<endl;
//	}
		for(int i=1;i<=m;i++){
			dfs(1,i);
		}
		cout<<(che*c1)%998244353<<endl;
		cout<<(fhe*f1)%998244353<<endl;
	
	
	}



	fre2();
	return 0;
}
