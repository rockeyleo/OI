#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <vector>
#include <stack>
#include <queue>
#include <set>
using namespace std;

void fre1(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
}
void fre2(){
	fclose(stdin);
	fclose(stdout);
}


int t,n,q;
struct z{
	int da;
};z F[1700000];
int A[1000010];


void up(int x){
	F[x].da=max(F[x*2].da,F[x*2+1].da);
}

void gai(int x,int l,int r,int l1,int r1,int d){
	if(l==l1 && r==r1){
		F[x].da=d;
		return;
	}
	int mid=(l+r)>>1;
	if(r1<=mid) gai(x*2,l,mid,l1,r1,d);
	else if(mid<l1) gai(x*2+1,mid+1,r,l1,r1,d);
	else {
		gai(x*2,l,mid,l1,mid,d);
		gai(x*2+1,mid+1,r,mid+1,r1,d);
	}
	up(x);
//	cout<<l1<<" "<<r1<<" "<<F[x].da<<endl;
}

int cha(int x,int l,int r,int l1,int r1){
	if(l==l1 && r==r1){
//		cout<<F[x].da<<endl;
		return F[x].da;
	}
	int mid=(l+r)>>1;
	if(r1<=mid) return cha(x*2,l,mid,l1,r1);
	else if(mid<l1) return cha(x*2+1,mid+1,r,l1,r1);
	else {
		return max(cha(x*2,l,mid,l1,mid),cha(x*2+1,mid+1,r,mid+1,r1));
	}

}

int suan(int l,int r){
	int he=0;
	for(int i=l;i<=r;i++){
		for(int o=i;o<=r;o++){
//			cout<<i<<" "<<o<<endl;
			int d=cha(1,1,2*n,i,o)*cha(1,1,2*n,i+n,o+n);
			he+=d;
//			cout<<d<<endl;
		}
	}
	return he;
	
}

int main(){
	
	fre1();
	cin>>t>>n;
	if(t==0 && n==3000){
		
	}
	for(int i=1;i<=n;i++){
		cin>>A[i];
		gai(1,1,2*n,i,i,A[i]);
	}
	for(int i=1;i<=n;i++){
		cin>>A[n+i];
		gai(1,1,2*n,i+n,i+n,A[i+n]);
	}
	
	cin>>q;
	for(int i=1;i<=q;i++){
		int a,b;
		cin>>a>>b;
//		cout<<cha(1,1,2*n,3,3)<<endl;
		cout<<suan(a,b)<<endl;
		
		
	}
	
	
	fre2();
	return 0;
}
