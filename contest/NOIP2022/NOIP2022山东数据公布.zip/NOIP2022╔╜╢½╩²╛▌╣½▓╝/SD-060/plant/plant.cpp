#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,c,f;
const int N=1010,mod=998244353;
int a[N][N];
int r[N][N];//ÿ������������ĳ���
int d[N][N];//ÿ�����������쳤�� 
int p[N][N];//ÿ���������������-1���������������-1 
int s[N][N];//ÿ�������µ���һ���ϰ�֮���rij-1�ĺ�;��f��ʱ��Ϊpij�ĺ� 
char S[N];
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,qwq;
	cin>>T>>qwq;
	while(T--){
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			scanf("%s",S+1);
			for(int j=1;j<=m;j++)
				a[i][j]=S[j]-'0';
		}
		for(int i=n;i>=1;i--){
			for(int j=m;j>=1;j--){
				r[i][j]=0;
				d[i][j]=0; 
				if(a[i][j])
					continue;
				r[i][j]=1;
				d[i][j]=1;
				if(j!=m&&a[i][j+1]==0)
					r[i][j]+=r[i][j+1];
				if(i!=n&&a[i+1][j]==0)
					d[i][j]+=d[i+1][j];
				p[i][j]=(r[i][j]-1)*(d[i][j]-1)%mod; 
			}
		}
		int ansc=0,ansf=0;
		for(int i=n;i>=1;i--){
			for(int j=m;j>=1;j--){
				s[i][j]=0;
				if(a[i][j])
					continue;
				s[i][j]=r[i][j]-1;
				if(i!=n)
					s[i][j]=(s[i][j]+s[i+1][j])%mod;
				if(i<=n-2&&a[i+1][j]==0&&a[i+2][j]==0)
					ansc=(ansc+(r[i][j]-1)*(s[i][j]-(r[i][j]-1)-(r[i+1][j]-1)+mod+mod)%mod)%mod;
			}
		}
		for(int i=n;i>=1;i--){
			for(int j=m;j>=1;j--){
				s[i][j]=0;
				if(a[i][j])
					continue;
				s[i][j]=p[i][j];
				if(i!=n)
					s[i][j]=(s[i][j]+s[i+1][j])%mod;
				if(i<=n-2&&a[i+1][j]==0&&a[i+2][j]==0)
					ansf=(ansf+(r[i][j]-1)*(s[i][j]-p[i][j]-p[i+1][j]+mod+mod)%mod)%mod;
			}
		}
		/*for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++)
				cout<<r[i][j]<<' ';
			cout<<'\n';
		}
		cout<<'\n';
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++)
				cout<<s[i][j]<<' ';
			cout<<'\n';
		}*/
		cout<<(ansc*c%mod+mod)%mod<<' '<<(ansf*f%mod+mod)%mod;
	}
}
