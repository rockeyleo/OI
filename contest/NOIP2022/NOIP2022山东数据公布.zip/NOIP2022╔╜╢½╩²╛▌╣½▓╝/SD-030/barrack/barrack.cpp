#include<bits/stdc++.h>
using namespace std;
const int MOD=1e9+7;
int read()
{
	int num=0,fu=1;
	char cr=getchar();
	while(cr<'0' || cr>'9') {if(cr=='-') fu=-1;cr=getchar();}
	while(cr>='0' && cr<='9') {num=(num<<1)+(num<<3)+cr-'0';cr=getchar();}
	return num*fu;
}

const int N=5e5+10;
const int M=1e6+10;
struct EDGE{
	int u,v,next,ex;
}edge[M<<1];
int cnt=1,head[N];
inline void add(int u,int v)
{
	edge[++cnt]=(EDGE){u,v,head[u],1};
	head[u]=cnt;
}
int n,m;
int xl[N],ex_b[M],vis[N];							//��Ӫ�ı�ţ� i�Ƿ�Ϊ�������� 
inline void DFS(int u)
{
	vis[u]=1;
	for(register int i=head[u]; i; i=edge[i].next)
	{
		if(edge[i].ex==0) continue;
		int v=edge[i].v;
		if(vis[v]) continue;
		DFS(v);
	}
}
int ans=0;
inline void Check(int mid, int pz,int num,int num_jy)		//���mid���������Ƿ������ͨ  ��ö�ٱ����� 
{
	if(num==mid)
	{
		for(register int i=1; i<=m; i++)
		{
			if(ex_b[i]) continue;
			edge[i*2].ex=0;
			edge[(i*2+1)^1].ex=0;
			for(int j=1; j<=n; j++) vis[j]=0;
			DFS(xl[1]);
			edge[i*2].ex=1;
			edge[(i*2+1)^1].ex=1;
			for(int j=1; j<=num_jy; j++)
				if(vis[xl[j]]==0)
			 		return;	//���� 1���ж� �޷���ͨ 
		}
		ans+=1;
		if(ans>=MOD) ans-=MOD;
		return;
	}
	if(pz==m+1) return;
	Check(mid, pz+1, num, num_jy);
	ex_b[pz]=1;
	Check(mid, pz+1, num+1, num_jy);
	ex_b[pz]=0;
} 
inline void Solve(int tar)	//��Щ��Ӫ���ж����ַ��� 
{
	for(int i=0; i<=m; i++)		//ö�ٱ�������Ŀ 
		Check(i, 1, 0, tar);
}
inline void ZH(int pz,int num, int tar)
{
	if(num==tar)
	{
		Solve(tar);
		return;
	}
	if(pz==n+1)
		return;
	ZH(pz+1, num, tar);
	xl[num+1]=pz;
	ZH(pz+1, num+1, tar);
	xl[num+1]=0;
}

int main()
{
//	freopen("in��.in","r",stdin);
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	
	n=read(),m=read();
	for(register int i=1; i<=m; i++)
	{
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	for(register int i=1; i<=n; i++)				//��Ӫ�ĸ��� 
	{
		ZH(1, 0, i);
	}
	cout<<ans<<endl; 
	
	return 0;
}
