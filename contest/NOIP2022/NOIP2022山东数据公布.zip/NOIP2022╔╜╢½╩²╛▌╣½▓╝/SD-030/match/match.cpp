#include<bits/stdc++.h>
#define int unsigned long long
using namespace std;
const int N=2.5e5+10;
inline int read()
{
	int num=0,fu=1;
	char cr=getchar();
	while(cr<'0' || cr>'9') {if(cr=='-') fu=-1;cr=getchar();}
	while(cr>='0' && cr<='9') {num=(num<<1)+(num<<3)+cr-'0';cr=getchar();}
	return num*fu;
}
int a[N],b[N];
int T,n;
int Q;
int ans=0;

signed main()
{
//	freopen("in��.in","r",stdin);
//	freopen("out.out","w",stdout);
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	
	T=read();
	n=read();
	for(int i=1; i<=n; i++) a[i]=read();
	for(int i=1; i<=n; i++) b[i]=read();
	Q=read();
	while(Q--)
	{
		int l=read(),r=read();
		ans=0;
		for(register int ll=l; ll<=r; ll++)
		{
			int mxa=0,mxb=0;
			for(register int rr=ll; rr<=r; rr++)
			{
				mxa=max(mxa, a[rr]);
				mxb=max(mxb, b[rr]);
				ans= (mxa*mxb)+ans;
			}
		}
		printf("%llu\n",ans);
	}
	
	return 0;
}
