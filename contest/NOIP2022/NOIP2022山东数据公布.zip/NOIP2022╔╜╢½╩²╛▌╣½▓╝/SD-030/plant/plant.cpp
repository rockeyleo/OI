#include<bits/stdc++.h>
using namespace std;								//��������Ķ��� �õĶ��� 
const int N=1e3+10;
const int MOD=998244353;

inline int read()
{
	int num=0,fu=1;
	char cr=getchar();
	while(cr<'0' || cr>'9') {if(cr=='-') fu=-1;cr=getchar();}
	while(cr>='0' && cr<='9') {num=(num<<1)+(num<<3)+cr-'0';cr=getchar();}
	return num*fu;
}
int T,id,n,m,c,f;
char mp[N][N];
int hx[N][N],zx[N][N];

inline void Ycl_hx(int x,int y)
{
	if(mp[x][y]=='1')
	{
		hx[x][y]=0;
		return;
	}
	int cnt=0;
	for(register int i=y+1; i<=m; i++)			//������ 
	{
		if(mp[x][i]=='0') cnt+=1;
		else break;
	}
	hx[x][y]=cnt;
	for(register int i=y+1; i<=m; i++)
		if(cnt-(i-y) >= 0)
			hx[x][i]=cnt-(i-y);
		else break;
}
inline void Ycl_zx(int x,int y)
{
	if(mp[x][y]=='1') 
	{
		zx[x][y]=0;
		return;
	}
	int cnt=0;
	for(register int i=x+1; i<=n; i++)
		if(mp[i][y]=='0') cnt+=1;
		else break;
	zx[x][y]=cnt;
	for(register int i=x+1; i<=n; i++)
	{
		if(cnt-(i-x) >= 0)
			zx[i][y]=cnt-(i-x);
		else break;
	}
}
int cntC,cntF;
inline void Solve(int x,int y)
{
	if(zx[x][y]<=1) return;
	for(register int xd=x+2; xd<=n; xd++)			//ö��C���¶�
	{
		cntC= (cntC+(1ll*hx[x][y]*hx[xd][y])%MOD)%MOD;
		if(zx[xd][y]==0) break;
	}
	for(register int xd=x+2; xd<=n; xd++)			//ö��F���¶� 
	{
		cntF= (cntF+(((1ll*hx[x][y]*hx[xd][y])%MOD)*zx[xd][y])%MOD)%MOD; 
		if(zx[xd][y]==0) break;
	}
}

int main()
{
//	freopen("in��.in","r",stdin);						//ע�͵�	�����������ļ� 
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	
	T=read(),id=read();
	while(T--)
	{
		n=read(),m=read(),c=read(),f=read();
		cntC=0;
		cntF=0;
		for(register int i=1; i<=n; i++)
		{
			scanf("%s",mp[i]+1);
		}
		if(c==0 && f==0)				//���е�һ���� 
		{
			printf("0 0\n");
			continue;
		}
		memset(zx,-1,sizeof(zx));
		memset(hx,-1,sizeof(hx));
		for(register int i=1; i<=n; i++)
			for(register int j=1; j<=m; j++)							//ע��ö�ٵ����л����� 
			{
				if(hx[i][j]==-1);
					Ycl_hx(i,j);
				if(zx[i][j]==-1)
					Ycl_zx(i,j);
			}
		for(register int i=1; i<=n; i++)
		{
			for(register int j=1; j<=m; j++)
			{
				if(hx[i][j]!=0 && zx[i][j]!=0)
					Solve(i,j);
			}
		}
		printf("%d %d\n",(c*cntC)%MOD,(f*cntF)%MOD);
	}
	
	return 0;
}
