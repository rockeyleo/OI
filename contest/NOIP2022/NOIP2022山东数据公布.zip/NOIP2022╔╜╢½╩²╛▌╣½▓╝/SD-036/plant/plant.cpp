#include<bits/stdc++.h>
using namespace std;
const long long P=998244353;
bool M[1005][1005];
int to[1005][1005],sto[1005][1005];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id,n,m,c,f;
	scanf("%d%d",&T,&id);
	while(T--){
		scanf("%d%d%d%d",&n,&m,&c,&f);
		long long cntc(0),cntf(0);
		memset(to,0,sizeof to);
		memset(sto,0,sizeof sto);
		for(int i=1;i<=n;++i){
			char str[1050];
			scanf("%s",str);
			for(int j=0;j<strlen(str);++j)
				M[i][j+1]=(str[j]=='0'?false:true);
		}
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j){
				if(M[i][j]==true)continue;
				int cntk=0;
				if(to[i][j]==0){
					for(int k=j+1;k<=m;++k){
						if(M[i][k]==0)++cntk;
						else break;	
					}
					if(cntk){
						for(int k=j;cntk;++k){
							to[i][k]=cntk;
							--cntk;
						}
					}	
				}
				if(sto[i][j]==0){
					for(int k=i+1;k<=n;++k){
						if(M[k][j]==0)++cntk;
						else break;
					}
					if(cntk){
						for(int k=i;cntk;++k){
							sto[k][j]=cntk;
							--cntk;
						}
					}	
				}
			}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(M[i][j]==true)continue;
				if(to[i][j]==0)continue;
				if(i+1>n||M[i+1][j]==1)continue;
				for(int k=i+2;k<=n;++k){
					if(M[k][j]==true)break;
					if(to[k][j]>0){
						long long tij=to[i][j],tkj=to[k][j],stokj=sto[k][j];
						cntc=(cntc+tij*tkj)%P;
						if(sto[k][j]>0)cntf=(cntf+(tij*tkj*stokj)%P)%P;
					}
				}
			}
		}
		printf("%lld %lld\n",(long long)c*cntc,(long long)f*cntf);
	}
}
