#include<bits/stdc++.h>
using namespace std;
int arr[2000005];
struct answer{
	int opt,x,y;
};
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T,n,m,k,nempty(0),ptr(0);
	vector<answer>ans;
	deque<int>a,b;
	cin>>T;
	while(T--){
		ptr=0;
		a.clear(),b.clear();
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<=m;++i)scanf("%d",&arr[i]);
		if(n==2){
			while(true){
				if(ptr==m&&a.empty()&&b.empty())break;
				if(a.empty()&&b.empty()){
					++ptr;
					a.push_front(arr[ptr]);
					ans.push_back({1,1,0});
					continue;
				}
				if(!b.empty()&&!a.empty()){
					if(b.back()==a.back()){
						b.pop_front();
						a.pop_front();
						ans.push_back({2,1,2});
					}
				}
				++ptr;
				if(!b.empty()&&arr[ptr]==b.front()){
					b.pop_front();
					ans.push_back({1,2,0}); 
				}
				else if(arr[ptr]==a.front()){
					a.pop_front();
					ans.push_back({1,1,0});	
				}
				else b.push_front(arr[ptr]),ans.push_back({1,2,0});
			}	
		}
		cout<<ans.size()<<endl;
		for(auto x:ans){
			if(x.opt==1){
				cout<<"1 "<<x.x<<endl; 
			}else cout<<"2 "<<x.x<<" "<<x.y<<endl;
		}
	}
}
