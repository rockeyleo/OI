#include<bits/stdc++.h>
using namespace std;
const long long P=1000000007;
int n,m;
inline long long fastpow(long long n,long long p){
	long long base=n,ans=1;
	while(p){
		if(p&1)ans=(ans*base)%P;
		p>>=1;
		base=(base*base)%P;
	}
	return ans;
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(m==n)cout<<(fastpow(2,n)*fastpow(2,m))%P<<endl;
	else cout<<((n*m)%P+(3*fastpow(4,n-2)%P))%P<<endl;;
}
