#include<bits/stdc++.h>
#define MAXN 250005
using namespace std;
struct segment{
	int arr[MAXN];
	struct node{
		int l,r,maxx;
		node operator+(const node &x){
			return {l,x.r,max(maxx,x.maxx)};
		}
	}tree[MAXN<<2],NP={0,0,INT_MIN};
	inline void pushup(int now){
		tree[now]=tree[now<<1]+tree[now<<1|1];
	}
	void build(int now,int l,int r){
		if(l==r){
			tree[now]={l,l,arr[l]};
			return;
		}
		int mid=(l+r)>>1;
		build(now<<1,l,mid);
		build(now<<1|1,mid+1,r);
		pushup(now);
	}
	node query(int now,int l,int r){
		if(l>tree[now].r||tree[now].l>r)return NP;
		else if(l<=tree[now].l&&tree[now].r<=r)return tree[now];
		else return query(now<<1,l,r)+query(now<<1|1,l,r);
	}
}N,Q;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	unsigned long long ans(0);
	int T,n,q;
	scanf("%d%d",&T,&n);
	for(int i=1;i<=n;++i)scanf("%d",&N.arr[i]);
	for(int i=1;i<=n;++i)scanf("%d",&Q.arr[i]);
	N.build(1,1,n);
	Q.build(1,1,n);
	cin>>q;
	while(q--){
		ans=0;
		int l,r;
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;++i)
			for(int j=i;j<=r;++j){
				ans+=((unsigned long long)N.query(1,i,j).maxx*(unsigned long long)Q.query(1,i,j).maxx);
			}
		printf("%lld\n",ans);
	}
}
