#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#include<ctime>
#include<random>
#include<queue>
#include<assert.h>
#include<set>
#define y1 y123
#define fi first
#define se second
#define mp make_pair
#define pb emplace_back
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<pii> vpii;
template<typename T>void cmax(T &x,T y){x=x>y?x:y;}
template<typename T>void cmin(T &x,T y){x=x<y?x:y;}
template<typename T>
T &read(T &r){
	r=0;bool w=0;char ch=getchar();
	while(ch<'0'||ch>'9')w=ch=='-'?1:0,ch=getchar();
	while(ch>='0'&&ch<='9')r=r*10+ch-'0',ch=getchar();
	return r=w?-r:r;
}
const int N=250010;
int T,n,Q;
ull a[N],b[N],lg[N];
int sta[19][N],stb[19][N];
int qmaxa(int l,int r){
	int k=lg[r-l+1];
	if(a[sta[k][l]] > a[sta[k][r-(1<<k)+1]])
		return sta[k][l];
	return sta[k][r-(1<<k)+1]; 
}
int qmaxb(int l,int r){
	int k=lg[r-l+1];
	if(b[stb[k][l]] > b[stb[k][r-(1<<k)+1]])
		return stb[k][l];
	return stb[k][r-(1<<k)+1]; 
}
ull solve(int l,int r){
	if(l>r)return 0;
	int p=qmaxa(l,r),q=qmaxb(l,r);
	ull s=1llu*a[p]*b[q]*(ull)(r-max(p,q)+1);
	s+=solve(l,max(p,q)-1); 
	return s;
}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(T);read(n);
	for(int i=1;i<=n;i++)read(a[i]),sta[0][i]=i;
	for(int i=1;i<=n;i++)read(b[i]),stb[0][i]=i;
	for(int i=2;i<=n;i++)lg[i]=lg[i>>1]+1;
	for(int j=1;j<19;j++)
		for(int i=1;i+(1<<j)-1<=n;i++){
			sta[j][i]=a[sta[j-1][i]]>a[sta[j-1][i+(1<<(j-1))]] ? sta[j-1][i] : sta[j-1][i+(1<<(j-1))];
		}
	for(int j=1;j<19;j++)
		for(int i=1;i+(1<<j)-1<=n;i++){
			stb[j][i]=b[stb[j-1][i]]>b[stb[j-1][i+(1<<(j-1))]] ? stb[j-1][i] : stb[j-1][i+(1<<(j-1))];
		}
	read(Q);
	for(int o=1;o<=Q;o++){
		int l,r;read(l);read(r);
		ull s=0;
		for(int i=l;i<=r;i++)
			s+=solve(i,r);
		cout << s << '\n';
	}
	return 0;
}
