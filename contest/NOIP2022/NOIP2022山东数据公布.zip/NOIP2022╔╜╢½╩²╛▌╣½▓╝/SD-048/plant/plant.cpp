#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#include<ctime>
#include<random>
#define y1 y123
#define fi first
#define se second
#define mp make_pair
#define pb emplace_back
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<pii> vpii;
template<typename T>void cmax(T &x,T y){x=x>y?x:y;}
template<typename T>void cmin(T &x,T y){x=x<y?x:y;}
template<typename T>
T &read(T &r){
	r=0;bool w=0;char ch=getchar();
	while(ch<'0'||ch>'9')w=ch=='-'?1:0,ch=getchar();
	while(ch>='0'&&ch<='9')r=r*10+ch-'0',ch=getchar();
	return r=w?-r:r;
}
const int mod=998244353;
inline void cadd(int &x,int y){x=(x+y>=mod)?(x+y-mod):(x+y);}
inline void cdel(int &x,int y){x=(x-y<0)?(x-y+mod):(x-y);}
inline int add(int x,int y){return (x+y>=mod)?(x+y-mod):(x+y);}
inline int del(int x,int y){return (x-y<0)?(x-y+mod):(x-y);}
const int N=1010;
int n,m,vc,vf;
int ansc,ansf;
int a[N][N];
int R[N][N],D[N][N];
char s[N][N];
void solve(){
	ansc=ansf=0;
	read(n);read(m);read(vc);read(vf);
	for(int i=1;i<=n;i++){
		scanf("%s",s[i]+1);
		for(int j=1;j<=m;j++){
			a[i][j]=s[i][j]-'0';
			R[i][j]=D[i][j]=0;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=m-1;j>=1;j--){
			if(a[i][j]==0 && a[i][j+1]==0){
				R[i][j]=add(1,R[i][j+1]);
			}
		}
	}
	for(int j=1;j<=m;j++){
		for(int i=n-1;i>=1;i--){
			if(a[i][j]==0 && a[i+1][j]==0){
				D[i][j]=add(1,D[i+1][j]);
			}
		}
	}
	for(int j=1;j<=m;j++){
		int sum=0;
		for(int i=1;i<=n;i++){
			if(a[i][j]==0){
				cadd(ansc,1ll*R[i][j]*sum%mod);
				cadd(ansf,1ll*R[i][j]*sum%mod*D[i][j]%mod);
				if(i>1 && a[i-1][j]==0)
					cadd(sum,R[i-1][j]);
			}
			else{
				sum=0;
			}
		}
	}
	cout << ansc*vc << ' ' << ansf*vf << '\n';
	return ;
}
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id;read(T);read(id);
	while(T--)solve(); 
	return 0;
}
