#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#include<ctime>
#include<random>
#include<queue>
#include<assert.h>
#include<set>
#define y1 y123
#define fi first
#define se second
#define mp make_pair
#define pb emplace_back
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<pii> vpii;
template<typename T>void cmax(T &x,T y){x=x>y?x:y;}
template<typename T>void cmin(T &x,T y){x=x<y?x:y;}
template<typename T>
T &read(T &r){
	r=0;bool w=0;char ch=getchar();
	while(ch<'0'||ch>'9')w=ch=='-'?1:0,ch=getchar();
	while(ch>='0'&&ch<='9')r=r*10+ch-'0',ch=getchar();
	return r=w?-r:r;
}
const int mod=1000000007;
inline void cadd(int &x,int y){x=(x+y>=mod)?(x+y-mod):(x+y);}
inline void cdel(int &x,int y){x=(x-y<0)?(x-y+mod):(x-y);}
inline int add(int x,int y){return (x+y>=mod)?(x+y-mod):(x+y);}
inline int del(int x,int y){return (x-y<0)?(x-y+mod):(x-y);}
const int N=1000010;
int n,m;
vi eg[N];
int eu[N],ev[N];
namespace subTree{
	int fpow[N];
	int f[N][3],siz[N],g[3];
	int s[N]; 
	int ans;
	void dfs(int x,int fa){
		siz[x]=1;
		f[x][0]=1;
		for(auto v:eg[x])if(v!=fa){
			dfs(v,x);siz[x]+=siz[v];
			for(int i=0;i<=2;i++){
				cadd(g[i],1ll*f[x][i]*fpow[siz[v]]%mod);
				cadd(g[min(2,i+1)],1ll*f[x][i]*s[v]%mod);
			}
			for(int i=0;i<=2;i++)f[x][i]=g[i],g[i]=0;
		}
		cadd(s[x],f[x][0]);
		cadd(s[x],f[x][1]*2ll%mod);
		cadd(s[x],f[x][2]*2ll%mod);
		cadd(ans,1ll*fpow[n-1-(siz[x]-1)] * f[x][0] % mod);
		cadd(ans,1ll*fpow[n-1-(siz[x]-1)] * f[x][1] % mod);
		cadd(ans,1ll*fpow[n-1-(siz[x]-1)] * f[x][2] % mod);
		cadd(ans,1ll*fpow[n-1-(siz[x]-1)] * f[x][2] % mod);
	}
	int main(){
		fpow[0]=1;for(int i=1;i<=n;i++)fpow[i]=2ll*fpow[i-1]%mod;
		dfs(1,0);
		cout << ans << '\n';
		return 0;
	}
}
namespace bf{
	int bit(int x){
		return 1<<(x-1);
	}
	int fa[N],vis[N],ok[N];
	int getfa(int x){
		return fa[x]==x?x:fa[x]=getfa(fa[x]);
	}
	void merge(int x,int y){
		fa[getfa(x)]=getfa(y);
	}
	int check(int S){
		for(int i=1;i<=n;i++)fa[i]=i;
		for(int i=1;i<=m;i++)
			if(ok[i])
				merge(eu[i],ev[i]);
		for(int i=1;i<=n;i++)
			if(bit(i)&S){
				for(int j=i;j<=n;j++)
					if(bit(j)&S){
						if(getfa(i)!=getfa(j))
							return 0;
					}
				return 1;
			}
		return 1;
	}
	int main(){
		int ans=0;
		for(int S=1;S<(1<<n);S++){
			for(int T=0;T<(1<<m);T++){
				for(int i=1;i<=m;i++)
					if(bit(i)&T)
						vis[i]=1;
					else
						vis[i]=0;
				for(int i=1;i<=m;i++)ok[i]=1;
				bool fl=1;
				for(int i=1;i<=m&&fl;i++)
					if(!vis[i]){
						ok[i]=0;
						fl&=check(S);
						ok[i]=1;
					}
				ans+=fl;
			}
		}
		cout << ans << '\n';
		return 0;
	}
}
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=m;i++){
		int x,y;read(x);read(y);
		eu[i]=x;ev[i]=y;
		eg[x].pb(y);eg[y].pb(x);
	}
	if(n<=8 && m<=10)return bf::main();
	if(m==n-1)return subTree::main();
	return 0;
}
