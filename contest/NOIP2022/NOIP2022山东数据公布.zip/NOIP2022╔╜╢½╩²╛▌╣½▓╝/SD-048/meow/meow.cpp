#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#include<ctime>
#include<random>
#include<queue>
#include<assert.h>
#include<set>
#define y1 y123
#define fi first
#define se second
#define mp make_pair
#define pb emplace_back
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<pii> vpii;
template<typename T>void cmax(T &x,T y){x=x>y?x:y;}
template<typename T>void cmin(T &x,T y){x=x<y?x:y;}
template<typename T>
T &read(T &r){
	r=0;bool w=0;char ch=getchar();
	while(ch<'0'||ch>'9')w=ch=='-'?1:0,ch=getchar();
	while(ch>='0'&&ch<='9')r=r*10+ch-'0',ch=getchar();
	return r=w?-r:r;
}
const int N=610;
const int M=4000010;
int n,m,k;
int a[M];
int op[M],s1[M],s2[M];
int vis[N];
int ct[N],stt[N][3],stx[N][3];
int tot;
int Push1(int x){
	++tot;
	op[tot]=1;s1[tot]=x;
	return tot;
}
int Push2(int x,int y){
	++tot;
	op[tot]=2;s1[tot]=x;s2[tot]=y;
	return tot;
}
void check(){
	static deque<int>q[N];
	for(int i=1;i<=n;i++)while(!q[i].empty())q[i].pop_back();
	int p=1;
	for(int i=1;i<=tot;i++){
		assert(1<=op[i] && op[i]<=2);
		if(op[i]==1){
			assert(p<=m);
			assert(1<=s1[i] && s1[i]<=n);
			int x=-1;
			if(!q[s1[i]].empty())x=q[s1[i]].back();
			if(x==a[p])q[s1[i]].pop_back();
			else q[s1[i]].push_back(a[p]);
			++p;
		}
		else{
			int x=s1[i],y=s2[i];
			assert(1<=x && x<=n);
			assert(1<=y && y<=n);
			assert(!q[x].empty());
			assert(!q[y].empty());
			assert(q[x].front()==q[y].front());
			q[x].pop_front();q[y].pop_front();
		}
	}
	for(int i=1;i<=n;i++)assert(q[i].empty());
}
namespace bf{
	const int M=4;
	deque<int>q[M];
	int fl=0;
	void dfs(int x){
		if(x==m+1){
			for(int i=1;i<=n;i++)
				if(!q[i].empty())
					return ;
			fl=1;
			cout << tot << '\n';
			for(int i=1;i<=tot;i++){
				if(op[i]==1)cout << 1 << ' ' << s1[i] << '\n';
				else cout << 2 << ' ' << s1[i] << ' ' << s2[i] << '\n';
			}
			return ;
		}
		for(int i=1;i<=n;i++){
			if(q[i].empty()){
				for(int j=1;j<=n;j++)
					if(!q[j].empty() && q[j].front()==a[x]){
						Push1(i);
						Push2(i,j);
						q[j].pop_front();
						dfs(x+1);
						if(fl)return ;
						q[j].push_front(a[x]);
						tot-=2;
					}
				break;
			}
		}
		for(int i=1;i<=n;i++){
			if(!q[i].empty() && q[i].back()==a[x]){
				q[i].pop_back();
				Push1(i);
				dfs(x+1);
				if(fl)return ;
				q[i].push_back(a[x]);
				--tot;
			}
			else{
				q[i].push_back(a[x]);
				Push1(i);
				dfs(x+1);
				if(fl)return ;
				q[i].pop_back();
				--tot;
			}
		}
	}
	void main(){
		fl=0;
		for(int i=1;i<=n;i++)while(!q[i].empty())q[i].pop_back();
		dfs(1);
		return ;
	}
}
namespace n1{
	void main(){
		cout << m << '\n';
		for(int i=1;i<=m;i++)puts("1 1");
		return ;
	}
}
namespace n2{
	void main(){
		for(int i=1;i<=m;i++){
			if(i<m && a[i]==a[i+1]){
				Push1(1);
				Push1(1);
				++i;
				continue;
			}
			bool fl=0;
			for(int j=1;j<=2;j++)
				if(ct[j] && stx[j][ct[j]]==a[i]){
					Push1(j);
					--ct[j];
					fl=1;
					break;
				}
			if(fl)continue;
			for(int j=1;j<=2;j++)
				if(ct[j] && stx[j][1]==a[i] && !ct[3-j]){
					Push1(3-j);
					Push2(1,2);
					ct[j]--;
					if(ct[j])stx[j][1]=stx[j][2];
					fl=1;
					break;
				}
			if(fl)continue;
			if(ct[1]+ct[2]<2){
				for(int j=1;j<=2;j++)
					if(ct[j]<2){
						Push1(j);
						stx[j][++ct[j]]=a[i];
						fl=1;
						break;
					}
				if(fl)continue; 
			}
			for(int j=1;j<=2;j++){
				if(ct[j]==2){
					if(a[i+1]==stx[j][1]){
						Push1(j);
						Push1(3-j);
						Push2(1,2);
						stx[j][1]=stx[j][2];
						stx[j][2]=a[i];
						fl=1;
						break;
					}
					else{
						Push1(3-j);
						stx[3-j][++ct[3-j]]=a[i];
						Push1(j);
						--ct[j];
						fl=1;
						break;
					}
				}
				if(ct[j]==1){
					if(a[i+1]==stx[3-j][1]){
						Push1(j);
						Push1(3-j);
						ct[3-j]=0;
						stx[j][++ct[j]]=a[i];
						fl=1;
						break;
					}
				}
			}
			i++;
			continue;
		}
		cout << tot << '\n';
		for(int i=1;i<=tot;i++){
			if(op[i]==1)cout << 1 << ' ' << s1[i] << '\n';
			else cout << 2 << ' ' << s1[i] << ' ' << s2[i] << '\n';
		}
		return ;
	}
}
void solve(){
	set<int>S;tot=0;
	read(n);read(m);read(k);
	for(int i=1;i<=m;i++)read(a[i]);
	if(m<=14)
		return bf::main();
	if(n==1)return n1::main();
	if(n==2)return n2::main();
	for(int i=1;i<=k;i++)vis[i]=0;
	for(int i=1;i<=n;i++){
		stt[i][1]=stt[i][2]=0;
		stx[i][1]=stx[i][2]=0;
		ct[i]=0;
	}
	for(int i=1;i<n;i++)S.insert(i);
	for(int i=1;i<=m;i++){
		if(i<m && a[i]==a[i+1]){
			Push1(1);
			Push1(1);
			++i;
			continue;
		}
		if(!vis[a[i]]){
			if(S.empty()){
				assert(i<m);
				assert(!vis[a[i]]);
				int y=a[i+1];
				int ty=vis[y];
				if(stx[ty][1]==y){
					Push1(ty);
					Push1(n);
					Push2(ty,n);
					vis[y]=0;
					vis[a[i]]=ty;
					--ct[ty];
					stt[ty][1]=stt[ty][2];
					stx[ty][1]=stx[ty][2];
					++ct[ty];
					stt[ty][ct[ty]]=tot-2;
					stx[ty][ct[ty]]=a[i];
				}
				else{
					int p=ty==1?2:1;
					if(stt[p][2]<stt[ty][2]){
						s1[stt[ty][2]]=p;
						Push1(ty);
						stt[ty][2]=tot;
						stx[ty][2]=a[i];
						vis[a[i]]=ty;
						Push1(p);
					}
					else{
						vis[stx[p][1]]=ty;
						s1[stt[ty][2]]=p;
						s1[stt[p][1]]=ty;
						swap(stt[ty][2],stt[p][1]);
						swap(stx[ty][2],stx[p][1]);
						Push1(p);int tmp=tot;
						Push1(n);
						Push2(p,n);
						stt[p][1]=stt[p][2];
						stx[p][1]=stx[p][2];
						stt[p][2]=tmp;
						stx[p][2]=a[i];
						vis[a[i]]=p;
					}
					vis[y]=0;
				}
				++i;
				continue;
			}
			else{
				int t=*(S.begin());
				Push1(t);
				++ct[t];
				stt[t][ct[t]]=tot;
				stx[t][ct[t]]=a[i];
				vis[a[i]]=t;
				if(ct[t]==2)S.erase(t);
			}
		}
		else{
			int t=vis[a[i]];
			if(stx[t][1]==a[i]){
				Push1(n);
				Push2(t,n);
				--ct[t];
				if(ct[t]==1)stt[t][1]=stt[t][2],stx[t][1]=stx[t][2];
			}
			else{
				Push1(t);
				--ct[t];
			}
			if(ct[t]==1){
				S.insert(t);
			}
			vis[a[i]]=0;
		}
	}
	cout << tot << '\n';
	for(int i=1;i<=tot;i++){
		if(op[i]==1)cout << 1 << ' ' << s1[i] << '\n';
		else cout << 2 << ' ' << s1[i] << ' ' << s2[i] << '\n';
	}
}
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T;read(T);
	while(T--)solve();
	return 0;
}
