#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void print(int x) {
	if (x<0) putchar('-'),x=-x;
	if (x>9) print(x/10);
	putchar(x%10+48);
}
int n,m,x,y,z,op,cnt,Id,T,c,f,AnsC,AnsF,tot,w[1021][1021];
int map1[1021][1021];
char ch;
const int Mod=998244353;
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout); 
	T=read(); Id=read();
    while(T--) {
    	AnsC=0; AnsF=0;
    	n=read(); m=read(); c=read(); f=read();
    	if (c==0&&f==0) {
    		putchar('0');
    		putchar(' ');
    		putchar('0');
    		putchar('\n');
    		continue;
		}
		for (int i=1;i<=n;++i) {
			for (int j=1;j<=m;++j) {
				cin>>ch;
		        if (ch=='0') map1[i][j]=0,tot++;
		        else map1[i][j]=1,cnt++;
			}
		}
	    	for (int i=1;i<=n;++i) {
	    		for (int j=1;j<=m;++j) {
	    	        if (map1[i+1][j]==1||map1[i][j]==1||map1[i][j+1]==1) continue;
	    	        for (int g=j+1;g<=m;++g) {
	    	        	if (map1[i][g]==1) break;
	    	        	for (int k=i+2;k<=n;++k) {
	    	        		if (map1[k][j]==1) break;
	    	        	for (int l=j+1;l<=m;++l) {
	    	        		if (map1[k][j]==0&&map1[k][l]==0)  {
	    	        			AnsC++,AnsC%=Mod;
								for (int kk=k+1;kk<=n&&f!=0;++kk) {
	    	        				if (map1[kk][j]==0) AnsF++,AnsF%=Mod;
	    	        				else break;
								}
							}
	    	        		else break;
					   	}
					   }
					}
			    }
			}
        print(AnsC%Mod); putchar(' ');
		if (f) print(AnsF%Mod),putchar('\n');
 	    else {
 	    	print(0); putchar('\n');
		 }
	 }
	return 0;
}
