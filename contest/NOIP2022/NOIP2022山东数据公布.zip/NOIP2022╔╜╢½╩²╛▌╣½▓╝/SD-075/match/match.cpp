#include<bits/stdc++.h>
#define int __int128
using namespace std;
inline int read(){
	int x=0,f=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void print(int x) {
	if (x<0) putchar('-'),x=-x;
	if (x>9) print(x/10);
	putchar(x%10+48);
}
int n,m,x,y,z,op,cnt,a[10123131],b[10231311],T,l,r,ans;
namespace ss{
	#define lson pos<<1
	#define rson pos<<1|1
	struct node{
		int sum,len,lazy;
	}tree[1023131],tree2[1023131];
	void build(int pos,int l,int r) {
		tree[pos].len=r-l+1;
		if (l==r) {
			tree[pos].sum=a[l];
			tree2[pos].sum=b[l];
			return ;
		}
		int mid=l+r>>1;
		build(lson,l,mid); build(rson,mid+1,r);
		tree[pos].sum=max(tree[lson].sum,tree[rson].sum);
	    tree2[pos].sum=max(tree2[lson].sum,tree2[rson].sum);
	}
	int query(int pos,int l,int r,int L,int R) {
	    if (l>=L && r<=R) {
	    	return (tree[pos].sum)*(tree2[pos].sum);
		}
		int mid=l+r>>1,res=0;
		if (L<=mid) res+=query(lson,l,mid,L,R);
		if (R>mid) res+=query(rson,mid+1,r,L,R);
		return res;
	}
}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout); 
	T=read(); n=read();
    for (int i=1;i<=n;++i) {
    	a[i]=read();
	}
	for (int i=1;i<=n;++i) {
		b[i]=read();
	}
	ss::build(1,1,n);
	m=read();
	for (int i=1;i<=m;++i) {
		l=read(); r=read();
		ans+=ss::query(1,1,n,l,r);
	}
	print(ans*2);
	return 0;
}
