#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void print(int x) {
	if (x<0) putchar('-'),x=-x;
	if (x>9) print(x/10);
	putchar(x%10+48);
}
const int N=1e6+2022;
int n,m,T,k,a[N],num[N],tot,t,op;
int X[N],Y[N],O[N];
bool vis[N],ff,ss[N];
void dfs(int now) {
	if(now==m+1) {
		ff=1; return ;
	}
	for (int i=1;i<=n;++i) {
		if (ff) return ;
		if (!vis[i]) {
			O[++tot]=1;X[tot]=i;
		    if (num[a[now]]){
			    O[++tot]=2;
				X[tot]=i; Y[tot]=num[a[now]];
				vis[num[a[now]]]=0;
				num[a[now]]=0;
		    }
		    else {
		    	vis[a[now]]=1;
		    	num[a[now]]=i;
			}
			dfs(now+1);
			if (ff) return ;
			tot--;
		}
	}
	for (int i=1;i<=n;++i) {
		if (ff) return ;
		if (vis[i]&&num[a[now]]==i) {
			O[++tot]=1;X[tot]=i;
			dfs(now+1);
			if (ff) return ;
			tot--;
		}
	}
	for (int i=1;i<=n;++i) {
		if (vis[i]) {
			O[++tot]=1;X[tot]=i;
			dfs(now+1);
			if(ff) return ;
			tot--;
		}
	}
}
signed main(){
    freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout); 
	T=read();
	while(T--) {
		tot=0;op=0;ff=0;
		n=read(); m=read(); k=read();
		for (int i=1;i<=m;++i) {
			a[i]=read();
		}
		for (int i=1;i<=n;++i) {
		    O[++tot]=1; X[tot]=i;
		    op++;
		    if (num[a[i]]) {
		    	vis[num[a[i]]]=0;
		    	O[++tot]=2; 
		    	X[tot]=num[a[i]]; Y[tot]=i;
			    num[a[i]]=0;
			}
			else {
				num[a[i]]=i;
		        vis[a[i]]=1;
			}

		}
	    dfs(n+1);
	    cout<<tot<<endl;
	    for (int i=1;i<=tot;++i) {
	    	if (O[i]==1) {
	    		putchar('1');
	    		putchar(' ');
	    		print(X[i]);
	    		putchar('\n');
			}
			else {
				putchar('2');
	    		putchar(' ');
	    		print(X[i]);
	    		putchar(' ');
	    		print(Y[i]);
	    		putchar('\n');
			}
		}
	}
	return 0;
}

