#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=0;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void print(int x) {
	if (x<0) putchar('-'),x=-x;
	if (x>9) print(x/10);
	putchar(x%10+48);
}
int n,m,x,y,z,op,cnt,ans,X[10231313],Y[10231133];
const int Mod=1e9+7;
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout); 
	n=read(); m=read();
	for (int i=1;i<=m;++i) {
		X[i]=read(); Y[i]=read();
	}
	for (int i=n;i>=1;--i) {
		ans+=(i*i)+1;
        ans%=Mod;
	}		
	print(ans);
	return 0;
}
