#include<bits/stdc++.h>
#define rep(i, l, r) for(int (i)=(l); (i)<=(r); (i)++)
#define per(i, r, l) for(int (i)=(r); (i)>=(l); (i)--)
#define x first
#define y second
using namespace std;
inline void Read(int &x){
  int f=1;
  x=0;
  char c=getchar();
  while(c<'0' or c>'9'){
    if(c=='-'){
      f=-1;
    }
    c=getchar();
  }
  while(c>='0' and c<='9'){
    x=x*10+c-'0', c=getchar();
  }
  x*=f;
}
const int N=50;
int T, n;
int a[N], b[N];
int main(){
  freopen("match.in", "r", stdin);
  freopen("match.out", "w", stdout);
  Read(T), Read(n);
  rep(i, 1, n){
    Read(a[i]);
  }
  rep(i, 1, n){
    Read(b[i]);
  }
  int q; Read(q);
  while(q--){
    int l, r; Read(l), Read(r);
    unsigned long long ans=0;
    rep(i, l, r){
      int m1=0, m2=0;
      rep(j, i, r){
        m1=max(m1, a[j]), m2=max(m2, b[j]);
        ans+=m1*m2;
      }
    }
    printf("%llu\n", ans);
  }
  return 0;
}
