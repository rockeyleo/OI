#include<bits/stdc++.h>
#define rep(i, l, r) for(int (i)=(l); (i)<=(r); (i)++)
#define per(i, r, l) for(int (i)=(r); (i)>=(l); (i)--)
#define x first
#define y second
using namespace std;
#define int long long
inline void Read(int &x){
  int f=1;
  x=0;
  char c=getchar();
  while(c<'0' or c>'9'){
    if(c=='-'){
      f=-1;
    }
    c=getchar();
  }
  while(c>='0' and c<='9'){
    x=x*10+c-'0', c=getchar();
  }
  x*=f;
}
const int p=1e9+7;
int n, m, f[500010], pw[5000010];
int iu[20], iv[20];
vector<int> e[20];
bool vis[20];
inline bool BFS(int S, int x){
  rep(i, 1, n){
    e[i].clear(), vis[i]=false;
  }
  rep(i, 1, m){
    if(i==x){
      continue;
    }
    e[iu[i]].push_back(iv[i]), e[iv[i]].push_back(iu[i]);
  }
  rep(s, 1, n){
    if(!((S>>s-1)&1)){
      continue;
    }
    rep(i, 1, n){
      vis[i]=false;
    }
    queue<int> q; q.push(s), vis[s]=true;
    while(!q.empty()){
      int u=q.front(); q.pop();
      for(int v: e[u]){
        if(!vis[v]){
          vis[v]=true, q.push(v);
        } 
      }
    }
    bool ff=true;
    rep(i, 1, n){
      if((S>>i-1)&1){
        ff&=vis[i];
      }
    }
    return ff;
  }
}
void Solve(){
  rep(i, 1, m){
    Read(iu[i]), Read(iv[i]);
  }
  int ans=0;
  rep(S, 1, (1<<n)-1){
    rep(T, 0, (1<<m)-1){
      bool ff=1;
      rep(i, 1, m){
        if(!((T>>i-1)&1)){
          ff&=BFS(S, i);
        }
      }
      ans+=ff;
    }
  }
  printf("%lld\n", ans);
}
signed main(){
  freopen("barrack.in", "r", stdin);
  freopen("barrack.out", "w", stdout);
  Read(n), Read(m);
  if(n<=8 and m<=10){
    Solve();
    return 0;
  }
  rep(i, 1, m){
    int x; Read(x), Read(x);
  }
  int ans=0;
  f[1]=1, pw[0]=1;
  rep(i, 1, n){
    pw[i]=pw[i-1]*2%p;
  }
  rep(i, 2, n){
    f[i]=(f[i-1]*2%p+pw[i-2])%p;
  }
  rep(i, 1, n){
    (ans+=pw[i-1]*f[n-i+1]%p)%=p;
  }
  printf("%lld\n", ans);
}
