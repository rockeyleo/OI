#include<bits/stdc++.h>
#define rep(i, l, r) for(int (i)=(l); (i)<=(r); (i)++)
#define per(i, r, l) for(int (i)=(r); (i)>=(l); (i)--)
#define x first
#define y second
using namespace std;
#define int long long
inline void Read(int &x){
  int f=1;
  x=0;
  char c=getchar();
  while(c<'0' or c>'9'){
    if(c=='-'){
      f=-1;
    }
    c=getchar();
  }
  while(c>='0' and c<='9'){
    x=x*10+c-'0', c=getchar();
  }
  x*=f;
}
const int N=310, M=2000010;
int n, m, k;
int a[M], st[N][5];
#define pii pair<int, int>
#define mkp make_pair
void Case15(){
  vector<pair<int, pii > > ans;
  rep(i, 1, n){
    st[i][0]=0;
  }
  rep(i, 1, m){
    int to=(a[i]-1)%(n-1)+1;
    if(st[to][0]<=1){
      st[to][++st[to][0]]=a[i];
      ans.push_back(mkp(1, mkp(to, 0ll)));
    }else {
      if(st[to][2]==a[i]){
        st[to][++st[to][0]]=a[i];
        ans.push_back(mkp(1, mkp(to, 0ll)));
      }else {
        st[n][++st[n][0]]=a[i];
        ans.push_back(mkp(1, mkp(n, 0ll)));
      }
    }
    int siz=st[to][0];
    if(siz>=2 and st[to][siz]==st[to][siz-1]){
      st[to][0]-=2;
    }
    if(st[n][0]>0){
      ans.push_back(mkp(2, mkp(to, n)));
      st[n][0]=0;
      rep(o, 1, st[to][0]-1){
        st[to][o]=st[to][o+1];
      }
      st[to][0]--;
    }
  }
  printf("%lld\n", (int)ans.size());
  for(auto i: ans){
    if(i.x==1){
      printf("1 %lld\n", i.y.x);
    }else {
      printf("2 %lld %lld\n", i.y.x, i.y.y);
    }
  }
}
void Case100(){
  return;
}
void MyMain(){
  Read(n), Read(m), Read(k);
  rep(i, 1, m){
    Read(a[i]);
  }
  if(k==2*(n-1)){
    Case15();
  }else {
    Case100();
  }
}
signed main(){
  freopen("meow.in", "r", stdin);
  freopen("meow.out", "w", stdout);
  int T; Read(T);
  while(T-->0){
    MyMain();
  }
  return 0;
}
