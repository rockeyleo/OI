#include<bits/stdc++.h>
#define rep(i, l, r) for(int (i)=(l); (i)<=(r); (i)++)
#define per(i, r, l) for(int (i)=(r); (i)>=(l); (i)--)
#define x first
#define y second
using namespace std;
#define int long long
inline void Read(int &x){
  int f=1;
  x=0;
  char c=getchar();
  while(c<'0' or c>'9'){
    if(c=='-'){
      f=-1;
    }
    c=getchar();
  }
  while(c>='0' and c<='9'){
    x=x*10+c-'0', c=getchar();
  }
  x*=f;
}
const int N=1010, p=998244353;
int n, m, c, f;
char s[N][N];
int r[N][N], sum[N][N], sum2[N][N];
void MyMain(){
  Read(n), Read(m), Read(c), Read(f);
  rep(i, 1, n){
    scanf("%s", s[i]+1);
    int cnt=0;
    per(j, m, 1){
      r[i][j]=cnt;
      if(s[i][j]=='0'){
        cnt++;
      }else {
        cnt=0;
      }
    }
  }
  
  rep(j, 1, m){
    sum[n+1][j]=0;
    per(i, n, 1){
      if(s[i][j]=='0'){
        sum[i][j]=(sum[i+1][j]+r[i][j])%p;
      }else {
        sum[i][j]=0;
      }
    }
  }
  
  rep(j, 1, m){
    sum2[n+1][j]=0;
    int cnt=0;
    per(i, n, 1){
      if(s[i][j]=='0'){
        cnt++, sum2[i][j]=(sum2[i+1][j]+r[i][j]*(cnt-1)%p)%p;
      }else {
        sum2[i][j]=0, cnt=0;
      }
    }
  }
  
  int ansc=0, ansf=0;
  rep(j, 1, m){
    rep(i1, 1, n){
      if(s[i1][j]=='1'){
        continue;
      }
      int i2=i1;
      while(i2<n and s[i2+1][j]=='0'){
        i2++; 
      }
      //Solve C
      rep(k, i1, i2-2){
        (ansc+=r[k][j]*sum[k+2][j]%p)%=p;
      }
      //Solve F
      rep(k, i1, i2-3){
        (ansf+=r[k][j]*sum2[k+2][j]%p)%=p;
      }
      i1=i2;
    }
  }
  printf("%lld %lld\n", ansc*c, ansf*f);
}
signed main(){
  freopen("plant.in", "r", stdin);
  freopen("plant.out", "w", stdout);
  int T, id; Read(T), Read(id);
  while(T-->0){
    MyMain();
  }
  return 0;
}
