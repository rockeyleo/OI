#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<set>
#include<queue>
#define N 100005
#define lc k<<1
#define rc k<<1|1
#define kl1 tree1[k].l
#define kr1 tree1[k].r
#define kl2 tree2[k].l
#define kr2 tree2[k].r
using namespace std;
struct node{
	unsigned long long l,r,maxn;
}tree1[N*4],tree2[N*4];
int n,T,Q;
unsigned long long mem1[10001][10001],mem2[10001][10001];
unsigned long long ans;
void build1(int k,int l,int r);
void build2(int k,int l,int r);
unsigned long long query1(int k,int l,int r){
	if(kl1>r||kr1<l) return 0;
	if(kl1>=l&&kr1<=r) return tree1[k].maxn;
	else return max(query1(lc,l,r),query1(rc,l,r));
}
unsigned long long query2(int k,int l,int r){
	if(kl2>r||kr2<l) return 0;
	if(kl2>=l&&kr2<=r) return tree2[k].maxn;
	else return max(query2(lc,l,r),query2(rc,l,r));
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	build1(1,1,n);
	build2(1,1,n);
	cin>>Q;
	int l,r;
	for(int k=1;k<=Q;k++){
		cin>>l>>r;
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				if(mem1[i][j]!=0&&mem2[i][j]!=0&&i<=10000&&j<=10000){
					ans+=mem1[i][j]*mem2[i][j];
				}
				if((mem1[i][j]!=0||mem2[i][j]!=0)&&i<=10000&&j<=10000){
					mem1[i][j]=query1(1,i,j);
					mem2[i][j]=query2(1,i,j);
					ans+=mem1[i][j]*mem2[i][j]; 
				}
				if(i<=10000&&j<=10000){
					ans+=query1(1,i,j)*query2(1,i,j);
				}
				
			}
		} 
		cout<<ans<<endl;
		ans=0;		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
void build1(int k,int l,int r){
	kl1=l;
	kr1=r;
	if(l==r) {
		cin>>tree1[k].maxn;
		return;
	}
	int mid=(l+r)>>1;
	build1(lc,l,mid);
	build1(rc,mid+1,r);
	tree1[k].maxn=max(tree1[lc].maxn,tree1[rc].maxn);
}
void build2(int k,int l,int r){
	kl2=l;
	kr2=r;
	if(l==r) {
		cin>>tree2[k].maxn;
		return;
	}
	int mid=(l+r)>>1;
	build2(lc,l,mid);
	build2(rc,mid+1,r);
	tree2[k].maxn=max(tree2[lc].maxn,tree2[rc].maxn);
}


