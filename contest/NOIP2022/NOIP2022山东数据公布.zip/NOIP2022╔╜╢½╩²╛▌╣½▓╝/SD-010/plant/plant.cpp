#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<set>
#include<queue>
#define ll long long
#define mod 998244353
using namespace std;

ll n,T,id,m,c,f,ans,ansf;
int map[1005][1005];
int mian();
int main(){
	ios::sync_with_stdio(false);
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	for(int i=0;i<=1004;i++){
		for(int j=0;j<=1004;j++){
			map[i][j]=1;
		}
	}
	for(int i=1;i<=T;i++){
		mian();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
int mian(){
	cin>>n>>m>>c>>f;
	char ch;
	for(int i=1;i<=n;i++){//��m��n 
		for(int j=1;j<=m;j++){
			cin>>ch;
			if(ch=='0'||ch=='1') map[i][j]=ch-'0';
		}
	}
	if(c==0&&f==0){
		cout<<0<<" "<<0<<endl;
	}
	if(c!=0&&f==0){//ö�١�C�������������ս� 
		for(int i=1;i<=n;i++){//������ (���Ͻ�&&���½�)
			for(int j=1;j<=m-2;j++){//������ �����Ͻǣ� 
				int ans1=0;
				for(int l=j+1;;l++){
					if(map[i][l]==1) break;
					ans1++;
				}
				if(ans1!=0){
					for(int k=i+2;k<=n;k++){//�����꣨���½ǣ�
						int ans2=0;
						if(map[k][j]==1) break;
						for(int l=j+1;;l++){
							if(map[k][l]==1) break;
							ans2++;
						} 
						ans+=ans1*ans2;
						ans%=mod;
					} 
				}
			}
		}
		cout<<ans<<" "<<0<<endl;
	}
	if(c!=0&&f!=0){//ö�١�C�������������ս� 
		for(int i=1;i<=n;i++){//������ (���Ͻ�&&���½�)
			for(int j=1;j<=m-2;j++){//������ �����Ͻǣ� 
				if(map[i][j]==1) continue;
				int ans1=0;
				for(int l=j+1;;l++){
					if(map[i][l]==1) break;
					ans1++;
				}
				if(ans1!=0&&map[i+1][j]!=1){
					for(int k=i+2;k<=n;k++){//�����꣨���½ǣ�
						int ans2=0;
						if(map[k][j]==1) break;
						for(int l=j+1;;l++){
							if(map[k][l]==1) break;
							ans2++;
						} 
						ans+=ans1*ans2;
						ans%=mod;
						if(ans2!=0){
							int ans3=0;
							for(int o=k+1;;o++){
								if(map[o][j]==1) break;
								ans3++;
							}
							ansf+=ans1*ans2*ans3;
							ansf%=mod;
						}
					} 
				}
			}
		}
		cout<<ans<<" "<<ansf<<endl;
	}
	ans=ansf=0;
	for(int i=0;i<=n+1;i++){
		for(int j=0;j<=m+1;j++){
			map[i][j]=1;
		}
		cout<<endl;
	}
	return 0;
}

