#include<bits\stdc++.h>
#define ll long long
using namespace std;
int main() {
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(154697250);
	cout<<rand();
	return 0;
}
