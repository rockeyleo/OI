#include<iostream>
using namespace std;
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t;
	cin>>t;
	while(t--) {
		cout<<0<<" "<<0<<'\n';
	}
	return 0;
}
