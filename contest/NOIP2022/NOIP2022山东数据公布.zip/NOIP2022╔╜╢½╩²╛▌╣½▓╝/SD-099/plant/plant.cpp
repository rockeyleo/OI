#include<bits/stdc++.h>
#define int long long
#define P 998244353
#define endl '\n'
#define N 1100
using namespace std;
int T,id,n,m,C,F,ansc,ansf;
int s1[N][N],s2[N][N],s3[N][N],s4[N][N];
char a[N][N];
void work1()
{
	while(T--)
	{
		ansc=0;ansf=0;
		cin>>n>>m>>C>>F;
		for(int i=1;i<=n;i++)
		  for(int j=1;j<=m;j++)
		    cin>>a[i][j];
		if(C==0&&F==0)
		{
			cout<<"0 0"<<endl;
			continue;
		}
		for(int i=n;i>=1;i--)
		{
			int ccc=0;
			for(int j=m;j>=1;j--)
			{
				if(a[i][j]=='0')s1[i][j]=ccc++;
				else ccc=0;
			}
		}
		for(int j=m;j>=1;j--)
		{
			int ccc=0;
			for(int i=n;i>=1;i--)
			{
				if(a[i][j]=='0')s2[i][j]=ccc++;
				else ccc=0;
			}
		}
		for(int i=1;i<=n;i++)
		  for(int j=1;j<=m;j++)
			for(int o=i+2;o<=i+s2[i][j];o++)
			  s3[i][j]=(s3[i][j]+s1[o][j]*s1[i][j])%P,
			  s4[i][j]=(s4[i][j]+s1[o][j]*(s1[i][j]*(s2[i][j]-o+i)%P))%P;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			  ansc=(ansc+s3[i][j])%P,
			  ansf=(ansf+s4[i][j])%P;
		}
		cout<<(ansc%P)<<" ";
		if(F==0)
		{
			cout<<0<<endl;
			continue;
		}
		cout<<(ansf%P)<<endl;
	}
}
signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	work1();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
2.5h

1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

*/
