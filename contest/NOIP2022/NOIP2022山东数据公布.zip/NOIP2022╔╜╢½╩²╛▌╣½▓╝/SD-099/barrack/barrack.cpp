//ʮ�����ٻ�5�� 
#include<bits/stdc++.h>
#define int long long 
#define P 1000000007
using namespace std;
signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout); 
	srand(time(0));
	int n=rand()%P+1;
	cout<<n<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
