//AFO
#include<bits/stdc++.h>
#define int long long
#define N 2000100
#define endl '\n'
using namespace std;
int T,n,m,k,mi[N],ans;
int a[7];
void work2()
{
	ans=0;
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=3;j++)
		{
			if(a[j]==mi[i])
			{
				ans+=2;
				return ;
			}
		}
	}
}
signed main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>T;
	while(T--)
	{
		ans=0;
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++)
		  scanf("%lld",&mi[i]);
		cout<<"114514"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
