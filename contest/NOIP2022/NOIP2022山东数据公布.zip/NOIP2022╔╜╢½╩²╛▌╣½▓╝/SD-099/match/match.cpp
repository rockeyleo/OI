#include<bits/stdc++.h>
#define int long long
#define P 998244353
#define endl '\n'
#define N 1100000
using namespace std;
int T,q,n,a[N],b[N];
unsigned long long ans;
signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
	    cin>>b[i];
	cin>>q;
	while(q--)
	{
		int l,r;
		cin>>l>>r;
		for(int i=l;i<=r;i++)
		{
			for(int j=i;j<=r;j++)
			{
				int mx1=0,mx2=0;
				for(int o=i;o<=j;o++)
				{
					mx1=max(mx1,a[o]);
					mx2=max(mx2,b[o]);
				}
				ans+=mx1*mx2;
			}
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
