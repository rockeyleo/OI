#include<bits/stdc++.h>
using namespace std;
int a[20000],b[20000];
int q;
int l[20000],r[20000];
int T,n;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	fro(int i=1;i<=n;i++){
		cin>>b[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>l[i]>>r[i];
	}
	cout<<
	return 0;
}
	
