#include<bits/stdc++.h>
using namespace std;
int T,id;
int n,m,c,f;
char mapp[1002][1002];
int sum1=0,sum2=0;int step=0;;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	cin>>n>>m>>c>>f;
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			cin>>mapp[i][j];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(mapp[i][j]=='0'&&mapp[i][j+1]=='0'){
				if(mapp[i+1][j]=='0'&&mapp[i+2][j]=='0'){
					if(mapp[i+2][j+1]=='0')
						sum1++;
				}
			}
		}
	}
	cout<<sum1;
	return 0;
}
