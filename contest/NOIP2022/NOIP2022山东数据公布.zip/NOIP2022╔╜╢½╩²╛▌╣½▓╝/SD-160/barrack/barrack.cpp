#include<bits/stdc++.h>
using namespace std;
int n,m;
long long sum=0,ret=1,ry=2;
int flag=0;
int l[5001][10004];
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int j=0;j<m;j++){
		int x,y;
		cin>>x>>y;
		if(x<y){
			swap(x,y);
		}
		l[x][y]=1;
		l[y][x]=1;
	}
	if(m>n){
		int cnt=1;
		for(int i=1;i<=n;i++){
			cnt=cnt*i;
		}
		cout<<cnt*cnt;
	}
	else if(m==n-1){
		ret=2*n+1;
		cout<<ret;
	}
	else if(m=n){
		int jj=0;
		for(int i=1;i<=n;i++){
			int sum1=0;
			for(int j=1;j<=n;j++){
				if(l[i][j]==1)
					sum1++;
			}
			if(sum1%2==1){
				flag=1;
				break;
			}
		}
		if(flag==0){
			int cnt=1;
			for(int i=1;i<=n;i++){
				int c=pow(i,2);
				cnt=cnt*c;
		}
			cout<<cnt;
		}
		else if(flag=1){
			int cheng=1;
			for(int i=1;i<=n+1;i++){
				cheng*=i;
			}
			int e=0;
			for(int i=1;i<n;i++){
				e+=i;
			}
			int d=pow(2,e);
			cout<<d+cheng;
		}
	}
	return 0;
}
