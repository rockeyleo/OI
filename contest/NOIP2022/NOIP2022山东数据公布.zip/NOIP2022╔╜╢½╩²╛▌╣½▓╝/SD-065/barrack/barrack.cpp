#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=501000,MOD=1000000007;
int n,m,u,v,ans;
int total=1,head[N],ver[2001000],Next[2001000],bri[2001000];
int TOTAL,HEAD[N],VER[2001000],NEXT[2001000];
int num,dfn[N],low[N],col[N];
int f[N][3],siz[N],brin[N],tsiz[N];
int ksm(int x,int y){
	int ans=1;
	while(y){
		if(y&1) ans=ans*x%MOD;
		y>>=1; x=x*x%MOD;
	}
	return ans;
}
void add(int u,int v){
	ver[++total]=v;
	Next[total]=head[u];
	head[u]=total;
	return ;
}
void ADD(int U,int V){
	VER[++TOTAL]=V;
	NEXT[TOTAL]=HEAD[U];
	HEAD[U]=TOTAL;
	return ;
}
void tarjan(int p,int fa){
	dfn[p]=low[p]=++num;
	for(int i=head[p];i;i=Next[i]){
		if(ver[i]==fa) continue;
		if(dfn[ver[i]]==0){
			tarjan(ver[i],p);
			low[p]=min(low[p],low[ver[i]]);
		}
		else{
			low[p]=min(low[p],dfn[ver[i]]);
		}
		if(low[ver[i]]>dfn[p]) bri[i]=bri[i^1]=1;
	}
	return ;
}
void dfs(int p){
	col[p]=num; siz[num]++;
	for(int i=head[p];i;i=Next[i]){
		if(col[ver[i]]){
			if(bri[i]){
				ADD(col[p],col[ver[i]]);
				ADD(col[ver[i]],col[p]);
			}
			else{brin[num]++;}
			continue;
		}
		if(bri[i]) continue;
		brin[num]++;
		dfs(ver[i]);
	}
	return ;
}
void sol(int p,int fa){
	tsiz[p]=siz[p];
	f[p][0]=ksm(2,brin[p]);
	f[p][1]=((ksm(2,tsiz[p])-1)*ksm(2,brin[p])%MOD+MOD)%MOD;
	for(int i=HEAD[p];i;i=NEXT[i]){
		if(VER[i]==fa) continue;
		sol(VER[i],p);
		f[p][2]=(f[p][2]+f[ver[i]][2]*f[p][0]%MOD*2%MOD+f[ver[i]][1]*f[p][0]%MOD-1+f[p][2]*f[ver[i]][0]%MOD*2%MOD)%MOD;
		f[p][1]=(f[p][1]*f[ver[i]][0]%MOD*2%MOD+f[p][0]*f[ver[i]][1]%MOD+f[p][1]*f[ver[i]][1]%MOD)%MOD;
		f[p][0]=f[p][0]*f[ver[i]][0]%MOD*2%MOD;
		tsiz[p]+=tsiz[ver[i]];
		brin[p]+=brin[ver[i]]+1;
	}
	ans=(ans+f[p][1]*ksm(2,m-brin[p])%MOD)%MOD;
	return ;
}
int read(){
	int x=0,w=1;
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	if(ch=='-') {w=-1; ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch^48); ch=getchar();}
	return x*w;
}
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(); m=read();
	for(int i=1;i<=m;i++){
		u=read(); v=read();
		add(u,v); add(v,u);
	}
	tarjan(1,0); num=0;
	for(int i=1;i<=n;i++){
		if(col[i]==0){
			num++; dfs(i); brin[num]/=2;
		}
	}
	sol(1,0);
	cout<<(ans%MOD+MOD)%MOD<<'\n';
	return 0;
}
/*
4 3
1 2
2 3
1 4

4 3
1 2
2 3
3 4
*/
