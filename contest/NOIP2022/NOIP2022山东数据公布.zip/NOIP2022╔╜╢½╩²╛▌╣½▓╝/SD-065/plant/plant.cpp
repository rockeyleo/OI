#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MOD=998244353;
int n,m,C,F,ansc,ansf,f[1100][1100],s[1100][1100][2];
char ch;
bool a[1100][1100];
void sol(){
	for(int i=1;i<=n;i++){
		for(int j=m;j>=1;j--){
			if(a[i][j]==0) f[i][j]=s[i][j][0]=s[i][j][1]=0;
			else{
				f[i][j]=f[i][j+1]+1;
				s[i][j][0]=(f[i][j]-1)+s[i-1][j][0];
				if(i>=3&&a[i-1][j]){
					ansc=(ansc+(f[i][j]-1)*s[i-2][j][0]%MOD)%MOD;
					s[i][j][1]=(s[i-1][j][1]+(f[i][j]-1)*s[i-2][j][0]%MOD)%MOD;
				}
				ansf=(ansf+s[i-1][j][1])%MOD;
			}
		}
	}
	return ;
}
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int kkk=0,sub=0;
	cin>>kkk>>sub;
	while(kkk--){
		cin>>n>>m>>C>>F; ch=ansc=ansf=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				ch=0; while(ch!='0'&&ch!='1') ch=getchar();
				if(ch=='0') a[i][j]=1; else a[i][j]=0;
				f[i][j]=s[i][j][0]=s[i][j][1]=0;
			}
		}
		for(int i=1;i<=n+1;i++) f[i][m+1]=s[i][m+1][0]=s[i][m+1][1]=0;
		for(int j=1;j<=m+1;j++) f[n+1][j]=s[n+1][j][0]=s[n+1][j][1]=0;
		sol();
		cout<<(ansc*C)%MOD<<" "<<(ansf*F)%MOD<<'\n';
	}
	return 0;
}
