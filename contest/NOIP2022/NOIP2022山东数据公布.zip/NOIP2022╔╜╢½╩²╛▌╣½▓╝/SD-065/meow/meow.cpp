#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[2001000],num[1100];
pair <int,int> wh[2001000];
int top;
struct work{
	int op,s1,s2;
} q[4001000];
void sol1(){
	queue <int> emp;
	for(int i=1;i<n;i++) emp.push(i),emp.push(i),num[i]=0;
	for(int i=1;i<=m;i++){
		if(wh[a[i]].first!=0){
			num[wh[a[i]].first]--; emp.push(wh[a[i]].first);
			if(wh[a[i]].second==0){
				q[++top]={1,n,0};
				q[++top]={2,wh[a[i]].first,n};
			}
			else{
				q[++top]={1,wh[a[i]].first,0};
			}
			wh[a[i]]=make_pair(0,0);
			continue;
		}
		wh[a[i]]=make_pair(emp.front(),num[emp.front()]);
		q[++top]={1,wh[a[i]].first,0};
		num[wh[a[i]].first]++; emp.pop();
	}
	return ;
}
void sol2(){
	
	return ;
}
int read(){
	int x=0,w=1;
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	if(ch=='-') {w=-1; ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch^48); ch=getchar();}
	return x*w;
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int kkk=read();
	while(kkk--){
		n=read(); m=read(); k=read(); top=0;
		for(int i=1;i<=m;i++) a[i]=read();
		if(k==2*n-2){sol1();}
		else sol2();
		cout<<top<<endl;
		for(int i=1;i<=top;i++){
			if(q[i].op==1) cout<<1<<" "<<q[i].s1<<'\n';
			else cout<<2<<" "<<q[i].s1<<" "<<q[i].s2<<'\n';
		}
		for(int i=1;i<=n;i++) num[i]=0;
		for(int i=1;i<=k;i++) wh[i]=make_pair(0,0);
	}
	return 0;
}
