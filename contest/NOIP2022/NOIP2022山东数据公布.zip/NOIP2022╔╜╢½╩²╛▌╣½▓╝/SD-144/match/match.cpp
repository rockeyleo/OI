#include<iostream>
#include<cstdio>
#define int __int128
#define N 114514
#define M 1919810
using namespace std;
inline int cin_(){
	int f=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-'){f=-1;}
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		k=k*10+c-'0';
		c=getchar();
	}
	return k*f;
}
inline void cout_(int n){
	if(n<0){
		putchar('-');
		n=-n;
	}
	if(n>9){cout_(n/10);}
	putchar(n%10+'0');
}
/*Miss my home so much.
Expected to go back today.
RP++ AK NOIP 2022

Luogu:367346*/
int t,n,Q;
int a[M],b[M];
signed main(){
//	As read() is appeared in <cstring>
//	read() is replaced by cin_()
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	t=cin_();
	n=cin_();
	for(int i=1;i<=n;i++){
		a[i]=cin_();
	}
	for(int i=1;i<=n;i++){
		b[i]=cin_();
	}
	Q=cin_();
	while(Q--){
		int ans=0;
		int l,r;
		l=cin_();
		r=cin_();
		for(int i=l;i<=r;i++){
			int amax=0,bmax=0;
			for(int j=i;j<=r;j++){
				amax=max(amax,a[j]);
				bmax=max(bmax,b[j]);
				ans+=(amax*bmax);
			}
		}
		cout_(ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
//We ain't ever getting older 
