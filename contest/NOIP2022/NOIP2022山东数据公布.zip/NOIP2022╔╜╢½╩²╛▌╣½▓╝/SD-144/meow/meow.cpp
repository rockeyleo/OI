#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#define N 114514
#define M 1919810
using namespace std;
inline int cin_(){
	int f=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-'){f=-1;}
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		k=k*10+c-'0';
		c=getchar();
	}
	return k*f;
}
/*Miss my home so much.
Expected to go back today.
RP++ AK NOIP 2022

Luogu:367346*/
int T,n,m,k;
int a[M];
int main(){
//	As read() is appeared in <cstring>
//	read() is replaced by cin_()
//	Special Judge?
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>T;
	while(T--){
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++){
			a[i]=cin_();
		}
	}
	cout<<"1\n1 1";
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
//Never gonna give you up
//Never gonna let you down
