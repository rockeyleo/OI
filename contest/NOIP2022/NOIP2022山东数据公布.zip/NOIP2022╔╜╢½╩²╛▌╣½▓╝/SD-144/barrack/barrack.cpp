#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstring>
#define N 114514
#define M 1919810
using namespace std;
inline int cin_(){
	int f=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-'){f=-1;}
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		k=k*10+c-'0';
		c=getchar();
	}
	return k*f;
}
bool floyd_c(){
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a[i][j]||(a[i][k]&&a[k][j])){
					return 1;
				}
			}
		} 
	}
	return 0;
}
/*Miss my home so much.
Expected to go back today.
RP++ AK NOIP 2022

Luogu:367346*/
int n,m,d[1001][1001]={};
int main(){
//	As read() is appeared in <cstring>
//	read() is replaced by cin_()
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		u=cin_();
		v=cin_();
		d[u][v]=d[v][u]=1;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
//Just something I can turn to somebody I can kiss
//I want something just like this 
