#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#define N 114514
#define M 1919810
using namespace std;
/*Miss my home so much.
Expected to go back today.
RP++ AK NOIP 2022

Luogu:367346*/
int T,id;
int n,m,c,f;
char a[1005][1005]={};
//bool vis[1005][1005]={},d[1005][1005]={};
//int dx[4]={1,-1,0,0},dy[4]={0,0,1,-1};
//int ans_c=0,ans_f=1;
/*

**  **  
*	*   **
**  *   * 
    **	**
    
**
*
**
*
DFS can only catch n==4 when m==2;
*/
//void print(){
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=m;j++){
//			cout<<a[i][j];
//		}
//		cout<<endl;
//	}
//	cout<<endl;
//}
//void dfs(int x,int y){
//	for(int i=0;i<4;i++){
//		int nx=x+dx[i],ny=y+dy[i];
//		if(nx>=1&&nx<=n&&ny>=1&&ny<=m&&vis[nx][ny]==0){
//			if(a[nx][ny]=='0'){a[nx][ny]='*';}
//			vis[nx][ny]=1;
//			dfs(nx,ny);
//			if(a[nx][ny]=='*'){a[nx][ny]='0';}
//			vis[nx][ny]=0;
//		} 
//	}
//	if(jc()){print();}
//	if(jf()){print();}
//}

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	while(T--){
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cin>>a[i][j];
			}
		}
//		ans_c=0;
//		ans_f=0; 
		if(c==0&&f==0){
			cout<<"0 0"<<endl;
		}else if(n==3&&m==2){
			if(a[1][1]=='1'||a[1][2]=='1'||a[2][1]=='1'||a[3][1]=='1'||a[3][2]=='1'){
				cout<<"0 0"<<endl;
			}else{
				cout<<"1 0"<<endl;
			}
		}else if(n==4&&m==2){
			if(a[2][1]=='1'||a[3][1]=='1'){
				cout<<"0 0"<<endl;
			}else if(a[1][1]=='1'&&a[4][1]=='1'){
				cout<<"0 0"<<endl;
			}else if(a[1][2]=='1'&&a[4][2]=='1'){
				cout<<"0 0"<<endl;
			}else if(a[1][1]=='1'&&a[4][2]=='1'){
				cout<<"0 0"<<endl;
			}else if(a[1][2]=='1'&&a[4][1]=='1'){
				cout<<"0 0"<<endl;
			}else if(a[1][1]=='1'||a[1][2]=='1'||a[4][1]=='1'||a[4][2]=='1'){
				cout<<"1 0"<<endl;
			}else if(a[3][2]=='1'){
				cout<<"2 0"<<endl;
			}else if(a[2][2]=='1'){
				cout<<"2 1"<<endl;
			}else{
				cout<<"3 1"<<endl;
			}
//			for(int i=1;i<=n;i++){
//				for(int j=1;j<=m;j++){
//					if(a[i][j]=='0'){
//						dfs(i,j);
//					}
//				}
//			}
//			cout<<ans_c<<" "<<ans_f<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
//Lately I've been I've been losing sleep
//dreaming the things that we could be 
