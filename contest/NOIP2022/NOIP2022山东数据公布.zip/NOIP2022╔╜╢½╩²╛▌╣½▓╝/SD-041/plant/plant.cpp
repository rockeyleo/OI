#include<bits/stdc++.h>
using namespace std;

const int N=1005;
const int mod=998244353;
long long sumc[N][N],sumf[N][N],cnt[N][N],a[N][N],ansc,ansf,t,id;
int n,m,c,f;

int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--) {
		scanf("%d%d%d%d",&n,&m,&c,&f);
		ansc=0,ansf=0;
		memset(cnt,0,sizeof(cnt));
		memset(sumc,0,sizeof(sumc));
		memset(sumf,0,sizeof(sumf));
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++) {
				char cc;
				cin>>cc;
				a[i][j]=cc-48;
				a[i][j]^=1;
			}
		for(int i=1; i<=n; i++) {
			for(int j=m; j>=1; j--) {
				if(a[i][j]==1) {
					if(a[i][j+1]==1)
						cnt[i][j]=cnt[i][j+1]+1;
					else
						cnt[i][j]=1;
				}
			}
		}
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				if(a[i-1][j]==1)
					sumc[i][j]=(max(cnt[i-2][j]-1,(long long)0))*(max(cnt[i][j]-1,(long long)0))%mod;
				if(a[i][j]==1)
					cnt[i][j]=(cnt[i][j]+max((long long)0,cnt[i-1][j]-1))%mod;
				ansc=(ansc+sumc[i][j])%mod;
			}
		}
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				if(a[i][j]==1) {
					sumf[i][j]=sumc[i-1][j];
					sumf[i][j]=(sumf[i][j]+sumf[i-1][j])%mod;
					ansf=(ansf+sumf[i][j])%mod;
				}
			}
		}
		cout<<ansc*c<<" "<<ansf*f<<endl;
	}
	fclose(stdin);
	fclose(stdout);
}
