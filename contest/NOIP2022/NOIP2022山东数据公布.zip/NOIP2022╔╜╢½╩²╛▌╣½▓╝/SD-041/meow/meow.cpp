#include<bits/stdc++.h>
using namespace std;
int read() {
	int x=0,w=1;
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')
		ch=getchar();
	if(ch=='-') {
		w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*w;
}
void write(int x) {
	if(x<0) {
		putchar('-');
		x=-x;
	}
	if(x>9)
		write(x/10);
	putchar(x%10+48);
}
const int N=4003;
int n,m,k,t,belong[N],pos[N],a[N],cnt,Ccnt,bel[N];
struct node {
	int opt,x,y;
} ans[2000006];
set<pair<int,int> >spos;
set<int>ansq;
bitset<N>vis;
list<int>stac[N];
int main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	t=read();
	while(t--) {
		n=read();
		m=read();
		k=read();
		memset(bel,0,sizeof(bel));
		memset(belong,0,sizeof(belong));
		memset(pos,0,sizeof(pos));
		memset(a,0,sizeof(a));
		vis.reset();
		cnt=0;
		Ccnt=0;
		spos.clear();
		ansq.clear();
		for(int i=1;i<=n;i++)
		stac[i].clear();
		for(int i=1;i<=n;i++)
		spos.insert({0,i});
		for(int i=1; i<=m; i++) {
			a[i]=read();
			if(vis[a[i]])
				pos[a[i]]=++Ccnt;
			vis[a[i]]=1;
		}
		for(int i=1; i<=n; i++) {
			spos.insert({0,i});
		}
//		for(int i=1;i<=n;i++)
//		cout<<pos[i]<<" ";
//		cout<<1;
		for(int i=1; i<=m; i++) {

			auto p=lower_bound(spos.begin(),spos.end(),make_pair(pos[a[i]],0));
//			if(p!=spos.end())
//			cout<<p->first<<endl;
			if(p!=spos.end()&&p->first==pos[a[i]]) {
//				cout<<"fd";
				ans[++cnt]= {1,p->second,0};
				stac[p->second].pop_back();
				if(!stac[p->second].empty())
					spos.insert({pos[stac[p->second].back()],belong[stac[p->second].back()]});
				else
					spos.insert({0,p->second});
//				cout<<"s1"<<" "<<p->second<<endl;
				spos.erase(p);
			}
//			cout<<i<<" ";
			else {
				--p;
				ans[++cnt]= {1,p->second,0};
				stac[p->second].push_back(a[i]);
				belong[a[i]]=p->second;
				spos.insert({pos[a[i]],belong[a[i]]});
//				cout<<"s2 "<<p->first<<" "<<p->second<<endl;
				spos.erase(p);
			}
		}
//		for(int i=1; i<=k; i++)
//			cout<<pos[i]<<" ";
////		cout<<1;
//		cout<<endl;
//		for(int i=1; i<=n; i++) {
//			while(!stac[i].empty()) {
//				cout<<stac[i].front()<<" ";
//				stac[i].pop_front();
//			}
//			cout<<endl;
//		}

		for(int i=1; i<=n; i++) {
			if(stac[i].empty())
				continue;
//			cout<<1;
			if(ansq.empty()) {
				ansq.insert(stac[i].front());
				bel[stac[i].front()]=i;
				stac[i].pop_front();
				continue;
			}
			auto p=ansq.find(stac[i].front());
			if(p==ansq.end()) {
				ansq.insert(stac[i].front());
				bel[stac[i].front()]=i;
				stac[i].pop_front();
				continue;
			}
			while(p!=ansq.end()) {
				
				auto pp=p;
				ansq.erase(p);
				ans[++cnt]= {2,i,bel[*pp]};
//				cout<<ans[cnt].x<<" "<<ans[cnt].y<<endl;
				
				if(!stac[i].size())
					break;
				stac[i].pop_front();
				
				if(stac[bel[*pp]].size()) {
//					cout<<stac[bel[*pp]].front()<<endl;
					int qq=bel[*pp];
					int sb=stac[bel[*pp]].front();
					ansq.insert(sb);
					bel[sb]=qq;
//					cout<<sb<<endl;
					stac[bel[*pp]].pop_front();
				}
//				cout<<"f";
				if(!ansq.size())
				break;
				p=ansq.find(stac[i].front());
			}
		}
//		cout<<1;
		for(int i=1; i<=cnt; i++) {
			if(ans[i].opt==1){
				write(ans[i].opt);
				putchar(' ');
				write(ans[i].x);
				putchar('\n');
			}
//				cout<<ans[i].opt<<" "<<ans[i].x<<endl;
			else
			{
				write(ans[i].opt);
				putchar(' ');
				write(ans[i].x);
				putchar(' ');
				write(ans[i].y);
				putchar('\n');
			}
//				cout<<ans[i].opt<<" "<<ans[i].x<<" "<<ans[i].y<<endl;
		}

	}
}
/*
1
3 10 5
1 2 3 4 5 2 3 4 5 1
*/
