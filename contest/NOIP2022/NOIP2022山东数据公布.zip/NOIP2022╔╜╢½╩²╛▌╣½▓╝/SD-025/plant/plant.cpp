#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
const long long N=1005,mod=998244353;
long long t,id,n,m,c,f,ansc,ansf;
long long s[N][N][3];
bool v[N][N];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d %d\n",&t,&id);
	while(t--){
		scanf("%d %d %d %d\n",&n,&m,&c,&f);
		ansc=ansf=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				char a;
				scanf("%c",&a);
				if(a=='1') v[i][j]=1;
				else v[i][j]=0;
			}
			if(i!=n) scanf("\n");
		}
		if(c==0&&f==0){
			printf("0 0\n");
			continue;
		}
		for(int i=1;i<=n;i++){
			int f=m;
			for(int j=m;j>=1;j--){
				if(v[i][j]) f=j-1;
				else s[i][j][0]=f;
			}
		}
		if(f==0){
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j--){
					s[i][j][2]=s[i-1][j][2]+s[i][j][0];
					s[i][j][2]%=mod;
				}
			}
		}
		for(int i=1;i<=m;i++){
			int f=n;
			for(int j=n;j>=1;j--){
				if(v[j][i]) f=j-1;
				else s[j][i][1]=f;
			}
		}
		for(int i=1;i<=n-2;i++){
			for(int j=1;j<=m-1;j++){
				if(f){
					if(!v[i][j]&&!v[i+1][j]){
						for(int k=i+2;k<=n;k++){
							if(v[k][j]) break;
							int sumc=((s[i][j][0]-j)*(s[k][j][0]-j))%mod;
							ansc=(ansc+sumc)%mod;
							ansf+=(sumc*(s[k][j][1]-k))%mod;
							ansf%=mod;
						}
					}
				}else{
					ansc+=((((s[s[i][j][1]][j][2]-s[i+1][j][2]))%mod)*s[i][j][0])%mod;
				}
			}
		}
		printf("%d %d\n",(ansc*c)%mod,(ansf*f)%mod);
	}
	return 0;
}
