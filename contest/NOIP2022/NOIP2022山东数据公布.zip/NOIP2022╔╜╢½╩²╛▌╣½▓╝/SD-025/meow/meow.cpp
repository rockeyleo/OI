#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
const int N=305,M=2e6+5;
int t,n,m,k,sum;
int s[M],st[2*N],ste[M];
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d\n",&t);
	if((t%1000)==1){
		while(t--){
			scanf("%d %d %d\n",&n,&m,&k);
			sum=m;
			for(int i=1;i<=m;i++){
				if(i<m) scanf("%d ",&s[i]);
				else scanf("%d",&s[m]);
				int xy;
				if(s[i]>=n) xy=s[i]-n+1;
				else xy=s[i];
				if(st[s[i]]){
					if(st[s[i]]==1){
						if(s[i]>=n&&st[xy]) st[xy]=1;
						if(s[i]<n&&st[s[i]+n-1]) st[s[i]+n-1]=1;
						sum++;
					}
					st[s[i]]=0;
				}else{
					if(s[i]>=n){
						if(st[xy]) st[s[i]]=2;
						else st[s[i]]=1;
					}else{
						if(st[xy+n-1]) st[xy]=2;
						else st[xy]=1;
					}
					st[s[i]]=1;
				}
			}
			if(t) scanf("\n");
			printf("%d\n",sum);
			for(int i=1;i<=m;i++){
				int xy;
				if(s[i]>=n) xy=s[i]-n+1;
				else xy=s[i];
				if(st[s[i]]){
					if(st[s[i]]==1){
						printf("1 %d\n2 %d %d\n",n,xy,n);\
						if(s[i]>=n&&st[xy]) st[xy]=1;
						if(s[i]<n&&st[s[i]+n-1]) st[s[i]+n-1]=1;
					}else printf("1 %d\n",xy);
					st[s[i]]=0;
				}else{
					printf("1 %d\n",xy);
					if(s[i]>=n){
						if(st[xy]) st[s[i]]=2;
						else st[s[i]]=1;
					}else{
						if(st[xy+n-1]) st[xy]=2;
						else st[xy]=1;
					}
					st[s[i]]=1;
				}
			}
		}
	}else{
		while(t--){
			scanf("%d %d %d\n",&n,&m,&k);
			printf("%d\n",m);
			for(int i=1;i<=m;i++){
				if(i<m) scanf("%d ",&s[i]);
				else scanf("%d",&s[m]);
				printf("1 1\n");
			}
		}
	}
	return 0;
}
