#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
long long t,n,m,s;
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	scanf("%d %d\n",&n,&m);
	s=(n*m)/1e9+7;
	printf("%d",(n*m)-(s*1e9+7));
	return 0;
}
