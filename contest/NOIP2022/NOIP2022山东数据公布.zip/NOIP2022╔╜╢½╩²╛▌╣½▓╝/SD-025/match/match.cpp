#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int t,n,q;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d %d\n",&t,&n);
	for(int i=1;i<n;i++) scanf("%d ",&t);
	scanf("%d\n",&t);
	for(int i=1;i<n;i++) scanf("%d ",&t);
	scanf("%d\n",&t);
	scanf("%d\n",&q);
	for(int i=1;i<=q;i++) printf("114514\n");
	return 0;
}
