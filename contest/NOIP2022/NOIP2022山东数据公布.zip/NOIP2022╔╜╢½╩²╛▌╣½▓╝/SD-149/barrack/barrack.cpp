#include<bits/stdc++.h>
using namespace std;

const int N=5e5+10;

const int M=1e6+10;

int n,m;

int main(){
	freopen("","r",stdin);
	freopen("","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		
	}
	
	fclose(stdin);
	fclose(stdout);
return 0;
}
