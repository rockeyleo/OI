#include<bits/stdc++.h>
using namespace std;

const int N = 1e3+10;

int T,id,sum_c=1,sum_f=1;

int n,m,c,f;

int hy[N];

int main(){
	freopen("C:\Users\HP\Desktop\noip\plant.in","r",stdin);
	freopen("C:\Users\HP\Desktop\noip\plant.out","w",stdout);
	scanf("%d%d",&T,&id);
	if(id==2){
		for(int i=1;i<=10;i++){//ȫ����ʼ��1 
			for(int j=1;j<=10;j++){
				hy[i][j]=1;
			}
		} 
		for(int h=1;h<=T;h++){
			scanf("%d%d%d%d",&n,&m,&c,&f);
			for(int i=1;i<=3;i++){
				scanf("%d",&hy[i]);
			} 
			for(int i=1;i<=3;i++){
				if(hy[1]!=0||hy[2]==10||hy[3]!=0)	sum_c=1;
			}
			printf("%d 0",sum_c);
		}	
	}
	if(id==3){
		for(int i=1;i<=10;i++){//ȫ����ʼ��1 
			for(int j=1;j<=10;j++){
				hy[i][j]=1;
			}
		} 
		for(int h=1;h<=T;h++){
			scanf("%d%d%d%d",&n,&m,&c,&f);
			for(int i=1;i<=4;i++){
				scanf("%d",&h[i]);
			} 
			if(hy[2]==10||hy[2]==11||hy[3]==10||hy[3]==11)	sum_c=0;
			if(hy[1]!=0||hy[3]!=0||hy[2]==10||hy[2]==11||hy[4]==10||hy[4]==11)	sum_f=0;
			printf("%d %d",sum_c+2,sum_f);
		}	
	}
	fclose(stdin);
	fclose(stdout);
return 0;
}
