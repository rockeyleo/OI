#include<bits/stdc++.h>
using namespace std;

#define INF 0x3f3f3f3f

typedef long long LL;

const int N=25e4+10;

int a[N],a1[N],b[N],b1[N];

int T,n,Q,tot=0;

LL ans=0;

int main(){
	freopen("C:\Users\HP\Desktop\noip\match.in","r",stdin);
	freopen("C:\Users\HP\Desktop\noip\match.out","w",stdout);
	scanf("%d%d",&T,&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		a1[i]=a[i];
	}
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	scanf("%d",&Q)
	for(int i=1;i<=Q;i++){
		int l,r;
		scanf("%d%d",&l,&r);
		int l1=l,r1=r;
		while(l1!=r){
			sort(a1,l1,r1);
			LL maxn=a1[l1];
		}
	} 
	
	fclose(stdin);
	fclose(stdout);
return 0;
}
