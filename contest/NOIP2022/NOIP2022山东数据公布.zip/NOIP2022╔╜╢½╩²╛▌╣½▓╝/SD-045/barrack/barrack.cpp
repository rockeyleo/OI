#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int a,b,n;
	cin>>a>>b;
	for(int i=1;i<=b;i++)
	cin>>a;
	if(a<=2){
		cout<<5;}
	else
	cout<<184;
    fclose(stdin);
	fclose(stdout);
}
