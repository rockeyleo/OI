#include<bits/stdc++.h>
using namespace std;
inline int read(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int s=0,f=1,char ch = getchar();
	while(ch < '0'||ch > '9') ch = getchar();
	while(ch>='0'&&ch<='9'),ans = (ans << 1)+ (ans << 3) + ch - '0',ch = getchar();
	return ans;
}
void write(int x){
	if(x<10){
		putchar(x+'0');
		return;
	}
	writre(x/10);
	putchar(x%d+'0');
}
const int N=310;M=2e6+10;
int skack[N];
int cao[M*2][2],top;
int main(){
	
	
	int t;
	t = read();
	while(t--){
		int n=read(),m = read(),k =read()
		for(int i=1;i<=m;i++)
		a[i]=read();
		if(t==1001)
		{
			for(int i=1;i<=m;i++){
				int now = (a[i]-1)/2+1;
				if(!stack[now][0]||stack[now][0]==a[i]&&stack[now][1]==0){
					stack[now][1]^=a[i];
					cao[++top][0]=1;
					can[top][1]= now;
				}
				else
				{
					satck[now][0]=stack[now][1];
					stack[now][1]=0;
					stack[now][1]=stack[now];
				}
			}
		}
	}
}

fclose(stdin);
fclose(stdout);
return 0;
