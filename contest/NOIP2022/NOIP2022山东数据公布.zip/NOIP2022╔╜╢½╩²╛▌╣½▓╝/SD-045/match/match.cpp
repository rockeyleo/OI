#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int a,b;
	cin>>a>>b;
	int c,d;
	cin>>c>>d;
	int e,f;
	cin>>e>>f;
	int g;
	cin>>g;
	int h,i;
	cin>>h>>i;
	cout<<8;
	fclose(stdin);
	fclose(stdout);
}
