#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int a,b,c,d,e,f,g;
	cin>>a>>b;
	cin>>c>>d>>e>>f;
	for(int i=1;i<=c;i++)
	cin>>g;
	if(c<=10){
		cout<<36<<" "<<18;
	}
	else
	cout<<115<<" "<<114;
	fclose(stdin);
	fclose(stdout);
}

