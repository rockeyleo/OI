/*

�ǵ���һ�¿ռ䣬�ܲ��ܿ� ll
���������� dp
hash �� ull 

solo@2022

biu#2019miss

*/


#include<bits/stdc++.h>

#define FOR(i,a,b) for(register int (i)=(a);(i)<=(b);(i)++)
#define FOR2(i,a,b) for(register int (i)=(a);(i)>=(b);(i)--)
#define int long long
#define ll long long
#define ull unsigned long long
#define re register
#define inl inline 
#define fi first
#define se second
#define inf 0x7f7f7f7f
#define INF 0x7f7f7f7f7f7f7f7f
#define div cout<<"-----------------------------------"<<endl;
#define pb push_back
#define mem(a,b) memset((a),(b),sizeof((a))) 
#define PII pair<int,int>

#define l(x) t[(x)].l
#define r(x) t[(x)].r
#define val(x) t[(x)].val
#define dat(x) t[(x)].dat
#define sum(x) t[(x)].sum
#define tag(x) t[(x)].tag
#define siz(x) t[(x)].siz
#define ran(x) t[(x)].ran
#define cnt(x) t[(x)].cnt
#define ls(x) x<<1
#define rs(x) x<<1|1

using namespace std;

inline int read(){
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

inline int maxx(int x,int y) { return x>y ? x:y; }
inline int minn(int x,int y) { return x>y ? y:x; }

const int N=1e3+10;

int n;
int a[N], b[N];

int sta[N][22], stb[N][22];

int maxa[N][N], maxb[N][N];

inl void pre(){
	FOR(k,1,19){
		FOR(i,1,n){
			int to=i+(1<<k)-1;
			if(to>n) break;
			sta[i][k]=max(sta[i][k-1], sta[i+(1<<(k-1))][k-1]);
			stb[i][k]=max(stb[i][k-1], stb[i+(1<<(k-1))][k-1]);
		}
	}
	return ;
}

inl void get(int l,int r){
	int now=l;
	int resa=-inf, resb=-inf;
	FOR2(k,19,0){
		int to=now+(1<<k)-1;
		if(to>r) continue;
		resa=max(resa,sta[now][k]);
		resb=max(resb,stb[now][k]);
		now=to+1;
	}
	maxa[l][r]=resa, maxb[l][r]=resb;
	return ;
}

ull ans;

signed main(){
	
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	
	srand(time(0));
	
	int T=read();
	
	if(T>5){
		ull x=rand()*rand()*rand();
		cout<<x<<endl;
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	
	n=read();
	FOR(i,1,n){
		a[i]=read(), sta[i][0]=a[i];
	}
	FOR(i,1,n){
		b[i]=read(), stb[i][0]=b[i];
	}
	pre();
	
	FOR(i,1,n){
		FOR(j,i,n){
			get(i,j);
//			cout<<"l:"<<i<<" r:"<<j<<" maxa:"<<maxa[i][j]<<" maxb:"<<maxb[i][j]<<endl;
		}
	}
	int Q=read();
	while(Q--){
		int l=read(), r=read();
		FOR(i,l,r){
			FOR(j,i,r){
				ans+=(ull)maxa[i][j]*maxb[i][j];
			}
		}
	}
	cout<<ans<<endl;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
/*

0 5
5 4 1 2 3
3 5 1 4 2
5


*/
