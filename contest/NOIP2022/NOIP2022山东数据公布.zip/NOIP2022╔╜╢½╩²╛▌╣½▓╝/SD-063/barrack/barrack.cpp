/*

�ǵ���һ�¿ռ䣬�ܲ��ܿ� ll
���������� dp
hash �� ull 

solo@2022

biu#2019miss

*/


#include<bits/stdc++.h>

#define FOR(i,a,b) for(register int (i)=(a);(i)<=(b);(i)++)
#define FOR2(i,a,b) for(register int (i)=(a);(i)>=(b);(i)--)
#define int long long
#define ll long long
#define ull unsigned long long
#define re register
#define in inline 
#define fi first
#define se second
#define inf 0x7f7f7f7f
#define INF 0x7f7f7f7f7f7f7f7f
#define div cout<<"-----------------------------------"<<endl;
#define pb push_back
#define mem(a,b) memset((a),(b),sizeof((a))) 
#define PII pair<int,int>

#define l(x) t[(x)].l
#define r(x) t[(x)].r
#define val(x) t[(x)].val
#define dat(x) t[(x)].dat
#define sum(x) t[(x)].sum
#define tag(x) t[(x)].tag
#define siz(x) t[(x)].siz
#define ran(x) t[(x)].ran
#define cnt(x) t[(x)].cnt
#define ls(x) x<<1
#define rs(x) x<<1|1

using namespace std;

inline int read(){
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

inline int maxx(int x,int y) { return x>y ? x:y; }
inline int minn(int x,int y) { return x>y ? y:x; }

const int N=1e3+10;
const int M=1e6+10;
const int mod=1e9+7;

int n, m;
int idx=1;
int h[N];
int e[M<<1], ne[M<<1];

bool g[N][N];
bool a[N][N];

int ans;
int vis[N];
int vis2[M<<1];

int fa[N]; 
 
in int get(int x){
	if(fa[x]==x) return x;
	return fa[x]=get(fa[x]);
}

in void merge(int x,int y){
	int fx=get(x), fy=get(y);
	fa[fx]=fy;
	return ;
}

in void init(){
	mem(a,0);
	mem(vis,0);
	mem(vis2,0);
	FOR(i,1,n) fa[i]=i;
	return ;
}

int m1, m2;

int p[N], p2[M<<1];

in void dfs1(int u,int last){
	if(u==m1+1){
		return ;
	}
	FOR(i,last+1,n){
		p[u]=i;
		dfs1(u+1,i);
	}
	return ;
}

in void dfs2(int u,int last){
	if(u==m2+1){
		return ;
	}
	for(register int i=last+2;i<=idx;i+=2){
		p2[u]=i;
		dfs2(u+1,i);
	}
	return ;
}

void solve(){
	FOR(i,0,n){
		init();
		m1=i, dfs1(1,0);
		
		cout<<"m1:"<<m1<<endl;
		FOR(j,1,m1){
			vis[p[j]]=1;
			cout<<p[j]<<" ";
		}
		cout<<endl;
		
		FOR(j,0,m){
			m2=j, dfs2(1,0);
			FOR(k,1,m2){
				int t=p2[k];
				int x=e[t], y=e[t^1];
				a[x][y]=1;
			}
			
			FOR(x,1,n){
				FOR(y,x+1,n){
					if(a[x][y]) merge(x,y);
				}
			}
			int cnt=0;
			FOR(k,1,m1){
				int x=p[k];
				if(fa[x]==x) cnt++;
			}
			if(cnt>1) continue;
			ans++;
		}
	}
	return ;
}

signed main(){
	
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	
	srand(time(0));
	int x=rand()*rand()%mod;
	cout<<x<<endl;
	
//	n=read(), m=read();
//	while(m--){
//		int x=read(), y=read();
//		g[x][y]=1;
//		idx++;
//		e[idx]=y, e[idx^1]=x;
//	}
//	
//	solve();
//	cout<<ans<<endl;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
/*

2 1
1 2
5


*/
