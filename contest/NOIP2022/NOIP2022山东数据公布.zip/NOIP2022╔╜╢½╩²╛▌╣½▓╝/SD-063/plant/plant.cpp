/*

�ǵ���һ�¿ռ䣬�ܲ��ܿ� ll
���������� dp
hash �� ull 

solo@2022

biu#2019miss

*/


#include<bits/stdc++.h>

#define FOR(i,a,b) for(register int (i)=(a);(i)<=(b);(i)++)
#define FOR2(i,a,b) for(register int (i)=(a);(i)>=(b);(i)--)
#define int long long
#define ll long long
#define ull unsigned long long
#define re register
#define inl inline 
#define fi first
#define se second
#define inf 0x7f7f7f7f
#define INF 0x7f7f7f7f7f7f7f7f
#define div cout<<"-----------------------------------"<<endl;
#define pb push_back
#define mem(a,b) memset((a),(b),sizeof((a))) 
#define PII pair<int,int>

#define l(x) t[(x)].l
#define r(x) t[(x)].r
#define val(x) t[(x)].val
#define dat(x) t[(x)].dat
#define sum(x) t[(x)].sum
#define tag(x) t[(x)].tag
#define siz(x) t[(x)].siz
#define ran(x) t[(x)].ran
#define cnt(x) t[(x)].cnt
#define ls(x) x<<1
#define rs(x) x<<1|1

using namespace std;

inline int read(){
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

inline int maxx(int x,int y) { return x>y ? x:y; }
inline int minn(int x,int y) { return x>y ? y:x; }

const int N=1e3+10;
const int mod=998244353;

int n,m;

char a[N][N];

int sum[N][N];//ÿ�������������켸�� 
int sum2[N][N];

int cnt[N][N];//�������켸�� 
int cnt2[N][N];

int C,F;

inl void solve(){
//	cout<<"!!"<<endl;
	
	int ans=0;//C
	int ans2=0;//F 
	
	FOR2(i,n,1){
		FOR2(j,m,1){
			if(a[i][j]=='1') continue;
			sum[i][j]=1+sum[i][j+1];
			cnt[i][j]=1+cnt[i+1][j];
			cnt2[i][j]=cnt2[i+1][j]+(sum[i][j]-1)*(cnt[i][j]-1)%mod, cnt2[i][j]%=mod;
		}
	}
	
//	FOR(i,1,n){
//		FOR(j,1,m){
////			cout<<sum[i][j]<<" ";
//			cout<<cnt2[i][j]<<" ";
//		}
//		cout<<endl;
//	}
//	cout<<endl;
//	
	FOR2(i,n,1){
		FOR(j,1,m){
			if(a[i][j]=='1') continue;
			sum2[i][j]=sum[i][j]-1+sum2[i+1][j];
//			cout<<"i:"<<i<<" j:"<<j<<" cnt[i+1][j]:"<<cnt2[i+1][j]<<" sum:"<<sum[i][j]<<" cnt:"<<cnt[i][j]<<endl;
		}
	}
	
//	FOR(i,1,n){
//		FOR(j,1,m){
////			cout<<cnt2[i][j]<<" ";
//			cout<<sum2[i][j]<<" ";
//		}
//		cout<<endl;
//	}
//	cout<<endl;
	
	FOR(i,1,n-2){
		FOR(j,1,m-1){
			if(a[i][j]=='1') continue;
			if(a[i+1][j]=='1') continue;
			if(sum2[i][j]<2) continue;
//			cout<<"i:"<<i<<" j:"<<j<<" sum:"<<sum[i][j]<<" sum2:"<<sum2[i][j]<<" res:"<<(sum[i][j]-1) * (sum2[i][j]-(sum[i][j]-1)-(sum[i+1][j]-1))<<endl;
			ans+=(sum[i][j]-1) * (sum2[i][j]-(sum[i][j]-1)-(sum[i+1][j]-1)) %mod;
			ans%=mod;
//			ans2+=(sum[i][j]-1) * (sum2[i][j]-(sum[i][j]-1)-(sum[i+1][j]-1))
		}
	}
	
	FOR(i,1,n-3){
		FOR(j,1,m-1){
			if(a[i][j]=='1') continue;
			if(a[i+1][j]=='1') continue;
			if(a[i+2][j]=='1') continue;
			
			int tmp1=(sum[i][j]-1)*(cnt[i][j]-1);
			int tmp2=(sum[i+1][j]-1)*(cnt[i+1][j]-1);
			if(tmp1+tmp2==cnt2[i][j]) continue;
			
//			cout<<"i:"<<i<<" j:"<<j<<" sum:"<<sum[i][j]<<" cnt2:"<<cnt2[i][j]<<" tmp1:"<<tmp1<<" tmp2:"<<tmp2<<" res:"<<(sum[i][j]-1) * (cnt2[i][j]-tmp1-tmp2)<<endl;
			
			
			ans2+=(sum[i][j]-1) * (cnt2[i][j]-tmp1-tmp2) %mod;
			ans2%=mod;
		}
	}
	
	printf("%lld %lld\n",ans*C,ans2*F);
	return ;
}

inl void init(){
	mem(sum,0);
	mem(sum2,0);
	mem(cnt,0);
	mem(cnt2,0);
	return ;
}

signed main(){
	
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	
	int T=read(), id=read();
	while(T--){
		init();
		n=read(), m=read();
		C=read(), F=read();
		FOR(i,1,n){
			scanf("%s",a[i]+1);
		}
		if(id==1) { printf("0 0\n"); continue; }
		solve();
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
