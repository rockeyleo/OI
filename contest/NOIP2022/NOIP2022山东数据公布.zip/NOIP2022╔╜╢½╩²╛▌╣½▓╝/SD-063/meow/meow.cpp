/*

�ǵ���һ�¿ռ䣬�ܲ��ܿ� ll
���������� dp
hash �� ull 

solo@2022

biu#2019miss

*/


#include<bits/stdc++.h>

#define FOR(i,a,b) for(register int (i)=(a);(i)<=(b);(i)++)
#define FOR2(i,a,b) for(register int (i)=(a);(i)>=(b);(i)--)
#define int long long
#define ll long long
#define ull unsigned long long
#define re register
#define inl inline 
#define fi first
#define se second
#define inf 0x7f7f7f7f
#define INF 0x7f7f7f7f7f7f7f7f
#define div cout<<"-----------------------------------"<<endl;
#define pb push_back
#define mem(a,b) memset((a),(b),sizeof((a))) 
#define PII pair<int,int>

#define l(x) t[(x)].l
#define r(x) t[(x)].r
#define val(x) t[(x)].val
#define dat(x) t[(x)].dat
#define sum(x) t[(x)].sum
#define tag(x) t[(x)].tag
#define siz(x) t[(x)].siz
#define ran(x) t[(x)].ran
#define cnt(x) t[(x)].cnt
#define ls(x) x<<1
#define rs(x) x<<1|1

using namespace std;

inline int read(){
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}

inline int maxx(int x,int y) { return x>y ? x:y; }
inline int minn(int x,int y) { return x>y ? y:x; }

const int N=2e6+10;

int n,m,k;
int a[N];

int q[100][100];
int head[100], tail[100];

//vector<int> s[N];
int s[N];

//in work(int i){
//	int x=q[i][head[i]];
//	vector<int>::iterator it;
//	it=s[x].begin();
//	int j=*it;
//	head[i]++, head[j]++;
//	s[x].erase(it);
//	int new_x=q[i][head[i]];
//	
//}

int ans;
struct OP{
	int x,y,z;
}op[N];

inl void work(int i,int x){
	int j=s[x];
	head[i]++, head[j]++;
	op[++ans].x=2;
	op[ans].y=i, op[ans].z=j;
	
//	cout<<"i:"<<i<<" j:"<<j<<" x:"<<x<<endl;
	
	s[x]=0;
	
//	if(head[i]<=tail[i]){
//		int y=q[i][head[i]];
//		s[y]=i;
//	}
//	if(head[j]<=tail[j]){
//		int y=q[j][head[j]];
//		s[y]=j;
//	}
	
	if(head[i]<=tail[i]){
		int y=q[i][head[i]];
//		cout<<"y:"<<y<<" i:"<<i<<" j:"<<s[y]<<endl;
		if(s[y]) work(i,y);
	}
	if(head[j]<=tail[j]){
		int z=q[j][head[j]];
//		cout<<"z:"<<z<<" j:"<<j<<" i:"<<s[z]<<endl;
		if(s[z]) work(j,z);
	}
	if(head[i]<=tail[i] && head[j]<=tail[j]){
		int y=q[i][head[i]];
		int z=q[j][head[j]];
		s[y]=j;
		if(y==z) work(i,y);
	}
	return ;
} 

inl bool check(){
	FOR(i,1,k) s[i]=0;
	FOR(i,1,n){
//		cout<<"i:"<<i<<" head:"<<head[i]<<" tail:"<<tail[i]<<endl;
		if(head[i]>tail[i]) continue;//�յ�
		int x=q[i][head[i]];
		if(s[x]==0) s[x]=i;
		else work(i,x);
//		if(s[x].empty()) s[x].push_back(i);
//		else{//���� 
//			work(i); 
//		} 
	}
	FOR(i,1,n){
		if(head[i]<=tail[i]) return false;
	}
	return true;
} 

//int res[]={0,1,1,1,1,1,2,2,2,2,3};

//inl bool ok(){
//	FOR(i,1,ans){
//		if(op[i].y!=res[i]) return false;
//	}
//	return true;
//}

inl bool dfs(int u){
//	cout<<"u:"<<u<<" a:"<<a[u]<<endl;
	if(u==m+1){
		int tmp=ans;
		
		int copy_head[100];
		int copy_tail[100];
		
		FOR(i,1,n){
//			cout<<"---i:"<<i<<" head:"<<head[i]<<" tail:"<<tail[i]<<endl;
			copy_head[i]=head[i];
			copy_tail[i]=tail[i];
		}
		
//		cout<<"check!"<<ans<<endl;
//		if(ok()){
//			div;
//			FOR(i,1,ans){
//				printf("%lld %lld\n",op[i].x,op[i].y);
//			}
//			FOR(i,1,n){
//				cout<<"i:"<<i<<" head:"<<head[i]<<" tail:"<<tail[i]<<" ";
//				FOR(j,head[i], tail[i]){
//					cout<<q[i][j]<<" ";
//				}
//				cout<<endl;
//			}
//		}
		
		
//		FOR(i,1,ans){
//			printf("%lld %lld\n",op[i].x,op[i].y);
//		}
		if(check()){
//			cout<<"YES!!"<<endl;
			return true;
		}
		else{
			
			ans=tmp;
			FOR(i,1,n){
				head[i]=copy_head[i];
				tail[i]=copy_tail[i];
			}
			return false;
		}
	}
	
//	cout<<"u:"<<u<<" a:"<<a[u]<<endl;
	
	
	FOR(i,1,n){//ѡ��һ��ջ�Ž�ȥ 
		int tmp=tail[i];
		int tmp2=q[i][tail[i]];
		q[i][++tail[i]]=a[u];
//		bool flag=0;
		if(head[i]<tail[i]){
//			cout<<"u:"<<u<<" i:"<<i<<" head:"<<head[i]<<" tail:"<<tail[i]<<" a:"<<q[i][tail[i]]<<" b:"<<q[i][tail[i]-1]<<endl;
//			flag=1;
			if(q[i][tail[i]]==q[i][tail[i]-1]){
				tail[i]-=2;
			}
		}
		op[++ans].x=1;
		op[ans].y=i;
		
		if(dfs(u+1)) return true;
		
		tail[i]=tmp, q[i][tail[i]]=tmp2;
//		if(flag==0) tail[i]--;
//		else{
//			tail[i]++;
//			q[i][tail[i]]=a[u];
//		}
		ans--;
	}
	return false;
}

inl void init(){
	FOR(i,1,n){
		head[i]=1, tail[i]=0;
	}
	mem(q,0), mem(s,0); 
	ans=0;
	return ;
}

signed main(){
	
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	int T=read();
	while(T--){
		n=read(), m=read(), k=read();
		init();
		FOR(i,1,m){
			a[i]=read();
		}
//		cout<<"!YES"<<endl;
		dfs(1);
		
		printf("%lld\n",ans);
		FOR(i,1,ans){
			int x=op[i].x, y=op[i].y, z=op[i].z;
			if(x==1) printf("%lld %lld\n",x,y);
			else printf("%lld %lld %lld\n",x,y,z);
		}
		
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
/*

1
2 4 2
1 2 1 2 

*/
