/*
	���һս��Ը�Լ������ź�
	NOIP 2022 RP++
	Time: 12:21 �����õ��ķ������ܵ����� 1=
	���ѧ OI �� 
	���, ���ѧ����
	ѧ OI �����ʱ����ĺܿ���
	���� OI ��ѧ ACM ���� 
	luogu uid : 396974
	AFO 
*/
#include <bits/stdc++.h>
#define pb push_back
#define lson rt << 1
#define rson rt << 1 | 1
#define int long long
using namespace std;
typedef long long ll;

const int N = 1e3 + 10;
const int Mod = 998244353;
const int INF = 0x3f3f3f3f;

inline int read() {
	int res = 0, f = 0; char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) f |= (ch == '-');
	for(; isdigit(ch); ch = getchar()) res = (res << 1) + (res << 3) + (ch - '0');
	return f ? -res : res;
}


int T, id, n, m, c, f, a[N][N], qzh[N][N], tz1[N][N], tz2[N][N]; // i, j ��������չ���� 
char ch[N][N];
 
inline int Query(int x, int y, int xx, int yy) { return qzh[xx][yy] - qzh[x - 1][yy] - qzh[xx][y - 1] + qzh[x - 1][y - 1]; }
inline bool Check1(int Mid, int x, int y) { return 0 == Query(x, y, x, y + Mid - 1); }
inline bool Check2(int Mid, int x, int y) { return 0 == Query(x, y, x + Mid - 1, y); }   

void Main() {
	ll ansc = 0, ansf = 0;
	n = read(), m = read(), c = read(), f = read();
	for(int i = 1; i <= n; i++, getchar()) {
		for(int j = 1; j <= m; j++) scanf("%c", &ch[i][j]);
	}
	if(c == 0 && f == 0) {
		cout << "0 0"; putchar('\n');
		return;
	}
	for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) a[i][j] = ch[i][j] - '0';
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= m; j++) {
			qzh[i][j] = qzh[i - 1][j] + qzh[i][j - 1] - qzh[i - 1][j - 1] + a[i][j];			
		}
	}
	for(int i = 1; i <= n; i++) { // ������������չ���� 
		for(int j = 1; j <= m; j++) {
			if(a[i][j] == 1) continue;
			int l = 0, r = m - j + 1, ans = 0;
			while(l <= r) {
				int Mid = (l + r) >> 1;
				if(Check1(Mid, i, j)) ans = Mid, l = Mid + 1;
				else r = Mid - 1;
			}
			tz1[i][j] = ans;
			l = 0, r = n - i + 1, ans = 0;
			while(l <= r) {
				int Mid = (l + r) >> 1;
				if(Check2(Mid, i, j)) ans = Mid, l = Mid + 1;
				else r = Mid - 1;
			}
			tz2[i][j] = ans;
		}
	}
	for(int i = 1; i <= n; i++) { // ö���������� 
		for(int j = i + 2; j <= n; j++) {
			for(int k = 1; k <= m; k++) { // ��ö��һ������
				if(Query(i, k, j, k)) continue;
				if(tz1[i][k] <= 1 || tz1[i][k] <= 1) continue;
				ansc = (ansc + (tz1[i][k] - 1) * (tz1[j][k] - 1)) % Mod;
				if(tz2[j][k] <= 1) continue;
				ansf = (ansf + ((tz1[i][k] - 1) * (tz1[j][k] - 1)) * (tz2[j][k] - 1)) % Mod;
			} 
		}
	}
	cout << (ansc * c) % Mod, putchar(' '), cout << (ansf * f) % Mod, putchar('\n');
}

signed main() {
//	return system("fc plant1.ans ans.out"), 0;
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T = read(), id = read();
	while(T--) Main();
	return 0;
}

