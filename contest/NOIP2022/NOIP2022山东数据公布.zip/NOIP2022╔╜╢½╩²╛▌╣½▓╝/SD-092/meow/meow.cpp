/*
	���һս��Ը�Լ������ź�
	NOIP 2022 RP++
	Time: 12:21 �����õ��ķ������ܵ����� 1=
	���ѧ OI �� 
	���, ���ѧ����
	ѧ OI �����ʱ����ĺܿ���
	���� OI ��ѧ���� 
	luogu uid : 396974 
*/
#include <bits/stdc++.h>
#define pb push_back
#define lson rt << 1
#define rson rt << 1 | 1
#define int long long
using namespace std;
typedef long long ll;

const int N = 1e6 + 10;
const int INF = 0x3f3f3f3f;

inline int read() {
	int res = 0, f = 0; char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) f |= (ch == '-');
	for(; isdigit(ch); ch = getchar()) res = (res << 1) + (res << 3) + (ch - '0');
	return f ? -res : res;
}

std::deque <int> q[310]; 
int n, m, k, a[N], T;


void Main() {
	n = read(), m = read(), k = read();
	for(int i = 1; i <= m; i++) a[i] = read();
	int rest = m, now = 1;
	for(int i = 1; i <= n; i++) q[i].clear();
	while(rest) {
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= n; j++) {
				if(!q[i].size() || !q[j].size()) continue;
				if(i == j) continue;
				if(q[i].back() == q[j].back()) {
					q[i].pop_back(), q[j].pop_back();
					cout << 2, putchar(' '), cout << i, putchar(' '), cout << j, putchar('\n');	
					rest -= 2;
				}
			}
		}
		for(int i = 1; i <= n; i++) {
			if(!q[i].size()) continue;
			if(q[i].front() == a[now]) {
				now++; rest -= 2; q[i].pop_front();
				cout<<1,putchar(' '),cout<<i,putchar('\n');
			} 
		}
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= n; j++) {
				if(!q[i].size() || !q[j].size()) continue;
				if(i == j) continue;
				if(q[i].back() == q[j].back()) {
					q[i].pop_back(), q[j].pop_back();
					cout << 2, putchar(' '), cout << i, putchar(' '), cout << j, putchar('\n');	
					rest -= 2;
				}
			}
		}
		if(now < m) {
			int f = 1;
			for(int i = 1; i <= n; i++) {
				if(!q[i].size()) {
					q[i].push_front(a[now]), now++;	
					cout<<1,putchar(' '),cout <<i,putchar('\n');
					f=1;
					break;
				}
			}
			if(!f) {
			int wz = rand() % n + 1;
			cout<<1,putchar(' '),cout <<wz,putchar('\n');
			q[wz].push_front(a[now]);
			now++;	
				
			}
		}
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= n; j++) {
				if(!q[i].size() || !q[j].size()) continue;
				if(i == j) continue;
				if(q[i].back() == q[j].back()) {
					q[i].pop_back(), q[j].pop_back();
					cout << 2, putchar(' '), cout << i, putchar(' '), cout << j, putchar('\n');	
					rest -= 2;
				}
			}
		}
	}
}

signed main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout); 
	srand(20060722); 
	T = read();
	while(T--) Main(); 
	return 0;
}

