/*
	���һս��Ը�Լ������ź�
	NOIP 2022 RP++
	Time: 12:21 �����õ��ķ������ܵ����� 1=
	���ѧ OI �� 
	���, ���ѧ����
	ѧ OI �����ʱ����ĺܿ���
	���� OI ��ѧ���� 
	luogu uid : 396974 
*/	
#include <bits/stdc++.h>
#define pb push_back
#define lson rt << 1
#define rson rt << 1 | 1
#define int long long
using namespace std;
typedef long long ll;
typedef unsigned long long ull;

const int N = 3000 + 10;
const int INF = 0x3f3f3f3f;
 
inline int read() {
	int res = 0, f = 0; char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) f |= (ch == '-');
	for(; isdigit(ch); ch = getchar()) res = (res << 1) + (res << 3) + (ch - '0');
	return f ? -res : res;
}
int Fa[N][22], Fb[N][22], T, n, a[N], b[N], Q, lg[N];
ull ANS[N][N], A[N][N];

inline int Querya(int l, int r) {
	int k = lg[r - l + 1];
	return max(Fa[l][k], Fa[r - (1 << k) + 1][k]);
}
inline int Queryb(int l, int r) {
	int k = lg[r - l + 1];
	return max(Fb[l][k], Fb[r - (1 << k) + 1][k]);
}

signed main() {
//	return system("fc match3.ans ans.out"), 0;
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	T = read(), n = read();
	lg[0] = -1;
	for(int i = 1; i <= n; i++) lg[i] = lg[i >> 1] + 1;
	for(int i = 1; i <= n; i++) a[i] = read(), Fa[i][0] = a[i];
	for(int i = 1; i <= n; i++) b[i] = read(), Fb[i][0] = b[i];
	for(int j = 1; j <= 20; j++) {
		for(int i = 1; i + (1 << j) - 1 <= n; i++) {
			Fa[i][j] = max(Fa[i][j - 1], Fa[i + (1 << (j - 1))][j - 1]);
			Fb[i][j] = max(Fb[i][j - 1], Fb[i + (1 << (j - 1))][j - 1]);			
		}
	}
	for(int i = 1; i <= n; i++) {
		for(int j = i; j <= n; j++) {
			ull calc = (Querya(i, j) * Queryb(i, j));
			A[i][j] = calc;
		}
	}
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			ANS[i][j] = ANS[i][j - 1] + A[i][j];
		}
	}
	Q = read();
	while(Q--) {
		ull ans = 0; 
		int l = read(), r = read();
		for(int i = l; i <= r; i++) ans += ANS[i][r] - ANS[i][i - 1];
		cout << ans; putchar('\n');
	}
	return 0;
}

