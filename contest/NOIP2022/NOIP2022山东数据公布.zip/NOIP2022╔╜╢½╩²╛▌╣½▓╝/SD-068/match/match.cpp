#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
typedef long long LL;
typedef unsigned long long ULL;

const int maxn = 100005;

inline LL read()
{
	LL s=0; bool w=0; char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-') w=1; ch=getchar();}
	while(ch>='0' && ch<='9'){s=(s<<3)+(s<<1)+(ch^48); ch=getchar();}
	return w ? ~s+1 : s;
}

int n,a[maxn],b[maxn];
int q;

int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T=read(); n=read();
	for(int i=1; i<=n; i++) a[i] = read();
	for(int i=1; i<=n; i++) b[i] = read();
	q=read();
	for(int i=1; i<=q; i++)
	{
		int l=read(); int r=read();
		unsigned long long ans = 0;
		for(int j=l; j<=r; j++)
		{
			ULL amax = 0;
			ULL bmax = 0;
			for(int k=j; k<=r; k++)
			{
				amax = max(amax,1ull*a[k]); bmax = max(bmax,1ull*b[k]);
				ans +=  amax*bmax;
			}
		}
		printf("%llu\n",ans);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
