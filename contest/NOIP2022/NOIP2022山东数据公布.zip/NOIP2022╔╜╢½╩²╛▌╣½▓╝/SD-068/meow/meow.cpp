#include<cstdio>
#include<iostream>
#include<cstring>
#include<stack>
#include<deque>
#include<queue>
using namespace std;
typedef long long LL;

const int maxn = 305;
const int maxm = 2000005;

inline LL read()
{
	LL s=0; bool w=0; char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-') w=1; ch=getchar();}
	while(ch>='0' && ch<='9'){s=(s<<3)+(s<<1)+(ch^48); ch=getchar();}
	return w ? ~s+1 : s;
}

int T,n,a[maxm],m,K;
deque<int> q[maxn];

struct Res
{
	int typ;
	int s1,s2;
	Res(){}
	Res(int t_,int s1_,int s2_){typ=t_; s1=s1_; s2=s2_;}
};
queue<Res> ans;

int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read(); m=read(); K=read();
		for(int i=1; i<=m; i++) a[i] = read();
		if(n==2)
		{
			for(int i=1; i<=m; i++)
			{
				if(q[1].empty() && (!q[2].empty()))
				{
					if(q[2].front() == a[i])
					{
						q[2].pop_front();
						ans.push(Res(1,1,1));
						ans.push(Res(2,1,2));
						continue;
					}
					else
					{
						q[2].push_back(a[i]);
						ans.push(Res(1,2,2));
						continue;
					}
				}
				else if(q[2].empty() && (!q[1].empty()))
				{
					if(q[1].front() == a[i])
					{
						q[1].pop_front();
						ans.push(Res(1,2,2));
						ans.push(Res(2,1,2));
						continue;
					}
					else
					{
						q[1].push_back(a[i]);
						ans.push(Res(1,1,1));
						continue;
					}
				}
				else if(q[1].empty() && q[2].empty())
				{
					q[1].push_back(a[i]);
					ans.push(Res(1,1,1));
					continue;
				}
				else if(q[1].back() == a[i])
				{
					q[1].pop_back();
					ans.push(Res(1,1,1));
					continue;
				}
				else if(q[2].back() == a[i])
				{
					q[2].pop_back();
					ans.push(Res(1,2,2));
					continue;
				}
			}
		}
		else {continue;}
		printf("%d\n",ans.size());
		while(!ans.empty())
		{
			Res tmp = ans.front(); ans.pop(); 
			if(tmp.typ == 1) printf("1 %d\n",tmp.s1);
			else printf("2 %d %d\n",tmp.s1,tmp.s2);
		}
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
