#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
typedef long long LL;

const int maxn = 1005;
const LL mod = 998244353;

inline LL read()
{
	LL s=0; bool w=0; char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-') w=1; ch=getchar();}
	while(ch>='0' && ch<='9'){s=(s<<3)+(s<<1)+(ch^48); ch=getchar();}
	return w ? ~s+1 : s;
}

inline LL madd(LL a,LL b){a+=b; return a>mod ? a-mod : a;}
inline LL msub(LL a,LL b){a-=b; return a<0 ? a+mod : a;}
inline LL M(LL a,LL b){return (a*b)%mod;}

int n,m,cc,ff;
int a[maxn][maxn];

LL heng[maxn][maxn];
LL shu[maxn][maxn];
LL zhe[maxn][maxn];

int T,id;

void find_heng()
{
	for(int i=1; i<=n; i++)
	{
		for(int j=m; j>=1; j--)
		{
			if(a[i][j] == 1) heng[i][j] = 0;
			else if(a[i][j] == 0) heng[i][j] = madd(heng[i][j+1], 1);
		}
	}
	return;
}

void find_shu()
{
	for(int j=1; j<=m; j++)
	{
		for(int i=n; i>=1; i--)
		{
			if(a[i][j] == 1) shu[i][j] = 0;
			else if(a[i][j] == 0) shu[i][j] = madd(shu[i+1][j], 1);
		}
	}
	return;
}

void find_zhe()
{
	for(int j=1; j<=m; j++)
	{
		for(int i=1; i<=n; i++)
		{
			if(a[i][j] == 1) zhe[i][j] = 0;
			else if(a[i][j] == 0 && a[i-1][j] == 0) zhe[i][j] = madd(zhe[i-1][j], heng[i-1][j+1]);
		}
	}
	return;
}

int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read(); id=read();
	while(T--)
	{
		n=read(); m=read(); cc=read(); ff=read();
		memset(heng,0,sizeof(heng)); memset(shu,0,sizeof(shu)); memset(zhe,0,sizeof(zhe));
		char ch;
		for(int i=1; i<=n; i++)
		{
			ch=getchar();
			while(ch!='0' && ch!='1') ch=getchar();
			for(int j=1; j<=m; j++)
			{
				a[i][j] = ch-'0';
				ch=getchar();
			}
		}
		find_heng(); find_shu(); find_zhe();
		LL ans_c = 0; LL ans_f = 0;
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=m; j++)
			{
				LL now_c = M(heng[i][j+1],zhe[i-1][j]);
				ans_c = madd(ans_c, now_c);
				ans_f = madd(ans_f, M(now_c,shu[i+1][j]));
			}
		}
		printf("%lld %lld\n",M(ans_c,cc),M(ans_f,ff));
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
