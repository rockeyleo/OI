#include<cstdio>
#include<iostream>
#include<cstring>
#include<stack>
using namespace std;
typedef long long LL;

const int maxn = 500005;
const int maxm = 1000005;
const LL mod = 1000000007;

inline LL read()
{
	LL s=0; bool w=0; char ch=getchar();
	while(ch<'0' || ch>'9'){if(ch=='-') w=1; ch=getchar();}
	while(ch>='0' && ch<='9'){s=(s<<3)+(s<<1)+(ch^48); ch=getchar();}
	return w ? ~s+1 : s;
}

inline LL madd(LL a,LL b){a+=b; return a>mod ? a-mod : a;}
inline LL msub(LL a,LL b){a-=b; return a<0 ? a+mod : a;}
inline LL M(LL a,LL b){return (a*b)%mod;}

LL pow2[maxm+10];
void init_math()
{
	pow2[0] = 1;
	for(int i=1; i<=maxm; i++) pow2[i] = M(pow2[i-1],2);
	return;
}

int n,m;

class Graph
{
public:
	struct Edge
	{
		int u,v,nxt;
		bool isb;
	}e[maxm<<1];
	int h[maxn],ecnt;
	void adde(int u,int v)
	{
		ecnt++; e[ecnt].u=u; e[ecnt].v=v; e[ecnt].nxt = h[u]; h[u] = ecnt; return;
	}
	Graph(){memset(h,0,sizeof(h)); ecnt = 1;}
}gr,tr;

int dfn[maxn],low[maxn],times;
int id[maxn];

void tarjan(int u,int lst)
{
	low[u] = dfn[u] = ++times;
	for(int i=gr.h[u]; i; i=gr.e[i].nxt)
	{
		int v=gr.e[i].v;
		if(!dfn[v])
		{
			tarjan(v,u);
			low[u] = min(low[u],low[v]);
			if(low[v] > dfn[u])
			{
				gr.e[i].isb = gr.e[i^1].isb = true;
			}
		}
		else if(v!=lst) low[u] = min(low[u],dfn[v]);
	}
	return;
}

int nowid;
LL val[maxn][2];
int dcc_size[maxn];
int edge_num[maxn];

void find_dcc(int u)
{
	id[u] = nowid;
	dcc_size[nowid]++;
	for(int i=gr.h[u]; i; i=gr.e[i].nxt)
	{
		if(gr.e[i].isb) continue;
		int v=gr.e[i].v;
		if(!id[v]) find_dcc(v);
	}
	return;
}

void build_tree()
{
	for(int i=1; i<=n; i++)
	{
		if(!id[i])
		{
			nowid++;
			find_dcc(i);
		}
	}
	for(int i=2; i<=gr.ecnt; i+=2)
	{
		int u=gr.e[i].u; int v=gr.e[i].v;
		if(id[u] == id[v])
		{
			edge_num[id[u]]++;
		}
		else
		{
			tr.adde(id[u],id[v]); tr.adde(id[v],id[u]);
		}
	}
	for(int i=1; i<=nowid; i++)
	{
		val[i][0] = pow2[edge_num[i]];
		val[i][1] = M(val[i][0], msub(pow2[dcc_size[i]],1));
	}
	return;
}

int siz[maxn];
LL f[maxn][2];
LL ans;

void dp(int u,int lst)
{
	siz[u] = edge_num[u];
	LL tmp1 = 1;
	LL tmp2 = 1;
	LL g0 = 0,g1 = 0;
	for(int i=tr.h[u]; i; i=tr.e[i].nxt)
	{
		int v=tr.e[i].v; if(v==lst) continue;
		dp(v,u);
		siz[u] += siz[v]+1;
		tmp1 = M(tmp1, madd(f[v][1], M(f[v][0],2)) );
		LL tmpp = M(f[v][1], madd(g0,g1)); g1=tmpp;
		g0 = madd(M(g0,M(2,f[v][0])), M(tmp2,f[v][1]));
		tmp2 = M(tmp2, M(2,f[v][0]));
	}
	f[u][0] = M(tmp2,val[u][0]); f[u][1] = madd(M(tmp1,val[u][1]),M(g1,val[u][0]));
	ans = madd(ans, M(f[u][1], pow2[m-siz[u]]));
//	printf("f[%d][0,1] = %lld %lld contri = %lld\n",u,f[u][0],f[u][1],M(f[u][1], pow2[m-siz[u]]));
	return;
}

int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	init_math();
	n=read(); m=read();
	for(int i=1; i<=m; i++)
	{
		int u=read(); int v=read();
		gr.adde(u,v); gr.adde(v,u);
	}
	tarjan(1,0);
	build_tree();
	dp(1,0);
	printf("%lld\n",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
