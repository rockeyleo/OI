#include<map>
#include<ctime>
#include<cmath>
#include<vector>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define int unsigned long long
using namespace std;

const int INF=0x3f3f3f3f;
const int Mod=998244353;
const int Maxn=1e6+7;

int read(){
    int x=0,f=0;
    char ch=getchar();
    for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
    for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^'0');
    return f?-x:x;
}

void print(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) print(x/10);
    putchar(x%10+'0');
}

int n,a[Maxn],b[Maxn],Log[Maxn];
int f[Maxn][21],F[Maxn][21];

int Query1(int l,int r){
    int x=Log[r-l+1];
    return max(f[l][x],f[r-(1<<x)+1][x]);
}

int Query2(int l,int r){
    int x=Log[r-l+1];
    return max(F[l][x],F[r-(1<<x)+1][x]);
}

signed main(){
//    return system("fc aaa.txt match2.ans"),0;
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    Log[0]=-1;
    for(int i=1;i<=Maxn-5;i++) Log[i]=Log[i>>1]+1;
    read();n=read();
    for(int i=1;i<=n;i++) a[i]=f[i][0]=read();
    for(int i=1;i<=n;i++) b[i]=F[i][0]=read();
    for(int i=1;i<=Log[n];i++){
        for(int j=1;j+(1<<i)-1<=n;j++){
            f[j][i]=max(f[j][i-1],f[j+(1<<i-1)][i-1]);
            F[j][i]=max(F[j][i-1],F[j+(1<<i-1)][i-1]);
        }
    }
    int Q=read();
    while(Q--){
        int l=read(),r=read();
        int ans=0;
        for(int p=l;p<=r;p++){
            for(int q=p;q<=r;q++){
//                cout<<p<<' '<<q<<endl;
                int Max1=Query1(p,q);
                int Max2=Query2(p,q);
                ans+=Max1*Max2;
            }
        }
        print(ans);putchar('\n');
    }
    return 0;
}

