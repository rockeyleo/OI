#include<map>
#include<ctime>
#include<cmath>
#include<vector>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define int long long
using namespace std;

const int INF=0x3f3f3f3f;
const int Mod=998244353;
const int Maxn=1005;

int read(){
    int x=0,f=0;
    char ch=getchar();
    for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
    for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^'0');
    return f?-x:x;
}

void print(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) print(x/10);
    putchar(x%10+'0');
}

int n,m,c,f;
int a[Maxn][Maxn];
int u[Maxn][Maxn],r[Maxn][Maxn],Q[Maxn][Maxn],q[Maxn][Maxn];

void Main(){
    memset(u,0,sizeof u);
    memset(r,0,sizeof r);
    memset(Q,0,sizeof Q);
    memset(q,0,sizeof q);
    int C=0,F=0;
    n=read(),m=read(),c=read(),f=read();
    if(!c&&!f) return puts("0 0"),void();
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            char ch;scanf(" %c",&ch);
            a[i][j]=(ch=='1')?1:0;
        }
    }
    
    for(int i=n;i>=1;i--){
        for(int j=m;j>=1;j--){
            if(a[i][j]==1) r[i][j]=-1;
            else{
                r[i][j]=1;
                if(j+1<=m&&a[i][j+1]==0) r[i][j]+=r[i][j+1];
            } 
        }
    }
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
    if(r[i][j]!=-1) r[i][j]--;

    for(int j=m;j>=1;j--){
        for(int i=n;i>=1;i--){
            if(a[i][j]==1) u[i][j]=-1;
            else {
                u[i][j]=1;
                if(i+1<=n&&a[i+1][j]==0) u[i][j]+=u[i+1][j];
            }
        }
    }
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
    if(u[i][j]!=-1) u[i][j]--;
    for(int i=n;i>=1;i--){
        for(int j=m;j>=1;j--){
            if(a[i][j]==1){
                Q[i][j]=0,q[i][j]=0;
                continue;
            } 
            Q[i][j]+=r[i][j]*u[i][j];Q[i][j]%=Mod;
            q[i][j]+=r[i][j];q[i][j]%=Mod;
        }
    }
    for(int j=1;j<=m;j++){
        for(int i=n;i>=1;i--){
            if(a[i][j]==1) continue;
            Q[i][j]+=Q[i+1][j];Q[i][j]%=Mod;
            q[i][j]+=q[i+1][j];q[i][j]%=Mod;
        }
    }
    
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(a[i][j]==1) continue;
            Q[i][j]-=r[i][j]*u[i][j];
            q[i][j]-=r[i][j];
            if(i+1<=n&&a[i+1][j]==1) continue;
            Q[i][j]-=r[i+1][j]*u[i+1][j];
            q[i][j]-=r[i+1][j];
        }
    }
    
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(a[i+1][j]==1||a[i][j]==1) continue;
            C+=r[i][j]*q[i][j];C%=Mod;
            F+=r[i][j]*Q[i][j];F%=Mod;
        }
    }
    print((C*c)%Mod),putchar(' '),print((f*F)%Mod);putchar('\n');
} 

signed main(){
    freopen("plant.in","r",stdin);
    freopen("plant.out","w",stdout);
    int T=read();read();
    while(T--) Main(); 
    return 0;
}

