#include<map>
#include<ctime>
#include<cmath>
#include<vector>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define int long long
using namespace std;

const int INF=0x3f3f3f3f;
const int Mod=998244353;
const int Maxn=1e6+7;

int read(){
    int x=0,f=0;
    char ch=getchar();
    for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
    for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch^'0');
    return f?-x:x;
}

void print(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) print(x/10);
    putchar(x%10+'0');
}

int n,m;
int head[100],cnt;
struct node{int v,nxt;}e[Maxn]; 
void Add(int u,int v){e[++cnt]=(node){v,head[u]};head[u]=cnt;}

int stc[Maxn],sc,u[Maxn],v[Maxn];

bool vis[100];
void dfs(int u,int fa){
    if(vis[u]) return; vis[u]=1;
    for(int i=head[u];i;i=e[i].nxt){
        int v=e[i].v;
        if(v==fa) continue;
        dfs(v,u);
    }
}

signed main(){
    freopen("barrack.in","r",stdin); 
    freopen("barrack.out","w",stdout); 
    n=read(),m=read();
    for(int i=1;i<=m;i++) u[i]=read(),v[i]=read();
    int ans=0;
    for(int i=0;i<(1<<n);i++){
        
        sc=0;
        for(int k=1;k<=14;k++) if((1<<(k-1))&i) stc[++sc]=k;
        
//        cout<<"i: "<<i<<'\n';
//        for(int k=1;k<=sc;k++) cout<<stc[k]<<' ';
//        cout<<'\n';
        
        for(int j=0;j<(1<<m);j++){
            bool f=0;
            memset(head,0,sizeof head),cnt=0;
            for(int k=1;k<=15;k++) if((1<<(k-1))&j){
//                cout<<k<<' ';
                Add(u[k],v[k]),Add(v[k],u[k]);
//                cout<<u[k]<<" "<<v[k]<<'\n';
            }
            if(sc) {
                memset(vis,0,sizeof vis),dfs(stc[1],-1);
                for(int k=1;k<=sc;k++)if(!vis[stc[k]]){f=1;break;}
            }
            if(f) continue;
            ans++;
        }
    }
    cout<<ans;
    return 0;
}

