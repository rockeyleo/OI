#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
long long ans1,ans2,ansc,ansf,b,d;
long long m,n,f,e,c,flag;
char a[10005][10005],i1,T,c1;
int dc(int i,int j){
	b=0;
	d=0;
	if(a[i][j]=='1'){
		if(a[i+1][j]=='1'&&a[i][j+1]=='1'&&a[i+2][j]=='1'){
			for(int x=1;x<=n-i;x++){
				if(a[i][j+x]=='1') b++;
				else break;
			}
			for(int x=2;x<=m-i;x++){
				if(a[i+x][j]=='1'){
					for(int y=1;y<=n-j;y++){
						if(a[i+x][j+y]=='1') d++;
						else break;
					}
				}
				else break;
			}
			return b*d;
		}
		else return 0;
	}
	else return 0;
}
int df(int i,int j){
	b=0;
	d=0;
	e=0;
	if(a[i][j]=='1'){
		if(a[i+1][j]=='1'&&a[i][j+1]=='1'&&a[i+2][j]=='1'){
			for(int x=1;x<=n-i;x++){
				if(a[i][j+x]=='1') b++;
				else break;
			}
			for(int x=2;x<=m-i;x++){
				if(a[i+x][j]=='1'&&a[i+x+1][j]=='1'){
					flag=0;
					for(int y=1;y<=n-j;y++){
						if(a[i+x][j+y]=='1') d++,flag=1;
						else break;
					}
					e=0;
					if(flag==1){
						for(int y=1;y<=n-i-x;y++){
				 if(a[i+x+y][j]=='1') e++;
					else break;
			}
			if(e!=0) d=e*d;
					}
				}
				else break;
			}
			return b*d;
		}
		else return 0;
	}
	else return 0;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T;
	cin>>i1;
	cin>>m>>n>>f>>c1;
	c=c1-48;
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];
			a[i][j]++;
		}
	}
	for(int x=1;x<=m;x++){
		for(int y=1;y<=n;y++){
			ans1=dc(x,y);
			ans2=df(x,y);
			ansc+=ans1;
			ansf+=ans2;
		}
	}
	cout<<ansc*c<<" "<<ansf*f;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
