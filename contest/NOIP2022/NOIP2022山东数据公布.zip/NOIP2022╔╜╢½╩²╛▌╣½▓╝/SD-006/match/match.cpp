#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int T,n,q,l,r,maxn,maxo,ans,x;
int N[100005],O[100005];
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++){
		cin>>N[i];
	}
	for(int i=1;i<=n;i++){
		cin>>O[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>l>>r;
		for(int x=l;x<=r;x++){
			for(int y=l;y<=r;y++){
				maxn=0;
				maxo=0;
				for(int z=x;z<=y;z++){
					maxn=max(maxn,N[z]);
					maxo=max(maxo,O[z]);
				}
				ans+=maxn*maxo;
			}
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
