#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
