#include<bits/stdc++.h>
#define int long long
#define ld long double
using namespace std;

inline int read()
{
	int s=0,w=1; char c=getchar();
	while(!isdigit(c)) {if(c=='-') w=-1; c=getchar();}
	while(isdigit(c)) s=(s<<1)+(s<<3)+(c^48),c=getchar();
	return s*w;
}

namespace LgxTpre
{
	static const int MAX=10010;
	static const int INF=2007070707070707;

	int T,n;
	int q,l,r;
	unsigned long long sum[MAX][MAX];
	unsigned long long ans;
	
	struct Segment_Tree
	{
		int val[MAX];
		struct tree
		{
			int l,r;
			int maxx;
		}t[MAX<<2];
		inline void pushup(int i)
		{
			t[i].maxx=max(t[i<<1].maxx,t[i<<1|1].maxx);
			return;
		}
		void build(int i,int l,int r)
		{
			t[i].l=l,t[i].r=r;
			if(l==r) {t[i].maxx=val[l];return;}
			int mid=(l+r)>>1;
			build(i<<1,l,mid);
			build(i<<1|1,mid+1,r);
			pushup(i);
			return;
		}
		int getans(int i,int l,int r)
		{
			if(t[i].l>=l&&t[i].r<=r) return t[i].maxx;
			int mid=(t[i].l+t[i].r)>>1,ans=-INF;
			if(l<=mid) ans=max(ans,getans(i<<1,l,r));
			if(r>mid) ans=max(ans,getans(i<<1|1,l,r));
			return ans; 
		}
	}a,b;

	inline void lmy_forever()
	{
		T=read(),n=read();
		for(int i=1;i<=n;++i)
			a.val[i]=read();
		for(int j=1;j<=n;++j)
			b.val[j]=read();
		a.build(1,1,n),b.build(1,1,n);
		for(int L=1;L<=n;++L)
			for(int R=L;R<=n;++R)
				sum[L][R]=a.getans(1,L,R)*b.getans(1,L,R);
		q=read();
		for(int i=1;i<=q;++i)
		{
			ans=0;
			l=read(),r=read();
			for(int L=l;L<=r;++L)
				for(int R=L;R<=r;++R)
					ans+=sum[L][R];
			cout<<ans<<endl;
		}
		return;
	}
}

signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);

	LgxTpre::lmy_forever();
	
	fclose(stdin);
	fclose(stdout);
	return (0-0);
}
