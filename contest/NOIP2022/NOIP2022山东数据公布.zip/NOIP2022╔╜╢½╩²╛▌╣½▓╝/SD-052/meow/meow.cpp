#include<bits/stdc++.h>
#define int long long
#define ld long double
using namespace std;

inline int read()
{
	int s=0,w=1; char c=getchar();
	while(!isdigit(c)) {if(c=='-') w=-1; c=getchar();}
	while(isdigit(c)) s=(s<<1)+(s<<3)+(c^48),c=getchar();
	return s*w;
}

namespace LgxTpre
{
	static const int MAX=2000010;
	static const int INF=2007070707070707;
	
	int T;
	int n,m,k;
	int a[MAX];
	
	struct operation
	{
		int op,x,y;
	}p[MAX<<2];
	int tot;
	int q[MAX],head,tail;
	inline void init1()
	{
		for(int i=1;i<=tot;++i)
			p[i].op=p[i].x=p[i].y=0;
		memset(q,0,sizeof q);
		tot=0;
		return;
	}
	
	inline void print()
	{
		cout<<tot<<endl;
		for(int i=1;i<=tot;++i)
			if(p[i].op==1)
				cout<<p[i].op<<" "<<p[i].x<<endl;
			else 
				cout<<p[i].op<<" "<<p[i].x<<" "<<p[i].y<<endl;
		return;
	}
	
	inline bool check(int x)
	{
		head=1,tail=0;
		int top=0;
		for(int i=1;i<=m;++i)
			if(a[i]==x)
				p[++tot].op=1,p[tot].x=1,++top;
			else
				{
					if(q[tail]==a[i]&&head<=tail) {--tail; p[++tot].op=1,p[tot].x=2; continue;} 
					if(top%2==0&&head<=tail&&q[head]==a[i]) {++head; p[++tot].op=1,p[tot].x=1; p[++tot].op=2,p[tot].x=1,p[tot].y=2; continue;}
					p[++tot].op=1,p[tot].x=2;
					q[++tail]=a[i];
				}
		if(head==tail+1) return 1;
		return 0;
	}
	inline void solve2()
	{
		while(T--)
		{
			n=read(),m=read(),k=read();
			for(int i=1;i<=m;++i)
				a[i]=read();
			init1(); if(check(1)) {print(); continue;} 
			init1(); if(check(2)) {print(); continue;} 
			init1(); if(check(3)) {print(); continue;} 
		}
		return;
	}
	
	int q1[MAX],head1,tail1;
	int q2[MAX],head2,tail2;
	int q3[MAX],head3,tail3;
	int flag;
	void dfs(int now)
	{
		if(flag) return;
		if(now==m+1)
		{
			if(head1==tail1+1&&head2==tail2+1&&head3==tail3+1) print(),flag=1;
			return;
		}	
		q1[++tail1]=a[now];
		++tot,p[tot].op=1,p[tot].x=1;
		if(q1[tail1]==q1[tail1-1])
		{
			int t=q1[tail1];
			q1[tail1--]=0,q1[tail1--]=0;
			dfs(now+1);
			q1[++tail1]=t,q1[++tail1]=t;
		}
		else dfs(now+1);
		q1[tail1--]=0;
		p[tot].op=0,p[tot].x=0,--tot;
		
		if(flag) return;
		
		q2[++tail1]=a[now];
		++tot,p[tot].op=1,p[tot].x=2;
		if(q2[tail2]==q2[tail2-1])
		{
			int t=q2[tail2];
			q2[tail2--]=0,q2[tail2--]=0;
			dfs(now+1);
			q1[++tail2]=t,q1[++tail2]=t;
		}
		else dfs(now+1);
		q2[tail2--]=0;
		p[tot].op=0,p[tot].x=0,--tot;
		
		if(flag) return;
		
		q3[++tail3]=a[now];
		++tot,p[tot].op=1,p[tot].x=1;
		if(q3[tail3]==q3[tail3-1])
		{
			int t=q3[tail3];
			q3[tail3--]=0,q1[tail3--]=0;
			dfs(now+1);
			q3[++tail3]=t,q1[++tail3]=t;
		}
		else dfs(now+1);
		q3[tail3--]=0;
		p[tot].op=0,p[tot].x=0,--tot;
		
		if(flag) return;
		
		if(q1[head1]==q2[head2])
		{
			++tot,p[tot].op=2,p[tot].x=1,p[tot].y=2;
			int t1=q1[head1],t2=q2[head2];
			q1[head1++]=0,q2[head2++]=0;
			dfs(now);
			q1[--head1]=t1,q2[--head2]=t2;
			p[tot].op=0,p[tot].x=0,p[tot].y=0,--tot;
		}
		
		if(flag) return;
		
		if(q1[head1]==q3[head3])
		{
			++tot,p[tot].op=2,p[tot].x=1,p[tot].y=3;
			int t1=q1[head1],t3=q3[head3];
			q1[head1++]=0,q3[head3++]=0;
			dfs(now);
			q1[--head1]=t1,q3[--head3]=t3;
			p[tot].op=0,p[tot].x=0,p[tot].y=0,--tot;
		}
		
		if(flag) return;
		
		if(q2[head2]==q3[head3])
		{
			++tot,p[tot].op=2,p[tot].x=2,p[tot].y=3;
			int t2=q2[head2],t3=q3[head3];
			q2[head2++]=0,q3[head3++]=0;
			dfs(now);
			q2[--head2]=t2,q3[--head3]=t3;
			p[tot].op=0,p[tot].x=0,p[tot].y=0,--tot;
		}
		return;
	}
	inline void init2()
	{
		memset(q1,0,sizeof q1);
		memset(q2,0,sizeof q2);
		memset(q3,0,sizeof q3);
		head1=head2=head3=1;
		tail1=tail2=tail3=0;
		memset(p,0,sizeof p);
		tot=0;
		return;
	}
	inline void solve3()
	{
		while(T--)
		{
			flag=0;
			n=read(),m=read(),k=read();
			for(int i=1;i<=m;++i)
				a[i]=read();
			init2(); 
			dfs(1);
		}
		return;
	}

	inline void lmy_forever()
	{
		T=read();
		if(T%10==2) solve2();
		if(T%10==3) solve3();
		return;
	}
}

signed main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	LgxTpre::lmy_forever();
	
	fclose(stdin);
	fclose(stdout);
	return (0-0);
}
