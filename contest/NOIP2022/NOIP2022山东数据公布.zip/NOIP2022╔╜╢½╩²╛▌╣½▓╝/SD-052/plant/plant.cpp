#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read()
{
	int s=0,w=1; char c=getchar();
	while(!isdigit(c)) {if(c=='-') w=-1; c=getchar();}
	while(isdigit(c)) s=(s<<1)+(s<<3)+(c^48),c=getchar();
	return s*w;
}

namespace LgxTpre
{
	static const int MAX=1010;
	static const int INF=20070707;
	static const int mod=998244353; 
	
	int T,id;
	int n,m,c,f;
	int mp[MAX][MAX];
	int oneh[MAX][MAX],ones[MAX][MAX];
	int ansc,ansf;
	char ch;
	
	inline void init()
	{
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				mp[i][j]=oneh[i][j]=ones[i][j]=0;
		ansc=0,ansf=0;
		return;
	}
	
	inline void lmy_forever()
	{
		T=read(),id=read();
		while(T--)
		{
			init();
			n=read(),m=read(),c=read(),f=read();
			for(int i=1;i<=n;++i)
			{
				for(int j=1;j<=m;++j)
					ch=getchar(),
					mp[i][j]=(ch=='1');
				ch=getchar();
			}
			for(int i=1;i<=n;++i)
			{
				int last=m+1;
				for(int j=m;j>=1;--j)
				{
					if(mp[i][j]==1) last=j;
					oneh[i][j]=last; 
				}
			}
			for(int j=1;j<=m;++j)
			{
				int last=n+1;
				for(int i=n;i>=1;--i)
				{
					if(mp[i][j]==1) last=i;
					ones[i][j]=last;
				}
			}
			for(int i=1;i<=n-2;++i)
				for(int j=1;j<=m;++j)
				{
					if(oneh[i][j]-j<2) continue;
					if(mp[i][j]==1||mp[i+1][j]==1) continue;
					for(int k=i+2;k<=n;++k)
					{
						if(mp[k][j]==1) break; 
						if(oneh[k][j]-j<2) continue;
						ansc+=(oneh[i][j]-j-1)*(oneh[k][j]-j-1);
						ansc%=mod;
						if(ones[k][j]-k<1) continue;
						ansf+=(oneh[i][j]-j-1)*(oneh[k][j]-j-1)*(ones[k][j]-k-1);
						ansf%=mod;
					}
				}
			cout<<ansc*c%mod<<" "<<ansf*f%mod<<endl;
		}
		return;
	}
}

signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	
	LgxTpre::lmy_forever();
	
	fclose(stdin);
	fclose(stdout);
	return (0-0);
}
