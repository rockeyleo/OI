#include<bits/stdc++.h>
#define N 310
#define M 610 
using namespace std;
int T,n,m,k;
int vis[M];
int Map[2000010],tot[2000010];
int s[N][3],t[N];
struct node{
	int op;
	int a;
	int b;
};
queue <node> p;
int num;
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		num=0;
		memset(vis,0,sizeof vis);
		memset(s,0,sizeof s);
		memset(t,0,sizeof t);
		scanf("%d%d%d",&n,&m,&k);
		if(k==n*2-2)
		{
			for(int i=1;i<=m;i++)
			{
				int x;
				scanf("%d",&x);
				int st=(x+1)/2;
				if(vis[x])
				{
					if(s[st][t[st]]==x)
					{
						node tmp;
						tmp.op=1;
						tmp.a=st;
						num++;
						p.push(tmp);
						t[st]--;
					}
					else
					{
						node tmp;
						tmp.op=1;
						tmp.a=n;
						num++;
						p.push(tmp);
						tmp.op=2;
						tmp.a=st;
						tmp.b=n;
						num++;
						p.push(tmp);
						t[st]--;
						s[st][t[st]]=s[st][t[st]+1];
					}
					vis[x]=false;
				}
				else
				{
					node tmp;
					tmp.op=1;
					tmp.a=st;
					num++;
					p.push(tmp);
					s[st][++t[st]]=x;
					vis[x]=true;
				}
			}
		}
		else if(n==2)
		{
			tot[0]=0;
			int tmp=0;
			for(int i=1;i<=m;i++)
			{
				int x;
				scanf("%d",&x);
				if(x==Map[tmp])
					tot[tmp]++;
				else
					Map[++tmp]=x,tot[tmp]=1;
			}
			for(int i=1;i<=tmp;i++)
			{
				while(tot[i]>1)
				{
					node tt;
					tt.op=1;
					tt.a=1;
					num+=2;
					p.push(tt);
					p.push(tt);
					tot[i]-=2;
				}
				if(tot[i]==0)
					continue;
				if(Map[i]==s[1][t[1]])
				{
					node tt;
					tt.op=1;
					tt.a=1;
					num++;
					p.push(tt);
					t[1]--;
				}
				else if(Map[i]==s[2][t[2]])
				{
					node tt;
					tt.op=1;
					tt.a=2;
					num++;
					p.push(tt);
					t[2]--;
				}
				else if(t[1]==0)
				{
					node tt;
					tt.op=1;
					tt.a=1;
					num++;
					p.push(tt);
					t[1]++;
					s[1][1]=Map[i];
					if(s[1][1]==s[2][1])
					{
						tt.op=2;tt.a=1;tt.b=2;
						num++;
						p.push(tt);
						t[1]--;t[2]--;
						s[2][1]=s[2][2];
					}
				}
				else if(t[2]==0)
				{
					node tt;
					tt.op=1;
					tt.a=2;
					num++;
					p.push(tt);
					t[2]++;
					s[2][1]=Map[i];
					if(s[1][1]==s[2][1])
					{
						tt.op=2;tt.a=1;tt.b=2;
						num++;
						p.push(tt);
						t[1]--;t[2]--;
						s[1][1]=s[1][2];
					}
				}
				else
				{
					int ss=i+1;
					while(tot[ss]%2==0)
						ss++;
					if(Map[ss]==s[1][1])
					{
						node tt;
						tt.op=1;
						tt.a=2;
						num++;
						p.push(tt);
						t[2]++;
						s[2][2]=Map[i];
					}
					else
					{
						node tt;
						tt.op=1;
						tt.a=1;
						num++;
						p.push(tt);
						t[1]++;
						s[1][2]=Map[i];
					}
				}
			}
		}
		printf("%d\n",num);
		while(!p.empty())
		{
			node tmp=p.front();
			p.pop();
			if(tmp.op==1)
				printf("1 %d\n",tmp.a);
			else
				printf("2 %d %d\n",tmp.a,tmp.b);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
