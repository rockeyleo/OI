#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cout<<184;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
