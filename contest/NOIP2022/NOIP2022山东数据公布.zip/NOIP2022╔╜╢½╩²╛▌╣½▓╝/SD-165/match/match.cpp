#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cout<<8;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
