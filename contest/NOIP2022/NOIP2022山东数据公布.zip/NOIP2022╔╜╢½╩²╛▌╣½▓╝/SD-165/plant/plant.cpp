#include<bits/stdc++.h>
#define N 1010
#define mod 998244353
using namespace std;
int n,m,c,f;
bool Map[N][N];
int h[N][N];
long long vc[N][N],vf[N][N];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,tmp;
	scanf("%d%d",&T,&tmp);
	while(T--)
	{
		memset(h,0,sizeof h);
		memset(vc,0,sizeof vc);
		memset(vf,0,sizeof vf);
		memset(Map,0,sizeof Map); 
		long long numc=0,numf=0;
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				char p;
				p=getchar();
				if(p=='1')
					Map[i][j]=false;
				else if(p=='0')
					Map[i][j]=true;
				else
					j--;
			}
		}
		for(int i=1;i<=n;i++)
			for(int j=m;j>=1;j--)
			{
				if(Map[i][j])
					h[i][j]=h[i][j+1]+1;
			}
		for(int i=1;i<=m;i++)
		{
			int now=0;
			for(int j=n;j>=1;j--)
			{
				if(Map[j][i])
					now++;
				else
					now=0;
				if(now>=1)
				{
					vc[j][i]=(vc[j+1][i]+h[j][i]-1)%mod;
				}
				if(now>=2)
				{
					vf[j][i]=(vf[j+1][i]+(h[j][i]-1)*(now-1))%mod;
				}
			}
		} 
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				if(Map[i][j]&&Map[i+1][j])
				{	
					numc=(numc+max(h[i][j]-1,0)*vc[i+2][j]%mod)%mod;
					numf=(numf+max(h[i][j]-1,0)*vf[i+2][j]%mod)%mod;
				}
			}
		}
		printf("%lld %lld\n",numc*c,numf*f);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 

