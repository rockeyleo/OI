#include<bits/stdc++.h>
#define ll long long
using namespace std;
void read(int &n){
	n=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		n=(n<<3)+(n<<1)+ch-'0';
		ch=getchar();
	}
	n*=f;
}
void print(ll n){
	if(n<0)putchar('-'),n=-n;
	if(n>9)print(n/10);
	putchar(n%10+'0');
}
const int N=5e5+5,M=1e6+5;
int n,m,u,v,h[N],e[M],ne[M],idx,size[N];
ll f[N][2];
void add(int u,int v){
	e[++idx]=v,ne[idx]=h[u],h[u]=idx;
}
void dfs1(int t,int p){
	size[t]=1;
	for(int i=h[t];i;i=ne[i]){
		int j=e[i];
		if(j!=p)dfs1(j,t),size[t]+=size[j];
	}
}
void dfs2(int t,int p){
	f[t][1]=1;
	for(int i=h[t];i;i=ne[i]){
		int j=e[i];
		if(j!=p)dfs1(j,t),f[t][1]*=(f[j][1]+1);
	}
	f[t][0]=1;
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=m;++i)read(u),read(v),add(u,v),add(v,u);
	dfs1(1,0),dfs2(1,0),print(f[1][1]*5);
	return 0;
}
