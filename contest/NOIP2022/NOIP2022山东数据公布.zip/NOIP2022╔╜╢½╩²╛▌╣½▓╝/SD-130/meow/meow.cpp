#include<bits/stdc++.h>
#define ll long long
using namespace std;
void read(int &n){
	n=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		n=(n<<3)+(n<<1)+ch-'0';
		ch=getchar();
	}
	n*=f;
}
void print(int n){
	if(n<0)putchar('-'),n=-n;
	if(n>9)print(n/10);
	putchar(n%10+'0');
}
const int N=305,M=2e6+5,K=605;
int t,n,m,k,a[M],q[K],top[N],down[N],qtop[K],th,tt,qdown[K],dh,dt,ans[M<<1][2],idx;
void sub1(){
	while(t--){
		read(n),read(m),read(k),idx=0,th=dh=1,tt=dt=n-1;
		for(int i=1;i<n;i++)qtop[i]=qdown[i]=i;
		for(int i=1;i<=m;++i){
			read(a[i]);
			if(!q[a[i]]){
				if(dh<=dt){
					ans[++idx][0]=qdown[dh],
					ans[idx][1]=0,
					down[qdown[dh]]=a[i],
					q[a[i]]=qdown[dh++];
				}
				else{
					ans[++idx][0]=qtop[th],
					ans[idx][1]=0,
					top[qtop[th]]=a[i],
					q[a[i]]=qtop[th++];
				}
			}
			else{
				if(down[q[a[i]]]==a[i]){
					ans[++idx][0]=n,
					ans[idx][1]=0,
					ans[++idx][0]=q[a[i]],
					ans[idx][1]=n;
					if(top[q[a[i]]])qtop[++tt]=q[a[i]];
					else qdown[++dt]=q[a[i]];
					down[q[a[i]]]=top[q[a[i]]],
					top[q[a[i]]]=0,
					q[a[i]]=0;
				}
				else{
					ans[++idx][0]=q[a[i]],
					ans[idx][1]=0,
					qtop[++tt]=q[a[i]],
					top[q[a[i]]]=0,
					q[a[i]]=0;
				}
			}
		}
		print(idx),putchar('\n');
		for(int i=1;i<=idx;++i)
			if(ans[i][1])print(2),putchar(' '),print(ans[i][0]),putchar(' '),print(ans[i][1]),putchar('\n');
			else print(1),putchar(' '),print(ans[i][0]),putchar('\n');
	}
}
int main(){
	freopen("meow.in","r",stdin),freopen("meow.out","w",stdout),
	read(t);
	if(t%10==1)sub1();
	else sub1();
	return 0;
}
