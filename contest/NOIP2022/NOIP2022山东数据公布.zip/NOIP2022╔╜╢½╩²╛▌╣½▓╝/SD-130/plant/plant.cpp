#include<bits/stdc++.h>
#define ll long long
using namespace std;
void read(int &n){
	n=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		n=(n<<3)+(n<<1)+ch-'0';
		ch=getchar();
	}
	n*=f;
}
void print(ll n){
	if(n<0)putchar('-'),n=-n;
	if(n>9)print(n/10);
	putchar(n%10+'0');
}
const int N=1005,mod=998244353;
int id,t,n,m,c,f,r[N][N],d[N][N];
bool st[N][N];
char op;
ll do_c(){
	ll res=0;
	for(int j=1;j<m;++j)
		for(int i=1;i<n-1;++i){
			if(st[i][j])continue;
			for(int k=2;k<d[i][j];++k)
				(res+=(r[i][j]-1)*(r[i+k][j]-1)%mod)%=mod;
		}
	return res;
}
ll do_f(){
	ll res=0;
	for(int j=1;j<m;++j)
		for(int i=1;i<n-2;++i){
			if(st[i][j])continue;
			for(int k=2;k<d[i][j]-1;++k)
				(res+=(r[i][j]-1)*(r[i+k][j]-1)%mod*(d[i][j]-k-1)%mod)%=mod;
		}
	return res;
}
int main(){
	freopen("plant.in","r",stdin),freopen("plant.out","w",stdout),
	read(t),read(id);
	while(t--){
		read(n),read(m),read(c),read(f),r[n][m]=1,d[n][m]=1;
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j){
				op=getchar();
				while(op<'0'||op>'9')op=getchar();
				st[i][j]=op-'0';
			}
		for(int j=m-1;j>=1;--j){
			if(st[n][j+1])r[n][j]=1;
			else r[n][j]=r[n][j+1]+1;
			d[n][j]=1;
		}
		for(int i=n-1;i>=1;--i){
			r[i][m]=1;
			if(st[i+1][m])d[i][m]=1;
			else d[i][m]=d[i+1][m]+1;			
			for(int j=m-1;j>=1;--j){
				if(st[i][j+1])r[i][j]=1;
				else r[i][j]=r[i][j+1]+1;
				if(st[i+1][j])d[i][j]=1;
				else d[i][j]=d[i+1][j]+1;
			}
		}
		if(c==0&&f==0)print(0);
		else if(c==0)print(0),putchar(' '),print(do_f());
		else if(f==0)print(do_c()),putchar(' '),print(0);
		else print(do_c()),putchar(' '),print(do_f());
	}
	return 0;
}
