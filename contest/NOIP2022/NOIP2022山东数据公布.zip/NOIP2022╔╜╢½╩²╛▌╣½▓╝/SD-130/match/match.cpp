#include<bits/stdc++.h>
#define ll long long
using namespace std;
void read(int &n){
	n=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		n=(n<<3)+(n<<1)+ch-'0';
		ch=getchar();
	}
	n*=f;
}
void print(ll n){
	if(n<0)putchar('-'),n=-n;
	if(n>9)print(n/10);
	putchar(n%10+'0');
}
int t,n,a,q;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(t),read(n);
	for(int i=1;i<=n;i++)read(a),read(a);
	read(q);
	while(q--)puts("0");
	return 0;
}
