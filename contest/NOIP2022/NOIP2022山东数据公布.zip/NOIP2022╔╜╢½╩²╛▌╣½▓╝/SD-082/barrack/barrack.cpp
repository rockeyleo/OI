#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int M = 1e6 + 5;
const int N = 5e5 + 5;
const int mod = 1e9 + 7;

int n, m, cnt, fg1;
int dp[N][2], h[N];

struct edge {
	int v, nxt;
	ll w;
} e[M << 1];

inline ll read() {
	ll x = 0;
	int fg = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		fg |= (ch == '-');
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return fg ? ~x + 1 : x;
}

void write(ll x) {
	if (x < 0) {
		putchar('-');
		x = -x;
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

void print(ll x, char y) {
	write(x);
	putchar(y);
}

void add(int u, int v) {
	e[++ cnt].v = v;
	e[cnt].nxt = h[u];
	h[u] = cnt;
}

void dfs(int u, int fat) {
	int fg = 1;
	for (int i = h[u]; i; i = e[i].nxt) {
		int v = e[i].v;
		if (v == fat)	continue;
		fg = 0;
		dfs(v, u);
		dp[u][0] = dp[v][0] + dp[v][1] * 2;
		dp[u][1] = dp[v][0] + dp[v][1];
		dp[u][0] %= mod;
		dp[u][1] %= mod;
	}
	if (fg) {
		dp[u][1] = 1;
	}
	return ;
}

int main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	n = read(), m = read();
	for (int i = 1; i <= m; ++ i) {
		int u = read(), v = read();
		add(u, v);
		add(v, u);
	}
	dfs(1, 0);
	print((dp[1][0] + dp[1][1]) % mod, '\n');
	fclose(stdin);
	fclose(stdout);
	return 0;
}

