#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 1e3 + 5;
const int mod = 998244353;

int T, id, n, m, c, f, ansc = 0, ansf = 0;
int l[N][N], h[N][N], ok[N][N];

inline ll read() {
	ll x = 0;
	int fg = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		fg |= (ch == '-');
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return fg ? ~x + 1 : x;
}

void write(ll x) {
	if (x < 0) {
		putchar('-');
		x = -x;
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

void print(ll x, char y) {
	write(x);
	putchar(y);
}

void dfsc(int y, int up, int down) {
	ll k = 0;
	if (y < 1) {
		return ;
	}
	if (down > n) {
		return ;
	}
	if (down - up <= 1) {
		return ;
	}
	if (l[down][y] - l[up - 1][y] == 0 && !ok[up][y + 1] && !ok[down][y + 1]) { // ��һ��û��1
		int diyihang = y + 1, dierhang = y + 1;
		while (!ok[up][diyihang + 1] && diyihang < m) {
			++ diyihang;
		}
		while (!ok[down][dierhang + 1] && dierhang < m) {
			++ dierhang;
		}
		k = ((diyihang - y) % mod * (dierhang - y) % mod) % mod;
		ansc += k;
	}
	if (down < n && !ok[down + 1][y] && k) {
		int xia = down + 1;
		while (!ok[xia + 1][y] && xia < n) {
			++ xia;
		}
		ansf += (k * (xia - down)) % mod;
		ansf %= mod;
	}
	if (l[down][y] - l[up - 1][y] == 0) {
		dfsc(y, up, down + 1);
	}
}

int main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T = read(), id = read();
	while (T --) {
		n = read(), m = read();
		c = read(), f = read();
		for (int i = 1; i <= n; ++ i) {
			for (int j = 1; j <= m; ++ j) {
				scanf("%1d", &ok[i][j]);
				h[i][j] = ok[i][j] + h[i][j - 1];
				l[i][j] = ok[i][j] + l[i - 1][j];
			}
		}
		if (c == 0 && f == 0) {
			print(0, ' ');
			print(0, ' ');
			continue;
		}

		for (int i = m - 1; i >= 1; -- i) {
			for (int j = 1; j < n - 1; ++ j) {
				dfsc(i, j, j + 2);
			}
		}
		print(ansc % mod * c % mod, ' ');
		print(ansf % mod * f % mod, '\n');
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
