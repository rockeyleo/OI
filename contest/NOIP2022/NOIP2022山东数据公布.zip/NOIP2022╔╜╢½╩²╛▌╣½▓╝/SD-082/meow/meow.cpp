#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 3e3 + 5;
const int M = 2e6 + 5;

int T, n, m, k, cnt, fg;
int a[M], ans[N], s1[N], s2[N], top[N], d[N];
ll q[N][N];

inline ll read() {
	ll x = 0;
	int fg = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		fg |= (ch == '-');
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return fg ? ~x + 1 : x;
}

void write(ll x) {
	if (x < 0) {
		putchar('-');
		x = -x;
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

void print(ll x, char y) {
	write(x);
	putchar(y);
}

void dfs(int u, int cot) {
	if (u > m && !cot) {
		fg = 1;
		return ;
	}
	if (u > m + 1)	return ;
	++ cnt;
	for (int i = 1; i <= n; ++ i) {
		if (q[i][top[i]] == a[u]) {
			ans[cnt] = 1;
			s1[cnt] = i;
			-- top[i];
//			cout << "ok1" << i << endl;
			dfs(u + 1, cot - 1);
			if (fg)	return ;
			++ top[i];
			q[i][top[i]] = a[u];
			s1[cnt] = 0;
			ans[cnt] = 0;
		}
	}
	for (int i = 1; i <= n; ++ i) {
		for (int j = i + 1; j <= n; ++ j) {
			if (q[i][d[i]] == q[j][d[j]] && q[i][d[i]] != 0) {
//				cout << "ok2" << q[i][d[i]] << " " << q[j][d[j]] << endl;
				ans[cnt] = 2;
				s1[cnt] = i;
				s2[cnt] = j;
				d[i] ++;
				d[j] ++;
				dfs(u, cot - 2);
				if (fg)	return ;
				-- d[i], -- d[j];
				s1[cnt] = 0, s2[cnt] = 0;
				ans[cnt] = 0;
			}
		}
	}
	for (int i = 1; i <= n; ++ i) {
//		if (top[i] - d[i] >= 2)	continue;
		q[i][top[i] ++] = a[u];
		ans[cnt] = 1;
		s1[cnt] = i;
		dfs(u + 1, cot + 1);
		if (fg)	return ;
		s1[cnt] = 0;
		ans[cnt] = 0;
		-- top[i];
		q[i][top[i]] = 0;
	}
	-- cnt;
}

int main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	T = read();
	while (T --) {
		n = read(), m = read(), k = read();
		for (int i = 1; i <= m; ++ i) {
			a[i] = read();
		}
		cnt = 0;
		memset(s1, 0, sizeof s1);
		memset(ans, 0, sizeof ans);
		memset(top, 0, sizeof top);
		memset(q, 0, sizeof q);
		memset(d, 0, sizeof d);
		dfs(1, 0);
		print(cnt, '\n');
		for (int i = 1; i <= cnt; ++ i) {
			print(ans[i], ' ');
			print(s1[i], ' ');
			if (ans[i] == 2) {
				print(s2[i], '\n');
			}
			else {
				putchar('\n');
			}
		}
//		cout << "ok" << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

