#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 3e5 + 5;

int T, n, Q;
int lg[N];
ll ans;
ll a[N], b[N], sta[N][20], stb[N][20];

inline ll read() {
	ll x = 0;
	int fg = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		fg |= (ch == '-');
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return fg ? ~x + 1 : x;
}

void write(ll x) {
	if (x < 0) {
		putchar('-');
		x = -x;
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

void print(ll x, char y) {
	write(x);
	putchar(y);
}

int main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	T = read();
	n = read();
	lg[0] = -1;
	for (int i = 1; i <= n; ++ i) {
		a[i] = read();
		lg[i] = lg[i >> 1] + 1;
		sta[i][0] = a[i];
	}
	for (int i = 1; i <= n; ++ i) {
		b[i] = read();
		stb[i][0] = b[i];
	}
	for (int i = 1; i <= lg[n]; ++ i) {
		for (int j = 1; j + (1 << i) - 1 <= n; ++ j) {
			sta[j][i] = max(sta[j][i - 1], sta[j + (1 << (i - 1))][i - 1]);
			stb[j][i] = max(stb[j][i - 1], stb[j + (1 << (i - 1))][i - 1]);
		}
	}
//	for (int h = 1; h <= 10; ++ h) {
//		int i = read(), j = read();
//		int k = lg[j - i + 1];
//		cout << max(sta[i][k], sta[j - (1 << k) + 1][k]) << " ";
//		cout << max(stb[i][k], stb[j - (1 << k) + 1][k]) << endl;
//	}
	Q = read();
	while (Q --) {
		int l = read(), r = read();
		for (int i = l; i <= r; ++ i) {
			for (int j = i; j <= r; ++ j) {
				int k = lg[j - i + 1];
				ll mxa = max(sta[i][k], sta[j - (1 << k) + 1][k]);
				ll mxb = max(stb[i][k], stb[j - (1 << k) + 1][k]);
				ans += (mxa * mxb);
			}
		}
	}
	print(ans, '\n');
	fclose(stdin);
	fclose(stdout);
	return 0;
}
