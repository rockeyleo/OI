#include <bits/stdc++.h>
using namespace std;

const int MOD = 1e9 + 7; 
bool WA;
int n, m;

int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 1; i <= m; ++ i)
	{
		int u, v;
		scanf("%d%d",&u,&v);
		if (u == v + 1 || v == u + 1)
		{
			;
		}
		else
		{
			WA = true;
		}
	}
		cout << rand()*rand()%MOD; 
	return 0;
 } 
