#include <bits/stdc++.h>
using namespace std;

const int M = 1007;
int T,n, m, k, a[M], tot[M], st[M][M], cnt = 1, c[M], d[M];
long long ans, sum;
bool AC;

int main()
{
	freopen("meow.in","r",stdin); freopen("meow.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
			memset(tot,0,sizeof tot);
	memset(st,0,sizeof st);
	cnt = 1; sum = m;
			scanf("%d%d%d",&n,&m,&k);sum = m;
			for (int i = 1; i <= n; ++ i) d[i] = 1; 
	for (int i = 1; i <= m; ++ i)
	{
		scanf("%d",&a[i]);
		tot[a[i]]++;
		if (tot[a[i]]&1)
		{
			ans ++;
			st[cnt][++st[cnt][0]] = i;
			c[a[i]] = cnt; 
		}
		else
		{
			AC = false;
			for (int j = 1; j <= cnt; ++ j)
			{
				if (a[st[j][d[j]]] == a[i] && cnt < n)
				{
					ans ++;ans ++; d[j] ++; sum -= 2;
					AC = true; break;
				}
				else
				{
					if (a[st[j][st[j][0]]] == a[i])
					{
						ans ++; st[j][0] --;sum -= 2;
						AC = true; break;
					}
				}
			}
			if (!AC)
			{
				ans ++;
				if (c[a[i]]+1 > cnt) cnt = c[a[i]] + 1;
				st[c[a[i]] + 1][++ st[c[a[i]] + 1][0]] = i;
			}
		}
	}
	while(sum)
	{
		for (int i = 1; i <= cnt; ++ i)
	{
		for (int j = i+1; j <= cnt; ++ j)
		{
			if (j!= i)
			if (a[st[i][d[i]]] == a[st[j][d[j]]])
			{
				ans ++;
				d[i]++, d[j]++;
				sum -=2;
			}
		}
	}
	 } 
	for (int i = 1; i <= n; ++ i)d[i] = 1; 
	memset(tot,0,sizeof tot);
	memset(st,0,sizeof st);
	cnt = 1; sum = m;
	cout << ans << '\n';
	for (int i = 1; i <= m; ++ i)
	{
		tot[a[i]]++;
		if (tot[a[i]]&1)
		{
			cout << 1 <<' ' << cnt << '\n';
			st[cnt][++st[cnt][0]] = i;
			c[a[i]] = cnt; 
		}
		else
		{
			AC = false;
			for (int j = 1; j <= cnt; ++ j)
			{
				if (a[st[j][d[j]]] == a[i] && cnt < n)
				{
					cout << 1 << ' ' << cnt + 1 << '\n';
					cout << 2 << ' ' << j << ' '<< cnt + 1 <<'\n';
					d[j] ++; sum -= 2;
					AC = true; break;
				}
				else
				{
					if (a[st[j][st[j][0]]] == a[i])
					{
						cout << 1 << ' ' << j << '\n';
						st[j][0] --;
						sum -= 2; 
						AC = true; break;
					}
				}
			}
			if (!AC)
			{
				cout << 1 << ' ' << c[a[i]] + 1 << '\n';
				if (c[a[i]]+1 > cnt) cnt = c[a[i]] + 1;
				st[c[a[i]] + 1][++ st[c[a[i]] + 1][0]] = i;
			}
		}
	}
		while(sum)
	{
		for (int i = 1; i <= cnt; ++ i)
	{
		for (int j = i+1; j <= cnt; ++ j)
		{
			if (j!= i)
			if (a[st[i][d[i]]] == a[st[j][d[j]]])
			{
				cout << 2 << " " << i << " " << j << '\n';
				d[i]++, d[j]++;
				sum -=2;
			}
		}
	}
	 } 
	}
	return 0;
}
