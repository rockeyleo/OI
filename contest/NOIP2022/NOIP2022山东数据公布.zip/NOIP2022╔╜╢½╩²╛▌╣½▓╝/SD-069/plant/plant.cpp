#include <bits/stdc++.h>
using namespace std;

const int MOD = 998244353;
int T, id, n, m, c, f;
int sm[1007][1007], Sum1[1007][1007], Sum2[1007][1007];
long long ansc, ansf, tmpc, tmpf; 
char ch;

void LOOK()
{
	for (int i = 1; i <= n; ++ i) 
	{
		for (int j = 1; j <= m; ++ j)
			cout << Sum1[i][j] << ' ';
		cout << '\n'; 
	}
	cout << '\n';
	for (int i = 1; i <= n; ++ i) 
	{
		for (int j = 1; j <= m; ++ j)
			cout << Sum2[i][j] << ' ';
		cout << '\n'; 
	}
 } 

int main()
{
	freopen("plant.in","r",stdin); freopen("plant.out","w",stdout);
	scanf("%d%d",&T,&id);
	while (T--)
	{
		memset(Sum1,0,sizeof Sum1);
		memset(Sum2,0,sizeof Sum2);
		scanf("%d%d%d%d",&n,&m,&c,&f);
		if(c == 0 && f == 0) 
		{
			cout << 0 << ' '<< 0 <<'\n';
			continue;
		 } 
		for (int i = 1; i <= n; ++ i)
		{
			for (int j = 1; j <= m; ++ j)
			{
				cin >> ch;
				if (ch == '0') sm[i][j] = 1;
				else sm[i][j] = 0; 
			}
		}
		for (int i = 1; i <= n; ++ i)
		{
			for (int j = m; j >= 1; -- j)
			{
				if (sm[i][j] == 1)
				{
					Sum1[i][j] = Sum1[i][j+1] + 1;
				}
			}
		}
		for (int j = 1; j <= m; ++ j)
		{
			for (int i = n; i >= 1; -- i)
			{
				if (sm[i][j] == 1)
				{
					Sum2[i][j] = Sum2[i+1][j] + 1;
				}
			}
		}
		for (int x1 = 1; x1 <= n; ++ x1)
		{
			for (int x2 = x1 + 2; x2 <= n; ++ x2)
			{ 
				for (int y0 = 1; y0 <= m; ++ y0)
				{
					if (!Sum2[x1][y0] || !Sum2[x2][y0]) continue;
					if (Sum2[x1][y0] - Sum2[x2][y0] != x2 - x1) continue;
					for (int yy = y0 + 1; yy <= m; ++ yy)
					{
						if (!sm[x1][yy]) continue;
						if (Sum1[x1][y0] - Sum1[x1][yy] != yy - y0) continue;
						for (int y2 = y0 + 1; y2 <= m; ++ y2)
						{
							if (!sm[x2][y2]) continue;
							if (Sum1[x2][y0] - Sum1[x2][y2] != y2 - y0) continue;
							ansc ++;
							ansf +=  Sum2[x2][y0] - 1;
						}
					}
				}
			}
		}
		cout << c*ansc << " " << f*ansf << '\n'; 
	}
	return 0;
}
