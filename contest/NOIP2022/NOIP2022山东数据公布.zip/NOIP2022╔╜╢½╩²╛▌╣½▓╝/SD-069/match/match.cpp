#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);

	cout << rand()*rand(); 
	return 0;
 } 
