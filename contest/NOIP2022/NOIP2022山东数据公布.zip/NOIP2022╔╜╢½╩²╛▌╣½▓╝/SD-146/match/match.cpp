#include <bits/stdc++.h>
#define er(s...) fprintf(stderr,s)

const int N=1098244,mod=998244353;

int gi() {
	int s=0,f=0;char c=getchar();
	while(!isdigit(c)) c=='-'?f=!f:0,c=getchar();
	while(isdigit(c)) s=(s<<3)+(s<<1)+c-'0',c=getchar();
	return f?-s:s;
}
signed main() {
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	printf("0\n");
}
