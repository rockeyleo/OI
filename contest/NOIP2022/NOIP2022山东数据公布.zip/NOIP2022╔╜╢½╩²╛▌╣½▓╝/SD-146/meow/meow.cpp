#include <bits/stdc++.h>
#define er(s...) fprintf(stderr,s)

const int N=2098244,M=1204,mod=998244353,INF=1e9;

int gi() {
	int s=0,f=0;char c=getchar();
	while(!isdigit(c)) c=='-'?f=!f:0,c=getchar();
	while(isdigit(c)) s=(s<<3)+(s<<1)+c-'0',c=getchar();
	return f?-s:s;
}
// positive: up, neg: down
int n,m,k,d[N],whe[N],nls,cnt[M],stk[M][3],tag[M];
using std::queue;
using std::array;
inline bool pos(const int x) {return x>0;}
array<int,3> ans[N];
int atp;
inline void op(const int id,const int x,const int y=0) {
//	er("OPERATOR: %d %d %d\n",id,x,y);
	if(id==1) ans[++atp]={1,x,0};
	else ans[++atp]={2,x,y};
}
queue<int> nl;
inline void join(const int x,const int pl) {
	if(cnt[pl]==1) stk[pl][2]=x,whe[x]=pl;
	else stk[pl][1]=x,whe[x]=-pl;
	op(1,pl),cnt[pl]++;
}
void add(const int x,const int nop=0) {
	int now;
	do now=nl.front(),nl.pop();
	while(cnt[now]>1||now==nop);
//	er("join: %d to %d\n",x,now);
	join(x,now);
}
void del(const int x) {
	int p=abs(whe[x]);
//	er("del at %d\n",p);
	if(pos(whe[x])) op(1,p);
	else {
		op(1,nls),op(2,p,nls);
		if(cnt[p]>1) whe[stk[p][2]]=-p,stk[p][1]=stk[p][2];
	}
	cnt[p]--;
	if(cnt[p]<2) nl.push(p);
	whe[x]=0;
}
inline void make(const int x,const int nop=0) {
	if(whe[x]==0) add(x,nop);
	else del(x);
}
void deb() {
//	for(int o=1;o<=n;o++) {
//		if(cnt[o]<2) er("0 ");
//		else er("%d ",stk[o][2]);
//	}
//	er("\n");
//	for(int o=1;o<=n;o++) {
//		if(cnt[o]<1) er("0 ");
//		else er("%d ",stk[o][1]);
//	}
//	er("\n");
}
void solve() {
	n=gi(),m=gi(),k=gi(),atp=0;
	for(int i=1;i<=n;i++) cnt[i]=stk[i][1]=stk[i][2]=0;
	for(int i=1;i<=k;i++) whe[i]=0;
	queue<int> pl[2*k+2];
	for(int i=1;i<=m;i++) d[i]=gi(),pl[d[i]].push(i);
	while(!nl.empty()) nl.pop();
	for(int i=1;i<=n-1;i++) nl.push(i),nl.push(i);
	nls=n;
	for(int i=1;i<=m;i++) {
		do pl[d[i]].pop();
		while(!pl[d[i]].empty()&&pl[d[i]].front()<=i);
//		er("%d begin:\n",i);
//		deb();
		if(whe[d[i]]==0) { // ���Լ���
			if(!nl.empty()) add(d[i]);
			else {
				int R=pl[d[i]].front();bool enp=0;
				array<int,4> p3={INF,INF,-1,-1};
				for(int sl=1;sl<=n;sl++) {
					if(sl==nls) continue;
					int dw=abs(stk[sl][1]),up=abs(stk[sl][2]);
					if(pl[up].front()>R) {
//						er("this1\n");
						int odev=0,hav=0;
						op(1,sl),cnt[sl]++;
						for(int p=i+1;p<R;p++) if(d[p]==dw) odev++;
						for(int p=i+1;p<R;p++) {
							if(d[p]==dw) {
								if(!hav&&(odev&1)) hav=1,op(1,nls),op(2,sl,nls),cnt[sl]--;
								else op(1,sl);
							} else make(d[p],sl);
						}
						if(odev&1) whe[dw]=0,whe[up]=-sl,stk[sl][1]=up,nl.push(sl);
						op(1,sl),cnt[sl]--,i=R,enp=1;
						break;
					} else if(pl[up].front()>pl[dw].front()) {
//						er("thi2s at %d\n",sl);
						int cp=d[i];
						op(1,sl),cnt[sl]++;
						for(int p=i+1;p<R;p++) {
							make(d[p]);
//							er("\t del: %d at %d\n",d[p],p);
//							deb();
							if(p==pl[dw].front()) {
								enp=1,i=p;
								break;
							}
						}
						stk[sl][1]=up,stk[sl][2]=cp;
						whe[cp]=sl,whe[dw]=0,whe[up]=-sl;
					}
					if(enp) break;
					if(pl[dw].front()<p3[1]) p3={sl,pl[dw].front(),dw,up};
				}
				if(enp) continue;
//				er("this3\n");
				join(d[i],nls);
				for(int p=i+1;p<R;p++) {
					if(d[p]==p3[2]) {
						op(1,p3[0]),cnt[p3[0]]--;
						if(cnt[nls]<2) nl.push(nls);
						nls=p3[0],i=p;
						break;
					} else if(d[p]==p3[3]) {
						if(whe[d[p]]) del(d[p]);
						else join(d[p],nls);
					} else make(d[p],p3[0]);
				}
			}
		} else del(d[i]);
	}
	printf("%d\n",atp);
	for(int i=1;i<=atp;i++) {
		if(ans[i][0]==1) printf("1 %d\n",ans[i][1]);
		else printf("2 %d %d\n",ans[i][1],ans[i][2]);
	}
}
signed main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T=gi();
	while(T--) solve();
}
/*
1
2 8 3
3 1 1 2 1 3 1 2 

*/
