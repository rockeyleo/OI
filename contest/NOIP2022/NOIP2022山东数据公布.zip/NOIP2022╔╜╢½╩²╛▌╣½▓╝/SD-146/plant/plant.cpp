#include <bits/stdc++.h>
#define int long long
#define er(s...) fprintf(stderr,s)

const int N=1098244,M=1204,mod=998244353;

int gi() {
	int s=0,f=0;char c=getchar();
	while(!isdigit(c)) c=='-'?f=!f:0,c=getchar();
	while(isdigit(c)) s=(s<<3)+(s<<1)+c-'0',c=getchar();
	return f?-s:s;
}
int n,m;
int tor[M][M],td[M][M],tu[M][M]; // include
bool c,f;
char s[M][M];
struct presum {
	int a[M][M];
	inline int get(const int lx,const int rx,const int ly,const int ry) const {
		return a[rx][ry]-a[lx-1][ry]-a[rx][ly-1]+a[lx-1][ly-1];
	}
} ho;
using std::max;
void solve() {
	n=gi(),m=gi(),c=gi(),f=gi();
	int cans=0,fans=0;
	for(int i=1;i<=n;i++) for(int o=1;o<=m;o++) ho.a[i][o]=tor[i][o]=td[i][o]=tu[i][o]=0;
	for(int i=1;i<=n;i++) scanf("%s",s[i]+1);
	for(int i=n;i;i--) {
		for(int o=m;o;o--) {
			if(s[i][o]=='1') tor[i][o]=0,td[i][o]=0;
			else tor[i][o]=tor[i][o+1]+1,td[i][o]=td[i+1][o]+1;
			ho.a[i][o]=max(0ll,tor[i][o]-1);
//			er("ho: %lld %lld %lld\n",i,o,ho.a[i][o]);
		}
	}
	for(int i=1;i<=n;i++) {
		for(int o=1;o<=m;o++) {
			ho.a[i][o]+=ho.a[i-1][o]+ho.a[i][o-1]-ho.a[i-1][o-1];
			if(s[i][o]=='1') tu[i][o]=0;
			else tu[i][o]=tu[i-1][o]+1;
		}
	}
	for(int i=1;i<=n;i++) {
		for(int o=1;o<=m;o++) {
			if(tor[i][o]<=1) continue;
			if(td[i][o]>=3) {
//				er("%lld %lld %lld %lld\n",i,o,tor[i][o]-1,ho.get(i+2,i+td[i][o]-1,o,o));
				(cans+=(tor[i][o]-1)*ho.get(i+2,i+td[i][o]-1,o,o))%=mod;
			}
			if(tu[i][o]>=3&&td[i][o]>=2) {
				(fans+=(tor[i][o]-1)*ho.get(i-2,i-tu[i][o]+1,o,o)%mod*(td[i][o]-1))%=mod;
			}
		}
	}
	printf("%lld %lld\n",c*cans,f*fans);
}
signed main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=gi(),id=gi();
	while(T--) solve();
}
