#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
//#define int long long

int rd()
{
	int x=0,w=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') ch=getchar(),w=-1;
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return x*w;
}
const int N=5e5+100,M=1e6+100,mod=1e9+7;
int n,m,hd[N],cnt=1,w[N],dfn[N],tot,top,num,low[N],c[N],stk[N];
struct node{
	int nxt,to;
}e[M<<1];
void add(int x,int y)
{
	++cnt;
	e[cnt]={hd[x],y};
	hd[x]=cnt;
}
void tarjan(int x,int fa)
{
	dfn[x]=low[x]=++tot;
	stk[++top]=x;
	for(int i=hd[x];i;i=e[i].nxt)
	{
		int y=e[i].to;
		if(i==fa) continue;
		if(dfn[y]){
			low[x]=min(low[x],dfn[y]);
		}
		else tarjan(y,i^1),low[x]=min(low[x],low[y]);
	}
	if(dfn[x]==low[x]){
		int z;num++;
		do
		{
			z=stk[top--];c[z]=num;
			w[num]++;
		}while(z!=x);
	} 
}
vector<int>v[N];
int deg[N];
long long f[N],g[N],p[M<<1];
int fpow(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;y>>=1;
	}
	return res;
}
void dfs(int x,int fa)
{
	f[x]=p[M+w[x]-deg[x]+1];
	g[x]=p[M+1-deg[x]];
	for(int i=0;i<v[x].size();++i)
	{
		int y=v[x][i];if(y==fa) continue;
		dfs(y,x);f[x]*=f[y]*p[M-m+1]%mod+1;g[x]*=g[y]*p[M-m+1]%mod+1;
		f[x]%=mod;g[x]%=mod;
	}
	f[x]*=p[M+m-1];f[x]%=mod;
	g[x]*=p[M+m-1];g[x]%=mod;
//	if(!siz){
//		f[x]=p[M+w[x]]*p[M+m-deg[x]]%mod;
//		g[x]=p[M+m-deg[x]];
//	}
}
signed main()
{
    freopen("barrack.in","r",stdin);
    freopen("barrack.out","w",stdout);
    n=rd();m=rd();
    for(int i=1;i<=m;++i)
    {
    	int x=rd(),y=rd();
    	add(x,y);add(y,x);
	}
	tarjan(1,0);
	for(int i=1;i<=n;++i)
	{
		for(int j=hd[i];j;j=e[j].nxt)
		{
			int y=e[j].to;
			if(c[i]==c[y]) continue;
			v[c[i]].pb(c[y]);
			deg[c[y]]++;
		}
	}
	p[M]=1;for(int i=1;i<=m+1;++i) p[M+i]=p[M+i-1]*2%mod;
	p[M-1]=fpow(2,mod-2);
	for(int i=2;i<=m+1;++i) p[M-i]=p[M-i+1]*p[M-1]%mod;
	dfs(1,0);
	long long ans=0;
	for(int i=1;i<=num;++i) ans+=f[i]-g[i];
	ans%=mod;ans+=mod;
	cout<<ans%mod;
    fclose(stdin);
    fclose(stdout);
	return 0;
}


