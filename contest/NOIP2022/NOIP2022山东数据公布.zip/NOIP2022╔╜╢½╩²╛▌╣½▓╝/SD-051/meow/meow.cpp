#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
//#define int long long

int rd()
{
	int x=0,w=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') ch=getchar(),w=-1;
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return x*w;
}
const int N=610,M=2e6+100;
int T,n,m,k,a[M],t[N],s[N][2],siz[N];
struct node{
	int op,s1,s2;
}q[M<<1];
int tot;
void solve()
{
	n=rd();m=rd();k=rd();tot=0;
	for(int i=1;i<=m;++i)
	{
		a[i]=rd();
	}
	for(int i=1;i<=m;++i)
	{
		if(t[a[i]]) {
		   if(s[t[a[i]]][siz[t[a[i]]]-1]==a[i]) {
		   	q[++tot]={1,t[a[i]],0};
		   	siz[t[a[i]]]--;
		   }	
		   else {
		   	q[++tot]={1,n,0};
		   	q[++tot]={2,t[a[i]],n};
		   	siz[t[a[i]]]--;
		   	s[t[a[i]]][0]=s[t[a[i]]][1];
		   }
		}
		else{
			t[a[i]]=(a[i]+1)/2;
			q[++tot]={1,t[a[i]],0};
			s[t[a[i]]][siz[t[a[i]]]++]=a[i];
		}
	}
	cout<<tot<<'\n';
	for(int i=1;i<=tot;++i)
	{
		if(q[i].op==1){
			cout<<1<<' '<<q[i].s1<<'\n';
		}
		else cout<<2<<' '<<q[i].s1<<' '<<q[i].s2<<'\n';
	}
}
signed main()
{
    freopen("meow.in","r",stdin);
    freopen("meow.out","w",stdout);
    T=rd();
//    if(T==1001)
//    {
	while(T--)
    solve();    	
//	}
    fclose(stdin);
    fclose(stdout);
	return 0;
}


