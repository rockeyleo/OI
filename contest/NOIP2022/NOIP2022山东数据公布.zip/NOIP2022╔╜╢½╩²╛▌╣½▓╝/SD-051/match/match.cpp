#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define ull unsigned long long

int rd()
{
	int x=0,w=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') ch=getchar(),w=-1;
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return x*w;
}
const int N=3100;
int t,n,q;
ull a[N],b[N],ma[N][N],mb[N][N];

signed main()
{
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
      t=rd();n=rd();
      for(int i=1;i<=n;++i) a[i]=rd();
      for(int i=1;i<=n;++i) b[i]=rd();
      for(int i=1;i<=n;++i)
      {
      	ma[i][i]=a[i];mb[i][i]=b[i];
      	for(int j=i+1;j<=n;++j) ma[i][j]=max(ma[i][j-1],a[j]),mb[i][j]=max(mb[i][j-1],b[j]);
	  }
      q=rd();
      while(q--)
      {
      	ull ans=0;
      	int l=rd(),r=rd();
      	for(int x=l;x<=r;++x)
      	{
      		for(int y=x;y<=r;++y)
      		{
      			ans+=ma[x][y]*mb[x][y];
			}
		}
		cout<<ans<<'\n';
	  }
    fclose(stdin);
    fclose(stdout);
	return 0;
}


