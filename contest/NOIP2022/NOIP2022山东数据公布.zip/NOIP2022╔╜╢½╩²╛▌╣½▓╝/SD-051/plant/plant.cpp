#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define int long long

int rd()
{
	int x=0,w=1;
	char ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') ch=getchar(),w=-1;
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return x*w;
}
const int N=1e3+100,mod=998244353;
int t,n,m,C,F,id,a[N][N],r[N][N],d[N][N],f[N];
char s[N];
void cadd(int &x,int y)
{
	x+=y;if(x>=mod) x-=mod;
}
signed main()
{
    freopen("plant.in","r",stdin);
    freopen("plant.out","w",stdout);
    t=rd();id=rd();
    while(t--)
    {
    	n=rd();m=rd();C=rd();F=rd();
    	for(int i=1;i<=n;++i){
    		scanf("%s",s+1);
    		for(int j=1;j<=m;++j) a[i][j]= s[j]-'0';
		}
		for(int i=1;i<=n;++i)
		{
			r[i][m]=a[i][m]^1;
			for(int j=m-1;j;--j)
			{
				if(a[i][j]) r[i][j]=0;
				else r[i][j]=r[i][j+1]+1;
			}
		}
		for(int j=1;j<=m;++j)
		{
			d[n][j]=a[n][j]^1;
			for(int i=n-1;i;--i)
			{
				if(a[i][j]) d[i][j]=0;
				else d[i][j]=d[i+1][j]+1;
			}
		}
		int res1=0,res2=0;
		for(int j=1;j<=m;++j)
		{
			for(int i=1;i<=n;++i)
			{
				if(a[i][j]){
					f[i]=0;continue;
				}
				if(r[i][j]>=2) {
					if(i>2&&a[i-1][j]==0) cadd(res1,f[i-2]*(r[i][j]-1)%mod);
					if(i>2&&a[i-1][j]==0) cadd(res2,f[i-2]*(r[i][j]-1)*(d[i][j]-1)%mod);
//					cout<<i<<' '<<j<<": "<<res1<<' '<<f[i-2]<<' '<<r[i][j]-1<<'\n';
					f[i]=f[i-1]+r[i][j]-1;
				}
				else f[i]=f[i-1];
			}
//			memset(f,0,sizeof f);
		}
		cout<<(C*res1)<<' '<<(F*res2)<<'\n';
//		memset(a,0,sizeof a);memset(d,0,sizeof d);memset(r,0,sizeof r);memset(f,0,sizeof f);
	}
    fclose(stdin);
    fclose(stdout);
	return 0;
}


