#include<bits/stdc++.h>
using namespace std;
#define N 9982
int t,n,q;
int a[250005],b[250005],l[250005],r[250005];
long long s[N][N];
long long temp=pow(2,64);
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int ans=0;
	cin>>t>>n;
	for (int i=1;i<=n;i++)
		cin>>a[i];
	for (int i=1;i<=n;i++)
		cin>>b[i];
	cin>>q;
	for (int i=1;i<=q;i++)
		cin>>l[i]>>r[i];
	for (int i=1;i<=q;i++)
	{
		ans=0;
		for (int j=l[i];j<=r[i];j++)
			for (int k=j;k<=r[i];k++)
			{
				int max1=1,max2=1;
				for (int x=j;x<=k;x++)
				{
					if (a[x]>max1)
						max1=a[x];
					if (b[x]>max2)
						max2=b[x];
				}
				ans+=max1*max2;
			}
		cout<<ans%temp<<endl;
	}
	return 0;
}
