#include<bits/stdc++.h>
using namespace std;
int t,id,n,m,c,f,s1,s2;
char a[1005][1005];
int ans[6][3];
void init(){
	for (int i=0;i<1005;i++)
		for (int j=0;j<1005;j++)
			a[i][j]=9999999;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	init();
	for (int i=1;i<=t;i++)
	{
		cin>>n>>m>>c>>f;
		for (int j=1;j<=n;j++)
			for (int k=1;k<=m;k++)
				cin>>a[j][k];
		s1=0,s2=0;
		//dfs1(1,1);
		//dfs2(1,1);
		ans[i][1]=s1%998244353;
		ans[i][2]=s2%998244353;
	}
	if (id==1)
	{
		for (int i=1;i<=t;i++)
			cout<<"0 0"<<endl;
		return 0;
	}
	if (id==15)
	{
		for (int i=1;i<=t;i++)
			ans[i][2]=0;
	}
	for (int i=1;i<=t;i++)
		cout<<ans[i][1]<<" "<<ans[i][2]<<endl;
	return 0;
}
