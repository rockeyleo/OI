#include<bits/stdc++.h>
using namespace std;
#define mmod 18446744073709551616
inline int read(){
	char c=getchar();
	int x=0,f=1;
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+c-'0';
	return x*f;
}
int T,n,a[1000009],b[1000009],Q,l,r;
long long ans=0;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=n;i++){
		b[i]=read();
	}
	Q=read();
	while(Q--){
		l=read();r=read();
		ans=0;
		for(int i=l;i<=r;i++){
			for(int j=l;j<=r;j++){
				
				ans=ans+a[i]*b[j];
			}
		}
		cout<<ans<<"\n";
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
