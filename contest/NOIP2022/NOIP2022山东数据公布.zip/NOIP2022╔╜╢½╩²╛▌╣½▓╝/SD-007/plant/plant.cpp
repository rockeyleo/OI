#include<bits/stdc++.h>
using namespace std;
#define modd 998244353
inline int read(){
	char c=getchar();
	int x=0,f=1;
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+c-'0';
	return x*f;
}
int T,id,n,m,c,f;
string a;
long long b[1009][1009];
//int b[1009][1009];
//bool d[1009][1009];
long long vc=0,vf=0;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read();
	id=read();
	while(T--){
		n=read();m=read();c=read();f=read();
		for(int i=0;i<n;i++){
			cin>>a;
			if(a[m-1]=='0')b[i][m-1]=1;
			if(a[m-1]=='1')b[i][m-1]=0;
			for(int j=m-2;j>=0;j--){
				if(a[j]=='0')b[i][j]=b[i][j+1]+1;
				if(a[j]=='1')b[i][j]=0;
			}
		}
		if(c==0&&f==0){
			cout<<vc<<" "<<vf<<"\n";
			continue;	
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				if(b[i][j]==0)continue;
				if(b[i+1][j]==0)continue;
				for(int k=i+2;k<n;k++){
					if(b[k][j]==0)break;
					if(b[k][j+1]>0){
						vc+=(b[i][j+1]*b[k][j+1])%modd;
						if(k<n-1&&b[k+1][j]>0){
							int t=0;
							for(int g=k+1;g<n;g++){
								if(b[g][j]>0)t++;
								else break;
							}
							vf+=(b[i][j+1]*b[k][j+1]*(t))%modd;
						}	
					}					
				}
			}
		}
		if(f==0)vf=0;
		cout<<vc<<" "<<vf<<"\n";
	}
	return 0;
	fclose(stdin);fclose(stdout);
}
