#include<bits/stdc++.h>
using namespace std;
inline int read(){
	char c=getchar();
	int x=0,f=1;
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+c-'0';
	return x*f;
}
int n,m;
long long ans;
struct node{
	int str;
	int end;
}v[50009];
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		v[i].str=read();v[i].end=read();
	}
	if(m==n-1){
		for(int i=2;i<=n;i++){
			ans=(i*2+ans)%1000000007;
		}
		ans=(ans+1)%1000000007;
		cout<<ans<<"\n";
	}
	else cout<<rand()<<endl;
	
	return 0;
	fclose(stdin);fclose(stdout);
}
