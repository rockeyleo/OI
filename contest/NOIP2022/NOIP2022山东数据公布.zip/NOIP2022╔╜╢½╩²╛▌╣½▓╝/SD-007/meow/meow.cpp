#include<bits/stdc++.h>
using namespace std;
#define mmod 18446744073709551616
inline int read(){
	char c=getchar();
	int x=0,f=1;
	for(;!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+c-'0';
	return x*f;
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	fclose(stdin);fclose(stdout);
}
