#include<iostream>
#include<cstdio>
using namespace std;
const int k=1e9+7;
long long n,m,head[2000010],to[2000010],nex[2000010],cnt=0;int u,v;
void add(int u,int v){
	to[++cnt]=v;
	nex[cnt]=head[u];
	head[u]=cnt;
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
		add(u,v);add(v,u);
	}
	cout<<(n*n*n+m*m*m)%k;
	return 0;
}
