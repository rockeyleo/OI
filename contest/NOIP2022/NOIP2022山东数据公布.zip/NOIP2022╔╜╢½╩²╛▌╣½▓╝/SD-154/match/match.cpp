#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
/**/int t,n,q,l,r,a[250010],b[250010];
unsigned long long mod=1;
const int N=5e7;
struct edge{
	int l,r;
	long long maxx;
}tree1[N];
struct node{
	int l,r;
	long long maxx;
}tree2[N];
long long cmp(long long x,long long y){
	return x>y?x:y;
}
void build1(int i,int l,int r){
	tree1[i].l=l;tree1[i].r=r;
	if(l==r){tree1[i].maxx=a[l];return;}
	int mid=(l+r)>>1;
	build1(i*2,l,mid);build1(i*2+1,mid+1,r);
	tree1[i].maxx=max(tree1[i*2].maxx,tree1[i*2+1].maxx);
}
void build2(int i,int l,int r){
	tree2[i].l=l;tree2[i].r=r;
	if(l==r){tree2[i].maxx=b[l];return;}
	int mid=(l+r)>>1;
	build2(i*2,l,mid);build2(i*2+1,mid+1,r);
	tree2[i].maxx=max(tree2[i*2].maxx,tree2[i*2+1].maxx);
}
long long search1(int i,int l,int r){
	if(tree1[i].l>=l&&tree1[i].r<=r)return tree1[i].maxx;
	long long u;
	if(tree1[i*2].r>=l)u=search1(i*2,l,r);
	if(tree1[i*2+1].l<=r)u=cmp(u,search1(i*2+1,l,r));
	return u;
}
long long search2(int i,int l,int r){
	if(tree2[i].l>=l&&tree2[i].r<=r)return tree2[i].maxx;
	long long u;
	if(tree2[i*2].r>=l)u=search2(i*2,l,r);
	if(tree2[i*2+1].l<=r)u=cmp(u,search2(i*2+1,l,r));
	return u;
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);/**/
	cin>>t>>n;
	for(int i=1;i<=63;i++)mod*=2;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)scanf("%d",&b[i]);
	build1(1,1,n);build2(1,1,n);
	cin>>q;
	//cout<<search1(1,2,2)<<" "<<search2(1,2,2)<<endl;
	while(q--){
		scanf("%d%d",&l,&r);
		unsigned long long sum=0;
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				sum+=search1(1,i,j)*search2(1,i,j)%mod;
				sum%=mod;
				//cout<<i<<" "<<j<<" "<<sum<<endl;
			}
		}
		cout<<sum<<endl;
	}/**/
	return 0;
}
