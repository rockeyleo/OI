#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int t,n,m,k;
int dui[310][10000],head[310],tail[310],a[2000010],cnt=0;
int main(){
	cin>>t;
	while(t--){
		scanf("%d%d%d",&n,&m,&k);
		memset(head,1,sizeof(head));
		memset(tail,0,sizeof(tail));
		int sum=m;
		for(int i=1;i<=m;i++){
			scanf("%d",&a[i]);
			for(int i=1;i<=n;i++){
				if(dui[i][tail[i]]==a[i]){
					dui[i][tail[i]]=0;
					tail[i]--;sum-=2;
					cout<<1<<" "<<i<<endl;break;
				}
				if(dui[i][head[i]]==a[i]){
					dui[i][head[i]]=0;
					head[i]++;sum-=2;
					cout<<1<<" "<<n<<endl;
					cout<<2<<" "<<i<<" "<<n<<endl;
					break;
				}
				if(i==n){
					cnt++;if(cnt==n)cnt=1;
					cout<<1<<" "<<cnt<<endl;
					tail[cnt]++;dui[cnt][tail[cnt]]=a[i];
					break;
				}
			}
		}
		while(sum>0){
			for(int i=1;i<=n;i++){
				for(int j=i+1;j<=n;j++){
					if(dui[i][head[i]]==dui[j][head[j]]){
						cout<<2<<" "<<i<<" "<<j<<endl;
						dui[i][head[i]]=0;dui[j][head[j]]=0;
						head[i]++;head[j]++;
						sum-=2;
					}
				}
			}
		}
	}
	return 0;
}
