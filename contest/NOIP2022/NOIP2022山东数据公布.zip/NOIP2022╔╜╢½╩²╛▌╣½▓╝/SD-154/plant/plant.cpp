#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll mod=998244353,c,f,sumc=0,sumf=0;
int rig[1010][1010],sou[1010][1010];
int t,id,n,m,a[1010][1010];
string s[1010];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);/**/
	cin>>t>>id;
	while(t--){
		scanf("%d%d%lld%lld",&n,&m,&c,&f);
		for(int i=1;i<=n;i++){
			cin>>s[i];
			for(int j=0;j<m;j++)a[i][j+1]=s[i][j]-'0';
		}
		for(int i=1;i<=n;i++){
			for(int j=m-1;j>=1;j--){
				if(!a[i][j+1])rig[i][j]=rig[i][j+1]+1;
				else rig[i][j]=0;
			}
		}
		for(int i=1;i<=m;i++){
			for(int j=n-1;j>=1;j--){
				if(!a[j+1][i])sou[j][i]=sou[j+1][i]+1;
				else sou[j][i]=0;
			}
		}
		/*for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cout<<rig[i][j]<<" ";
			}
			cout<<endl;
		}
		cout<<endl;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cout<<sou[i][j]<<" ";
			}
			cout<<endl;
		}*/
		sumc=0,sumf=0;
		for(int i=2;i<=n-1;i++){
			for(int j=2;j<=m;j++){
				if(a[i-1][j]==1||a[i-1][j-1]==1||a[i][j-1]==1||a[i+1][j-1]==1)continue;
				long long w=0;
				for(int k=i+1;k<=n;k++){
					if(a[k][j-1]==1)break;
					w+=rig[k][j-1];
				}
				//cout<<i<<" "<<j<<" "<<rig[i-1][j-1]<<endl;
				sumc+=rig[i-1][j-1]*w;sumc%=mod;
			}
		}//c��
		for(int i=2;i<=n-2;i++){
			for(int j=2;j<=m;j++){
				if(a[i-1][j-1]==1||a[i-1][j]==1||a[i][j-1]==1||a[i+1][j-1]==1||a[i+2][j-1]==1)continue;
				long long w=0;
				for(int k=i+1;k<=n;k++){
					if(a[k][j-1]==1)break;
					w+=rig[k][j-1]*sou[k][j-1];
				}
				sumf+=rig[i-1][j-1]*w;sumf%=mod;
			}
		}
		c=c*sumc%mod;f=f*sumf%mod;
		printf("%lld %lld\n",c%mod,f%mod);
	}
	return 0;
} 
