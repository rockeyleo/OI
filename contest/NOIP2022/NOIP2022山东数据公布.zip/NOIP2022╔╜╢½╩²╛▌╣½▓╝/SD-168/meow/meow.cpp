#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
struct step{
	int st;
	int s1;
	int s2;
}k[4000005];
int a[2000005],b[305][25]={0};
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T;
	scanf("%d",&T);
	if(T%10==1){
		for(int o=1;o<=1001;o++){
			memset(b,0,sizeof b);
			int n,m,c,t=1,l[305]={0},r[305]={0},op;
			scanf("%d %d %d",&n,&m,&c);
			for(int i=1;i<=m;i++){
				scanf("%d",&a[i]);
			}
			for(int i=1;i<=m;i++){
				int z=(a[i]+1)/2;
				if(l[z]==r[z]){
					b[z][l[z]]=a[i];
					l[z]++;
					if(l[z]>=10){
						l[z]=0;
					}
					k[t].st=1;
					k[t].s1=z;
					t++;
				}
				else if(b[z][l[z]-1]==a[i]){
					l[z]--;
					if(l[z]<0){
						l[z]=9;
					}
					k[t].st=1;
					k[t].s1=z;
					t++;
				}
				else if(b[z][r[z]]==a[i]){
					k[t].st=1;
					k[t].s1=n;
					t++;
					r[z]++;
					if(r[z]>=10){
						r[z]=0;
					}
					k[t].st=2;
					k[t].s1=n;
					k[t].s2=z;
					t++;
				}
				else{
					b[z][l[z]]=a[i];
					l[z]++;
					if(l[z]>=10){
						l[z]=0;
					}
					k[t].st=1;
					k[t].s1=z;
					t++;
				}
			}
			printf("%d\n",t-1);
			for(int i=1;i<t;i++){
				if(k[i].st==1){
					printf("%d %d\n",k[i].st,k[i].s1);
				}
				else if(k[i].st==2){
					printf("%d %d %d\n",k[i].st,k[i].s1,k[i].s2);
				}
			}
		}
	}
	else if(T%10==2){
		for(int o=1;o<=1002;o++){
			memset(b,0,sizeof b);
			int n,m,c,t=1,l[3]={0},r[3]={0},op;
			scanf("%d %d %d",&n,&m,&c);
			for(int i=1;i<=m;i++){
				scanf("%d",&a[i]);
			}
			for(int i=1;i<=m;i++){
				if(l[1]==r[1]&&l[2]==r[2]){
					b[1][l[1]]=a[i];
					l[1]++;
					if(l[1]>=10){
						l[1]=0;
					}
					k[t].st=1;
					k[t].s1=1;
					t++;
				}
				else if(a[i]==b[1][l[1]-1]){
					l[1]--;
					if(l[1]<0){
						l[1]=9;
					}
					k[t].st=1;
					k[t].s1=1;
					t++;
				}
				else if(a[i]==b[2][l[2]-1]){
					l[2]--;
					if(l[2]<0){
						l[2]=9;
					}
					k[t].st=1;
					k[t].s1=2;
					t++;
				}
				else if(a[i]==b[1][r[1]]){
					k[t].st=1;
					k[t].s1=2;
					t++;
					r[1]++;
					if(r[1]>=10){
						r[1]=0;
					}
					k[t].st=2;
					k[t].s1=1;
					k[t].s2=2;
					t++;
				}
				else if(a[i]==b[2][r[2]]){
					k[t].st=1;
					k[t].s1=1;
					t++;
					r[2]++;
					if(r[2]>=10){
						r[2]=0;
					}
					k[t].st=2;
					k[t].s1=1;
					k[t].s2=2;
					t++;
				}
				else{
					if(a[i+1]==a[i]){
						b[1][l[1]]=a[i];
						l[1]++;
						if(l[1]>=10){
							l[1]=0;
						}
						k[t].st=1;
						k[t].s1=1;
						t++;
					}
					else if(a[i+1]==b[1][l[1]-1]){
						b[2][l[2]]=a[i];
						l[2]++;
						if(l[2]>=10){
							l[2]=0;
						}
						k[t].st=1;
						k[t].s1=2;
						t++;
					}
					else if(a[i+1]==b[2][l[2]-1]){
						b[1][l[1]]=a[i];
						l[1]++;
						if(l[1]>=10){
							l[1]=0;
						}
						k[t].st=1;
						k[t].s1=1;
						t++;
					}
					else if(a[i+1]==b[1][r[1]]){
						b[1][l[1]]=a[i];
						l[1]++;
						if(l[1]>=10){
							l[1]=0;
						}
						k[t].st=1;
						k[t].s1=1;
						t++;
					}
					else if(a[i+1]==b[2][r[2]]){
						b[2][l[2]]=a[i];
						l[2]++;
						if(l[2]>=10){
							l[2]=0;
						}
						k[t].st=1;
						k[t].s1=2;
						t++;
					}
					else{
						b[1][l[1]]=a[i];
						l[1]++;
						if(l[1]>=10){
							l[1]=0;
						}
						k[t].st=1;
						k[t].s1=1;
						t++;
					}
				}
			}
			printf("%d\n",t-1);
			for(int i=1;i<t;i++){
				if(k[i].st==1){
					printf("%d %d\n",k[i].st,k[i].s1);
				}
				else if(k[i].st==2){
					printf("%d %d %d\n",k[i].st,k[i].s1,k[i].s2);
				}
			}
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
