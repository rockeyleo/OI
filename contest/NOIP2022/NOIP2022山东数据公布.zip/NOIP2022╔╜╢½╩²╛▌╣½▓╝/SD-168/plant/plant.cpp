#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char a[1005][1005];
const int P=998244353;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id;
	scanf("%d %d",&T,&id);
	if(id==1){
		for(int o=1;o<=T;o++){
			int n,m,c,f;
			scanf("%d %d %d %d",&n,&m,&c,&f);
			for(int i=1;i<=n;i++){
				for(int j=0;j<=m;j++){
					scanf("%c",&a[i][j]);
				}
			}
			printf("0 0\n");
		}
	}
	else if(id==2){
		for(int o=1;o<=T;o++){
			int n,m,c,f;
			scanf("%d %d %d %d",&n,&m,&c,&f);
			int sum=0,t1=2,t2=2;
			for(int i=1;i<=n;i++){
				for(int j=0;j<=m;j++){
					scanf("%c",&a[i][j]);
					if(a[i][j]=='1'){
						sum++;
						t1=i;t2=j;
					}
				}
			}
			//cout<<a[2][1];
			if(sum>1||t1!=2||t2!=2){
				printf("0 0\n");
			}
			else{
				printf("1 0\n");
			}
		}
	}
	else if(id==3||id==4){
		for(int o=1;o<=T;o++){
			int n,m,c,f;
			scanf("%d %d %d %d",&n,&m,&c,&f);
			for(int i=1;i<=n;i++){
				for(int j=0;j<=m;j++){
					scanf("%c",&a[i][j]);
				}
			}
			int nc=0,nf=0,l=1,r=1;
			while(l<n-1){
				if(a[l][1]=='0'){
					for(r=l;a[r][1]=='0'&&r<=n;r++);
					for(int i=l;i<=r;i++){
						if(a[i][2]=='0'){
							for(int j=i+2;j<=r;j++){
								if(a[j][2]=='0'){
									nc++;
									nf+=r-j-1;
									nc%=P;
									nf%=P;
									//cout<<j;
								}
								
							}
						}
					}
					l=r;
				}
				l++;
			}
			printf("%d %d\n",nc,nf);
		}
		
	}
	else if(id==5){
		for(int o=1;o<=T;o++){
			int n,m,c,f;
			scanf("%d %d %d %d",&n,&m,&c,&f);
			for(int i=1;i<=n;i++){
				for(int j=0;j<=m;j++){
					scanf("%c",&a[i][j]);
				}
			}
			int nc=0,nf=0;
			for(int k=1;k<=m;k+=3){
				int l=1,r=1;
				while(l<n-1){
					if(a[l][k]=='0'){
						for(r=l;a[r][k]=='0'&&r<=n;r++);
						for(int i=l;i<=r;i++){
							if(a[i][k+1]=='0'){
								for(int j=i+2;j<=r;j++){
									if(a[j][k+1]=='0'){
										nc++;
										nf+=r-j-1;
										nc%=P;
										nf%=P;
										//cout<<j;
									}
								
								}
							}
						}
						l=r;
					}
					l++;
				}	
			}
			
			printf("%d %d\n",nc,nf);
		}
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
