#include <iostream> 
#include <cstdio>
#include <ctime>
#include <cstdlib>
using namespace std;
int main(){
	freopen("plant.in","w",stdout);
	cout<<1<<" "<<20<<endl;
	cout<<1000<<" "<<1000<<" "<<1<<" "<<1<<endl;
	srand(time(0)); 
	for(int i=1;i<=1000;++i){
		for(int j=1;j<=1000;++j)
			cout<<0;
		cout<<endl; 
	} 
	return 0;
}
