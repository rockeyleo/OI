#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

#define int long long 

const int N=1100,mod=998244353;
int dp[N][N][4][2];//f[i][j][1/2][0/1] ��ʾ �� i �� ��ߵ����� j �� �ķ������� 1/2 ����ķ������������һ������/���ڸ��� 
int t,id;
int n,m,c,f;
int a[N][N];
int d[N][N];


signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--){
		cin>>n>>m>>c>>f;
		int ansc=0,ansf=0;
		memset(dp,0,sizeof(dp));
		memset(d,0,sizeof(d));
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				char c;
				cin>>c;
				a[i][j]=c-'0';
			}
		}
		for(int i=1;i<=n;++i){
			int la=m+1;
			for(int j=m;j>=1;--j){
				if(a[i][j])
					la=j;
				d[i][j]=la-j-1;
			}
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(a[i][j]){
					dp[i][j][1][0]=dp[i][j][1][1]=dp[i][j][2][0]=dp[i][j][2][1]=0;
				}
				else{
					dp[i][j][1][1]=d[i][j];
					dp[i][j][1][0]=(dp[i-1][j][1][0]+dp[i-1][j][1][1])%mod;
					dp[i][j][2][1]=dp[i-1][j][1][0]*d[i][j]%mod;
					dp[i][j][2][0]=(dp[i-1][j][2][0]+dp[i-1][j][2][1])%mod;
				}
			}
		}
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				ansc=(dp[i][j][2][1]+ansc)%mod,ansf=(dp[i][j][2][0]+ansf)%mod;
		cout<<c*ansc%mod<<" "<<f*ansf%mod<<endl;
	}	
	return 0;
}
