#include <iostream>
#include <deque>
using namespace std;

const int N=2e6+100;
int a[N];
int n,m,k,cnt;
deque<int> q[N];
int ans=0;

int main(){
	freopen("meow.out","r",stdin);
	cin>>n>>m>>k;
	for(int i=1;i<=m;++i)	cin>>a[i];
	cin>>cnt;
	for(int i=1;i<=cnt;++i){
		int op,x,y;
		cin>>op>>x;
		if(op==1)
			deque[x].push_back(a[i]);
		else{
			cin>>y;
			deque[x].pop_front();
			deque[y].pop_front();
			ans+=2;
		}
	}
	cout<<ans<<endl;
	return 0;
}
