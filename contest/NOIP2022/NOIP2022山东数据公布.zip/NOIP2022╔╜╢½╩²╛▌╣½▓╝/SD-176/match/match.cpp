#include <iostream>
#include <cstdio>

using namespace std;

#define int unsigned long long 

const int N=260000;
int t,n,q;
int a[N],b[N];

signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(int i=1;i<=n;++i)
		cin>>a[i];
	for(int i=1;i<=n;++i)
		cin>>b[i];
	cin>>q;
	while(q--){
		int l,r;
		int ans=0;
		cin>>l>>r;
		int maxa,maxb;
		for(int i=l;i<=r;++i){
			maxa=a[i],maxb=b[i]; 
			for(int j=i;j<=r;++j){
				maxa=max(maxa,a[j]),maxb=max(maxb,b[j]); 
				ans+=maxa*maxb;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
