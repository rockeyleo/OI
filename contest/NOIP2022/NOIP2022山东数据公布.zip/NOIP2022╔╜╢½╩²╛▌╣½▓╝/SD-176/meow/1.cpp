#include <iostream>
#include <deque>
using namespace std;

const int N=2e6+100;
int a[N];
int n,m,k,cnt;
deque<int> q[N];
int ans=0;
int dd;

int main(){
	freopen("meow.out","r",stdin);
	cin>>n>>m>>k;
	for(int i=1;i<=m;++i)	cin>>a[i];
	cin>>cnt;
	for(int i=1;i<=cnt;++i){
		int op,x,y;
		cin>>op>>x;
		if(op==1){
			if(!q[x].empty() && a[++dd]==q[x].back())
				q[x].pop_back(),ans+=2;
			else
				q[x].push_back(a[i]);
		}
		else{
			cin>>y;
			q[x].pop_front();
			q[y].pop_front();
			ans+=2;
		}
	}
	for(int i=1;i<=n;++i)
		if(q[i].size()!=0)
			cout<<i<<" "<<q[i].size()<<endl;
	cout<<ans<<endl;
	return 0;
}
