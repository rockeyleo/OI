//����Ū�������ߡ�
//�Ҿ��������䵽��һ���м�
 

#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
#include <deque>
using namespace std;

const int N=2e6+1000;
int a[N],nxt[N],las[310];
int f[N];//�����ɫ ���ĸ�ջ��
int b[310];//ջ�м���Ԫ���� 
int state[N];//��ջ������or���档 
int pl[310][4];//ջ��Ԫ����ɫ���µ��ϣ� 
int tim[310][4];//ջ��Ԫ�س�ջʱ�䡣 
int t,n,m,k;
int ans[2*N][4],cnt;//������ 
bool st[310];
int num[N];

int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout); 
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
	cin>>t;
	if(t%10==1){
		while(t--){
			cnt=0;
			cin>>n>>m>>k;
			queue<int>q;
			for(int i=1;i<n;++i)
				q.push(i);
			for(int i=1;i<=m;++i){
				int d;
				cin>>d;
				if(f[d]){
					if(state[d]){
					//	cout<<1<<" "<<f[d]<<'\n';
						ans[++cnt][1]=1;
						ans[cnt][2]=f[d];
						b[f[d]]--;
						if(b[f[d]]!=0)
							q.push(f[d]);
						f[d]=0;
					}
					else{
						//cout<<1<<" "<<n<<'\n';
						//cout<<2<<" "<<f[d]<<" "<<n<<'\n';
						ans[++cnt][1]=1;
						ans[cnt][2]=n;
						ans[++cnt][1]=2;
						ans[cnt][2]=f[d];
						ans[cnt][3]=n;
						b[f[d]]--;
						if(b[f[d]]!=0){
							q.push(f[d]);
							pl[f[d]][1]=pl[f[d]][2],pl[f[d]][2]=0;
							state[pl[f[d]][1]]=0;
						}
						f[d]=0;
					}
				}
				else{
					int tt=q.front();
					f[d]=tt;
					//cout<<1<<" "<<tt<<'\n';
					ans[++cnt][1]=1;
					ans[cnt][2]=tt;
					if(b[tt]==0){
						state[d]=0;
						pl[tt][1]=d;
					}
					else{
						state[d]=1;
						pl[tt][2]=d;
					}
					b[tt]++;
					if(b[tt]==2)
						q.pop();
				}
			}
			cout<<cnt<<'\n';
			for(int i=1;i<=cnt;++i){
				cout<<ans[i][1]<<" "<<ans[i][2];
				if(ans[i][1]==2)
					cout<<" "<<ans[i][3];
				cout<<'\n';
			}
		}
	}
	else{
		while(t--){
			cnt=0;
			cin>>n>>m>>k;
			deque<int> s[310],tim[310];
			queue<int> q;
			//q.front();
			for(int i=1;i<=m;++i){
				cin>>a[i];
				if(las[a[i]])
					nxt[las[a[i]]]=i;
				las[a[i]]=i;
			}
	//		for(int i=1;i<=m;++i)
		//		cout<<nxt[i]<<" ";
			for(int i=1;i<n;++i)
				q.push(i);
			for(int i=1;i<=m;++i){
		//		cout<<i<<endl;
				int t=a[i];
				if(f[t]){
			//		cout<<i<<" "<<f[t]<<" "<<s[f[t]].size()<<endl;
					if(s[f[t]].back()==t){
						ans[++cnt][1]=1;
						ans[cnt][2]=f[t];
						s[f[t]].pop_back();
						tim[f[t]].pop_back();
						if(s[f[t]].size()<2)
							st[f[t]]=0;
					}
					else{
						ans[++cnt][1]=1;
						ans[cnt][2]=n;
						ans[++cnt][1]=2;
						ans[cnt][2]=f[t];
						ans[cnt][3]=n;
						s[f[t]].pop_front();
						tim[f[t]].pop_front();
						if(s[f[t]].size()<2)
							st[f[t]]=0;
					}
					f[t]=0;
				}
				else{
					bool flag=0;
					for(int j=1;j<n;++j){
						if(!s[j].empty() &&  tim[j].back()>nxt[i]){
							ans[++cnt][1]=1;
							ans[cnt][2]=j;
							ans[cnt][3]=1;
							s[j].push_back(t);
							tim[j].push_back(nxt[i]);
							f[t]=j;
							flag=1;
							break;
						}
					}
					if(flag==0){
						for(int j=1;j<n;++j){
							if(s[j].size()<2){
								ans[++cnt][1]=1;
								ans[cnt][2]=j;
								ans[cnt][3]=2;
								s[j].push_back(t);
								tim[j].push_back(nxt[i]);
								f[t]=j;
								flag=1;
								if(s[j].size()==2)
									st[j]=1;
								break;
							}
						}
						if(flag==0){/*
							bool st=0;
							for(int j=1;j<n;++j){
								if(tim[j].back()>nxt[i]){
									ans[++cnt][1]=1;
									ans[cnt][2]=j;
									ans[cnt][3]=3;
									s[j].push_back(t);
									tim[j].push_back(nxt[i]);
									f[t]=j;
									flag=1;
								}
							}*/
							ans[++cnt][1]=1;
							ans[cnt][2]=n;
							ans[cnt][3]=3;
				//			cout<<"QWQ"<<t<<" "<<n<<endl;
							s[n].push_back(t);
							tim[n].push_back(nxt[i]);
							f[t]=n;
							flag=1;
						}
					}
				}
			}
			cout<<cnt<<'\n';
			for(int i=1;i<=cnt;++i){
				cout<<ans[i][1]<<" "<<ans[i][2];
				if(ans[i][1]==2)
					cout<<" "<<ans[i][3];
				cout<<'\n';
			}
		}
	}
	return 0;
} 
