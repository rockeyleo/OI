#include<bits/stdc++.h>
#define fir first
#define sec second

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

const int N = 1010, mod = 998244353;

LL read() {
	LL x = 0, f = 1; char s = getchar();
	while (s < '0' || s > '9') {
		if (s == '-') f = -1;
		s = getchar();
	}
	while (s <= '9' && s >= '0') {
		x = x * 10 + s - '0';
		s = getchar();
	}
	return x * f;
}

void print(LL x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}
int n, m, c, f, T, id;
char s[N][N];
int g[N][N];
int lendep[N][N]; // ÿ�������µĳ���
int lenright[N][N]; // ÿ�������ҵĳ��� 
int cnum[N][N];
int fnum[N][N];
void add(int &x, LL y) {x = (((LL)x + y) % mod + mod) % mod;}
void mul(int &x, LL y) {x = 1ll * x * y % mod;}
int main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T = read(), id = read();
	while (T--) {
		n = read(), m = read(), c = read(), f = read();
		for (int i = 1; i <= n; i++) 
			for (int j = 1; j <= m; j++) g[i][j] = cnum[i][j] = fnum[i][j] = 0; // ��� 

		for (int i = 1; i <= n; i++)  scanf("%s", s[i] + 1);
		if (c == 0 && f == 0) {
			puts("0 0");
			continue;
		} 
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				g[i][j] = s[i][j] - '0';
			}
		}
		// ��ͳ�����ҵĳ��� 
		for (int i = 1; i <= n; i++) {
			int num = 0;
			for (int j = m; j >= 1; j--) {
				if (g[i][j]) lenright[i][j] = num = 0;
				else lenright[i][j] = ++num;
			}
		}
		// ͳ�����µĳ��� 
		for (int j = 1; j <= m; j++) {
			int num = 0; 
			for (int i = n; i >= 1; i--) {
				if (g[i][j]) lendep[i][j] = num = 0;
				else lendep[i][j] = ++ num;
			}
		}
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				if (g[i][j]) continue;
				for (int k = 2; k <= lendep[i][j] - 1; k++) {
					int u = i + k;
				    add(cnum[u][j], (LL)(lenright[i][j] - 1) * (lenright[u][j] - 1));
				    cnum[u][j] = cnum[u][j];
				}
			}
		}
		// ö��f����
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				if (g[i][j]) continue;
			    LL cnt = 1ll * cnum[i][j] * (lendep[i][j] - 1) % mod;
				add(fnum[i][j], cnt);
			}
		}
		// ͳ�ƴ� 
		int numc = 0, numf = 0;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				add(numc, cnum[i][j]);
				add(numf, fnum[i][j]);
			}
		}
		printf("%lld %lld\n", 1ll * c * numc, 1ll * f * numf);   
    }
	return 0;
	
}


