#include<bits/stdc++.h>
#define fir first
#define sec second

using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> PII;

const int N = 1e6 + 100;

LL read() {
	LL x = 0, f = 1; char s = getchar();
	while (s < '0' || s > '9') {
		if (s == '-') f = -1;
		s = getchar();
	}
	while (s <= '9' && s >= '0') {
		x = x * 10 + s - '0';
		s = getchar();
	}
	return x * f;
}

void print(LL x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

int T, n, Q;
int sta[N][50], stb[N][50];
int a[N], b[N];
int dui[N];


int main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	T = read(), n = read();
	dui[0] = -1;
	for (int i = 1; i <= n; i++) a[i] = read(), dui[i] = dui[i / 2] + 1;
	for (int i = 1; i <= n; i++) b[i] = read();
	for (int i = 0; i <= 40; i++) {
		for (int j = 1; j + (1ll << i) - 1 <= n; j++) {
			if (!i) sta[j][i] = a[j];
			else sta[j][i] = max(sta[j][i - 1], sta[j + (1 << i - 1)][i - 1]);
		}
	}
	for (int i = 0; i <= 40; i++) {
		for (int j = 1; j + (1ll << i) - 1 <= n; j++) {
			if (!i) stb[j][i] = b[j];
			else stb[j][i] = max(stb[j][i - 1], stb[j + (1 << i - 1)][i - 1]);
		}
	}
	Q = read();
	ULL ans;
	while (Q--) {
		ans = 0;
		int l, r;
		l = read(), r = read();
		for (int i = l; i <= r; i++) {
			for (int j = i; j <= r; j++) {
				int len = j - i + 1;
				int amax = max(sta[i][dui[len]], sta[j - (1 << dui[len]) + 1][dui[len]]);
				int bmax = max(stb[i][dui[len]], stb[j - (1 << dui[len]) + 1][dui[len]]);
				ans += (LL)amax * bmax;
			}
		}
		printf("%llu\n", ans);
	}
	return 0;
}




