#include<bits/stdc++.h>
#define fir first
#define sec second

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

const int N = 310, M = 2e6 + 10, K = 610;

LL read() {
	LL x = 0, f = 1; char s = getchar();
	while (s < '0' || s > '9') {
		if (s == '-') f = -1;
		s = getchar();
	}
	while (s <= '9' && s >= '0') {
		x = x * 10 + s - '0';
		s = getchar();
	}
	return x * f;
}

void print(LL x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

int T;
vector<int> num[K]; // ��¼ÿһ��Ŀ��Ʒ����˵ڼ���ջ��
vector<int> tmp; // ��ǰ��Щջ�ǿյ� 
vector<int> tmp2; // ��¼��Щվ����һ��Ԫ�ص� 
int sta[N][2]; // 0��ʾ�ڵײ���Ԫ�أ�1��ʾ�ڶ�����Ԫ�� 
int n, m, k;
int a[M]; 
int cnt;
PII g[M * 2][2];
//bool book[20];
//deque<int> s[4];
//bool check() {
//	for (int i = 1; i <= 3; i++) {
//		bool s = false;
//		if (s[i].size() > 1) {
//			for (int k = 1; k <= 3; k++) {
//				if (i == k) continue;
//				if (val == s[k].back()) 
//				   s[i].pop_back(), s[k].pop_back();
//				   s = true;
//			}
//		}
//		else if (s[i].size() == 1) {
//			int val = s[i][0];
//			for (int k = 1; k <= 3; k++) {
//				if (i == k) continue;
//				if (val == s[k].back()) {
//				   s[i].pop_back(), s[k].pop_back();
//				   s = true;   
//				}
//			}
//			if (!s) return false;
//		}
//	}
//	return true;
//}
//
//void dfs(int u, int now) {
//	if (now > 2 * m + 1) return;
//	if (flag) return;
//	if (now >= m && check()) {
//		printf("%d\n", now - 1);
// 		for (int i = 1; i < cnt; i++) {
// 			if (g[i][0].fir == 1) 	
//			    printf("1 %d\n", g[i][1].fir);
//			else 
//				printf("2 %d %d\n", g[i][1].fir, g[i][1].sec);
//		}
//		return;
//	}
//	for (int j = 1; j <= 3; j++) {
//		if (s[j].size() != 0 && s[j].front() == a[i]) {
//			g[now][0] = {1, 0};
//		    g[now][1] = {j, 0};
//		    s[j].pop_front();
//		    dfs(i + 1, now + 1);
//		}
//		else {
//			s[j].push_front(a[i]);
//			g[now][0] = {1, 0};
//			g[now][1] = {j, 0};
//			dfs(i + 1, now + 1);
//			s[j].pop_front(); 
//	    }
//	}
//}

int main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	T = read();
	if (T % 10 == 1) {
		while (T--) {
			n = read(), m = read(), k = read();
			tmp.clear();
			tmp2.clear();
			for (int i = 1; i <= n; i++) sta[i][0] = sta[i][1] = 0; 
			for (int i = 1; i <= k; i++) num[i].clear();
			cnt = 0; // ��� 
			for (int i = 1; i <= n; i++) tmp.push_back(i); // ��ʼ�� 
			for (int i = 1; i <= m; i++)  a[i] = read();
			for (int i = 1; i <= m; i++) {
				int x = a[i];
				if (num[x].size() == 0) { // �����ǰǰ��Ԫ��û�п������� 
					if (tmp.size() > 1) {
						int now = tmp.back(); 
						tmp.pop_back();
						num[x].push_back(now);
						sta[now][1] = x;
						tmp2.push_back(now);
						g[++cnt][0] = {1, 0};
						g[cnt][1] = {now, 0};
					}
					else {
						int now = tmp2.back();
						tmp2.pop_back();
						num[x].push_back(now);
						sta[now][0] = sta[now][1];
						sta[now][1] = x;
						g[++cnt][0] = {1, 0};
						g[cnt][1] = {now, 0};
					}
				} // 1���� 
				else {
					int predir = num[x].back(); // ��һ��ͬ���λ�� 
					num[x].pop_back();	
					if (sta[predir][1] == x) {
						sta[predir][1] = sta[predir][0];
						if (sta[predir][1] == 0) tmp.push_back(predir);
						else if (sta[predir][1] != 0) tmp2.push_back(predir);
						g[++cnt][0] = {1, 0};
						g[cnt][1] = {predir, 0}; 
					} // ��top 
					else if (sta[predir][0] == x) {
						int now = tmp.back();
						g[++cnt][0] = {1, 0};
						g[cnt][1] = {now, 0};
						g[++cnt][0] = {2, 0}; // 2���� 
						g[cnt][1] = {now, predir};
						tmp2.push_back(predir); // ��ǰɾȥһ����ֻʣ��һ��Ԫ�� 
					} // ��depth, ջ��������Ԫ�� 
				}
 			}
 			printf("%d\n", cnt);
 			for (int i = 1; i <= cnt; i++) {
 				if (g[i][0].fir == 1) 	
				    printf("1 %d\n", g[i][1].fir);
				else 
					printf("2 %d %d\n", g[i][1].fir, g[i][1].sec);
			}
		}
	}
	return 0;
}


