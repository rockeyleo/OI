#include<bits/stdc++.h>
#define fir first
#define sec second

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
\
const int N = 1000, mod = 1e9 + 7;

LL read() {
	LL x = 0, f = 1; char s = getchar();
	while (s < '0' || s > '9') {
		if (s == '-') f = -1;
		s = getchar();
	}
	while (s <= '9' && s >= '0') {
		x = x * 10 + s - '0';
		s = getchar();
	}
	return x * f;
}

void print(LL x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

int main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	srand((unsigned)time(NULL));
	cout << (LL)rand() * rand() % mod << endl;
	return 0;
}


