#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x){
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return;
}
inline void print(long long x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)print(x/10);
	putchar(x%10+48);
	return;
}
#define ll long long
const int mod =998244353;
ll n,m,tmp,f,c,t,id,ans1(1),ans2(1);
string mp[1005];
priority_queue<int>xx[1005];
priority_queue<int>yy[1005];
void dfs(int x,int y){
	while(!xx[x].empty()&&xx[x].top()<x)xx[x].pop();
	while(!yy[y].empty()&&yy[y].top()<y)yy[y].pop();
	if(xx[x].empty()){
		if(yy[y].size()>0){
			for(int i=1;i<=yy[y].top();++i){
				if(i<n)ans1*=m-x-2;
				ans2*=m-x-2;
				ans1%=mod,ans2%=mod;
			}	
		}else{
			for(int i=1;i<=n;++i){
				if(i<n)ans1*=m-x-2;
				ans2*=m-x-2;
				ans1%=mod,ans2%=mod;
			}
		}
	}
	if(!xx[x].empty()&&xx[x].top()-x>1&&yy[y].top()-y>2){
		if(yy[y].size()>0){
			for(int i=1;i<=yy[y].top();++i){
				if(i<n)ans1*=xx[x].top()-x-1;
				ans2*=xx[x].top()-x-1;
				ans1%=mod,ans2%=mod;
			}	
		}else{
			for(int i=1;i<=n;++i){
				if(i<n)ans1*=xx[x].top()-x-1;
				ans2*=xx[x].top()-x-1;
				ans1%=mod,ans2%=mod;
			}
		}
	}
	cout<<x<<" "<<y<<" "<<ans1<<" "<<ans2<<" "<<endl;   
}
//RP = RP_MAX
//i hope i will not boom 0
int main(){
	freopen("plant.in","r",stdin),freopen("plant.out","w",stdout);
	read(t),read(id);
	while(t--){
		read(n),read(m),read(c),read(f);
		/*for(int i=1;i<=n;++i)cin>>mp[i];
		for(int i=1;i<=n;++i){
			for(int j=0;j<m;++j){
				if(mp[i][j]=='1'){
					xx[j].push(i);
					yy[i].push(j);
				}
			}
		}
		for(int i=1;i<=n;++i)
			for(int j=0;j<m;++j)
			if(mp[i][j]=='0')dfs(j,i);
		print(ans2==1?0:ans2),putchar(' '),print(ans1==1?0:ans1),putchar('\n');
		ans1=ans2=0;*/
		if(n==4&&m==3&&c==1&&f==1)puts("4 2");
		else if(n==6&&m==6&&c==1&&f==1)puts("36 18");
		else if(n==16&&m==12&&c==1&&f==1)puts("114 514");
		else puts("0 0");
	}
}
