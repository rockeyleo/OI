#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x){
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return;
}
inline void print(long long x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)print(x/10);
	putchar(x%10+48);
	return;
}
#define int long long
#define MAXN 500005
int arr1[MAXN],arr2[MAXN];
struct node{
	int l,r,maxx1,maxx2;
	node operator+(const node &x)const{
		return {l,x.r,max(maxx1,x.maxx1),max(maxx2,x.maxx2)};
	}
}stree[MAXN<<2];
inline void pushup(int now){
	stree[now]=stree[now<<1]+stree[now<<1|1];
}
void build(int l,int r,int now){
	if(l==r){
		stree[now]={l,l,arr1[l],arr2[l]};
		return;
	}
	int mid((l+r)>>1);
	build(l,mid,now<<1);
	build(mid+1,r,now<<1|1);
	pushup(now);
}
node query(int l,int r,int now){
	if(stree[now].l>=l&&stree[now].r<=r)return stree[now];
	if(stree[now].r<l||stree[now].l>r)return {0,0,0,0};
	return query(l,r,now<<1)+query(l,r,now<<1|1);
}
//const __int128 mod=18446744073709551616;
int t,n,q,l,r;
signed main(){
	freopen("match.in","r",stdin),freopen("match.out","w",stdout);
	read(t),read(n);
	for(int i=1;i<=n;++i)read(arr1[i]);
	for(int i=1;i<=n;++i)read(arr2[i]);
	build(1,n,1);
	read(q);
	while(q--){
		long long ans(0);
		read(l),read(r);
		for(int i=l;i<=r;++i){
			for(int j=i;j<=r;++j){
				ans+=(query(i,j,1).maxx1*query(i,j,1).maxx2);
			}
		}
		print(ans),putchar('\n');
	}
}

