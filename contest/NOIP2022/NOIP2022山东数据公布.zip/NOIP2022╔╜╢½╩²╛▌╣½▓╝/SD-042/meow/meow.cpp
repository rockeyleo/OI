#include<bits/stdc++.h>
using namespace std;
inline void read(long long &x){
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return;
}
inline void print(long long x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)print(x/10);
	putchar(x%10+48);
	return;
}
#define ll long long
ll t,n,m,k,tmp,ncnt(0);
deque<ll>p[305];
deque<ll>pp;
queue<tuple<int,int,int>>q;
int main(){
	freopen("meow.in","r",stdin),freopen("meow.out","w",stdout);
	read(t);
	while(t--){
		read(n),read(m),read(k);
		for(int i=1;i<=m;++i){
			read(tmp);
			pp.push_back(tmp);
		}
		while(!pp.empty()){
			int nowp=pp.front();
			pp.pop_front();
			bool flag1=0,flag2=0;
			for(int i=1;i<=ncnt;++i){
				if(p[i].front()==nowp){
					q.push(make_tuple(1,i,0));
					p[i].pop_front();
					flag1=1;
				}
			}
			if(flag1==0){
				p[++ncnt].push_front(nowp);
				for(int i=1;i<ncnt;++i){
					if(p[i].back()==nowp){
						q.push(make_tuple(2,ncnt,i));
						p[i].pop_back();
						p[ncnt].pop_back();
						--ncnt;
						flag2=1;
					}
				}
				if(flag2==0)q.push(make_tuple(1,ncnt,0));
			}
		}
		print(q.size()),putchar('\n');
		while(!q.empty()){
			auto tp=q.front();
			if(get<0>(tp)==1){
				print(get<0>(tp)),putchar(' '),print(get<1>(tp)),putchar('\n');
			}else{
				print(get<0>(tp)),putchar(' '),print(get<1>(tp)),putchar(' '),print(get<2>(tp)),putchar('\n');
			}
			q.pop();
		}
		ncnt=0;
	}
}
