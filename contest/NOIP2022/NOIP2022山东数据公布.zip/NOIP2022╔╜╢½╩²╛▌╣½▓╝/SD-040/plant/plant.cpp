#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int read()
{
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+(c-'0');c=getchar();}
	return x*f;
}
char c[1005];
long long x[1005][1005],f[1005],a[1005][1005],fir[1005][1005],y[1005][1005];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int tt,id;
	tt=read();
	id=read();
	while(tt--)
	{
		int n=read(),m=read(),cc=read(),ff=read();
		if(cc==0&&ff==0)
		{
			cout<<0<<" "<<0<<endl;
		}
		int cnt=0;
		for(int i=1;i<=n;++i)
		  for(int j=1;j<=m;++j)
		  {
		  	  x[i][j]=0;
		  	  y[i][j]=0;
		  }
		for(int i=1;i<=n;++i) 
		{
		    int tot=0;
		    cin>>c+1;
			for(int j=1;j<=m;++j)
		    {
		    	a[i][j]=c[j]-'0';
				if(a[i][j]==1)
				{
					f[++tot]=j;
				}
		    }
		    int t=tot;
		    cnt=1;
		    for(int j=m;j>=1;--j)
		    {
		    	if(f[t]>j) t--;
		    	if(f[t]==j)
		    	{
		    		cnt=0;
				}
				if(f[t]!=j) x[i][j]=cnt;
				cnt++;
			}
		}
		cnt=1;
		for(int j=1;j<=m;j++)
		{
			int tot=0;
			cnt=1;
			for(int i=1;i<=n;i++)
		    {
		  	    if(a[i][j]==1)
				{
					f[++tot]=i;
				}
		    }
		    int t=tot;
		    for(int i=n;i>=1;--i)
			{
				if(f[t]>i) t--;
		    	if(f[t]==i)
		    	{
		    		cnt=0;
				}
				if(f[t]!=i) y[i][j]=cnt;
				cnt++;
			}
		}
		long long ans1=0,ans2=0;
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=m;++j)
			{
				if(a[i][j]==0&&x[i][j]>1&&a[i+1][j]!=1&&cc==1)
				{
					for(int k=i+2;k<=n;++k)
					{
						if(a[k][j]==1) break;
						ans1=(ans1+(x[k][j]-1)*(x[i][j]-1)%mod)%mod;
					}
				}
				if(a[i][j]==0&&y[i][j]>1&&a[i+1][j]!=1&&ff==1)
				{
					for(int k=i+2;k<=n;++k)
					{
						if(a[k][j]==1) break;
						ans2=(ans2+((x[k][j]-1)*(x[i][j]-1)%mod)*(y[k][j]-1))%mod;
					}
				}
			}
		}
		cout<<ans1*cc%mod<<" "<<ans2*ff%mod<<endl;
	}
	return 0;
}
/*
1 0
4 3 1 1
001
010
000
000
*/
