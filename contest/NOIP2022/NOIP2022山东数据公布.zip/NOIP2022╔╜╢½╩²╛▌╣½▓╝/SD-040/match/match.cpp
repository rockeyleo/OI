#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
struct node{
	int l,r;
	long long add,val,maxx;
}t[400000],tt[400000];
int a[400000],b[400000];
int ls(int p){return p<<1;}
int rs(int p){return p<<1|1;}
int read()
{
	int x=0,f=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		x=x*10+(c-'0');
		c=getchar();
	}
	return x*f;
}
void build1(int p,int l,int r)
{
	t[p].l=l;
	t[p].r=r;
	if(l==r)
	{
		t[p].maxx=a[l];
		return ;
	}
	int mid=(l+r)>>1;
	build1(ls(p),l,mid);
	build1(rs(p),mid+1,r);
	t[p].maxx=max(t[ls(p)].maxx,t[rs(p)].maxx);
}
void build2(int p,int l,int r)
{
	tt[p].l=l;
	tt[p].r=r;
	if(l==r)
	{
		tt[p].maxx=b[l];
		return ;
	}
	int mid=(l+r)>>1;
	build2(ls(p),l,mid);
	build2(rs(p),mid+1,r);
	tt[p].maxx=max(tt[ls(p)].maxx,tt[rs(p)].maxx);
}
long long ask1(int p,int l,int r)
{
	if(t[p].l>=l&&t[p].r<=r)
	{
		return t[p].maxx;
	}
	long long ans=0;
	int mid=(t[p].l+t[p].r)>>1;
	if(l<=mid) ans=max(ask1(ls(p),l,r),ans);
	if(r>mid) ans=max(ans,ask1(rs(p),l,r));
	return ans;
}
long long ask2(int p,int l,int r)
{
	if(t[p].l>=l&&t[p].r<=r)
	{
		return tt[p].maxx;
	}
	long long ans=0;
	int mid=(tt[p].l+tt[p].r)>>1;
	if(l<=mid) ans=max(ask2(ls(p),l,r),ans);
	if(r>mid) ans=max(ans,ask2(rs(p),l,r));
	return ans;
}
int ttt,n,o,vis[3005][3005];
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>ttt>>n;
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	} 
	build1(1,1,n);
	for(int i=1;i<=n;i++)
	{
		b[i]=read();
	} 
	build2(1,1,n);
	o=read();
	while(o--)
	{
	    unsigned long long ans=0;
		int l=read(),r=read();
		for(int p=l;p<=r;p++)
		{
			for(int q=p;q<=r;q++)
			{
				long long sum1=ask1(1,p,q);
				long long sum2=ask2(1,p,q);
				ans+=(unsigned long long)sum1*sum2;
			}
		}
		printf("%lld",ans);
	}
	return 0;
}
/*
0 2
2 1
1 2
1
1 2
*/
