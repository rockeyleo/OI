#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(20070322);
	cout<<rand()%50+1;
	return 0;
}
