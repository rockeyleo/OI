#include<iostream>
#include<cstdio>
#include<climits>
#include<cctype>
#define ll long long

using namespace std;
namespace ly
{
	namespace IO
	{
		template<typename type>
		inline type read(type &x)
		{
			x=0;bool flag(0);char ch=getchar();
			while(!isdigit(ch)) flag^=ch=='-',ch=getchar();
			while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
			return flag?x=-x:x;
		}
		template<typename type>
		inline void write(type x)
		{
			x<0?x=-x,putchar('-'):0;
			static short Stack[50],top(0);
			do Stack[++top]=x%10,x/=10;while(x);
			while(top) putchar(Stack[top--]|48);
		}
		inline char read(char &x){do x=getchar();while(isspace(x));return x;}
		inline char write(const char &x){return putchar(x);}
		inline void read(char *x){static char ch;read(ch);do *(x++)=ch;while(!isspace(ch=getchar())&&~ch);}
		template<typename type>inline void write(const type *x){while(*x)putchar(*(x++));}
		inline void read(string &x){static char ch;read(ch),x.clear();do x+=ch;while(!isspace(ch=getchar())&&~ch);}
		inline void write(const string &x){for(int i=0,len=x.length();i<len;++i)putchar(x[i]);}
		template<typename type,typename...T>inline void read(type &x,T&...y){read(x),read(y...);}
		template<typename type,typename...T>
		inline void write(const type &x,const T&...y){write(x),putchar(' '),write(y...),sizeof...(y)^1?0:putchar('\n');}
		template<typename type>
		inline void put(const type &x,bool flag=1){write(x),flag?putchar('\n'):putchar(' ');}
	}using namespace IO;
	namespace algorithm
	{
		
	}using namespace algorithm;
}using namespace ly::IO;

#define maxn 1010

int T,id,n,m,c,f,sx[maxn][maxn],sy[maxn][maxn];//sx[i][j]:sum of a[i][1...j] sy[i][j]:sum of a[1...j][i]
char a[maxn][maxn];
ll ansc,ansf,p=998244353;

auto sumx=[](int x,int y1,int y2){return sx[x][y2]-sx[x][y1-1];};
auto sumy=[](int y,int x1,int x2){return sy[y][x2]-sy[y][x1-1];};

auto posx=[](int x,int L,int R)//position of the first 1 in line x,L~R
{
	int l=L,r=R,mid;
	while(l<r)
	{
		mid=(l+r)>>1;
		if(sumx(x,l,mid)) r=mid;
		else l=mid+1;
	}
	return a[x][l]=='1'?l:0;
};

auto posy=[](int y,int L,int R)//position of the first 1 in col y,L~R
{
	int l=L,r=R,mid;
	while(l<r)
	{
		mid=(l+r)>>1;
		if(sumy(y,l,mid)) r=mid;
		else l=mid+1;
	}
	return a[l][y]=='1'?l:0;
};

int px[maxn][maxn],py[maxn][maxn];//O(n^2mlogn)->O(n^2m)

signed main()
{
	freopen("plant.in","r",stdin),freopen("plant.out","w",stdout);
	read(T,id);
	while(T--)
	{
		read(n,m,c,f);
		for(int i=1;i<=n;++i) read(a[i]+1);
		if(!c&&!f){write(0,0);continue;}
		for(int i=1;i<=n;++i)
			for(int j=1;j<=m;++j)
				sx[i][j]=sx[i][j-1]+(a[i][j]^48);
		for(int i=1;i<=m;++i)
			for(int j=1;j<=n;++j)
				sy[i][j]=sy[i][j-1]+(a[j][i]^48);
		for(int x=1;x<=n;++x)
			for(int y=1;y<=m;++y)
				px[x][y]=posx(x,y,m),py[y][x]=posy(y,x,n);
		ansc=ansf=0;
		for(int x1=1,r1,r2,r3;x1<=n;++x1)
			for(int x2=x1+2;x2<=n;++x2)
				for(int y=1;y<m;++y)
				{
					if(a[x1][y+1]^48||a[x2][y+1]^48||sumy(y,x1,x2)) continue;
					r1=px[x1][y+1],r2=px[x2][y+1];
					if(!r1) r1=m+1;
					if(!r2) r2=m+1;
					r1--,r2--;
					ansc=(ansc+(r1-y)*(r2-y))%p;
					if(x2<n)
					{
						r3=py[y][x2+1];
						if(!r3) r3=n+1;
						r3--;
						ansf=(ansf+(r1-y)*(r2-y)*(r3-x2))%p;
					}
				}
		write(ansc*c%p,ansf*f%p);
	}
	return 0;
}
