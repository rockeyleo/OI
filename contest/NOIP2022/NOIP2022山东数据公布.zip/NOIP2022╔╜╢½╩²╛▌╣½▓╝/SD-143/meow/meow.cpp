#include<iostream>
#include<cstdio>
#include<climits>
#include<cctype>
#define ll long long

using namespace std;
namespace ly
{
	namespace IO
	{
		template<typename type>
		inline type read(type &x)
		{
			x=0;bool flag(0);char ch=getchar();
			while(!isdigit(ch)) flag^=ch=='-',ch=getchar();
			while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
			return flag?x=-x:x;
		}
		template<typename type>
		inline void write(type x)
		{
			x<0?x=-x,putchar('-'):0;
			static short Stack[50],top(0);
			do Stack[++top]=x%10,x/=10;while(x);
			while(top) putchar(Stack[top--]|48);
		}
		inline char read(char &x){do x=getchar();while(isspace(x));return x;}
		inline char write(const char &x){return putchar(x);}
		inline void read(char *x){static char ch;read(ch);do *(x++)=ch;while(!isspace(ch=getchar())&&~ch);}
		template<typename type>inline void write(const type *x){while(*x)putchar(*(x++));}
		inline void read(string &x){static char ch;read(ch),x.clear();do x+=ch;while(!isspace(ch=getchar())&&~ch);}
		inline void write(const string &x){for(int i=0,len=x.length();i<len;++i)putchar(x[i]);}
		template<typename type,typename...T>inline void read(type &x,T&...y){read(x),read(y...);}
		template<typename type,typename...T>
		inline void write(const type &x,const T&...y){write(x),putchar(' '),write(y...),sizeof...(y)^1?0:putchar('\n');}
		template<typename type>
		inline void put(const type &x,bool flag=1){write(x),flag?putchar('\n'):putchar(' ');}
	}using namespace IO;
	namespace algorithm
	{
		
	}using namespace algorithm;
	namespace DS
	{
		#define maxn 2000010
		template<typename type>
		class deque
		{
			private:
				int head,tail,n;
				type a[maxn];
			public:
				int id;
				deque(int i=0){head=tail=n=0,id=i;}
				//void push_front(const type &x){head=(head?head-1:maxn-1),a[head]=x,n++;}
				//void push_back(const type &x){a[tail]=x,tail=(++tail^maxn?tail:0),n++;}
				void push(const type &x){a[tail]=x,tail=(++tail^maxn?tail:0),n++;}
				void pop_bot(){head=(++head^maxn?head:0),n--;}
				void pop_top(){tail=(tail?tail-1:maxn-1),n--;}
				type bot(){return a[head];}
				type top(){return a[tail?tail-1:maxn-1];}
				type operator [](int i)const{return a[head+i-1-(head+i-1<maxn?0:maxn)];}
				int size(){return n;}
				bool empty(){return !n;}
				void print(){for(int i=0;i<n;++i)put(a[head+i-(head+i<maxn?0:maxn)],0);write('\n');}
		};
		#undef maxn
	}
}using namespace ly::IO;

#define maxn 310
#define maxm 2000010

int T,n,m,k,x,ans,a[maxm];
ly::DS::deque<int>s1(1),s2(2);
class ANS
{
	public:
		int x,y,z;
		ANS(int a=1,int b=0,int c=0){x=a,y=b,z=c;}
		void put(){(x&1)?(write(1,y),0):(write(2,y,z),0);}
}Ans[maxm<<1];
auto op=[](int k,int x,int y=0){Ans[++ans]={k,x,y};};

signed main()
{
	freopen("meow.in","r",stdin),freopen("meow.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n,m,k);
		for(int i=1;i<=m;++i)
		{
			read(x);
			if(s1.empty()&&s2.empty()){op(1,s1.id),s1.push(x);continue;}
			if(!s1.empty()&&s1.top()==x){op(1,s1.id),s1.pop_top();continue;}
			if(!s2.empty()&&s2.top()==x){op(1,s2.id),s2.pop_top();continue;}
			if(!s1.empty()&&!s2.empty()&&s1.bot()==s2.bot()) op(2,s1.id,s2.id),s1.pop_bot(),s2.pop_bot();
			if(s1.empty()&&s2.bot()==x){op(1,s1.id),op(2,s1.id,s2.id),s2.pop_bot();continue;}
			if(s2.empty()&&s1.bot()==x){op(1,s2.id),op(2,s1.id,s2.id),s1.pop_bot();continue;}
			op(1,s1.id),s1.push(x);
		}
		put(ans);
		for(int i=1;i<=ans;++i) Ans[i].put();
	}
	return 0;
}
