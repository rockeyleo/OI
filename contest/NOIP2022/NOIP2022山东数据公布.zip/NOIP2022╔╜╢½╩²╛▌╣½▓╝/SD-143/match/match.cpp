#include<iostream>
#include<cstdio>
#include<climits>
#include<cctype>
#include<cmath>
#define ll long long
#define ull unsigned long long

using namespace std;
namespace ly
{
	namespace IO
	{
		template<typename type>
		inline type read(type &x)
		{
			x=0;bool flag(0);char ch=getchar();
			while(!isdigit(ch)) flag^=ch=='-',ch=getchar();
			while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
			return flag?x=-x:x;
		}
		template<typename type>
		inline void write(type x)
		{
			x<0?x=-x,putchar('-'):0;
			static short Stack[50],top(0);
			do Stack[++top]=x%10,x/=10;while(x);
			while(top) putchar(Stack[top--]|48);
		}
		inline char read(char &x){do x=getchar();while(isspace(x));return x;}
		inline char write(const char &x){return putchar(x);}
		inline void read(char *x){static char ch;read(ch);do *(x++)=ch;while(!isspace(ch=getchar())&&~ch);}
		template<typename type>inline void write(const type *x){while(*x)putchar(*(x++));}
		inline void read(string &x){static char ch;read(ch),x.clear();do x+=ch;while(!isspace(ch=getchar())&&~ch);}
		inline void write(const string &x){for(int i=0,len=x.length();i<len;++i)putchar(x[i]);}
		template<typename type,typename...T>inline void read(type &x,T&...y){read(x),read(y...);}
		template<typename type,typename...T>
		inline void write(const type &x,const T&...y){write(x),putchar(' '),write(y...),sizeof...(y)^1?0:putchar('\n');}
		template<typename type>
		inline void put(const type &x,bool flag=1){write(x),flag?putchar('\n'):putchar(' ');}
	}using namespace IO;
	namespace algorithm
	{
		auto max=[](const auto &x,const auto &y){return x<y?y:x;};
	}using namespace algorithm;
}using namespace ly::IO;

#define maxn 300010

int T,n,q,l,r,a[maxn],b[maxn],f[maxn][30][2],Log[30];
ull ans;

auto query=[](int l,int r,int x){int k=Log[r-l+1];return ly::max(f[l][k][x],f[r-(1<<k)+1][k][x]);};

signed main()
{
	freopen("match.in","r",stdin),freopen("match.out","w",stdout);
	read(T,n);
	for(int i=1;i<=n;++i) f[i][0][0]=read(a[i]);
	for(int i=1;i<=n;++i) f[i][0][1]=read(b[i]);
	for(int j=1;j<30;++j)
		for(int i=1;i+(1<<j)-1<=n;++i)
			for(int k=0;k<=1;++k)
				f[i][j][k]=ly::max(f[i][j-1][k],f[i+(1<<(j-1))][j-1][k]);
	for(int i=1;i<=n;++i) Log[i]=log2(i);
	read(q);
	while(q--)
	{
		read(l,r);
		ans=0;
		for(int i=l;i<=r;++i)
			for(int j=i;j<=r;++j)
				ans+=1ull*query(i,j,0)*query(i,j,1);
		put(ans);
	}
	return 0;
}
