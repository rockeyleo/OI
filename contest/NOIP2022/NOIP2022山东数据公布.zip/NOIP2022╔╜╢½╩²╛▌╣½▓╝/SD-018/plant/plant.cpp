#include<iostream>
#include<cstdio>
using namespace std;
int T,id,n,m,c,f;
long long vc=0,vf=0;
char cha[1001][1001];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int ulen,dlen,llen,flen,fbo=1;
	cin>>T>>id>>n>>m>>c>>f;
	for(int i=0;i<n;i++)cin>>cha[i];
	
	if(id==1)
	{
		cout<<0<<" "<<0;
		return 0;
	}
	if(id==15)fbo=0;
	else if(id==5)m=2;
	else if(id==6)n=3;
	
	for(int i=0;i<n-2;i++)
	{
		for(int j=0;j<m-1;j++)
		{
			
			
				llen=2;
			while(1)
			{
			    if(cha[i][j]=='0'&&cha[i+llen-1][j]=='0'&&cha[i+llen][j]=='0'&&cha[i][j+1]=='0'&&cha[i+llen][j+1]=='0')
			    {
			    	ulen=1;
			    dlen=1;
			    while(1)
			    {
			    	if(j+ulen+1==m)break;
			    	if(cha[i][j+ulen+1]=='0')ulen++;
			    	else break;
			    }
			    while(1)
			    {
			    	
			    	if(j+dlen+1==m)break;
			    	if(cha[i+llen][j+dlen+1]=='0')dlen++;
			    	else break;
			    }
			    flen=0;
			    while(fbo)
				{
					if(i+llen+flen==n-1)break;
					else 
					{	
						if(cha[i+llen+1+flen][j]=='0')
						{
						    
						    flen++;
						}
						else break;
					}
				}
				vf=vf+(dlen*ulen*flen);
			    vc=vc+(dlen*ulen);
				}
			    
			    
		    if(cha[i+llen-1][j]=='0')llen++;
		    else break;
		    if((i+llen)>=n)break;
		    }
			
			
		}
	}
	vc=(vc*c)%998244353;
	vf=(vf*f)%998244353;
	cout<<vc<<" "<<vf;
	return 0;
}
