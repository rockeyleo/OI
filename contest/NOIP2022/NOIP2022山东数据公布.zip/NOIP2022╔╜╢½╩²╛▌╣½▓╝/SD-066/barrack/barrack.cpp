#include<bits/stdc++.h>
using namespace std;
#define maxn 500004
const long long p=1000000007;
long long fstpow(int a,int b) {
	long long res=1ll;
	while(b) {
		if(b & 1) res=1ll*res*a%p;
		a=1ll*a*a%p;
		b>>=1;
	}
	return res;
}
struct aaa{
	int to,nxt;
}a[maxn<<2];
int col[maxn],colo,ge[maxn],dfn[maxn],low[maxn],inn[maxn],siz[maxn],top[maxn],cnt,fa[maxn],c[maxn];
int head[maxn],tot;
void add(int x,int y) {
	a[tot].to=y;
	a[tot].nxt=head[x];
	head[x]=tot++;
}
stack<int> s;
void tar(int u,int f) {
	dfn[u]=low[u]=++cnt;
	s.push(u);
	inn[u]=1;
	for(int i=head[u];i!=-1;i=a[i].nxt) {
		int v=a[i].to;
		if(v == f) continue;
		if(!dfn[v]) {
			tar(v,u);
			low[u]=min(low[u],low[v]);
		} else if(inn[v]) low[u]=min(low[u],dfn[v]);
	}
	if(low[u] == dfn[u]) {
		int x;
		++colo;
		while(1) {
			x=s.top();
			s.pop();
			col[x]=colo;
			ge[colo]++;
			inn[x]=0;
			if(x == u) break;
		}
	}
}
int n,m;
vector<int> e[maxn];
struct edd{
	int x,y;
}edg[maxn];
int dep[maxn],son[maxn],tp[maxn];
void dfs1(int u,int f) {
	fa[u]=f;
	dep[u]=dep[f]+1;
	siz[u]=1;
	int maxsiz=0;
	for(int v:e[u]) {
		if(v == f) continue;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v] > maxsiz) {
			maxsiz=siz[v];
			son[u]=v;
		}
	}
}
void dfs2(int u,int t) {
	tp[u]=t;
	if(son[u]) dfs2(son[u],t);
	for(int v:e[u]) {
		if(v == fa[u] || v==son[u]) continue;
		dfs2(v,v);
	}
}
int lca(int x,int y) {
	while(top[x] != top[y]) {
		if(dep[tp[x]] < dep[tp[y]]) swap(x,y);
		x=fa[tp[x]];
	}
	return dep[x] < dep[y] ? x : y;
}
int sum;
void getdfs(int u,int f) {
	for(int v:e[u]) {
		if(v == f) continue;
		getdfs(v,u);
		c[u]+=c[v];
	}
	if(c[u] > 0) sum++;
}
long long ans=0;
void getans() {
	cout<<((fstpow(2,2*n)-fstpow(2,n))%p+p)%p<<endl;
}
int main() {
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++) {
		int x,y;
		scanf("%d %d",&x,&y);
		edg[i]={x,y};
		add(x,y);
		add(y,x);
	}
	tar(1,1);
	if(colo == 1) {
		getans();
		return 0;
	}
	for(int i=1;i<=m;i++) {
		int x=edg[i].x,y=edg[i].y;
		if(col[x] == col[y]) continue;
		e[col[x]].push_back(col[y]);
		e[col[y]].push_back(col[x]);
	}
	dfs1(1,1);
	dfs2(1,1);
	for(int i=1;i<(1<<colo);i++) {
		for(int j=1;j<=colo;j++) c[j]=0;
		for(int j=0;j<colo;j++) {
			if(!(i&(1<<j))) continue;
			for(int k=0;k<colo;k++) {
				if(j == k) continue;
				if(!(i&(1<<k))) continue;
				c[j+1]++;
				c[k+1]++;
				c[lca(j+1,k+1)]-=2;
			}
		}
		sum=0;
		getdfs(1,1);
		long long res=1ll;
		for(int j=0;j<colo;j++) {
			if(!(i&(1<<j))) continue;
			res=res*(fstpow(2,ge[j+1])-1)%p;
		}
		ans=(ans+res*fstpow(2,m-sum)%p)%p;
	}
	cout<<ans<<endl;
//	cout<<colo<<endl;
//	for(int i=1;i<=n;i++) printf("%d ",col[i]);
	return 0;
}
// lixp loves My_Youth forever!!!
