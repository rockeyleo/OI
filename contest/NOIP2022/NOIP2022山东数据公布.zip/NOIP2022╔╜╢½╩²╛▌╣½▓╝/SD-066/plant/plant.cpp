#include<bits/stdc++.h>
using namespace std;
const long long p=998244353;
long long maxyou[1005][1005],maxxia[1005][1005],ansc,ansf,sigmac[1005][1005],sigmaf[1005][1005];
long long a[1005][1005];
long long n,m,c,f;
void calcc(long long x,long long y) {
	if(maxyou[x][y] == 0) return;
//	for(long  long i=x+2;i<=x+maxxia[x][y];i++) {
//		ansc=(ansc+maxyou[x][y]*maxyou[i][y]%p)%p;
//	}
	ansc=(ansc+maxyou[x][y]*(((sigmac[x][y]-maxyou[x+1][y]-maxyou[x][y])%p+p)%p)%p)%p;
}
void calcf(long long x,long long y) {
	if(maxyou[x][y] == 0) return;
//	for(long  long i=x+2;i<x+maxxia[x][y];i++) {
//		ansf=(ansf+maxyou[x][y]*maxyou[i][y]%p*(x+maxxia[x][y]-i)%p)%p;
//	}
	ansf=(ansf+maxyou[x][y]*(((sigmaf[x][y]-maxyou[x+1][y]*maxxia[x+1][y]-maxyou[x][y]*maxxia[x][y])%p+p)%p)%p)%p;
}
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	long long T,id;
	scanf("%lld %lld",&T,&id);
	while(T--) {
		memset(sigmac,0,sizeof(sigmac));
		memset(sigmaf,0,sizeof(sigmaf));
		ansc=0,ansf=0;
		scanf("%lld %lld %lld %lld",&n,&m,&c,&f);
//		cout<<n<<m<<endl;
		for(long long i=1;i<=n;i++) {
			for(long long j=1;j<=m;j++) scanf("%1lld",&a[i][j]);
		}
		if(c == 0 && f==0) {
			printf("0 0\n");
			return 0;
		}
		for(long long i=1;i<=n;i++) {
			long long maxlen=0;
			for(long long j=m;j>=1;j--) {
				maxyou[i][j]=maxlen;
				if(a[i][j] == 1) {
					maxlen=0;
					maxyou[i][j]=0;
				} else maxlen++;
			}
		}
		for(long long j=1;j<=m;j++) {
			long long maxlen=0;
			for(long long i=n;i>=1;i--) {
				maxxia[i][j]=maxlen;
				if(a[i][j]) {
					maxlen=0;
					maxxia[i][j]=0;
				} else maxlen++;
			}
		}
		for(int j=1;j<=m;j++) {
			for(int i=n;i>=1;i--) {
				sigmac[i][j]=(sigmac[i+1][j]+maxyou[i][j])%p;
				sigmaf[i][j]=(sigmaf[i+1][j]+maxyou[i][j]*maxxia[i][j])%p;
				if(a[i][j] == 1) sigmac[i][j]=0,sigmaf[i][j]=0;
			}
		}
//		for(int i=1;i<=n;i++) {
//			for(int j=1;j<=m;j++) printf("%lld ",sigmaf[i][j]);
//			puts("");
//		}
		if(c != 0) {
			for(long long i=1;i<n-1;i++) {
				for(long long j=1;j<m;j++) {
					calcc(i,j);
				}
			}
		} 
		if(f != 0) {
			for(long long i=1;i<n-1;i++) {
				for(long long j=1;j<m;j++) {
					calcf(i,j);
				}
			}
		}
		printf("%lld %lld\n",ansc,ansf);
	}
	return 0;
}
// lixp loves My_Youth forever!!!
