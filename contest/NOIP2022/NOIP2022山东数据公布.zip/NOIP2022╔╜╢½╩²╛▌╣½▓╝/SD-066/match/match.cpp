#include<bits/stdc++.h>
using namespace std;
#define maxn 250005
#define ull unsigned long long
ull ans;
inline int getmax(int a,int b) {
	return a > b ? a : b;
}
int T,n,a[maxn],b[maxn];
int main() {
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d %d",&T,&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	int q;
	scanf("%d",&q);
	while(q--) {
		int l,r;
		scanf("%d %d",&l,&r);
		ans=0;
		for(int i=l;i<=r;i++) {
			int maxa=0,maxb=0;
			for(int j=i;j<=r;j++) {
				maxa=getmax(maxa,a[j]);
				maxb=getmax(maxb,b[j]);
				ans+=(ull)maxa*maxb;
			}
		}
		printf("%llu\n",ans);
	}
	return 0;
}
// lixp loves My_Youth forever!!!
