#include<bits/stdc++.h>
using namespace std;
#define maxn 2000004
struct anss{
	int opt,x,y;
}ans[4000005];
int cnt,n,T,m,k;
int l,r,s[maxn],s1[maxn],l1,r1,ge[maxn],a[maxn],sum[maxn];
void xiao() {
	while(l<=r && l1<=r1 && s[l]==s1[l1]) {
		++cnt;
		ans[cnt].opt=2;
		ans[cnt].x=1;
		ans[cnt].y=2;
		l++,l1++;
	}
}
int main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		cnt=0;
		l=1,r=0;
		l1=1,r1=0;
		scanf("%d %d %d",&n,&m,&k);
		for(int i=1;i<=k;i++) ge[i]=0,sum[i]=0;
		if(n == 2) {
			for(int i=1;i<=m;i++) {
				int x;
				scanf("%d",&x);
				if(s[r] == x) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=1;
					r--;
				} else if(s[l] == x) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=2;
					++cnt;
					ans[cnt].opt=2;
					ans[cnt].x=1;
					ans[cnt].y=2;
					l++;
				} else {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=1;
					r++;
					s[r]=x;
				}
			}
		} else {
			for(int i=1;i<=m;i++) {
				scanf("%d",&a[i]);
				sum[a[i]]++;
			}
			for(int i=1;i<=m;i++) {
				int x;
				x=a[i];
				if(r>=l && s[r] == x) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=1;
					ge[x]--;
					r--;
					xiao();
					continue;
				}
				if(r>=l && s[l] == x) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=3;
					++cnt;
					ans[cnt].opt=2;
					ans[cnt].x=1;
					ans[cnt].y=3;
					l++;
					ge[x]--;
					xiao();
					continue;
				}
				if(r1>=l1 && s1[r1] == x) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=2;
					r1--;
					xiao();
					continue;
				}
				if(r1>=l1 && s1[l1] == x) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=3;
					++cnt;
					ans[cnt].opt=2;
					ans[cnt].x=2;
					ans[cnt].y=3;
					l1++;
					xiao();
					continue;
				}
				if(ge[x] >= sum[x]/2) {
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=2;
					++r1;
					s1[r1]=x;
					xiao();
				} else {
					ge[x]++;
					++cnt;
					ans[cnt].opt=1;
					ans[cnt].x=1;
					++r;
					s[r]=x;
					xiao();
				}
			}
			for(int i=l;i<=r;i++) {
				++cnt;
				ans[cnt].opt=2;
				ans[cnt].x=1,ans[cnt].y=1;
			}
		}
		printf("%d\n",cnt);
		for(int i=1;i<=cnt;i++) {
			printf("%d %d",ans[i].opt,ans[i].x);
			if(ans[i].opt == 2) printf(" %d\n",ans[i].y);
			else putchar('\n');
		}
	}
	return 0;
}
// lixp loves My_Youth forever!!!
