#include<iostream>
#include<cstdio>
#include<algorithm>
#include<queue>
#include<unordered_map>
#include<cstring>
#include<cstdlib>
#include<stack>
using namespace std;
typedef long long ll;
ll mp[1009];
ll t,n,m,k;
ll a[2000009];
ll nz[1009][2];
stack<ll> st;
void clear(){
	memset(mp,0,sizeof(mp));
	memset(nz,0,sizeof(nz));
	while(!st.empty())st.pop();
}
void sub1(){
	clear();
	for(int i=1;i<n;i++){
		st.push(i);
		st.push(i);
	}
	for(int i=1;i<=m;i++){
		if(mp[a[i]]==0){
			mp[a[i]]=st.top();
			if(nz[st.top()][0]==0){
				nz[st.top()][0]=a[i];
			}
			else{
				nz[st.top()][1]=a[i];
			}
			st.pop();
			cout<<"1 "<<mp[a[i]]<<'\n';
		}
		else{
			st.push(mp[a[i]]);
			if(nz[mp[a[i]]][1]==a[i]){
				cout<<"1 "<<mp[a[i]]<<'\n';
				nz[mp[a[i]]][1]=0;
			}
			else{
				cout<<"1 "<<n<<'\n';
				cout<<"2 "<<n<<' '<<mp[a[i]]<<'\n';
				nz[mp[a[i]]][0]=nz[mp[a[i]]][1];
				nz[mp[a[i]]][1]=0;
			}
			mp[a[i]]=0;
		}
	}
}
ll fg[4][100];
ll stk[5][20];
ll ans[100];
ll cnt=0;
void print(){
	cout<<cnt<<'\n';
	for(int i=1;i<=m;i++){
		cout<<'1'<<' '<<ans[i]%10000<<'\n';
		if(ans[i]/10000){
			cout<<'2'<<' '<<ans[i]%10000<<' '<<ans[i]/10000<<'\n';
		}
	}
}
bool pd(){
	for(int i=1;i<=n;i++){
		if(stk[i][0]!=0)return false;
	}
	print();
	return true;
}
void wy(ll l,ll del){
	for(int i=1;i+del>=1&&i<=stk[l][0];i++){
		stk[l][i]=stk[l][i+del];
	}
	stk[l][0]-=del;
}
bool dfs(int now){
	if(now==m+1){
		return pd();
	}
	for(int i=1;i<=n;i++){
		stk[i][0]++;
		stk[i][stk[i][0]]=a[now];
		if(stk[i][0]!=1&&stk[i][stk[i][0]]==stk[i][stk[i][0]-1]){
			stk[i][0]-=2;
			cnt++;
			ans[now]=i;
			if(dfs(now+1))return true;
			cnt--;
			stk[i][0]+=2;
		}
		if(stk[i][0]==1){
			for(int j=1;j<=n;j++){
				if(j==i||stk[j][1]!=stk[i][1])continue;
				wy(i,1);wy(j,1);
				ans[now]=i+j*1e4;
				cnt+=2;
				if(dfs(now+1))return true;
				cnt-=2;
				wy(i,-1);wy(j,-1);
				stk[i][1]=a[now];
				stk[j][1]=a[now];
			}
		}
			ans[now]=i;
			cnt++;
			if(dfs(now+1))return true;
			cnt--;
			ans[now]=0;
		stk[i][stk[i][0]]=0;
		stk[i][0]--;
	}
	return false;
}
void sub2(){
	dfs(1);
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cin>>t;
	ll opt=t%1000;
	while(t--){
		cnt=0;
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++)cin>>a[i];
		if(opt==1)sub1();
		else sub2();
	}
	return 0;
}
