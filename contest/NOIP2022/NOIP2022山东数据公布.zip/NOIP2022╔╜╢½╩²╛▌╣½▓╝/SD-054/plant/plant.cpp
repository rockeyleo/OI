#include<iostream>
#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
#include<cstdlib>
using namespace std;
typedef long long ll;
const ll mod=998244353;
ll n,m;
char s[1109][1109];
ll sumh[1109][1109];
ll suml[1109][1109];
ll l[1109][1109];
ll h[1109][1109];
ll ansc,ansf;
void clear(){
	memset(s,0,sizeof(s));
	memset(sumh,0,sizeof(sumh));
	memset(suml,0,sizeof(suml));
	memset(l,0,sizeof(l));
	memset(h,0,sizeof(h));
	ansc=ansf=0;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ll t,id;
	cin>>t>>id;
	while(t--){
		clear();
		ll c,f;
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			scanf("%s",s[i]+1); 
		}
		for(int i=1;i<=n;i++){
			for(int j=m;j>=1;j--){
				if(s[i][j]=='0'){
					h[i][j]=h[i][j+1]+1;
					sumh[i][j]=h[i][j]-1;
				}
			}
		}
		for(int j=1;j<=m;j++){
			for(int i=n;i>=1;i--){
				if(s[i][j]=='0'){
					l[i][j]=l[i+1][j]+1;
					suml[i][j]=(l[i][j]-1)*sumh[i][j];
					}
			}
		}
		ll he,pt=0;
		for(ll j=1;j<=m-1;j++){
			he=0;
			pt=2;
			for(ll i=1;i<=n-2;i++){
				while(s[i][j]=='1'||s[i+1][j]=='1'||s[i+2][j]=='1'){
					i++;
					pt=i+1;
					he=0;
				}
				if(i>n-2)break;
				while(1){
					if(pt>=n||s[pt+1][j]!='0'){
						break;
					}
					pt++;
					he+=sumh[pt][j];
				}
				ansc=(ansc+he*sumh[i][j]%mod)%mod;
				he-=sumh[i+2][j];
			} 
		}
		for(ll j=1;j<=m-1;j++){
			he=0;
			pt=2;
			for(ll i=1;i<=n-3;i++){
				while(s[i][j]=='1'||s[i+1][j]=='1'||s[i+2][j]=='1'||s[i+3][j]=='1'){
					i++;
					pt=i+1;
					he=0;
				}
				if(i>n-3)break;
				while(1){
					if(pt>=n||s[pt+1][j]!='0'){
						break;
					}
					pt++;
					he+=suml[pt][j];
				}
				ansf=(ansf+he*sumh[i][j]%mod)%mod;
				he-=suml[i+2][j];
			} 
		}
		cout<<(ansc*c%mod)<<' '<<(ansf*f%mod)<<'\n'; 
	}
	return 0;
}
