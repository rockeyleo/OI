#include <bits/stdc++.h>
using namespace std;
__int128_t p = 18446744073709551615;
const int M = 50010;
int f1[M][25];
int f2[M][25];
int T,n;
void init(){
	for(int j=1;(1<<j)<=n;j++){
		for(int i=1;i+(1<<j)-1<=n;i++){
			f1[i][j] = max(f1[i][j-1],f1[i+(1<<(j-1))][j-1]);
		}
	}
	for(int j=1;(1<<j)<=n;j++){
		for(int i=1;i+(1<<j)-1<=n;i++){
			f2[i][j] = max(f2[i][j-1],f2[i+(1<<(j-1))][j-1]);
		}
	}
}

int l2g(int x){
	if(x==1)return 0;
	return(l2g(x/2)+1);
}

int query1(int x,int y){
	int len = l2g(y-x+1);
	return max(f1[x][len],f1[y-(1<<len)+1][len]);
}

int query2(int x,int y){
	int len = l2g(y-x+1);
	return max(f2[x][len],f2[y-(1<<len)+1][len]);
}

void write(__int128_t a){
	__int128_t y = 10;
	int len = 1;
	while(y<a){
		y*=10;
		len++;
	}
	while(len--){
		y/=10;
		putchar(a/y+'0');
		a %= y;
	}
}

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	p+=1;
	
	cin>>T>>n;
	for(int i=1;i<=n;i++){
		scanf("%d",&f1[i][0]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&f2[i][0]);
	}
	init();
	int Q; cin>>Q;
	while(Q--){
		__int128_t ans = 0;
		int l,r;
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				ans = ((query1(i,j)*query2(i,j))%p + ans%p)%p;
//				write(ans);cout<<endl;
//				cout<<i<<" "<<j<<" "<<(query1(i,j)*query2(i,j))<<endl;
			}
		}
		write(ans);
		printf("\n");
	}
}
