#include <bits/stdc++.h>
using namespace std;
const int M = 2000100;
deque<int>dq[300];
int cnt;
int color[M];
int n,m,k;
int vis[M];

//void dfs(int cnt,int last){
//	if(last==0){
//		return;
//	}
//	for(int i=1;i<=n;i++){
//		if(vis[i])continue;
////		if(dfs())
//	}
//}

int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T;
	cin>>T;
	while(T--){
		cin>>n>>m>>k;
		int opt = 0;
		cout<<2*n-1<<endl;
		if(n==2){
			dq[1].push_back(color[1]);
			printf("1 1\n");opt++;
			for(int i=2;i<=m;i++){
				if(dq[1].front()==color[i]){
					dq[1].pop_front();
					printf("1 1\n");
				}else if(dq[2].front()==color[i]){
					dq[2].pop_front();
					printf("1 2\n");
				}else if(dq[1].back()==color[i]){
					dq[2].push_front(color[i]);
					printf("1 2\n");
					printf("2 1 2\n");
				}else if(dq[2].back()==color[i]){
					dq[1].push_front(color[i]);
					printf("1 1\n");
					printf("2 1 2\n");
				}else{
					dq[1].push_front(color[i]);
					printf("1 1\n");
				}
			}
		}
	}
}
