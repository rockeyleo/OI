#include <bits/stdc++.h>
using namespace std;
const long long p = 1e9+7;

long long pw(int x){
	long long ans = 1;
	for(int i=1;i<=x;i++){
		ans = (ans%p*2%p)%p;
	}
	return ans;
}

int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		int f,t;
		scanf("%d%d",&f,&t);
	}
	long long ans = 0;
	ans = (n%p+ans%p)%p;
	for(int i=1;i<=n;i++){
		ans += (pw(i+1)+ans%p)%p;
	}
	cout<<ans/2<<endl;
}
