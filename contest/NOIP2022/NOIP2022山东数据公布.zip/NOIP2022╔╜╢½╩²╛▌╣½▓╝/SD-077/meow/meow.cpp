#include<bits/stdc++.h>
using namespace std;
#define ll long long
int bk[1000001],a[100001],t,n,m,k,xl[100007],gk[10007],js;
deque<int>q[3];
bool chck(int lim) {
    while(!q[1].empty()) q[1].pop_back();
    while(!q[0].empty()) q[0].pop_back();
    while(!q[2].empty()) q[2].pop_back();
    int top = 1;
    for(int i = 1;i <= lim;++ i) {
        if(bk[i] == 0) {
            if(q[xl[i]].empty()) {
                q[xl[i]].push_front(a[top]);
                top++;
                continue;
            }
            int gh = q[xl[i]].front();
            if(gh == a[top]) {
                q[xl[i]].pop_front();
                top++;
                continue;
            }
            q[xl[i]].push_front(a[top]);
            top++;
        }
        else {
            if(q[xl[i]].size()==0||q[gk[i]].size()==0) continue;
            int gh = q[xl[i]].back(),hc = q[gk[i]].back();
            if(gh==hc) {
                q[xl[i]].pop_back();
                q[gk[i]].pop_back();
            }
        }
    }
    return (top==m+1&&q[0].size()==0&&q[1].size()==0&&q[2].size()==0);
}
int LIM;
void dfs(int k) {
    if(k >= LIM) return ;
    if(k >= m+1) {
        if(chck(k-1)) {
            cout<<k-1<<'\n';
            for(int i = 1;i < k;++ i) {
                if(bk[i]==0) cout<<1<<' '<<xl[i]+1<<'\n';
                else cout<<2<<' '<<xl[i]+1<<' '<<gk[i]+1<<'\n';
            }
            exit(0);
        }
    }
    for(int i = 0;i <= 1;++ i) {
        bk[k] = i;
        if(i == 0) {
            for(int j = 0;j <= 2;++ j) {
                xl[k] = j;
                dfs(k+1);
            }
        }
        else {
            for(int j = 0;j < 3;++ j) {
                for(int o = j+1;o < 3;++ o) {
                    xl[k] = j; gk[k] = o;
                    dfs(k+1);
                }
            }
        }
    }
}
int main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
//	ios::sync_with_stdio(0);
//	cin.tie(0); cout.tie(0);
	cin>>t;
	while(t--) {
	    cin>>n>>m>>k;
	    for(int i = 1;i <= m;++ i) cin>>a[i];
	    for(LIM = m;;LIM++) {
	        dfs(1);
        }
    }
	return 0;
}
