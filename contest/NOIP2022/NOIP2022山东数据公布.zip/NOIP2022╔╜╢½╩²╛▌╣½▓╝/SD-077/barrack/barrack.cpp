#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m;
const int mod = 1e9+7;
struct op{
    int frm,to,nxt;
}e[10001],h[1001];
int head[100001],num;
void add(int frm,int to) {
    e[++num] = op{frm,to,head[frm]};
    head[frm] = num;
}
int f[101][101],all;
int bk[1000007],ans,rs[100001];
bool vis[101];
bool chck(int x,int y) {
    if(x==y) return 1;
    for(int i = head[x];i;i = e[i].nxt) {
        int v = e[i].to;
        if(f[x][v]==0||vis[v]) continue;
        vis[v] = 1;
        if(chck(v,y)) {
            vis[v] = 0;
            return 1;
        }
        vis[v] = 0;
    }
    return 0;
}
int kl[101][101],fg[101][101];
void DFS(int x) {
    if(x == all+1) {
        int top = 0;
        memset(f,-1,sizeof f);
        for(int i = 1;i <= all;++ i) f[h[i].frm][h[i].to] = f[h[i].to][h[i].frm] = rs[i];
        for(int i = 1;i <= all;++ i) {
            if(!rs[i]) {
                if(bk[h[i].frm]==0||bk[h[i].to]==0) continue;
                if(chck(h[i].frm,h[i].to)==0&&chck(h[i].to,h[i].frm)==0) return ;
            }
        }
        ans++;
        return ;
    }
    for(int i = 0;i <= 1;++ i) {
        rs[x] = i;
        DFS(x+1);
    }
}
void dfs(int k) {
    if(k == n+1) {
        int bj = 0;
        for(int i = 1;i <= n;++ i) if(bk[i]) bj = 1;
        if(!bj) return ;
        DFS(1);
        return ;
    }
    for(int i = 0;i <= 1;++ i) {
        bk[k] = i;
        dfs(k+1);
    }
}
/*
4 4
1 2
2 3
3 1
1 4
*/
int main() {

	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
//	ios::sync_with_stdio(0);
//	cin.tie(0); cout.tie(0);
	cin>>n>>m;
	for(int i = 1;i <= m;++ i) {
	    int u,v;
	    cin>>u>>v;
	    add(u,v);
	    add(v,u);
	    fg[v][u] = fg[u][v] = 1;
	    h[++all] = {u,v};
    }
    dfs(1);
    cout<<ans;
	return 0;
}



