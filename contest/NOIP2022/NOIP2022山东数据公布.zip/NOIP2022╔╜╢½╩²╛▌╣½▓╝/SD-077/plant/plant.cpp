#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 998244353;
int read() {
    int x = 0,f = 1; char c = getchar();
    while(c < '0'||c > '9') {if(c=='-') f=-1; c = getchar();}
    while(c >= '0'&&c <= '9') {x = (x<<3)+(x<<1)+(c^48); c = getchar();}
    return x*f;
}
char s[1017][1017];
int T,id,C,F,n,m,c,f,xl[1117],gh[1117];
int gtc() {
    c = 0;
    for(int j = 1;j <= m;++ j) {
        int js = 0;
        for(int o = 1;o <= n;++ o) {
            if(s[o][j]=='0') js++;
            else {
                int top = 0; 
                if(js>=3) {
                    for(int i = o-js;i < o;++ i) {
                        int k = j;
                        while(s[i][k]=='0'&&k<=m) k++; k--;
                        xl[++top] = max(k-j,0ll);
                    }
                    gh[top+1] = 0;
                    gh[top+2] = 0;
                    for(int k = top;k >= 3;-- k) gh[k] = (gh[k+1]+xl[k])%mod;
                    for(int i = 1;i <= top;++ i) c = (c+(xl[i]*gh[i+2])%mod)%mod;
                }
                js = 0;
            }
        }
        int top = 0; 
        if(js>=3) {
            for(int i = n-js+1;i <= n;++ i) {
                int k = j;
                while(s[i][k]=='0'&&k<=m) k++; k--;
                xl[++top] = max(k-j,0ll);
            }
            gh[top+1] = 0;
            gh[top+2] = 0;
            for(int k = top;k >= 3;-- k) gh[k] = (gh[k+1]+xl[k])%mod;
            for(int i = 1;i <= top;++ i) c = (c+(xl[i]*gh[i+2])%mod)%mod;
        }
        js = 0;
    }
    return c;
}
int gtf() {
    f = 0;
    for(int j = 1;j <= m;++ j) {
        int js = 0;
        for(int o = 1;o <= n;++ o) {
            if(s[o][j]=='0') js++;
            else {
                int top = 0; 
                if(js>=4) {
                    for(int i = o-js;i < o;++ i) {
                        int k = j;
                        while(s[i][k]=='0'&&k<=m) k++; k--;
                        xl[++top] = max(k-j,0ll);
                    }
                    int res = 0;
                    gh[top] = 0;
                    gh[top+1] = 0;
                    gh[top+2] = 0;
                    for(int k = top-1;k >= 3;-- k) gh[k] = (gh[k+1]+xl[k])%mod;
                    for(int i = 1;i <= top;++ i) res = (res+(xl[i]*gh[i+2])%mod)%mod;
                    f = (f+(res*(js-3))%mod)%mod;
                }
                js = 0;
            }
        }
        int top = 0; 
        if(js>=4) {
            for(int i = n-js+1;i <= n;++ i) {
                int k = j;
                while(s[i][k]=='0'&&k<=m) k++; k--;
                xl[++top] = max(k-j,0ll);
            }
            int res = 0;
            gh[top] = 0;
            gh[top+1] = 0;
            gh[top+2] = 0;
            for(int k = top-1;k >= 3;-- k) gh[k] = (gh[k+1]+xl[k])%mod;
            for(int i = 1;i <= top;++ i) res = (res+(xl[i]*gh[i+2])%mod)%mod;
            f = (f+(res*(js-3))%mod)%mod;
        }
        js = 0;
    }
    return f;
}
signed main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
    cin>>T>>id;
    while(T--) {
        n=read(),m=read(),C=read(),F=read();
        for(int i = 1;i <= n;++ i) scanf("%s",s[i]+1);
        cout<<(gtc()*C)%mod<<' '<<(gtf()*F)%mod<<'\n';
    }
	return 0;
}

