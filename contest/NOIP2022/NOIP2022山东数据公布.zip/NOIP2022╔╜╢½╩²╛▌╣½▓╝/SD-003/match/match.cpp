#include<bits/stdc++.h>
using namespace std;
int T,n,Q,a[250005],b[250005],l,r;
long long ans,mod=(1<<30);
int max1(int L,int R){
	int sum=0;
	for(int i=L;i<=R;i++){
		sum=max(sum,a[i]);
	}
	return sum;
}
int max2(int L,int R){
	int sum=0;
	for(int i=L;i<=R;i++){
		sum=max(sum,b[i]);
	}
	return sum;
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	long long p=mod*mod*2*2;
	//cout<<"mod "<<4*p<<endl;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	cin>>Q;
	for(int i=1;i<=Q;i++){
		cin>>l>>r;
		ans=0;
		for(int j=l;j<=r;j++){
			for(int k=j;k<=r;k++){
				int m1=max1(j,k);
				int m2=max2(j,k);
				ans+=m1*m2;
				ans%p;
			}
		}
		cout<<ans%p<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
