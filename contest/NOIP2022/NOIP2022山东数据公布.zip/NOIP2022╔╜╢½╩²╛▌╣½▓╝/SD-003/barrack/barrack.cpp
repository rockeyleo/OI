#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("","r",stdin);
	freopen("","w",stdout);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
