#include<bits/stdc++.h>
using namespace std;
int T,id,n,m,c,f;
char a[1000][1000];
string s;
int pd(int l,int r){
	//int sum=1;
	for(int i=l;i<=r;i++){
		if(a[i][1]=='1'){
			return 0;
		}
	}
	return 1;
}
int make(int p){
	int ans=0;
	for(int i=1;i<=n;i++){
		if(a[i][2]=='1') continue;
		for(int j=i+2;j<=n;j++){
			if(a[j][2]=='1') continue;
			if(!p&&pd(i,j)) ans++;
			else if(p&&pd(i,j)){
				for(int k=j+1;k<=n;k++){
					if(a[k][1]=='1') break;
					else ans++;
				}
			}
		}	
	}
	return ans;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	for(int i=1;i<=T;i++){
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			cin>>s;
			for(int j=1;j<=m;j++){
				a[i][j]=s[j-1];
			}
		}
		if(c==0&&f==0){
			cout<<0<<" "<<0<<endl;
			continue;
		}
		cout<<c*make(0)%998244353<<" ";
		cout<<c*make(1)%998244353<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
