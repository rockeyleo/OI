// QZP NOIP 2022 rp++!!!!!!!!!!!!!!!!!!
#include<bits/stdc++.h>
//#define int long long 
#define ll long long 
const int N = 2e5+5;
const int M = 505;
const int INF = 0x3f3f3f3;
const int Mod = 1e9+7;
using namespace std;

inline ll read()
{
	ll s=0;
	bool f = true;
	char ch = getchar();
	while(ch<'0' || ch>'9')
	{
		if(ch=='-') f=false;
		ch = getchar();
 	}
 	while(ch>='0' && ch<='9')
 	{
 		s = s * 10 + ch - '0';
 		ch = getchar();
	}
	return f?s:~s+1;
}
 
int n,m,Ans;
 struct node{
 	int v,next;
 }edge[N];int head[N],cnt;
 
 inline void add(int u,int v)
 {
 	edge[++cnt] = node{v,head[u]};
 	head[u] = cnt;
 }
 
 
signed main() 
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(time(NULL));
	n=read();m=read();
	
	for(int i=1;i<=m;i++)
	{
		int u=read() , v=read();
		add(u,v);add(v,u);
	}
	
	cout << rand() * rand() % Mod;
	return 0;
}
