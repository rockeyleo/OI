// QZP NOIP 2022 rp++!!!!!!!!!!!!!!!!!!
#include<bits/stdc++.h>
#define ll unsigned long long 
#define int long long 
const int N = 2e5+5;
const int M = 505;
const int INF = 0x3f3f3f3;
const int Mod = 1e9;
using namespace std;

inline ll read()
{
	ll s=0;
	bool f = true;
	char ch = getchar();
	while(ch<'0' || ch>'9')
	{
		if(ch=='-') f=false;
		ch = getchar();
 	}
 	while(ch>='0' && ch<='9')
 	{
 		s = s * 10 + ch - '0'; 
 		ch = getchar();
	}
	return f?s:~s+1;
}

int n,m,T;
ll Ans ;
int f[N][20],g[N][20];
int S[3060][3060];

inline int query(int l,int r)
{
	int k = log2(r - l + 1);
	return max(f[l][k] , f[r-(1<<k)+1][k]);
}


inline int query1(int l,int r)
{
	int k = log2(r - l + 1);
	return max(g[l][k] , g[r-(1<<k)+1][k]);
}

inline int AK(int l,int r)
{
	Ans =  0;
	for(int i=l;i<=r;i++)
	{
		for(int j=i;j<=r;j++)
		{
			Ans = (Ans + (query(i,j) * query1(i,j) ) % Mod) % Mod;
//			cout << Ans << '\n';
		}
	}
	S[l][r] = Ans;
	return Ans;
}

signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();n=read();
	for(int i=1;i<=n;i++) f[i][0]=read();
	for(int i=1;i<=n;i++) g[i][0]=read();
	int k = log2(n);
	for(int j=1;j<=k;j++)
	{
		for(int i=1;i+(1<<(j-1))-1<=n;i++)
		{
			f[i][j] = max(f[i][j-1] , f[i+(1<<(j-1))][j-1]);
			g[i][j] = max(g[i][j-1] , g[i+(1<<(j-1))][j-1]);
		}
	}
	m=read();
	for(int i=1;i<=m;i++)
	{
		int l=read() , r=read();
		if(l > r) swap(l,r);
		if(S[l][r]!=0) cout << S[l][r] << "\n";
		else cout << AK(l,r) << "\n";
	}
	return 0;
}

/*
0 2
2 1
1 2
1
1 2
*/
