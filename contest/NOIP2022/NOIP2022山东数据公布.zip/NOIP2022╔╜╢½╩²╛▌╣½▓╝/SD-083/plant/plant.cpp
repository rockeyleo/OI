// QZP NOIP 2022 rp++!!!!!!!!!!!!!!!!!!
#include<bits/stdc++.h>
//#define int long long 
#define ll long long 
const int N = 2e5+5;
const int M = 505;
const int INF = 0x3f3f3f3;
const int Mod = 998244353; 
using namespace std;

inline ll read()
{
	ll s=0;
	bool f = true;
	char ch = getchar();
	while(ch<'0' || ch>'9')
	{
		if(ch=='-') f=false;
		ch = getchar();
 	}
 	while(ch>='0' && ch<='9')
 	{
 		s = s * 10 + ch - '0';
 		ch = getchar();
	}
	return f?s:~s+1;
}
 
int n,m,Ans,id,k,c,f;
 
signed main() 
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	srand(time(NULL));
	int T=read();id=read();
	while(T--)
	{
		n=read();m=read();c=read();f=read();
		if(c==0 && f==0)
		{
			cout << 0 << " " << 0<< "\n";
			continue;
		}
		else if (f == 0) cout << rand() % Mod << " " << 0 << "\n";
		else cout<< rand() % Mod << " " << rand() % Mod<< "\n";
	}
	return 0;
}
