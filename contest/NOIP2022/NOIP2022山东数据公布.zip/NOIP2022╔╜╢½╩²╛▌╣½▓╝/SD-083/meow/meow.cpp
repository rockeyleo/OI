// QZP NOIP 2022 rp++!!!!!!!!!!!!!!!!!!
#include<bits/stdc++.h>
//#define int long long 
#define ll long long 
const int N = 2e5+5;
const int M = 505;
const int INF = 0x3f3f3f3;
using namespace std;

inline ll read()
{
	ll s=0;
	bool f = true;
	char ch = getchar();
	while(ch<'0' || ch>'9')
	{
		if(ch=='-') f=false;
		ch = getchar();
 	}
 	while(ch>='0' && ch<='9')
 	{
 		s = s * 10 + ch - '0';
 		ch = getchar();
	}
	return f?s:~s+1;
}
 
int n,m,Ans,k,cnt;
int val[N];
deque<int>q[5];
deque<int>g[5];
//int r[M][M];
int check[N];

inline void init()
{
	for(int i=1;i<=n;i++)
	{
		while(!g[i].empty()) g[i].pop_back(); 
		int y = q[i].size();
		for(int j=1;j<=y;j++)
		{
			g[i].push_back(q[i].front());
			q[i].push_back(q[i].front());q[i].pop_front(); 
		}
	}
}
int op;
inline bool ask()
{	 
//	op = 0 ;
//	int sum = 0 ,l = 0;
//	for(int i=1;i<=n;i++)
//	{
//		if(!g[i].size()) continue;
//		int y =  g[i].size();
//		int Last = g[i].front(); 
//		g[i].pop_front();
//		for(int j=2;j<=y;j++)
//		{
//			int u = g[i].front();
//			if(u == Last) g[i].pop_front() , Last = g[i].front() , op++;
//			else
//			{ 
//				Last = u;
//				g[i].push_back(Last);
//				g[i].push_back(q[i].front());
//				g[i].pop_front();
//			}
// 		}
//	}
////	cout << q[1].size() << " " << q[2].size() << "\n";
//	int cnt = 0 ;
//	for(int i=1;i<=n;i++) 
//	{
//		cnt += g[i].size();
//	}
//	if(cnt ==0 ) exit(0);
//	cout << cnt << endl;
	for(int i=1;i<=n;i++)
	{
		if(!g[i].size()) continue;
		for(int j=i+1;j<=n;j++)
		{
			if(!g[i].size()) continue;
			while(g[i].front() == g[j].front() && g[i].size() && g[i].size()) 
			{
				g[i].pop_front();g[j].pop_front();
				op++;
//				cout << 2 << " " << i << " " << j << "\n"; 
			}
		} 
	}
	int sum = 0;
	for(int i=1;i<=n;i++)
	{
		sum += g[i].size();
		if(sum)return false;
	}
//	cout << "AK" << "\n";
	return true;
}
inline void AK()
{ 
	cout <<op + m - 1 <<"\n";
	for(int i=1;i<=m;i++) cout << 1 << " " << check[i] << "\n";
//	cout << "\n"; 
//	int sum = 0 ,l = 0;
//	for(int i=1;i<=n;i++)
//	{
//		if(!q[i].size()) continue;
//		int y =  q[i].size();
//		int Last = q[i].front(); 
//		q[i].pop_front();
//		for(int j=2;j<=y;j++)
//		{
//			int u = q[i].front();
//			if(u == Last) q[i].pop_front() , Last = q[i].front()  ;
//			else
//			{ 
//				Last = u;
//				q[i].push_back(Last);
//				q[i].push_back(q[i].front());
//				q[i].pop_front();
//			}
// 		}
//	}
////	cout << q[1].size() << " " << q[2].size() << "\n";
//	int cnt = 0 ;
//	for(int i=1;i<=n;i++) 
//	{
//		cnt += q[i].size();
//	}
//	if(cnt ==0 ) exit(0);
//	cout << cnt << endl;
	for(int i=1;i<=n;i++)
	{
		if(!q[i].size()) continue;
		for(int j=i+1;j<=n;j++)
		{
			if(!q[i].size()) continue;
			while(q[i].front() == q[j].front() && q[i].size() && q[i].size()) 
			{
				q[i].pop_front();q[j].pop_front();
				cout << 2 << " " << i << " " << j << "\n"; 
			}
		} 
	}
	exit(0);
}

void dfs(int now,int cnt)
{
	if(now == m+1)
	{
		init();
		if(ask()) AK();
//		exit(0);
		return  ;
	}
	for(int j=now;j<=m;j++)
	{
		for(int i=1;i<=n;i++)
		{
			check[cnt+1] = i;
			q[i].push_back(val[j]);
			dfs(now+1,cnt+1);
			q[i].pop_back(); 
		}
	} 
}
 
signed main() 
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);	
	int T=read();
	while(T--)
	{
		n=read();m=read();k=read();
		for(int i=1;i<=m;i++) val[i]=read();
		dfs(1,0);
	} 
	return 0;
}
/*
1
2 4 2
1 2 1 2
*/
