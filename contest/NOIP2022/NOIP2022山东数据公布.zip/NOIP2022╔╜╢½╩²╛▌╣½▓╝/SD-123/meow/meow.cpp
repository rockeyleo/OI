#include<bits/stdc++.h>
using namespace std;
int T;
int n,m,k,tot,a[1000001],a1[1000001],a2[1000001];
struct node{
	long long num,s1,s2;
}ans[1000001];
void solve2()
{
	long long tail=1,head=0,tail1=1,head1=0;
	for(int i=1;i<=m;i++)
	{
		if(a[i]==a1[head]){
			ans[++tot].num=1;
			ans[tot].s1=1;
			head--;
		}
		else if(a[i]==a2[head]){
			ans[++tot].num=1;
			ans[tot].s1=2;
			head1--;
		}
		else if(a[i+1]==a1[head]){
			a2[++head1]=a[i];
			ans[++tot].num=1;
			ans[tot].s1=2;
		}
		else if(a[i]!=a1[tail]){
			a1[++head]=a[i];
			ans[++tot].num=1;
			ans[tot].s1=1;
		}
		else{
			ans[++tot].num=1;
			ans[tot].s1=2;
			ans[++tot].num=2;
			ans[tot].s1=1;
			ans[tot].s2=2;
			tail++;
		}
	}
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>T;
	for(int q=1;q<=T;q++){
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++){
			cin>>a[i];
		}
		if(n==2)solve2();
		cout<<tot<<endl;
		for(int i=1;i<=tot;i++){
			if(ans[i].num==1)cout<<ans[i].num<<" "<<ans[i].s1<<endl;
			else cout<<ans[i].num<<" "<<ans[i].s1<<" "<<ans[i].s2<<endl;
		}
		a1[1]=0;
		tot=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
