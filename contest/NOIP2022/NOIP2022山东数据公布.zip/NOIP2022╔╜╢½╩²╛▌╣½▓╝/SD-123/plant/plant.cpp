#include<bits/stdc++.h>
using namespace std;
int T,id;
long long n,m,c,vc,vf,f,mo=998244353;
char a[1001][1001];
int read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
void solvec()
{
	for(int x1=1;x1<=n;x1++){
		for(int x2=x1+2;x2<=n;x2++){
			for(int y0=1;y0<=m;y0++){
				int pd=1;
				for(int x=x1;x<=x2;x++){
					if(a[x][y0]=='1'){
						pd=0;
						break;
					}
				}
				if(pd){
					for(int y1=y0+1;y1<=m;y1++)
					{
						pd=1;
						for(int y=y0;y<=y1;y++){
							if(a[x1][y]=='1'){
								pd=0;break;
							}
						}
						if(pd){
							for(int y2=y0+1;y2<=m;y2++){
								pd=1;
								for(int y=y0;y<=y2;y++){
									if(a[x2][y]=='1'){
										pd=0;
										break;
									}
								}
								if(pd)vc=(vc+1)%mo;
								else break;
							}
						}
						else break;
					}
				}
			}
		}
	}
}
void solvef()
{
	for(int x1=1;x1<=n;x1++){
		for(int x2=x1+2;x2<=n;x2++){
			for(int x3=x2+1;x3<=n;x3++){
				for(int y0=1;y0<=m;y0++){
					int pd=1;
					for(int x=x1;x<=x3;x++){
						if(a[x][y0]=='1'){
							pd=0;
							break;
						}
					}
					if(pd){
						for(int y1=y0+1;y1<=m;y1++){
							pd=1;
							for(int y=y0;y<=y1;y++){
								if(a[x1][y]=='1'){
									pd=0;
									break;
								}
							}
							if(pd){
								for(int y2=y0+1;y2<=m;y2++)
								{
									pd=1;
									for(int y=y0;y<=y2;y++){
										if(a[x2][y]=='1'){
											pd=0;
											break;
										}
									}
									if(pd)vf=(vf+1)%mo;
									else break;
								}
							}
							else break;
						}
					}
				}
			}
		}
	}
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read();id=read();
	for(int q=1;q<=T;q++){
		n=read();m=read();c=read();f=read();
		vc=0;vf=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++)cin>>a[i][j];
		}
		if(c==0)cout<<"0 ";
		if(c==1)solvec();
		if(c==1){
			vc=vc*c%mo;
			cout<<vc<<" ";
		}
		if(f==0)cout<<"0"<<endl;
		if(f==1)solvef();
		if(f==1){
			vf=vf*f%mo;
			cout<<vf<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
