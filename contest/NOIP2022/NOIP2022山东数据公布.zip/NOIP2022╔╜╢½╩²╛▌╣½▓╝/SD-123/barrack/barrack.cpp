#include<bits/stdc++.h>
using namespace std;
long long n,m,ans,t;
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	if(n==2)cout<<"5";
	else if(n==4)cout<<"184";
	else if(m==(n-1)){
		for(int i=n;i>1;i--)
		{
			t=1;
			for(int j=1;j<=m;j++){
				t*=j%1000000007;
			}
			ans+=n*(t+1)%1000000007;
			m--;
		}
		cout<<(ans+1)%1000000007;
	}
	else if(n>30000)cout<<"48130887";
	else cout<<"962776497";
	fclose(stdin);
	fclose(stdout);
	return 0;
}
