#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#define ll long long
#define ull unsigned long long
#define N 250005
#define lson p<<1
#define rson p<<1|1

using namespace std;

int T,type,n,a[N],b[N];
int L1[N],R1[N],L2[N],R2[N];
ull ans,su[3003][3003];
struct tree {int l,r,maxn,pos;} t[N*4][3]; 

void build(int p,int k,int l,int r){
	t[p][k].l = l; t[p][k].r = r;
	if(l == r) {
		if(k == 1) t[p][k].maxn = a[l], t[p][k].pos = l;
		if(k == 2) t[p][k].maxn = b[l], t[p][k].pos = l;
		return ;
	}
	int mid = (l+r) >> 1;
	build(lson,k,l,mid);
	build(rson,k,mid+1,r);
	t[p][k].maxn = max(t[lson][k].maxn, t[rson][k].maxn);
	if(t[lson][k].maxn > t[rson][k].maxn)
		t[p][k].pos = t[lson][k].pos;
	else
		t[p][k].pos = t[rson][k].pos;
}

int query(int p,int k,int l,int r){
	if(l <= t[p][k].l && t[p][k].r <= r) return t[p][k].pos;
	int mid = (t[p][k].l + t[p][k].r) >> 1;
	int p1 = 0, p2 = 0;
	if(l <= mid) p1 = query(lson,k,l,r);
	if(r > mid) p2 = query(rson,k,l,r);
	if(k == 1)
	{
		if(a[p1] > a[p2]) return p1;
		else return p2;
	}
	if(k == 2)
	{
		if(b[p1] > b[p2]) return p1;
		else return p2;
	}
}

void divide1(int l,int r){
	if(l > r) return ;
	int maxd = query(1,1,l,r);
	L1[maxd] = l; R1[maxd] = r;
	divide1(l,maxd-1);
	divide1(maxd+1,r);
}

void divide2(int l,int r){
	if(l > r) return ;
	int maxd = query(1,2,l,r);
	L2[maxd] = l; R2[maxd] = r;
	divide2(l,maxd-1);
	divide2(maxd+1,r);
}

void calc(int x,int y)
{
	int tot = 0;
	
	for(int i=x; i<=y; ++i)
	{
		ull sum = 0;
	
		divide2(L1[i],R1[i]);
		
		for(int j=L1[i]; j<=R1[i]; ++j)
		{
			++tot;
			if(L2[j] > i || R2[j] < i) continue;
			ull lleft = min(j-L2[j], i-L2[j]) + 1;
			ull rright = min(R2[j]-j, R2[j]-i) + 1;
			sum += lleft * rright * b[j];
		}
		
		ans += sum * a[i];
	}
	cout<<tot<<endl;
}

int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d%d",&type,&n);
	
	for(int i=1; i<=n; ++i) scanf("%d",&a[i]);
	for(int i=1; i<=n; ++i) scanf("%d",&b[i]);
	
	if(n <= 3000 && T <= 3000)
	{
		for(int i=1; i<=n; ++i)
		{
			int maxa = 0, maxb = 0;
			for(int j=i; j<=n; ++j)
			{
				maxa = max(maxa, a[j]);
				maxb = max(maxb, b[j]);
				su[i][j] = su[i][j-1] + maxa * maxb;
			}
		}
		
		scanf("%d",&T);
		while(T--)
		{
			int l,r;
			scanf("%d%d",&l,&r);
			ans = 0;
			for(int i=l; i<=r; ++i)
				ans += su[i][r];
			cout<<ans<<endl; 
		}
		return 0;
	}
	
	build(1,1,1,n);
	build(1,2,1,n);
	
	scanf("%d",&T);
	
	while(T--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		
		ans = 0;
		
		divide1(x,y);
		
		calc(x,y);
		
		cout<<ans<<endl;
	}
	
	return 0;
}
