#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#define ll long long
#define ull unsigned long long
#define mod 998244353
#define N 1004

using namespace std;

int T,id,n,m,C,F;
ll s[N][N],has[N][N],had[N][N],ans1,ans2;
char c[N][N];

int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout); 
	
	ios::sync_with_stdio(0);
	
	cin>>T>>id; 
	
	while(T--)
	{
		cin>>n>>m>>C>>F;
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=m; ++j)
				cin>>c[i][j];
		
		if(C == 0 && F == 0) { cout<<"0 0"<<endl; continue; }
		
		memset(has,0,sizeof(has));
		memset(had,0,sizeof(had));
		for(int i=m; i>=1; --i)
			for(int j=1; j<=n; ++j)
				if(c[j][i+1] == '0' && c[j][i] == '0')
					has[j][i] = has[j][i+1] + 1;
		
		for(int i=n; i>=1; --i)
			for(int j=1; j<=m; ++j)
				if(c[i+1][j] == '0' && c[i][j] == '0')
					had[i][j] = had[i+1][j] + 1;
		
		memset(s,0,sizeof(s));
		for(int i=n; i>=1; --i)
			for(int j=1; j<=m; ++j)
				if(c[i][j] == '0')
					s[i][j] = (has[i][j] + s[i+1][j]) % mod;
					
		ans1 = ans2 = 0;
		
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=m; ++j)
			{
				if(c[i][j] == '1' || c[i+1][j] == '1') continue;
				ans1 = (ans1 + has[i][j] * s[i+2][j]) % mod;
			}
		// C end
		
		memset(s,0,sizeof(s));
		
		for(int i=n; i>=1; --i)
			for(int j=1; j<=m; ++j)
				if(c[i][j] == '0')
					s[i][j] = (has[i][j]*had[i][j]%mod + s[i+1][j]) % mod;
		
		for(int i=1; i<=n; ++i)
			for(int j=1; j<=m; ++j)
			{
				if(c[i][j] == '1' || c[i+1][j] == '1') continue; 
				ans2 = (ans2 + has[i][j] * s[i+2][j]) % mod;
			}
		
		// F end
		
		cout<<ans1*C<<" "<<ans2*F<<endl;
	}
	
	return 0;
}

// %%% do_while_true 
