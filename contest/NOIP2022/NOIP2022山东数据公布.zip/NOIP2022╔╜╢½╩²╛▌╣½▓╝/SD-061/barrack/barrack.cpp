#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#define ll long long
#define ull unsigned long long
#define N 30

using namespace std;

int n,m,ans,out;
vector<pair<int,int> > g[N];
bool vis[N],in[N];

void dfs(int u)
{
	vis[u] = 1;
	for(auto e:g[u])
	{
		if( (in[e.second] || out != e.second) && !vis[e.first] )
			dfs(e.first);
	}
}

int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1; i<=m; ++i)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back({y,i});
		g[y].push_back({x,i});
	}
	
	int tot1 = (1<<n)-1, tot2 = (1<<m)-1;
	
	for(int i=1; i<=tot1; ++i)
	{
		for(int j=0; j<=tot2; ++j)
		{
			memset(in,0,sizeof(in));
			for(int k=1; k<=m; ++k)
				if((1<<(k-1)) & j) in[k] = 1;
			bool flag = 1;
			
			for(int k=1; k<=m; ++k)
			{
				memset(vis,0,sizeof(vis));
				out = k;
				for(int l=1; l<=n; ++l)
					if((1<<(l-1)) & i)
					{
						dfs(l);
						break; 
					}
				for(int l=1; l<=n; ++l)
					if( ((1<<(l-1))&i) && !vis[l])
						flag = 0;
			}
			
			if(flag) ++ans;
		}
	} 
	
	cout<<ans;
	
	return 0;
}
