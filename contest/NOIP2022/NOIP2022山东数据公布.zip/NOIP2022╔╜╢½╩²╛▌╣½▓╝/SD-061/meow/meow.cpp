#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#include<deque>
#define ll long long
#define ull unsigned long long
#define N 2000010

using namespace std;

int T,n,m,k,a[N],sum;
deque<int> st[305];

void sub_1(){
	sum = 0;
	for(int i=1; i<=m; ++i)
	{
		int tag = (a[i] + 1) / 2;
		if(st[tag].size() == 0)
		{
			st[tag].push_back(a[i]);
			++sum;
		}
		else
		{
			if(st[tag].front() == a[i])
			{
				st[tag].pop_front();
				sum += 2;
			}
			else 
			{
				if(st[tag].back() == a[i])
				{
					st[tag].pop_back();
					++sum;
				}
				else
				{
					st[tag].push_back(a[i]);
					++sum;
				}
			}
		}
	}
	
	printf("%d\n",sum);
	for(int i=1; i<=m; ++i)
	{
		int tag = (a[i] + 1) / 2;
		if(st[tag].size() == 0)
		{
			st[tag].push_back(a[i]);
			printf("1 %d\n",tag);
		}
		else
		{
			if(st[tag].front() == a[i])
			{
				st[tag].pop_front();
				printf("1 %d\n",n);
				printf("2 %d %d\n",tag,n);
			}
			else 
			{
				if(st[tag].back() == a[i])
				{
					st[tag].pop_back();
					printf("1 %d\n",tag);
				}
				else
				{
					st[tag].push_back(a[i]);
					printf("1 %d\n",tag);
				}
			}
		}
	}
}

int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	scanf("%d",&T);
	
	while(T--)
	{
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1; i<=m; ++i) scanf("%d",&a[i]);
		if(k == 2*n-2) {sub_1(); continue;}
	}
	
	return 0;
}

