#include<bits/stdc++.h>

#define int long long
#define PIII pair<int, pair<int, int> >
#define PII pair<int, int >
#define x first
#define y second
#define mod 1000000007

using namespace std;

const int inf = 2147483647;

int n, m;

signed main()
{
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	cin >> n >> m;
	if(m == n) cout << (n + 1) * (m + 1) % mod;
	else cout << ((n * n) % mod - 1 + mod) % mod;
	
	return 0;
}

