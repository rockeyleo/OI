#include<bits/stdc++.h>

#define maxn 1005
#define PII pair<int, int >
#define x first
#define y second

using namespace std;

int T, n, m, k;
int stk[maxn], hh = 1, tt = 1;
int path[maxn];

int main()
{
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	cin >> T;
	while(T -- )
	{
		int res = 0;
		scanf("%d%d%d", &n, &m, &k);
		int card;
		while(m -- )
		{
			scanf("%d", &card);
			if(card == stk[hh]) path[res ++ ] = 1, stk[hh -- ];
			else if(card == stk[tt]) 
				path[res ++ ] = 2, path[res ++ ] = 3, stk[tt ++ ];
			else path[res ++ ] = 1, stk[hh ++ ] = 1;
		}
		printf("%d\n", res);
		for(int i = 0; i < res ; i ++ )
			if(path[i] == 1) printf("1 1\n");
			else if(path[i] == 2) printf("1 2\n");
			else printf("2 1 2\n");
	}
	return 0;
}

