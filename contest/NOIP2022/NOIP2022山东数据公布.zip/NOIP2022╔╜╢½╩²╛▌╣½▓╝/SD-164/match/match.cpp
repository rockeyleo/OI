#include<bits/stdc++.h>

#define maxn 3005
#define ll long long
#define PIII pair<int, pair<int, int> >
#define PII pair<int, int >
#define x first
#define y second

using namespace std;

int id, T, n;
ll a[maxn], b[maxn];

signed main()
{
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	cin >> id >> n;
	for(int i = 1; i <= n; i ++ ) cin >> a[i];
	for(int i = 1; i <= n; i ++ ) cin >> b[i];
	cin >> T;
	while(T -- )
	{
		ll res = 0;
		int l, r;
		scanf("%d%d", &l, &r);
		for(int p = l; p <= r; p ++ )
			for(int q = p; q <= r; q ++ )
			{
				ll maxa = 0, maxb = 0;
				for(int i = p; i <= q; i ++ )
				{
					maxa = max(maxa, a[i]);
					maxb = max(maxb, b[i]);
				}
				res = res + maxa * maxb;
			}
		printf("%lld\n", res);
	}
	return 0;
}

