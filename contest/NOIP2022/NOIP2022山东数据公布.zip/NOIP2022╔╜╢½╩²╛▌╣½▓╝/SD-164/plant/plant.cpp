#include<bits/stdc++.h>

#define PIII pair<int, pair<int, int> >
#define PII pair<int, int >
#define x first
#define y second
#define mod 998244353
#define maxn 1005
#define int long long

using namespace std;

const int inf = 2147483647;

int T, id;
int n, m, c, f;
char a[maxn][maxn];
int cnt[maxn][maxn];

void init()
{
	memset(cnt, 0, sizeof cnt);
	for(int i = 1; i <= n; i ++ )
		for(int j = 1; j <= m; j ++ )
			if(a[i][j] != '1') 
				for(int x = j; x <= m; x ++ ) 
				{
					if(a[i][x + 1] == '1' || x == m) break;
					cnt[i][j] ++ ;
				}
}

int solvec()
{ 
	int res = 0;
	for(int i = 1; i <= n - 2; i ++ ) 
		for(int j = 1; j <= m - 1; j ++ )  
		{
			if(cnt[i][j] == 0) continue;
			if(a[i + 1][j] == '1') continue;

			int sumx1 = cnt[i][j], sumx2 = 0;			
			for(int x2 = i + 2; x2 <= n; x2 ++ ) 
			{
				if(a[x2][j] == '1') break;
				sumx2 = cnt[x2][j];
				res = (res + (sumx1 * sumx2) % mod + mod) % mod;
			}
			
			while(cnt[i][j] != 0 && j <= m - 1) j ++ ;
		}
	return res;
}

int solvef()
{
	int res = 0;
	for(int i = 1; i <= n - 3; i ++ )
		for(int j = 1; j <= m - 1; j ++ )
		{
			if(cnt[i][j] == 0) continue;
			if(a[i + 1][j] == '1') continue;
			if(a[i + 3][j] == '1') continue;
			
			int sumx1 = cnt[i][j], sumx2 = 0;
			for(int x2 = i + 2; x2 <= n - 1; x2 ++ )
			{
				if(a[x2][j] == '1') break;
				sumx2 = cnt[x2][j];
				int cntx3 = 0, pos = x2;
				while(pos + 1 <= n && a[pos + 1][j] != '1') cntx3 ++ ,pos ++ ;
				res = (res + (sumx1 * sumx2 * cntx3) % mod + mod ) % mod;
			}
			while(cnt[i][j] != 0 && j <= m - 1) j ++ ;
		}
	return res;
}

signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin >> T >> id;
	while(T -- )
	{
		char t;
		cin >> n >> m >> c ;
		cin >> t, f = t - '0';
		for(int i = 1; i <= n; i ++ )
			for(int j = 1; j <= m; j ++ )
				cin >> a[i][j];
		init();
		if(c == 0 && f == 0)
		{
			cout << 0 << " " << 0 << endl;
			continue;
		}
		if(c == 0)
		{
			cout << 0 << " " << solvef() % mod << endl;
			continue;
		}
		if(f == 0)
		{
			cout << solvec() % mod << " " << 0 << endl;
			continue;
		}
		cout << solvec() % mod << " " << solvef() % mod << endl;
	}
	return 0;
}
