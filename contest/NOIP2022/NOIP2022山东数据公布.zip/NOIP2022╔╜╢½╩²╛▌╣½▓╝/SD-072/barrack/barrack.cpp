#include<bits/stdc++.h>
#define INF 1e9
using namespace std;
const int N=1e6+5;
const int M=5e5+5;
int fa[M],dis[3005][3005];
int b[M],c[M],ans=0;
int n,m,u[N],v[N];
//-------------------------------
int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
//-------------------------------
bool check() {
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			dis[i][j]=INF;
	for(int i=1;i<=n;i++) dis[i][i]=0;
	for(int i=1;i<=m;i++)
	{
		if(!c[i]) continue;
		dis[u[i]][v[i]]=dis[v[i]][u[i]]=1;
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(b[i]&&b[j]&&dis[i][j]>=INF)
				return false;
	return true;
}
//-------------------------------
void DFS(int x) {
	if(x==m+1) {
		if(check()) ans++;
		return;
	}
	for(int i=0;i<=1;i++)
	{
		c[x]=i;
		DFS(x+1);
	}
}
//-------------------------------
void dfs(int x) {
	if(x==n+1) {
		int cnt=0;
		for(int i=1;i<=n;i++) if(b[i]) cnt++;
		if(!cnt) return;
		DFS(1);
		return;
	}
	for(int i=0;i<=1;i++)
	{
		b[x]=i;
		dfs(x+1);
	}
}
//-------------------------------
void Main() {
	n=read(),m=read();
	for(int i=1;i<=m;i++) u[i]=read(),v[i]=read();
	dfs(1);
	cout<<ans<<"\n";
}
//-------------------------------
signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	Main();
	return 0;
}
