#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=250005;
int f[3005][3005];
int lg[N],f1[N][22],f2[N][22];
int T,n,m,a[N],b[N];
//-------------------------------
int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
//-------------------------------
void work() {
	for(int i=1;i<=n;i++) f1[i][0]=a[i];
	for(int i=1;i<=n;i++) f2[i][0]=b[i];
	lg[1]=0;for(int i=2;i<=n;i++) lg[i]=lg[i>>1]+1;
	for(int j=1;j<=lg[n];j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			f1[i][j]=max(f1[i][j-1],f1[i+(1<<(j-1))][j-1]);
	for(int j=1;j<=lg[n];j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			f2[i][j]=max(f2[i][j-1],f2[i+(1<<(j-1))][j-1]);
}
//-------------------------------
void Main() {
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	work();m=read();
	for(int i=1;i<=n;i++)
	{
		int res=0;	
		for(int j=i;j<=n;j++)
		{
			int k=lg[j-i+1];
			int m1=max(f1[i][k],f1[j-(1<<k)+1][k]);
			int m2=max(f2[i][k],f2[j-(1<<k)+1][k]);
			res=(res+m1*m2);
			f[i][j]=res;
		}
	}
	while(m--)
	{
		int l=read(),r=read(),ans=0;
		for(int i=l;i<=r;i++) ans+=f[i][r];
		cout<<ans<<"\n";
	}
}
//-------------------------------
signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();
	Main();
	return 0;
}
