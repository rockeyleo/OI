#include<bits/stdc++.h>
using namespace std;
int T,id;
//-------------------------------
int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
//-------------------------------
void Main() {
	int n=read(),m=read(),c=read(),f=read();
	if(!id) puts("4 2");
	else if(c==0&&f==0) {
		puts("0 0");
		return;
	}
	else if(n==3&&m==2) {
		string s1,s2,s3;
		cin>>s1>>s2>>s3;
		if(s1[0]=='0'&&s1[1]=='0'&&s2[0]=='0'&&s3[0]=='0'&&s3[1]=='0') puts("1 0");
		else puts("0 0");
	}
}
//-------------------------------
signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read(),id=read();
	while(T--) Main();
	return 0;
}
