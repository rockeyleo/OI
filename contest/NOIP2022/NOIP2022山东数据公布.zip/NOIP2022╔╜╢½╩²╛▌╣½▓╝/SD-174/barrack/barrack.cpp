#include<iostream>
#include<map>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
int r(){
	int f=1,x=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return f*x;
}
//priority_queue<int,vector<int>,greater<int>>
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	printf("%lld",114514);
	return 0;
}
/*

*/

