#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int re(){
	int f=1,x=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return f*x;
}
int T,n,q;
struct node{
	long long maxx;
}treea[2000001],treeb[2000001];
void bbuild(int l,int r,int n){
	if(l==r){
		treeb[n].maxx=re();
		return;
	}
	int mid=(l+r)/2;
	bbuild(l,mid,n*2);
	bbuild(mid+1,r,n*2+1);
//	cout <<treeb[n*2].maxx<<"==="<<treeb[n*2+1].maxx<<endl;
	treeb[n].maxx=max(treeb[n*2].maxx,treeb[n*2+1].maxx);
	//cout <<n<<":"<<treeb[n].maxx<<l<<" "<<r<<endl; 
}
void abuild(int l,int r,int n){
	if(l==r){
		treea[n].maxx=re();
		return;
	}
	int mid=(l+r)/2;
	abuild(l,mid,n*2);
	abuild(mid+1,r,n*2+1);
	treea[n].maxx=max(treea[n*2].maxx,treea[n*2+1].maxx);
	
}
long long bfind(int l,int r,int n,int L,int R){
	if(L<=l&&r<=R){
		return treeb[n].maxx;
	}
	int mid=(l+r)/2;
	long long maxxx=-1;
	if(L<=mid)maxxx=max(maxxx,bfind(l,mid,n*2,L,R));
	if(R>mid)maxxx=max(maxxx,bfind(mid+1,r,n*2+1,L,R));
	return maxxx;
}
long long afind(int l,int r,int n,int L,int R){
	if(L<=l&&r<=R){
		return treea[n].maxx;
	}
	int mid=(l+r)/2;
	long long maxxx=-1;
	if(L<=mid)maxxx=max(maxxx,afind(l,mid,n*2,L,R));
	if(R>mid)maxxx=max(maxxx,afind(mid+1,r,n*2+1,L,R));
	return maxxx;
}
//priority_queue<int,vector<int>,greater<int>>
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=re();
	n=re();
	abuild(1,n,1);
	bbuild(1,n,1);
///	cout <<afind(1,n,1,1,n)<<" "<<bfind(1,n,1,1,n)<<endl;
	q=re();
	for(int i=1;i<=q;i++){
		long long l=re(),r=re(),sum=0;
		for(int zuo=l;zuo<=r;zuo++){
			for(int you=zuo;you<=r;you++){
				sum+=afind(1,n,1,zuo,you)*bfind(1,n,1,zuo,you);
		//		cout <<zuo<<" "<<you<<"--"<<afind(1,n,1,zuo,you)<<" "<<bfind(1,n,1,zuo,you)<<endl;
			}
		}
		printf("%lld\n",sum);
	} 
	return 0;
}
/*
0 2
2 1
1 2
1 
1 2
*/

