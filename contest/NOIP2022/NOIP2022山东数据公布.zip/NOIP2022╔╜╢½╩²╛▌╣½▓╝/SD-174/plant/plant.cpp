#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int r(){
	int f=1,x=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return f*x;
}
long long modd=998244353;
//priority_queue<int,vector<int>,greater<int>>
char ma[2001][2001],T,id,n,m,c,f;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=r(),id=r();
	for(int qwq=1;qwq<=T;qwq++){
		n=r(),m=r(),c=r(),f=r();
		if(c==0&&f==0){
			cout <<0<<" "<<0<<endl;
			continue;
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cin >>ma[i][j];
			}
		} 
		if(n==3&&m==2){
			if(ma[1][1]!='1'&&ma[1][2]!='1'&&ma[2][1]!='1'&&ma[3][1]!='1'&&ma[3][2]!='1'){
				printf("%lld %lld\n",1,0);
			}else{
				printf("%lld %lld\n",0,0);
			}
			continue;
		}
		if(n==4&&m==2){
			int ff=0,cc=0;
			if(ma[1][1]!='1'&&ma[1][2]!='1'&&ma[2][1]!='1'&&ma[3][1]!='1'&&ma[3][2]!='1'){
				cc++;
			}
			if(ma[1][1]!='1'&&ma[1][2]!='1'&&ma[2][1]!='1'&&ma[3][1]!='1'&&ma[4][1]!='1'&&ma[4][2]!='1'){
				cc++;
			}
			if(ma[1][1]!='1'&&ma[1][2]!='1'&&ma[2][1]!='1'&&ma[3][1]!='1'&&ma[3][2]!='1'&&ma[4][1]!='1'){
				ff++;
			}
			printf("%lld %lld\n",cc*c%modd,ff*f%modd);
			continue;
		}
		if(f==0){
			long long cc=0,ff=0;
			for(int i=1;i<=n;i++){//c
				for(int j=1;j<=m;j++){
					int h=0,s=0; 
					if(ma[i][j]=='0'&&ma[i+1][j]=='0'&&ma[i][j+1]=='0'&&i+1<=n&&j+1<=m){
						for(int q=1;q+j<=m;q++){
							if(ma[i][j+q]=='1')break;
							else h++;
						}
					//	cout <<h<<endl;
						for(int k=2;k+i<=n;k++){
							for(int q=1;q+j<=m;q++){
								if(ma[i+k][j+q]=='1')break;
								else s++;
							}
							cc+=s*h;
							s=0;
						}
					}
				}
			} 
			printf("%lld %lld\n",cc*c%modd,ff*f%modd);
			continue;
		}else{
			long long cc=0,ff=0;
			for(int i=1;i<=n;i++){//c
				for(int j=1;j<=m;j++){
					int h=0,s=0; 
					if(ma[i][j]=='0'&&ma[i+1][j]=='0'&&ma[i+2][j]=='0'&&ma[i][j+1]=='0'&&i+2<=n&&j+1<=m){
						for(int q=1;q+j<=m;q++){
							if(ma[i][j+q]=='1')break;
							else h++;
						}
					//	cout <<h<<endl;
						for(int k=2;k+i<=n;k++){
							if(ma[i+k][j]=='1')break;
							for(int q=1;q+j<=m;q++){
								if(ma[i+k][j+q]=='1')break;
								else s++;
							}
							cc+=s*h;
							s=0;
						}
					}
				}
			} 
			for(int i=1;i<=n;i++){//f
				for(int j=1;j<=m;j++){
					int h=0,s=0,x=0; 
					if(ma[i][j]=='0'&&ma[i+1][j]=='0'&&ma[i+2][j]=='0'&&ma[i][j+1]=='0'&&i+2<=n&&j+1<=m){
						for(int q=1;q+j<=m;q++){
							if(ma[i][j+q]=='1')break;
							else h++;
						}
						for(int k=2;k+i<=n;k++){
							if(ma[i+k][j]=='1')break;
							for(int q=1;q+j<=m;q++){
								if(ma[i+k][j+q]=='1')break;
								else s++;
							}
							if(s){
								for(int p=k+1;ma[i+p-2][j]=='0'&&p+i<=n;p++){
									if(ma[i+p][j]=='1')break;
									else x++;
								}
							}	
							ff+=s*h*x;
							s=0;
							x=0;
						}
					}
				}
			}
			printf("%lld %lld\n",cc*c%modd,ff*f%modd);
			continue;
		}
	}
	return 0;
}
/*
1 0
4 3 1 1
001
000
000
000

1 0
4 2 1 1
00
00
01
00

1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111
*/

