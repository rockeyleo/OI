#include<iostream>
#include<map>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
int r(){
	int f=1,x=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return f*x;
}
int d1[10000010],d2[1000010],d3[10000010],c1,c2,c3,x1=1,x2=1,x3=1;
//priority_queue<int,vector<int>,greater<int>>
int T,n,m,k,a[1000010]; 
deque<int> dd1,dd2,dd3;
int book[1000001],v1[1000001],v2[1000001],cnt;
map<int,int> bo1,bo2,bo3;
bool pd=0;
void dfs(int num,int step){
	if(pd)return;
	if(num==m+1&&dd1.empty()&&dd2.empty()&&dd3.empty()){
		cout <<step<<endl;
		for(int i=1;i<=step;i++){
			if(book[i]==1){
				cout <<1<<" "<<v1[i]<<endl;
			}else{
				cout <<2<<" "<<v1[i]<<" "<<v2[i]<<endl; 
			}
		}
		pd=1;
	}
	if(num>=m+1)return;
	
	dd1.push_back(a[num]);
	book[step+1]=1;
	v1[step+1]=1;
	dfs(num+1,step+1);
	dd1.pop_back();
	
	book[step+1]=1;
	v1[step+1]=2;
	dd2.push_back(a[num]);
	dd2.pop_back();
	
	book[step+1]=1;
	v1[step+1]=3;
	dd3.push_back(a[num]);
	dd3.pop_back();
	
	if(a[num]==dd1.back()){
		book[step+1]=1;
		v1[step+1]=1;
		int t=dd1.back();
		dd1.pop_back();
		dfs(num+1,step+1);
		dd1.push_back(t);
	}
	
	if(a[num]==dd2.back()){
		book[step+1]=1;
		v1[step+1]=2;
		int t=dd2.back();
		dd2.pop_back();
		dfs(num+1,step+1);
		dd2.push_back(t);
	}
	
	
	if(a[num]==dd3.back()){
		book[step+1]=1;
		v1[step+1]=3;
		int t=dd3.back();
		dd3.pop_back();
		dfs(num+1,step+1);
		dd3.push_back(t);
	}
	
	if(a[num]==dd1.front()&&(dd2.empty()||dd3.empty())){
		book[step+1]=1;
		if(dd2.empty())v1[step+1]=2;
		else v1[step+1]=3;
		book[step+2]=2;
		if(dd2.empty())v1[step+2]=1,v2[step+2]=2;
		else v1[step+2]=1,v2[step+2]=3;
		int t=dd1.back();
		dd1.pop_back();
		dfs(num+1,step+2);
		dd1.push_back(t);
	}
	
	if(a[num]==dd2.front()&&(dd1.empty()||dd3.empty())){
		book[step+1]=1;
		if(dd1.empty())v1[step+1]=1;
		else v1[step+1]=3;
		book[step+2]=2;
		if(dd1.empty())v1[step+2]=1,v2[step+2]=2;
		else v1[step+2]=2,v2[step+2]=3;
		int t=dd2.back();
		dd2.pop_back();
		dfs(num+1,step+2);
		dd2.push_back(t);
	}
	
	if(a[num]==dd3.front()&&(dd2.empty()||dd1.empty())){
		book[step+1]=1;
		if(dd2.empty())v1[step+1]=2;
		else v1[step+1]=1;
		book[step+2]=2;
		if(dd2.empty())v1[step+2]=2,v2[step+2]=3;
		else v1[step+2]=1,v2[step+2]=3;
		int t=dd3.back();
		dd3.pop_back();
		dfs(num+1,step+2);
		dd3.push_back(t);
	}
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=r();
	for(int qwq=1;qwq<=T;qwq++){
		cnt=0;
		n=r(),m=r(),k=r();
 		if(1){
			c1=c2=c3=0;
			x1=x2=x3=1;
			for(int i=1;i<=m;i++){
				int t=r();
				if(i==1){
					d1[++c1]=t;
					book[++cnt]=1;
					v1[cnt]=1;
				}else{
					if(t==d1[c1]&&c1){
						book[++cnt]=1;
						v1[cnt]=1;
						c1--;
					}else if(t==d2[c2]&&c2){
						book[++cnt]=1;
						v1[cnt]=2;
						c2--;
					}else if(t==d1[x1]&&!c2&&c1){
						book[++cnt]=1;
						v1[cnt]=2;
						book[++cnt]=2;
						v1[cnt]=1;
						v2[cnt]=2;
						x1++;
					}else if(t==d2[x2]&&!c1&&c2){
						book[++cnt]=1;
						v1[cnt]=1;
						book[++cnt]=2;
						v1[cnt]=1;
						v2[cnt]=2;
						x2++;
					}else{
						d2[++c2]=t;
						book[++cnt]=1;
						v1[cnt]=2;
					}
				}
			}
			cout <<cnt<<endl;
			for(int j=1;j<=cnt;j++){
				if(book[j]==1){
					printf("%lld %lld\n",1,v1[j]);
				}else{
					printf("%lld %lld %lld\n",2,v1[j],v2[j]);
				}
			}
		}else{
			for(int i=1;i<=n;i++){
				a[i]=r();
			}
			dfs(1,0);
		}
		//if(T%10==3)
	}
	return 0;
}
/*
2
2 4 2
1 2 1 2
*/

