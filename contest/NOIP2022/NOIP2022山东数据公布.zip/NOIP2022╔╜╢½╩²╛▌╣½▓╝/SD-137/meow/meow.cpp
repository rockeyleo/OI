#include<queue>
#include<deque>
#include<stack>
#include<vector>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define N (305)
#define M (2000005)
#define ll long long
#define debug puts("qwq")
#define stp getchar()
#define ls(xxx) (xxx)<<1
#define rs(xxx) (xxx)<<1|1
#define PII pair<int,int>
#define INF (0x3f3f3f3f)//�ǵø�!!!
#define mod ((ll)(998244353))
#define MP(xxx,yyy) make_pair(xxx,yyy)
using namespace std;
int t,n,m,k;
int a[M]; 
deque<int> s[N];
int opt1[M],opt2[M],opt3[M],cnt;
void solve2(){
	//use st[1] & st[2]
	for(int i=1;i<=m;i++){
//		printf("1:");
//		for(deque<int>::iterator it=s[1].begin();it!=s[1].end();it++){
//			printf("%d ",*it);
//		}
//		puts("");
//		printf("2:");
//		for(deque<int>::iterator it=s[2].begin();it!=s[2].end();it++){
//			printf("%d ",*it);
//		}
//		puts("");
		//now=a[i]
		if(s[1].front()==a[i]){
			s[1].pop_front();
//			printf("%d %d\n",1,1);
			opt1[++cnt]=1;
			opt2[cnt]=1;
		}else if(s[2].front()==a[i]){
			s[2].pop_front();
//			printf("%d %d\n",1,2);
			opt1[++cnt]=1;
			opt2[cnt]=2;
		}else if(s[1].empty()){
			s[1].push_front(a[i]);
//			printf("%d %d\n",1,1);
			opt1[++cnt]=1;
			opt2[cnt]=1;
		}else if(s[2].empty()){
			s[2].push_front(a[i]);
//			printf("%d %d\n",1,2);
			opt1[++cnt]=1;
			opt2[cnt]=2;
		}else{
			s[1].push_front(a[i]);
//			printf("%d %d\n",1,2);
			opt1[++cnt]=1;
			opt2[cnt]=1;
		}
		if(s[1].back()==s[2].back()){
			s[1].pop_back();
			s[2].pop_back();
//			printf("#6 %d %d %d\n",2,1,2); 
			opt1[++cnt]=2;
			opt2[cnt]=1;
			opt3[cnt]=2;
		}
	}
}
void solve(){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			if(s[j].front()==a[i]){
				s[j].pop_front();
				//printf("%d %d\n",1,j);
				opt1[++cnt]=1;
				opt2[cnt]=j;
				break;
			}else if(s[j].empty()){
				s[j].push_front(a[i]);
				//printf("%d %d\n",1,j);
				opt1[++cnt]=1;
				opt2[cnt]=j;
				break;
			}else if(s[j].front()==a[i+1] && j+1<=n){
				s[j+1].push_front(a[i]);
				//printf("%d %d\n",1,j+1);
				opt1[++cnt]=1;
				opt2[cnt]=j+1;
				break;
			}else{
				s[1].push_front(a[i]);
				//printf("%d %d\n",1,1);
				opt1[++cnt]=1;
				opt2[cnt]=1;
				break;
			}
		}
		for(int j=1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(!s[j].empty() && !s[k].empty() && s[j].back()==s[k].back()){
					s[j].pop_back();
					s[k].pop_back();
					//printf("%d %d %d\n",2,j,k);
					opt1[++cnt]=2;
					opt2[cnt]=j;
					opt2[cnt]=k;
				}
			}
		}
	}
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&t);
	for(int rr=1;rr<=t;rr++){
		cnt=0;
		scanf("%d %d %d",&n,&m,&k);
		for(int i=1;i<=m;i++){
			scanf("%d",&a[i]);
		}
		a[m+1]=a[m+2]=INF;
		if(t%10==2){
			solve2();
		}else{
			solve();
		}
//	solve2();
		printf("%d\n",cnt);
		for(int i=1;i<=cnt;i++){
			if(opt1[i]==1) printf("%d %d\n",1,opt2[i]);
			else printf("%d %d %d\n",2,opt2[i],opt3[i]);
		}
	}
	return 0;
}
//freopen!!!freopen!!!freopen!!!һ���ǵð�ע��ɾ��!!!
//������Ϣһ��ɾ��!!!!
//NOIP2022 RP++!!!
//%%%%%zyb

