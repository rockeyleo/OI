#include<queue>
#include<stack>
#include<vector>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define N (100005)
#define M (1005)
#define ll long long
#define ull unsigned long long
#define debug puts("qwq")
#define ls(xxx) (xxx)<<1
#define rs(xxx) (xxx)<<1|1
#define PII pair<int,int>
#define INF (0x3f3f3f3f)//�ǵø�!!!
#define mod ((ll)(998244353))
#define MP(xxx,yyy) make_pair(xxx,yyy)
using namespace std;
int tt,n,q;
int a[N],b[N];
struct T{
	int l,r,vala,valb;
}t[N<<2];
void build(int p,int l,int r){
	t[p].l=l,t[p].r=r;
	if(l==r){
		t[p].vala=a[l];
		t[p].valb=b[l];
		return;
	}
	int mid=l+r>>1;
	build(ls(p),l,mid);
	build(rs(p),mid+1,r);
	t[p].vala=max(t[ls(p)].vala,t[rs(p)].vala);
	t[p].valb=max(t[ls(p)].valb,t[rs(p)].valb);
}
int qa(int p,int l,int r){
	if(l<=t[p].l && r>=t[p].r){
		return t[p].vala;
	}
	int mid=t[p].l+t[p].r>>1;
	int ans=-INF;
	if(l<=mid) ans=max(ans,qa(ls(p),l,r));
	if(r>mid) ans=max(ans,qa(rs(p),l,r));
	return ans;
}
int qb(int p,int l,int r){
	if(l<=t[p].l && r>=t[p].r){
		return t[p].valb;
	}
	int mid=t[p].l+t[p].r>>1;
	int ans=-INF;
	if(l<=mid) ans=max(ans,qb(ls(p),l,r));
	if(r>mid) ans=max(ans,qb(rs(p),l,r));
	return ans;
}
ull ans=0;
ll rd(){
	ll x=0,f=1; char ch=getchar();
	while(!isdigit(ch)){ if(ch=='-') f=-1; ch=getchar();}
	while(isdigit(ch)){ x=(x<<1)+(x<<3)+(ch^48); ch=getchar();}
	return x*f;
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d %d",&tt,&n);
	for(int i=1;i<=n;i++){
		a[i]=rd();
	}
	for(int i=1;i<=n;i++){
		b[i]=rd();
	}
	build(1,1,n);
	scanf("%d",&q);
	while(q--){
		ans=0;
		int l=rd(); int r=rd(); 
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				if(i==j) ans+=(ull)a[i]*b[j];
				else ans+=(ull)qa(1,i,j)*qb(1,i,j);
			}
		}
		printf("%llu\n",ans);
	}
	return 0;
}
//freopen!!!freopen!!!freopen!!!һ���ǵð�ע��ɾ��!!!
//������Ϣһ��ɾ��!!!!
//NOIP2022 RP++!!!
//%%%%%zyb

