#include<queue>
#include<stack>
#include<vector>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define N (1005)
#define M (1005)
#define ll long long
#define debug puts("qwq")
#define ls(xxx) (xxx)<<1
#define rs(xxx) (xxx)<<1|1
#define PII pair<int,int>
#define INF (0x3f3f3f3f)//�ǵø�!!!
#define mod (998244353)
#define MP(xxx,yyy) make_pair(xxx,yyy)
using namespace std;
int t,id,n,m,c,f;
bool g[N][N];
int cntn[N][N],cntm[N][N];
ll ans_c=0,ans_f=0;
int check(int x,int y){
	int tmp=0;
	for(int i=y;i<=m;i++){
//		printf("->check,g[%d][%d]=%d\n",x,i,g[x][i]);
		//getchar();
		if(g[x][i]!=1) tmp++;
		else break;
	}
//	printf("->check ret=%d\n",tmp);
	return tmp;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	
	scanf("%d %d",&t,&id);
	while(t--){
		scanf("%d %d %d %d",&n,&m,&c,&f);
		memset(g,1,sizeof(g));
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				char c;
				cin>>c;
				if(c=='0'){
					g[i][j]=0;
				}
			}
		}
	//	for(int j=1;j<=m;j++){
	//		for(int i=1;i<=n;i++){
	//			cntm[i][j]=cnt[i-1][j]+g[i][j];
	//		}
	//	}
	//	for(int i=1;i<=n;i++){
	//		for(int j=1;j<=m;j++){
	//			cntn[i][j]=cnt[i][j-1]+g[i][j];
	//		}
	//	}
		ans_c=ans_f=0;
		int ans_zong=0;
		for(int j=1;j<=m;j++){//ö������ y ���
			int ans_heng1=0,ans_heng2=0;
			for(int i=1;i<=n;i++){//ö������ x ���
				ans_heng1=ans_heng2=0;
				if(g[i][j]==1 || g[i][j+1]==1) continue;
				ans_heng1+=check(i,j)-1;
	//			printf("check(%d,%d)=%d\n",i,j,check(i,j));
				for(int k=i+2;k<=n;k++){//ö���յ�
					if(g[k][j]==1 || g[k][j+1]==1){
						break;
					}
					ans_heng2+=check(k,j)-1;
					for(int l=k+1;l<=n;l++){
						if(g[j][l]!=1) ans_zong++;
						else break;
					}
				}
				ans_c+=ans_heng1*ans_heng2;
				ans_f+=ans_zong*ans_c;
	//			if(f==1) i=tmpk+1;
			}
		}
	
		printf("%lld %lld\n",ans_c*c,ans_c/2*f);
	} 
	return 0;
}
//freopen!!!freopen!!!freopen!!!һ���ǵð�ע��ɾ��!!!
//������Ϣһ��ɾ��!!!!
//NOIP2022 RP++!!!
//%%%%%zyb

