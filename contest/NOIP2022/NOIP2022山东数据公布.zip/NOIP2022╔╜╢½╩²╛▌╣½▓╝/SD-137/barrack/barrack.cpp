#include<queue>
#include<stack>
#include<vector>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cstdlib>
#include<random>
#include<ctime>
#define N (500005)
#define M (2000005)
#define ll long long
#define debug puts("qwq")
#define ls(xxx) (xxx)<<1
#define rs(xxx) (xxx)<<1|1
#define PII pair<int,int>
#define INF (0x3f3f3f3f)//�ǵø�!!!
#define mod ((ll)(998244353))
#define MP(xxx,yyy) make_pair(xxx,yyy)
using namespace std;
int n,m;
struct E{
	int nxt,to;
}edge[M<<1];
int head[N],num_edge;
void add(int from,int to){
	num_edge++;
	edge[num_edge].nxt=head[from];
	edge[num_edge].to=to;
	head[from]=num_edge;
}
bool ca=1;
bool vis[N],f=0;
//void check(int x,int dir){
//	if(x==dir){
//		f=1;
//		return;
//	}
//	for(int i=head[x];i;i=edge[i].nxt){
//		int j=edge[i].to;
//		if(!vis[j] && !f){
//			vis[j]=1;
//			dfs(j,dir);
//			vis[j]=0;
//		}
//	}
//	return;
//}
//bool barn[N],barm[m<<1];
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1,u,v;i<=m;i++){
		scanf("%d %d",&u,&v);
		add(u,v); add(v,u);
		if(u!=v+1 && v!=u+1) ca=0;
	}
//	if(ca){
//		
//	}
	srand(time(0));
	printf("%d\n",rand()%(n*100));
	return 0;
}
//freopen!!!freopen!!!freopen!!!һ���ǵð�ע��ɾ��!!!
//������Ϣһ��ɾ��!!!!
//NOIP2022 RP++!!!
//%%%%%zyb

