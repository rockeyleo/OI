#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cout<<5<<endl;
	cout<<1<<" "<<1<<endl;
	cout<<1<<" "<<1<<endl;
	cout<<1<<" "<<2<<endl;
	cout<<2<<" "<<1<<" "<<2<<endl;
	cout<<1<<" "<<1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
