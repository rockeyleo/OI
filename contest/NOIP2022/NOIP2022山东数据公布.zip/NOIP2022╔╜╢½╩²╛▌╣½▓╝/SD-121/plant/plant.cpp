#include<bits/stdc++.h>
using namespace std;
int t,id,n,m,c,f1,f[1001][1001],ans1,ans2,cnt1,cnt2,cnt3;
char mp[1001][1001]; 
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	for(int l=1;l<=t;l++)
	{
		cin>>n>>m>>c>>f1;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cin>>mp[i][j];
				if(mp[i][j]=='1')f[i][j]=1;
				else f[i][j]=0;
			}
		}
		ans1=0;
		ans2=0;
		for(int y0=1;y0<=m;y0++)
		{
			for(int x1=1;x1<=n;x1++)
			{
				for(int x2=x1+2;x2<=n;x2++)
				{
					if(f[x1+1][y0]==1)break;
					if(f[x1][y0]!=1&&f[x2][y0]!=1)
					{
						cnt1=0;
						cnt2=0;
						for(int y=y0+1;y<=m;y++)
						{
							if(f[x1][y]!=1)cnt1++;
							else break;
						}
						for(int y=y0+1;y<=m;y++)
						{
							if(f[x2][y]!=1)cnt2++;
							else break;
						}
						ans1+=(cnt1*cnt2);
					}
				}
			}
		}
		for(int y0=1;y0<=m;y0++)
		{
			for(int x1=1;x1<=n;x1++)
			{
				for(int x2=x1+2;x2<=n;x2++)
				{
					if(f[x1+1][y0]==1)break;
					if(f[x1][y0]!=1&&f[x2][y0]!=1)
					{
						cnt1=0;
						cnt2=0;
						cnt3=0;
						for(int y=y0+1;y<=m;y++)
						{
							if(f[x1][y]!=1)cnt1++;
							else break;
						}
						for(int y=y0+1;y<=m;y++)
						{
							if(f[x2][y]!=1)cnt2++;
							else break;
						}
						for(int x3=x2+1;x3<=n;x3++)
						{
							if(f[x3][1]!=1)cnt3++;
							else break;
						}
						ans2+=(cnt1*cnt2*cnt3);
					}
				}
			}
		}
		cout<<ans1*c<<" "<<ans2*f1<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
