#include<bits/stdc++.h>
using namespace std;
unsigned long long t,n,a[250001],b[250001];
unsigned long long st1[101][250001],st2[101][250001],ans[1000001],ans1,ans2,q;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		st1[0][i]=a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
		st2[0][i]=b[i];
	}
	int p=log(n)/log(2);
	for(int k=1;k<=p;k++)
	{
		for(int i=1;i<=n-(1<<k)+1;i++)
		{
			st1[k][i]=max(st1[k-1][i],st1[k-1][i-(1<<(k-1))+2]);
			st2[k][i]=max(st2[k-1][i],st2[k-1][i-(1<<(k-1))+2]);
		}
	}
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		int l,r;
		cin>>l>>r;
		for(int x=l;x<=r;x++)
		{
			for(int y=x;y<=r;y++)
			{
				int num=log(y-x+1)/log(2);
				ans1=max(st1[num][x],st1[num][y-(1<<num)+1]);
				ans2=max(st2[num][x],st2[num][y-(1<<num)+1]);
				ans[i]+=(ans1*ans2);
			}
		}
	}
	for(int i=1;i<=q;i++)cout<<ans[i]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
