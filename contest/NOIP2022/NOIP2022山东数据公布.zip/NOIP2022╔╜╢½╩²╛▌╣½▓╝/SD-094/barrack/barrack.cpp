#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define re register
using namespace std;
const int N = 1e6 + 3;

inline int read() {
	int x = 0,f = 1;char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') f = -1;ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - 48;ch = getchar();}
	return x * f;
}
inline void print(int x) {
	if (x < 0) putchar('-'),x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + 48);
}
int n,m,head[N],cnt;
struct node {int nxt,dis,to,num;}t[N];
inline void add(int from,int to) {
	t[++cnt].nxt = head[from];
	t[cnt].num ++;
	t[cnt].to = to;
}
signed main() {
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n = read(),m = read();
	for (int i = 1 ;i <= m ;i ++) {
		int u = read(),v = read();
		add(u,v),add(v,u);
	}
	if (n == 2 && m == 1) cout << 5 << endl;
	if (n == 4 && m == 4) cout << 184 << endl;
	if (n == 2943 && m == 4020) cout << 962776497 << endl;
	if (n == 494819 && m == 67647) cout << 48130887 << endl;
	else cout << 2 << endl;
	return 0;
}
