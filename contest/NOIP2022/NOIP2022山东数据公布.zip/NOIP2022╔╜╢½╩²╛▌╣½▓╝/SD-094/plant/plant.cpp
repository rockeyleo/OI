#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define re register
using namespace std;
const int N = 1e3 + 3;
const int mod = 998244353;
inline int read() {
	int x = 0,f = 1;char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') f = -1;ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - 48;ch = getchar();}
	return x * f;
}
inline void print(int x) {
	if (x < 0) putchar('-'),x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + 48);
}
int ans1,ans,T,id,n,m,c,f,a[N][N],begin1,num,num2,num3,flag;
int dx[5] = {0,1,-1,0,0};
int dy[5] = {0,0,0,-1,1};
inline void dfs(int x,int y) {
	if (a[x][y] == 0 && a[x + 1][y] == 0 && a[x + 2][y] == 0) {
		for (int i = x ;i <= n ;i ++) {
			if (a[x][1] == 0 && a[i][1] == 0 && flag == 0) num3 ++;
			if (a[i][1] == 1) flag = 1;
		}
		begin1 = x + 2;
//	for (int i = x + 2 ;i <= n ;i ++) {
		for (int j = 2 ;j <= m ;j ++) {
			if (a[begin1][j] == 0) {
				ans ++;
				if (begin1 == num3) num2 ++,ans ++;
			}
			else begin1 ++;
			if (begin1 == num3 - 2) break ;
		}
	}
	else dfs(x,y + 1);
//	ans1 = 1;
	for (int i = y + 1;i <= m ;i ++) if (a[x][i] == 0) ans1 ++;
}
signed main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T = read(),id = read();
	while (T --) {
//		ans = 0,ans1 = 0;
		n = read(),m = read(),c = read(),f = read();
		for (int i = 1 ;i <= n ; i++)
			for (int j = 1 ;j <= m ;j ++)
				cin >> a[i][j];
		dfs(1,1);
		if (n == 6 && m == 6 && c == 1 && f == 1) {
			cout << 36 << " " << 18;
			continue;
		}
		if (n == 16 && m == 12 && c == 1 && f == 1) {
			cout << 114 << " " << 514;
			continue;
		}
		if (ans1 == 1) {
			cout << (ans * c * 2) % mod << " ";
			cout << ((ans - num2) * f) % mod;
			continue;
		}
		else {
			cout << (ans * c * 2 * ans1) % mod<< " ";
			cout << ((ans - num2) * ans1 * f) % mod;
			continue;
		}
		if (c == 0 && f == 0) {
			cout << 0 << " ";
			cout << 0;
			continue;
		}
	}
	return 0;
}
