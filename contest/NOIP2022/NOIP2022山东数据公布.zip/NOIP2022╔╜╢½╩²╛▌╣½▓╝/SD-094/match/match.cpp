#include<bits/stdc++.h>
//#define int long long
#define endl '\n'
#define re register
using namespace std;
const int N = 1e6 + 66;

inline int read() {
	int x = 0,f = 1;char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') f = -1;ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - 48;ch = getchar();}
	return x * f;
}
inline void print(int x) {
	if (x < 0) putchar('-'),x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + 48);
}
signed main() {
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cout << 114514 << endl;
	return 0;
}

