#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define re register
using namespace std;
const int N = 5e3 + 66;

inline int read() {
	int x = 0,f = 1;char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') f = -1;ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - 48;ch = getchar();}
	return x * f;
}
inline void print(int x) {
	if (x < 0) putchar('-'),x = -x;
	if (x > 9) print(x / 10);
	putchar(x % 10 + 48);
}
int T,n,m,k,a[N],ans,flag[N];
queue<int >q1,q2;
signed main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T = read();
	while (T --) {
		ans = 0;
		memset(flag,0,sizeof flag);
		memset(a,0,sizeof a);
		n = read(), m = read(), k = read();
		for (int i = 1 ;i <= m ;i ++) a[i] = read();
		q1.push(a[1]);
		flag[1] = 1;
		for (int i = 1 ;i <= m ;i ++) {
			if (a[i] == q1.front()) {
				ans ++;
				q1.pop();
				flag[i] = 1;
			}
			
			else if (a[i] == q2.front()) {
				ans ++;
				q2.pop();
				flag[i] = 2;
			}
			else  {
				ans ++;
				flag[i] = 3;
				q2.push(a[i]);
			}
		}
		if (!q1.empty() || !q2.empty())	if (q1.front() == q2.front()) flag[ans ++] = 4;
		cout << ans << endl;
		for (int i = 1 ;i <= ans ;i ++) {
			if (flag[i] == 1) cout << 1 << " " << 1 << endl;
			if (flag[i] == 2 || flag[i] == 3) cout << 1 << " " << 2 << endl;
			if (flag[i] == 4) cout << 2 << " " << 1 << " " << 2 << " " << endl;
		}
	}
	return 0;
}
