#include<bits/stdc++.h>
#define LL unsigned long long
using namespace std;
inline void read(LL &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9')
		c=getchar();
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c-48);
		c=getchar();
	}
}
struct node
{
	LL l,r,maxx,len;
	node operator +(const node &x)const
	{
		return {l,x.r,max(maxx,x.maxx),len+x.len};
	}
}tree1[800050],tree2[800050];
LL arr[200050];
int n,m,t,q;
void build1(int now,int x,int y)
{
	if(x==y)
	{
		tree1[now]={(LL)x,(LL)x,arr[(LL)x],1};
		return ;
	}
	int mid=(x+y)>>1;
	build1(now<<1,x,mid),build1(now<<1|1,mid+1,y);
	tree1[now]=tree1[now<<1]+tree1[now<<1|1];
}
void build2(int now,int x,int y)
{
	if(x==y)
	{
		tree2[now]={(LL)x,(LL)x,arr[(LL)x],1};
		return ;
	}
	int mid=(x+y)>>1;
	build2(now<<1,x,mid),build2(now<<1|1,mid+1,y);
	tree2[now]=tree2[now<<1]+tree2[now<<1|1];
}
int query1(int now,int x,int y)
{
	if(tree1[now].l>(LL)y||tree1[now].r<(LL)x)
		return 0;
	if(tree1[now].l>=(LL)x&&tree1[now].r<=(LL)y)
		return tree1[now].maxx;
	return max(query1(now<<1,x,y),query1(now<<1|1,x,y));
	
}
int query2(int now,int x,int y)
{
	if(tree2[now].l>(LL)y||tree2[now].r<(LL)x)
		return 0;
	if(tree2[now].l>=(LL)x&&tree2[now].r<=(LL)y)
		return tree2[now].maxx;
	return max(query2(now<<1,x,y),query2(now<<1|1,x,y));
	
}
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d%d",&t,&n);
	for(int i=1;i<=n;i++)
		read(arr[i]);
	build1(1,1,n);
	for(int i=1;i<=n;i++)
		read(arr[i]);
	build2(1,1,n);
	scanf("%d",&q);
	while(q--)
	{
		int l,r;
		LL sum=0;
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;i++)
		{
			for(int j=i;j<=r;j++)
				sum+=query1(1,i,j)*query2(1,i,j);
		}
		cout<<sum<<'\n';
	}
	return 0;
}

