#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,m;
LL p[500050];
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
	}
	LL sum=1;
	p[1]=1;
	for(int i=2;i<=n;i++)
	{
		p[i]=p[i-1]*2;
		sum=(sum+p[i]*i%1000000007);
	}
	cout<<sum;
	return 0;
}

