#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	char c=getchar();	
	while(c<'0'||c>'9')
		c=getchar();
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c-48);
		c=getchar();
	}
}
int num[1050],dis[1050][1050],a[1050][1050],b[1050][1050];
int t,id,n,m,ansc,ansf,c,f;
inline void fin()
{
	for(int i=1;i<=n-2;i++)
	{
		for(int j=1;j<=num[i];j++)
		{
			for(int t1=b[i][j];dis[i][t1]&&t1<=m;t1++)
			{
				if(dis[i][t1]==1||dis[i][t1+1])
					continue;
				while(a[i+1][b[i][j]]&&b[i][j]<t1)
					b[i][j]++;
				if(a[i+1][b[i][j]])
					break;
				
				for(int i2=i+2;i2<=n;i2++)
				{
					if(a[i2][b[i][j]])
						break;
					if(!a[i2][b[i][j]])
					{
						int t=b[i][j];
						for(;t<=m;t++)
							if(!dis[i2][t])
								break;
						if(dis[i2][t-1]==1)
							continue;
						ansc=((dis[i][t1]-dis[i][b[i][j]])*(dis[i2][t-1]-dis[i2][b[i][j]])+ansc)%998244353;
						int sum=0;
						for(int k=i2+1;k<=n;k++)
						{
							if(!a[k][b[i][j]])
								sum++;
							else
								break;
						}
						ansf=((dis[i][t1]-dis[i][b[i][j]])*(dis[i2][t-1]-dis[i2][b[i][j]])*sum+ansf)%998244353;
					}
				}
				
			}
		}
	}
	return ;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	read(t),read(id);
	while(t--)
	{
		read(n),read(m),read(c),read(f);
		ansc=ansf=0;
		for(int i=1;i<=n;i++)
		{
			num[i]=0;
			for(int j=1;j<=m;j++)
				dis[i][j]=0;
		}
		char ch[1050][1050];
		for(int i=1;i<=n;i++)
		{
			cin>>ch[i];
			int f=0,cnt=0;
			for(int j=1;j<=m;j++)
			{
				a[i][j]=ch[i][j-1]-'0';
				if((!a[i][j])&&(!f))
					f=j,b[i][++cnt]=j;
				if(!a[i][j])
					dis[i][j]=j-f+1;
				if(a[i][j]&&f)
					num[i]++,f=0;
			}
			if(f)
				num[i]++;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
				printf("%d ",dis[i][j]);
			putchar('\n');
			
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
				printf("%d ",b[i][j]);
			putchar('\n');
			
		}
		for(int i=1;i<=n;i++)
			printf("%d ",num[i]);
		fin();
		printf("%d %d\n",ansc*c%998244353,ansf*f%998244353);
	}
	return 0;
}

