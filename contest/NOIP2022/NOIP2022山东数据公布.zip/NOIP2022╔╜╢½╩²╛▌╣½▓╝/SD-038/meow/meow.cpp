#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9')
		c=getchar();
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c-48);
		c=getchar();
	}
}
int q[3][100005000];
int n,m,t,k;
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	read(t);
	if(t%10==2)
	{
		while(t--)
		{
			int head=1,tail=0;
			read(n),read(m),read(k);
			printf("%d",m);
			for(int i=1;i<=m;i++)
			{
				int k;
				read(k);
				if(k==q[1][tail]&&head<=tail)
				{
					q[1][tail--]=0;
					printf("1 1\n");
				}
				else if(k==q[1][head]&&head<=tail)
				{
					head++;
					printf("1 2\n2 1 2\n");
				}
				else
				{
					printf("1 1\n");
					q[1][++tail]=k;
				}
					
			}
		}
	}
	return 0;
}

