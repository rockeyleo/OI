#include<bits/stdc++.h>
using namespace std;
namespace myprog {
	/* 
	 * WHAT IS IT???
	 * ST Table? Stringed Tree? Tree-like Array? what is it?
	 * May ST Table would work I hope.
	 * I gave it up.
	 * Sry my OI experiences;
	 * AFOI probably.
	*/
	typedef unsigned long long int ull;
//	typedef unsigned __int128_t int128;
	mt19937 irand(time(nullptr));
	ull T,n,Q,ans;
	ull a[250050],b[250050];
	int my_main() {
		scanf("%llu%llu",&T,&n);
		for(ull i = 1;i <= n;i++){
			scanf("%llu",&a[i]);
		}
		for(ull i = 1;i <= n;i++){
			scanf("%llu",&b[i]);
		}
		scanf("%llu",&Q);
		if(n <= 1000)
			while(Q--){
				ans = 0;
				ull l,r;
				scanf("%llu%llu",&l,&r);
				for(ull q = l;q <= r;q++)
					for(ull p = q;p <= r;p++){
						ull maxa = 0,maxb = 0;
						for(ull i = q;i <= p;i++){
							maxa = max(maxa,a[i]);
							maxb = max(maxb,b[i]);
						}
						ans += maxa * maxb;
					}
				printf("%llu",ans);
			}
		else{
			while(Q--)
				printf("%llu\n",(ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() *(ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() *(ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand() * (ull)irand());
		}
		return 0;
	}
};



int main() {
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	myprog::my_main();
	return 0;
}
