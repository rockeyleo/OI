#include<bits/stdc++.h>
using namespace std;
namespace myprog {
	/*
	* WHY IT WILL CRASH BY INVAILD MEMORY ACCESS???
	* SO STRANGE ISN'T IT?
	* IDK WHY.
	* Only pass pretest 1.
	*/
	int T;
	int n,m,k;
	int cards[2000050];
	deque<int> stacks[602];
	stack<string> stk;
	int dfs(int depth,int ops) {
		if(depth == m + 1 or ops > 2 * m + 1) {
			for(int i = 1; i <= n; i++) {
				if(!stacks[i].empty()) {
					return 0;
				}
			}
			printf("%d\n",ops);
			return 1;
		}
		// Case 1
		for(int i = 1; i <= n; i++) {
			if(!stacks[i].empty()) {
				if(stacks[i].back() == cards[depth]) {
					stacks[i].pop_back();
					if(dfs(depth + 1,ops + 1)) {
						stk.push("1 "+to_string(i)+"\n");
						return 1;
					}
					stacks[i].push_back(cards[depth]);
				} else {
					stacks[i].push_back(cards[depth]);
					if(dfs(depth + 1,ops + 1)) {
						stk.push("1 "+to_string(i)+"\n");
						return 1;
					}
					stacks[i].pop_back();
				}
			} else {
				stacks[i].push_back(cards[depth]);
				if(dfs(depth + 1,ops + 1)) {
					stk.push("1 "+to_string(i)+"\n");
					return 1;
				}
				stacks[i].pop_back();
			}
		}
		// Case 2
		for(int i = 1; i <= n; i++) {
			for(int j = i + 1; j <= n; j++) {
				if(!stacks[i].empty() && !stacks[j].empty()) {
					if(stacks[i].front() == stacks[j].front()) {
						int sam = stacks[i].front();
						stacks[i].pop_front();
						stacks[j].pop_front();
						if(dfs(depth,ops + 1)) {
							stk.push("2 "+to_string(i) + " " + to_string(j) +"\n");
							return 1;
						}
						stacks[i].push_front(sam);
						stacks[j].push_front(sam);
					}
				}
			}
		}
		return 0;
	}
	int my_main() {
		scanf("%d",&T);
		while(T--) {
			memset(cards,0,sizeof(cards));
			for(int i = 0; i < 602; i++) {
				stacks[i].clear();
			}
			scanf("%d%d%d",&n,&m,&k);
			for(int i = 1; i <= m; i++) {
				scanf("%d",&cards[i]);
			}
			dfs(1,0);
			while(!stk.empty()){
				printf("%s",stk.top().c_str());
				stk.pop();
			}
		}
		return 0;
	}
};



int main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	myprog::my_main();
	return 0;
}
