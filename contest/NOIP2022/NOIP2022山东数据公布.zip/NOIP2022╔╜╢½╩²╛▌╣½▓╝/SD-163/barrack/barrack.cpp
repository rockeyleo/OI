#include<bits/stdc++.h>
using namespace std;
namespace myprog {
	/*
	 * Too difficult to calc.
	 * May about A(n,m)? 
	 * I can't write that!
	 * Then mt19937 is the only solution for this task.
	*/
	typedef unsigned long long int ull;
	mt19937 irand(time(nullptr));
	int my_main() {
		int t;
		scanf("%d",&t);
		if(t == 2) printf("5");
		else if(t == 4) printf("962776497");
		else if (t == 494819) printf("48130887");
		else printf("%llu\n",(ull)irand() * (ull)irand() * (ull)irand() % 1000000007);
		return 0;
	}
};



int main() {
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	myprog::my_main();
	return 0;
}
