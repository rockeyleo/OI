#include<bits/stdc++.h>
using namespace std;
namespace myprog {
	/*
	 * First time take place in NOIP.
	 * DFS can pass all preload testcases.
	 * but I think the final test can't be that easy.
	 * Espically for \Theta(10 ^ 9) maxium of it.
	 * May redebug it sooner.
	 * 11.26 10:03
	*/
	typedef unsigned long long int ull;
	const ull MOD = 998244353;
	ull T,testcaseid;
	ull c,f;
	bool calc_c,calc_f;
	bool garden[1050][1050];
	ull n,m;
	ull ansc = 0,ansf = 0;
	void dfs_c(ull upx,ull btx,ull ly,ull ruy,ull rby); //UpperX BottomX LeftY RightUpperY RightBottomY
	void dfs_f(ull upx,ull mdx,ull btx,ull ly,ull ruy,ull rby);//UpperX MidiumX BottomX LeftY RightUpperY RightBottomY
	int my_main() {
		scanf("%llu%llu",&T,&testcaseid);
		while(T--) {
			memset(garden,0,sizeof(garden));
			scanf("%llu%llu%llu%llu",&n,&m,&c,&f);
			calc_c = c;
			calc_f = f;
			for(ull i = 1; i <= n; i++) {
				for(ull j = 1; j <= m; j++) {
					char ch = getchar();
					while(ch < '0' or ch > '1') ch = getchar(); //Read Endl;
					garden[i][j] = ch - '0';
				}
			}
			if(calc_c) {
				dfs_c(0,0,0,0,0);
			}
			if(calc_f) {
				dfs_f(0,0,0,0,0,0);
			}
			printf("%llu %llu\n",ansc % MOD,ansf % MOD);
		}
		return 0;
	}
	void dfs_c(ull upx,ull btx,ull ly,ull ruy,ull rby) { //Use dfs search C
//		printf("%llu %llu %llu %llu %llu\n",upx,btx,ly,ruy,rby);
		if (upx && btx && ly && ruy && rby) { // Five Point got
			ansc = ansc % MOD + 1;
			return;
		}
		if(!upx && ! ly) {
			for(ull i = 1; i <= n; i++) {
				for(ull j = 1; j <= m; j++) {
					if(!garden[i][j]) {
						dfs_c(i,btx,j,ruy,rby);
					}
				}
			}
			return;
		}
		if(!btx) {
			for(ull i = upx; i <= n; i++) {
				if(garden[i][ly]) return;
				if(upx + 1 >= i) continue;
				dfs_c(upx,i,ly,ruy,rby);
			}
			return;
		}
		if(!ruy) {
			for(ull i = ly; i <= m; i++) {
				if(garden[upx][i]) return;
				if(ly == i) continue;
				dfs_c(upx,btx,ly,i,rby);
			}
			return;
		}
		if(!rby) {
			for(ull i = ly; i <= m; i++) {
				if(garden[btx][i]) return;
				if(ly == i) continue;
				dfs_c(upx,btx,ly,ruy,i);
			}
			return;
		}
	}
	void dfs_f(ull upx,ull mdx,ull btx,ull ly,ull ruy,ull rby) { //Use dfs search F
//		printf("%llu %llu %llu %llu %llu %llu\n",upx,mdx,btx,ly,ruy,rby);
		if (upx && mdx && btx && ly && ruy && rby) { // Six Point got
			ansf = ansf % MOD + 1;
			return;
		}
		if(!upx && ! ly) {
			for(ull i = 1; i <= n; i++) {
				for(ull j = 1; j <= m; j++) {
					if(!garden[i][j]) {
						dfs_f(i,mdx,btx,j,ruy,rby);
					}
				}
			}
			return;
		}
		if(!mdx) {
			for(ull i = upx; i <= n; i++) {
				if(garden[i][ly]) return;
				if(upx + 1 >= i) continue;
				dfs_f(upx,i,btx,ly,ruy,rby);
			}
			return;
		}
		if(!btx) {
			for(ull i = mdx; i <= n; i++) {
				if(garden[i][ly]) return;
				if(mdx >= i) continue;
				dfs_f(upx,mdx,i,ly,ruy,rby);
			}
			return;
		}
		if(!ruy) {
			for(ull i = ly; i <= m; i++) {
				if(garden[upx][i]) return;
				if(ly == i) continue;
				dfs_f(upx,mdx,btx,ly,i,rby);
			}
			return;
		}
		if(!rby) {
			for(ull i = ly; i <= m; i++) {
				if(garden[mdx][i]) return;
				if(ly == i) continue;
				dfs_f(upx,mdx,btx,ly,ruy,i);
			}
			return;
		}
	}
};



int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	myprog::my_main();
	return 0;
}
