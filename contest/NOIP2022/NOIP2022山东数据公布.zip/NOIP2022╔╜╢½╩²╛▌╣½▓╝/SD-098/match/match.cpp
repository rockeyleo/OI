/*
long long
MLE
Ҳûʲô��˵�ģ�ƽʱ�Ѿ���ǿ�ˣ�����ȶ����ӣ�
���ͣ���������
*/
#include<bits/stdc++.h>
#define ll long long
#define int long long
#define max(A,B) (A<B?B:A)
#define min(A,B) (A<B?A:B)
#define bug cout<<"I AK NOIP!"<<'\n';
#define gc getchar
using namespace std;
const int N=6e5+5;

inline ll read(){ll res=0,f=0;char ch=gc();for(;!isdigit(ch);ch=gc()) f=(ch=='-'?1:0);for(;isdigit(ch);ch=gc()) res=(res<<3)+(res<<1)+(ch^'0');return f?-res:res;}
int T,n,a[N],b[N],Q;
int ans,Maxa=-1,Maxb=-1;

void dfs(int l,int r)
{
	for(int i=l;i<=r;i++)
	{
		Maxa=-1,Maxb=-1;
		for(int j=i;j<=r;j++)
		{
			Maxa=max(Maxa,a[j]);
			Maxb=max(Maxb,b[j]);
			ans+=Maxa*Maxb;
		}
	}
}

signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read(),n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	Q=read();
	int q=0,p=0;
	while(Q--)
	{
		ans=0;
		q=read(),p=read();
		dfs(q,p);
		cout<<ans<<'\n';
	}
	return 0;
}
/*
0 2
2 1
1 2
3
1 2
1 2
1 2


1 6
5 2 1 6 3 4
3 4 6 5 1 2
*/


