/*
long long
MLE
Ҳûʲô��˵�ģ�ƽʱ�Ѿ���ǿ�ˣ�����ȶ����ӣ�
���ͣ���������
*/
#include<bits/stdc++.h>
#define ll long long
#define int long long
#define max(A,B) (A<B?B:A)
#define min(A,B) (A<B?A:B)
#define bug cout<<"I AK NOIP!"<<'\n';
#define gc getchar
using namespace std;
const int N=1e5+5,mod=1e9+7;

inline ll read(){ll res=0,f=0;char ch=gc();for(;!isdigit(ch);ch=gc()) f=(ch=='-'?1:0);for(;isdigit(ch);ch=gc()) res=(res<<3)+(res<<1)+(ch^'0');return f?-res:res;}

struct node{
	int to,nxt,bj;
}e[50];int head[50],cnt;
inline void add(int a,int b){e[++cnt].nxt=head[a];e[cnt].to=b;head[a]=cnt;}
int ans,n,m,a,b,jil[50],vis[50];

inline void wuy(int x,int fa,int qwq){
	vis[x]=1;
	for(int i=head[x];i;i=e[i].nxt)
	{
		int nxt=e[i].to;
		if(nxt==fa || e[i].bj==-1 || vis[nxt]) continue;
		wuy(nxt,x,qwq);
	}
}
inline int pd(int qwq){
	for(int i=1;i<=m;i++)
	{
		if(e[(i-1)*2+1].bj) continue ;
		e[(i-1)*2+1].bj=e[(i-1)*2+2].bj=-1;
		memset(vis,0,sizeof vis);
		wuy(jil[1],0,qwq);
		e[(i-1)*2+1].bj=e[(i-1)*2+2].bj=0;
		for(int i=1;i<=qwq;i++) if(!vis[jil[i]]) return 0;	
	}
	return 1;
}
inline void dfs2(int x,int qwq)
{
	if(x==m+1) {
		if(pd(qwq)) ans++;
		return ;
	}
	e[(x-1)*2+1].bj=e[(x-1)*2+2].bj=1;
 	dfs2(x+1,qwq);
	e[(x-1)*2+1].bj=e[(x-1)*2+2].bj=0;
	dfs2(x+1,qwq);
}
inline void dfs(int x,int jis,int qwq)
{
	if(jis==qwq+1){ dfs2(1,qwq);ans%=mod;return ;}
	for(int i=x;i<=n-(qwq-jis);i++) jil[jis]=i,dfs(i+1,jis+1,qwq);
}

signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++) a=read(),b=read(),add(a,b),add(b,a);
	for(int i=1;i<=n;i++) dfs(1,1,i);
	cout<<ans%mod;
	return 0;
}
/*
4 4
1 2
3 1
1 4
2 3
*/
