/*
long long
MLE
Ҳûʲô��˵�ģ�ƽʱ�Ѿ���ǿ�ˣ�����ȶ����ӣ�
���ͣ���������
*/
#include<bits/stdc++.h>
#define ll int
#define max(A,B) (A<B?B:A)
#define min(A,B) (A<B?A:B)
#define bug cout<<"I AK NOIP!"<<'\n';
#define gc getchar
using namespace std;
const int N=1e5+5;

inline ll read(){ll res=0,f=0;char ch=gc();for(;!isdigit(ch);ch=gc()) f=(ch=='-'?1:0);for(;isdigit(ch);ch=gc()) res=(res<<3)+(res<<1)+(ch^'0');return f?-res:res;}
int T,n,m,kk,a[N],Map[N][3],jis;
vector<int> vec[N];

signed main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	srand(time(0));
	T=read();
	while(T--)
	{
		n=read(),m=read(),kk=read();
		memset(Map,0,sizeof Map);
		for(int i=1;i<=m;i++)
		{
			a[i]=read();
			if(Map[a[i]][1]){
				for(int j=1;j<n;j++)
					{
					if(Map[a[i]][1]){
						cout<<1<<' '<<n<<'\n';
						cout<<2<<' '<<Map[a[i]][1]<<' '<<n<<'\n';
						vec[Map[a[i]][1]].erase(vec[Map[a[i]][1]].begin());
						Map[a[i]][1]=0;Map[a[i]][2]=0;
					}
				}
		}else {
			if(Map[a[i]][2]){
				cout<<1<<' '<<Map[a[i]][2]<<'\n';
				auto it=vec[Map[a[i]][2]].end();it--;
				vec[Map[a[i]][2]].erase(it);
				Map[a[i]][1]=0;Map[a[i]][2]=0;
			} else{
				int qwq=rand()%(n-1)+1;
				cout<<1<<' '<<qwq<<'\n';
				int wuy=vec[qwq][vec[qwq].size()-1];
				Map[vec[qwq][vec[qwq].size()-1]][1]=Map[vec[qwq][vec[qwq].size()-1]][2]=0;
				vec[qwq].push_back(a[i]);
				for(int k=1;k<n;k++) if(vec[k].size() && vec[k][0]==wuy) Map[wuy][1]=k;
				for(int k=1;k<n;k++) if(vec[k].size() && vec[k][vec[k].size()-1]==wuy) Map[wuy][2]=k;
			}
		}
		for(int k=1;k<n;k++) if(vec[k].size() && vec[k][0]==a[i]) Map[a[i]][1]=k;
		for(int k=1;k<n;k++) if(vec[k].size() && vec[k][vec[k].size()-1]==a[i]) Map[a[i]][2]=k;
	}
	}
	return 0;
}

