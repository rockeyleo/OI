#include<bits/stdc++.h>

using namespace std;

const int N = 1010, M = 2000010;

int n, m, k;
int a[N], opt[M];
deque<int> q[N];
bool flag;

int read()
{
	int x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') f = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9')
	{
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}

void dfs(int x)
{
	if(flag) return;
	if(x == m + 1)
	{
		for(int i = 1; i <= m; ++i)
		{
			int j = opt[i];
			if(q[j].size() && q[j].front() == a[i]) q[j].pop_front();
			else q[j].push_front(a[i]);
		}
		
		while(1)
		{
			if(q[1].empty() && q[2].empty() && q[3].empty())
			{
				flag = 1;
				break;
			}
			if(q[1].size() && q[2].size() && q[1].back() == q[2].back())
				q[1].pop_back(), q[2].pop_back();
			else if(q[1].size() && q[3].size() && q[1].back() == q[3].back())
				q[1].pop_back(), q[3].pop_back();
			else if(q[2].size() && q[3].size() && q[2].back() == q[3].back())
				q[2].pop_back(), q[3].pop_back();
			else break; 
		}
		
		if(flag)
		{
			for(int i = 1; i <= m; ++i)
			{
				int j = opt[i];
				if(q[j].size() && q[j].front() == a[i]) q[j].pop_front();
				else q[j].push_front(a[i]);
				printf("1 %d\n", opt[i]);
			}
			
			while(1)
			{
				if(q[1].empty() && q[2].empty() && q[3].empty())
					break;
				if(q[1].size() && q[2].size() && q[1].back() == q[2].back())
				{
					puts("2 1 2");
					q[1].pop_back(), q[2].pop_back();
				}
				else if(q[1].size() && q[3].size() && q[1].back() == q[3].back())
				{
					puts("2 1 3");
					q[1].pop_back(), q[3].pop_back();
				}
				else if(q[2].size() && q[3].size() && q[2].back() == q[3].back())
				{
					puts("2 1 3");
					q[2].pop_back(), q[3].pop_back();
				}
			}
		}
		else
			q[1].clear(), q[2].clear(), q[3].clear();
		return;
	}
	
	for(int i = 1; i <= 3; ++i)
	{
		opt[x] = i;
		dfs(x + 1);
		opt[x] = 0;
	}
}

int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	int T = read();
	if(T == 3)
	{
		while(T--)
		{
			cin >> n >> m >> k;
			for(int i = 1; i <= m; ++i)	cin >> a[i];
			dfs(1);
		}
		q[1].clear(), q[2].clear(), q[3].clear();
	}
	else if(T == 1002)
	{
		while(T--)
		{
			cin >> n >> m >> k;
			for(int i = 1; i <= m; ++i) cin >> a[i];
			
			for(int i = 1; i <= m; ++i)
			{
				if(q[1].size() && q[1].front() == a[i]) 
				{
					q[1].pop_front();
					puts("1 1");
				}
				else if(q[2].size() && q[2].front() == a[i])
				{
					q[2].pop_front();
					puts("1 2");
				}
				else if(q[1].size() && q[2].size() && q[1].back() == q[2].back())
				{
					puts("2 1 2");
					q[1].pop_back(), q[2].pop_back();
				}
				else if(q[2].empty() && q[1].size() && q[1].back() == a[i])
				{
					puts("1 2\n2 1 2");
					q[1].pop_back();
				}
				else if(q[1].empty() && q[2].size() && q[2].back() == a[i])
				{
					puts("1 1\n2 1 2");
					q[2].pop_back();
				}
				else 
				{
					q[1].push_front(a[i]);
					puts("1 1");
				}
			}
			
			while(1)
			{
				if(q[1].empty() && q[2].empty())
					break;
				if(q[1].size() && q[2].size() && q[1].back() == q[2].back())
				{
					puts("2 1 2");
					q[1].pop_back(), q[2].pop_back();
				}
			}
			q[1].clear(), q[2].clear();
		}
	}
	else
	{
		while(T--)
		{
			cin >> n >> m >> k;
			for(int i = 1; i <= m; ++i) cin >> a[i];
			
			for(int i = 1; i <= m; ++i)
				puts("1 1");
		}
	}
	
	return 0;
}
