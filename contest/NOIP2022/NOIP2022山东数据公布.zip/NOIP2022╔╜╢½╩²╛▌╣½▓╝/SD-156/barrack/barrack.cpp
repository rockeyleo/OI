#include<bits/stdc++.h>

using namespace std;

const int N = 500010, M = 2000010, mod = 1e9 + 7, INF = 0x3f3f3f3f;
typedef long long ll;
typedef pair<int,int> PII;

#define x first
#define y second

int n, m;
int d[3010][3010];
bool isy[N], canb[M];
ll ans;
PII edge[N];

int read()
{
	int x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') f = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9')
	{
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}

void print(int x)
{
	if(x < 0)
	{
		putchar('-');
		x = -x;
	}
	if(x > 9) print(x / 10);
	putchar(x % 10 + 48);
}

bool check(int s1, int s2)
{
	int cnt = 0;
	for(int i = 0; i <= max(n, m); ++i) isy[i] = canb[i] = 0;
	for(int i = 0; i < n; ++i)
		if(s1 & (1 << i))
		{
			cnt++;
			isy[i + 1] = 1;
		}
	if(cnt == 1) return true;
	for(int i = 0; i < m; ++i)
		if(!(s2 & (1 << i)))
			canb[i + 1] = 1;
	
	for(int i = 1; i <= m; ++i)
		if(canb[i])
		{
			int u = edge[i].x, v = edge[i].y;
			d[u][v] = d[v][u] = INF;
			for(int k = 1; k <= n; ++k)
				for(int i = 1; i <= n; ++i)
					for(int j = 1; j <= n; ++j)
						d[i][j] = min(d[i][j], d[i][k] + d[k][j]);		
			for(int i = 1; i <= n; ++i)
				for(int j = 1; j <= n; ++j)
					if(isy[i] && isy[j] && d[i][j] == INF)
						return false;
			d[u][v] = d[v][u] = 1;
		}
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j)
			d[i][j] = INF;
	for(int i = 1; i <= m; ++i)
	{
		int u = edge[i].x, v = edge[i].y;
		d[u][v] = d[v][u] = 1;
	}
	return true;
}

int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n = read(), m = read();
	
	memset(d, 0x3f, sizeof d);
	for(int i = 1, u, v; i <= m; ++i)
	{
		u = read(), v = read();
		d[u][v] = d[v][u] = 1;
		edge[i] = {u, v};
	}
	
	for(int i = 1; i < 1 << n; ++i)
		for(int j = 0; j < 1 << m; ++j)
		{
			if(check(i, j))
			{
				if(ans + 1 == mod) ans = 0;
				else ans++;
			}
		}
	
	print(ans);
	puts("");
	
	return 0;
}
