#include<bits/stdc++.h>

using namespace std;

const int N = 1010, mod = 998244353;
typedef long long ll;
typedef pair<int,int> PII; 

#define x first
#define y second

ll n, m, c, f;
char s[N];
int mp[N][N];
ll s1[N][N], s2[N][N];
ll ansc, ansf;
vector<PII> shu[N]; 

ll read()
{
	ll x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') f = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9')
	{
		x = (x << 3) + (x << 1) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}

void print(ll x)
{
	if(x < 0)
	{
		putchar('-');
		x = -x;
	}
	if(x > 9) print(x / 10);
	putchar(x % 10 + 48);
}

int find1(int i, int j)
{
	int l = 0, r = m - j + 1;
	while(l < r)
	{
		int mid = l + r + 1 >> 1;
		if(s1[i][j + mid - 1] - s1[i][j - 1] == 0)
			l = mid;
		else
			r = mid - 1;
	}
	return l;
}

int find2(int i, int j)
{
	int l = 0, r = n - i + 1;
	while(l < r)
	{
		int mid = l + r + 1 >> 1;
		if(s2[j][i + mid - 1] - s2[j][i - 1] == 0)
			l = mid;
		else
			r = mid - 1;
	}
	return l;
}

int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ll T = read(), id = read();
	while(T--)
	{
		n = read(), m = read(), c = read(), f = read();
		if(c == 0 && f == 0)
		{
			cout << 0 << ' ' << 0 << endl;
			continue;
		}
		for(int i = 1; i <= n; ++i)
		{
			scanf("%s", s + 1);
			for(int j = 1; j <= m; ++j)
				if(s[j] == '0') mp[i][j] = 0;
				else mp[i][j] = 1;	
		}
		
		for(int i = 1; i <= n; ++i)//���i�е�ǰ׺�� 
			for(int j = 1; j <= m; ++j)
				s1[i][j] = s1[i][j - 1] + mp[i][j];
		for(int i = 1; i <= m; ++i)//���i�е�ǰ׺�� 
			for(int j = 1; j <= n; ++j)
				s2[i][j] = s2[i][j - 1] + mp[j][i];
		
		for(int i = 1; i <= m; ++i)//��ÿһ��ȫ��0���� 
		{
			int pos = 0, len = 0;
			for(int j = 1; j <= n; ++j)
				if(mp[j][i] == 0)
				{
					if(pos == 0) pos = j;
					len++;
					if(j == n)
					{
						if(len >= 3)
							shu[i].push_back({pos, j});
					}
				}
				else
				{
					if(len >= 3)
						shu[i].push_back({pos, j - 1});
					pos = len = 0;
				}
		}
		
		for(int i = 1; i <= m; ++i)
		{
			for(PII a : shu[i])
			{
				ll l = a.x, r = a.y;
				for(int i1 = l; i1 <= r; ++i1)
				{
					ll up = find1(i1, i);
					for(int j = i1 + 2; j <= r; ++j)
					{
						ll down = find1(j, i);
						ll resc = 1ll * (up - 1) * (down - 1);
						ansc = (ansc + resc) % mod;
						if(!f) continue;
						ll ff = find2(j, i);
						ansf = (ansf + 1ll * (ff - 1) * resc) % mod;
					}	
				}
			}
		}
		
		print(1ll * ansc * c % mod), putchar(' '), print(1ll * ansf * f % mod), puts("");
		ansc = ansf = 0;
		for(int i = 1; i <= n; ++i)
		{
			shu[i].clear();
			for(int j = 1; j <= m; ++j)
				mp[i][j] = s1[i][j] = s2[i][j] = 0;
		}
	}
	return 0;
}
