#include <bits/stdc++.h>

#define Heriko return
#define Deltana 0
#define Yoisaki return
#define Kanade 1
#define I inline
#define LL long long
#define CI const int
#define CL const long long
#define mst(a, b) memset(a, b, sizeof(a))
#define mkp(a, b) make_pair(a, b)

using namespace std;

template<typename J>
I void fr(J &x) {
	x = 0;
	short f(1);
	char c(getchar());

	while(c < '0' or c > '9') {
		if(c == '-')
			f = -1;

		c = getchar();
	}

	while('0' <= c and c <= '9') {
		x = (x << 1) + (x << 3) + (c ^= 48);
		c = getchar();
	}

	x *= f;
}

template<typename J>
I void fw(J x, bool k) {
	if(x < 0)
		x = -x, putchar('-');

	static short stk[35];
	short top(0);

	do {
		stk[top ++] = x % 10;
		x /= 10;
	}
	while(x);

	while(top)
		putchar(stk[-- top] + '0');

	k ? puts("") : putchar(' ');
}

template<typename J>
I J Hmax(const J &x, const J &y) {
	Heriko x > y ? x : y;
}

template<typename J>
I J Hmin(const J &x, const J &y) {
	Heriko x < y ? x : y;
}

CL MXX(1005), MOD(998244353);

char s[MXX][MXX];

int c[MXX][MXX], d[MXX][MXX], n, m;

LL cx, fx;

vector< pair<int, int> > v;

signed main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	
	int T, id;
	fr(T), fr(id);
	
	while(T --) {
		fr(n), fr(m), fr(cx), fr(fx);
		LL ansc(0), ansf(0);
		v.clear();
		
		for(int i(1); i <= n; ++ i)
			scanf("%s", s[i] + 1);
			
		for(int i(1); i <= n; ++ i)
			for(int j(1); j <= m; ++ j)
				c[i][j] = d[i][j] = 0;
			
		int cnt(0);

		for(int i(1); i <= n; ++ i) {
			cnt = 0;

			for(int j(m); j; -- j) {
				if(s[i][j] == '1')
					cnt = 0;
				else
					c[i][j] = ++ cnt;
			}
		}
		
		cnt = 0;
		
		for(int j(1); j <= m; ++ j) {
			cnt = 0;
			
			for(int i(n); i; -- i) {
				if(s[i][j] == '1')
					cnt = 0;
				else
					d[i][j] = ++ cnt;
			}
		}
		
		for(int j(1); j <= m; ++ j) {
			for(int i(1); i <= n; ++ i)
				if(s[i][j] == '1')
					v.push_back(mkp(-1, -1));
				else if(c[i][j] >= 2)
					v.push_back(mkp(c[i][j], i));
					
			v.push_back(mkp(-1, m));
		}
		
		int tmp(1);
		
		for(int i(0); i < (int)v.size(); ++ i) {
			if(v[i].first == -1) {
				if(v[i].second == m)
					++ tmp;
				
				continue;
			}
			
			for(int j(i + 1); j < (int)v.size(); ++ j) {
				if(v[j].first == -1)
					break;
				
				if(v[i].second + 1 < v[j].second) {
					LL val(1ll * (v[i].first - 1ll) * (v[j].first - 1ll) % MOD);
					ansc = (ansc + val) % MOD;
					ansf = (ansf + val * 1ll * (d[v[j].second][tmp] - 1ll) % MOD) % MOD;
				}
			}
		}

		fw(cx * ansc % MOD, 0), fw(fx * ansf % MOD, 1);
	}

	Heriko Deltana;
}

