#include <bits/stdc++.h>

#define Heriko return
#define Deltana 0
#define Yoisaki return
#define Kanade 1
#define I inline
#define LL long long
#define CI const int
#define CL const long long
#define ULL unsigned long long
#define mst(a, b) memset(a, b, sizeof(a))
#define mkp(a, b) make_pair(a, b)

using namespace std;

template<typename J>
I void fr(J &x) {
	x = 0;
	short f(1);
	char c(getchar());

	while(c < '0' or c > '9') {
		if(c == '-')
			f = -1;

		c = getchar();
	}

	while('0' <= c and c <= '9') {
		x = (x << 1) + (x << 3) + (c ^= 48);
		c = getchar();
	}

	x *= f;
}

template<typename J>
I void fw(J x, bool k) {
	if(x < 0)
		x = -x, putchar('-');

	static short stk[35];
	short top(0);

	do {
		stk[top ++] = x % 10;
		x /= 10;
	}
	while(x);

	while(top)
		putchar(stk[-- top] + '0');

	k ? puts("") : putchar(' ');
}

template<typename J>
I J Hmax(const J &x, const J &y) {
	Heriko x > y ? x : y;
}

template<typename J>
I J Hmin(const J &x, const J &y) {
	Heriko x < y ? x : y;
}

CI MXX(2e6 + 5);

int n, a[MXX][22], b[MXX][22], q;

ULL ans;

I ULL QueryA(int l, int r) {
	int tmp(log2(r - l + 1));
	
	Heriko Hmax(a[l][tmp], a[r - (1 << tmp) + 1][tmp]);
}

I ULL QueryB(int l, int r) {
	int tmp(log2(r - l + 1));
	
	Heriko Hmax(b[l][tmp], b[r - (1 << tmp) + 1][tmp]);
}

signed main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	
	int T;
	fr(T), fr(n);

	for(int i(1); i <= n; ++ i)
		fr(a[i][0]);
		
	for(int i(1); i <= n; ++ i)
		fr(b[i][0]);
		
	for(int lg(1); lg <= 21; ++ lg)
		for(int i(1); i <= n; ++ i) {
			a[i][lg] = Hmax(a[i][lg - 1], a[i + (1 << (lg - 1))][lg - 1]);
			b[i][lg] = Hmax(b[i][lg - 1], b[i + (1 << (lg - 1))][lg - 1]);
		}

	fr(q);
	
	while(q --) {
		int lx, rx;
		fr(lx), fr(rx), ans = 0;
		
		for(int len(1); len <= (rx - lx + 1); ++ len)
			for(int l(lx), r(lx + len - 1); r <= rx; ++ l, ++ r)
				ans += QueryA(l, r) * QueryB(l, r);
				
		fw(ans, 1);
	}

	Heriko Deltana;
}

/*
Never Gonna Give You Up ( x )

Give Up and Retire From OI ( ��)

2021 - 2022.

I am stupid, always a fool. 
*/

