#include <bits/stdc++.h>

#define Heriko return
#define Deltana 0
#define Yoisaki return
#define Kanade 1
#define I inline
#define LL long long
#define CI const int
#define CL const long long
#define mst(a, b) memset(a, b, sizeof(a))
#define mkp(a, b) make_pair(a, b)

using namespace std;

template<typename J>
I void fr(J &x) {
	x = 0;
	short f(1);
	char c(getchar());

	while(c < '0' or c > '9') {
		if(c == '-')
			f = -1;

		c = getchar();
	}

	while('0' <= c and c <= '9') {
		x = (x << 1) + (x << 3) + (c ^= 48);
		c = getchar();
	}

	x *= f;
}

template<typename J>
I void fw(J x, bool k) {
	if(x < 0)
		x = -x, putchar('-');

	static short stk[35];
	short top(0);

	do {
		stk[top ++] = x % 10;
		x /= 10;
	}
	while(x);

	while(top)
		putchar(stk[-- top] + '0');

	k ? puts("") : putchar(' ');
}

template<typename J>
I J Hmax(const J &x, const J &y) {
	Heriko x > y ? x : y;
}

template<typename J>
I J Hmin(const J &x, const J &y) {
	Heriko x < y ? x : y;
}

CL MXX(1e6 + 5), MOD(1e9 + 7);

I LL FstPow(LL x, LL y = MOD - 2) {
	x %= MOD;
	LL res(1);
	
	while(y) {
		if(y & 1)
			(res *= x) %= MOD;
			
		(x *= x) %= MOD;
		y >>= 1;
	}
	
	Heriko res;
}

int n, m;

struct Edge {
	int nex, to, val;
}

r[MXX << 1];

int rcnt, head[MXX];

I void ADD(int x, int y) {
	r[++ rcnt] = (Edge){head[x], y, 0}, head[x] = rcnt;
	r[++ rcnt] = (Edge){head[y], x, 0}, head[y] = rcnt;
}

LL ans(0);

signed main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	
	fr(n), fr(m);
	
	for(int i(1); i <= m; ++ i) {
		int x, y;
		fr(x), fr(y);
		ADD(x, y);
	}
	
	ans = FstPow(2, m) % MOD;
	fw(1 + n * n % MOD * FstPow(2, m - 1) % MOD, 1);

	Heriko Deltana;
}

