#include <bits/stdc++.h>

#define Heriko return
#define Deltana 0
#define Yoisaki return
#define Kanade 1
#define I inline
#define LL long long
#define CI const int
#define CL const long long
#define mst(a, b) memset(a, b, sizeof(a))
#define mkp(a, b) make_pair(a, b)

using namespace std;

template<typename J>
I void fr(J &x) {
	x = 0;
	short f(1);
	char c(getchar());

	while(c < '0' or c > '9') {
		if(c == '-')
			f = -1;

		c = getchar();
	}

	while('0' <= c and c <= '9') {
		x = (x << 1) + (x << 3) + (c ^= 48);
		c = getchar();
	}

	x *= f;
}

template<typename J>
I void fw(J x, bool k) {
	if(x < 0)
		x = -x, putchar('-');

	static short stk[35];
	short top(0);

	do {
		stk[top ++] = x % 10;
		x /= 10;
	}
	while(x);

	while(top)
		putchar(stk[-- top] + '0');

	k ? puts("") : putchar(' ');
}

template<typename J>
I J Hmax(const J &x, const J &y) {
	Heriko x > y ? x : y;
}

template<typename J>
I J Hmin(const J &x, const J &y) {
	Heriko x < y ? x : y;
}

CI NXX(305), MXX(2e6 + 5);

int n, m, k, a[MXX], hd[NXX], ln[NXX], v[NXX][2005], co[NXX << 1];

vector<int> ans1;
vector< pair<int, int> > ans2;

signed main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	
	int T;
	fr(T);
	
	while(T --) {
		fr(n), fr(m), fr(k), mst(v, 0);
		int cnt(0), tot(0);
		ans1.clear(), ans2.clear();
	
		for(int i(1); i <= m; ++ i)
			fr(a[i]), ++ co[a[i]];
			
		for(int i(1); i <= n; ++ i)
			hd[i] = ln[i] = 0;
			
		for(int i(1); i <= m; ++ i) {
			for(int j(1); j <= n; ++ j) {
				if(v[j][ln[j]] == a[i]) {
					ans1.push_back(j);
					-- ln[j], ++ tot, co[a[i]] -= 2;
					
					if(co[a[i]] == 0)
						++ cnt;

					break;
				}
				
				if(v[j][ln[j]] < a[i]) {
					ans1.push_back(j);
					v[j][++ ln[j]] = a[i], ++ tot;
					
					break;
				}
			}
		}
		
		for(int i(1); i <= n; ++ i) {
			if(cnt == m)
				break;
				
			if(hd[i] > ln[i])
				continue;
			
			for(int j(i + 1); j <= n; ++ j) {
				if(hd[j] > ln[j])
					continue;
				
				if(v[i][hd[i]] == v[j][hd[j]]) {
					ans2.push_back(mkp(i, j));
					++ hd[i], ++ hd[j];
					++ tot;
					co[v[i][hd[i]]] -= 2;
					
					if(co[v[i][hd[i]]] == 0)
						++ cnt;
				}
				
				if(cnt == m)
					break;
			}
			
			if(cnt == m)
				break;
		}
		
		fw(tot, 1);
		
		for(int i(0); i < (int)ans1.size(); ++ i)
			fw(1, 0), fw(ans1[i], 1);
			
		for(int i(0); i < (int)ans2.size(); ++ i)
			fw(2, 0), fw(ans2[i].first, 0), fw(ans2[i].second, 1);
	}

	Heriko Deltana;
}

