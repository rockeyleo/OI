/*���� 62+15+15+8=������100*/
/*������ ɶ�������� ׼��AFO*/
/*freopen("match3.in","r",stdin);freopen("match3.in","w",stout);freopen("match3.out","r",stdin);*/ 
/*freopen("match3.in",stdin,"r");freopen("match.txt");freopen("match3.out","r",stdin);I love kkksc03 and chen_zhe */ 
/*��ӭд���Ի��������ȥ ������˾� ͦ�Ի�� y0 y1 cmath scanf(114514)1919810 ��Ц��*/
/*do_while_true AK NOIP!*/
/*Rocky Bunnie=Hiensou=Yue Ai Yue Ye=Spin Eternally=SH*T;regular-10=coming s��n*/
/*awask=trash*/
#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN=1e5+10,MAXM=1e6+10;
inline int F_read()
{
	char c=getchar();int u=0,v=1;
	while(c>'9'||c<'0')v=(c=='-'?0:1),c=getchar();
	while(c<='9'&&c>='0')u=(u<<3)+(u<<1)+(c^48),c=getchar();
	return (v?u:-u);
}
int a[3008],b[3008],n,m,id;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	id=F_read();n=F_read();
	for(int i=1;i<=n;i++)a[i]=F_read();
	for(int i=1;i<=n;i++)b[i]=F_read();
	m=F_read();
	for(int i=1;i<=m;i++)
	{
		int l=F_read(),r=F_read();
		unsigned long long ans=0;
		for(int j=l;j<=r;j++)
			for(int k=j;k<=r;k++)
			{
				int maxnum1=a[j],maxnum2=b[j];
				for(int l=j+1;l<=k;l++)maxnum1=max(maxnum1,a[l]),maxnum2=max(maxnum2,b[l]);
				ans+=maxnum1*maxnum2;
			}
		cout<<ans<<endl;
	}
	return 0;
}
