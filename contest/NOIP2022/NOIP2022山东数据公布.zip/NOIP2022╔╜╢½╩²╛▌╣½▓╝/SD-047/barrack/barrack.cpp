#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN=5e5+10,MAXM=2e6+10,mod=1e9+7;
typedef long long LL;
inline int F_read()
{
	char c=getchar();int u=0,v=1;
	while(c>'9'||c<'0')v=(c=='-'?0:1),c=getchar();
	while(c<='9'&&c>='0')u=(u<<3)+(u<<1)+(c^48),c=getchar();
	return (v?u:-u);
}
int n,m,ans;
int pow2[MAXM];
int a[3008][3008];
int edg[5008][2];
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	pow2[0]=1;
	for(int i=1;i<=MAXM-114514;i++)pow2[i]=(pow2[i-1]*2)%mod;
	n=F_read();m=F_read();
	LL ans=pow2[n+m]-pow2[m];
	if(ans<0)ans+=mod;
	printf("%lld",ans);
	return 0;
} 
