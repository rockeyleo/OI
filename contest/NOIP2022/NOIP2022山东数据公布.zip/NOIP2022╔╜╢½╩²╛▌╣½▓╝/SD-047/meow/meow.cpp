/*3k����ƭ30�֣��������ң�����������Сʱ����ʱ��˳��������*/
#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN=1e5+10,MAXM=1e6+10;
inline int F_read()
{
	char c=getchar();int u=0,v=1;
	while(c>'9'||c<'0')v=(c=='-'?0:1),c=getchar();
	while(c<='9'&&c>='0')u=(u<<3)+(u<<1)+(c^48),c=getchar();
	return (v?u:-u);
}
int T,n,m,k,tend;
int a[3000008];
int h[3000008][3],h1=0,h2=0;
int ans[6000008][3],ansnum;
void fir()
{
	ansnum=0;
	int yc[3]={1,2,3};
	for(int i=1;i<=m;i++)
	{
		if(a[i]==a[i+1])
		{
			ans[++ansnum][0]=1,ans[ansnum][1]=1;
			ans[++ansnum][0]=1,ans[ansnum][1]=1;
			i++;
			continue;
		}
		if(a[i]==h[h1][0]){ans[++ansnum][0]=1,ans[ansnum][1]=1;h1--;continue;}
		if(a[i]==h[h2][1]){ans[++ansnum][0]=1,ans[ansnum][1]=2;h2--;continue;}
		if(h1==0){ans[++ansnum][0]=1,ans[ansnum][1]=1;h[++h1][0]=a[i];continue;}
		if(h2==0){ans[++ansnum][0]=1,ans[ansnum][1]=2;h[++h2][1]=a[i];continue;}
		if(a[i+1]==h[h1][0]){ans[++ansnum][0]=1,ans[ansnum][1]=2;h[++h2][1]=a[i];continue;}
		ans[++ansnum][0]=1,ans[ansnum][1]=1;h[++h1][0]=a[i];
	}
	printf("%d\n",ansnum+h1);
	for(int i=1;i<=ansnum;i++)printf("%d %d\n",ans[i][0],ans[i][1]);
	while(h1)h1--,printf("2 1 2\n");
}
void sec()//����1~3
{
	//����ÿһ�� ��n-1Ϊ�ָ� 
	ansnum=0;
	int r[400][3]={0},N=n-1;
	for(int i=1;i<=m;i++)
	{
		if(a[i]>N)
		{
			if(r[a[i]-N][1]==1&&r[a[i]-N][2]==2)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i]-N;
				r[a[i]-N][2]=0;//ԭ�������д�� 
			}
			else if(r[a[i]-N][1]==2&&r[a[i]-N][2]==1)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=n;
				ans[++ansnum][0]=2,ans[ansnum][1]=a[i]-N,ans[ansnum][2]=n;
				r[a[i]-N][1]=1,r[a[i]-N][2]=0;
			}
			else if(r[a[i]-N][1]==2&&r[a[i]-N][2]==0)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i]-N;
				r[a[i]-N][1]=0;
			}
			else if(r[a[i]-N][1]==0&&r[a[i]-N][2]==0)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i]-N;
				r[a[i]-N][1]=2;
			}
			else if(r[a[i]-N][1]==1&&r[a[i]-N][2]==0)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i]-N;
				r[a[i]-N][2]=2;
			}
		}
		else
		{
			if(r[a[i]][1]==1&&r[a[i]][2]==2)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=n;
				ans[++ansnum][0]=2,ans[ansnum][1]=a[i],ans[ansnum][2]=n;
				r[a[i]][1]=2,r[a[i]][2]=0;
			}
			else if(r[a[i]][1]==2&&r[a[i]][2]==1)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i];
				r[a[i]][2]=0;
			}
			else if(r[a[i]][1]==2&&r[a[i]][2]==0)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i];
				r[a[i]][2]=1;
			}
			else if(r[a[i]][1]==0&&r[a[i]][2]==0)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i];
				r[a[i]][1]=1;
			}
			else if(r[a[i]][1]==1&&r[a[i]][2]==0)
			{
				ans[++ansnum][0]=1,ans[ansnum][1]=a[i];
				r[a[i]][2]=0;
			}
		}
	}
	printf("%d\n",ansnum);
	for(int i=1;i<=ansnum;i++)
	{
		printf("%d",ans[i][0]);
		if(ans[i][0]==1)printf(" %d\n",ans[i][1]);
		else printf(" %d %d\n",ans[i][1],ans[i][2]);
	}
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=F_read();tend=T%10;
	while(T--)
	{
		n=F_read();m=F_read();k=F_read();
		for(int i=1;i<=m;i++)a[i]=F_read();
		if(n==2&&k==3)fir();
		else if(k==2*n-2)sec();
	//	else if(n==3&&k==5)las();
	}
	return 0;
} 
