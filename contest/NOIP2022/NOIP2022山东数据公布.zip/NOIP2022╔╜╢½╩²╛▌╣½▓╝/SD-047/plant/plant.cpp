/*rp++
/ 9:40
/ eg_3 114 514
/��ǰԤ���÷֣�62pts */
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN=1e3+10,mod=998244353;
typedef long long LL;
inline int F_read()
{
	char c=getchar();int u=0,v=1;
	while(c>'9'||c<'0')v=(c=='-'?0:1),c=getchar();
	while(c<='9'&&c>='0')u=(u<<3)+(u<<1)+(c^48),c=getchar();
	return (v?u:-u);
}
LL ans,cnum,fnum,cans,fans;
int a[MAXN][MAXN],k1[MAXN][MAXN],k2[MAXN][MAXN],T,id;
//k1[i][j]��ʾa[i][j]����ж��ٸ�������0�������� 
//k2[i][j]��ʾa[i][j]�����ж��ٸ�������0�������� 
int n,m;
void dfs()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if(k1[i][j]>=2&&k2[i][j]>=3)
			{
				for(int k=2;k<=k2[i][j]-1;k++)
				{
				//	cout<<i<<' '<<j<<' '<<k+i<<endl;
					if(k1[k+i][j]>=2)
					{
						LL dec=(k1[i][j]-1)*(k1[i+k][j]-1)%mod;
				//		cout<<dec<<' ';
						cans=(cans+dec)%mod;
						fans=(fans+dec*(k2[i][j]-k-1))%mod;
					}
				}
			}
		}
	cans*=cnum;
	fans*=fnum;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=F_read();id=F_read();
	if(id==1)
	{
		for(int i=1;i<=T;i++)
			printf("0 0\n");
		return 0;
	}
	while(T--)
	{
		ans=0;cans=0;fans=0;
		n=F_read();m=F_read();cnum=F_read();fnum=F_read();
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
			{
				char c=getchar();
				while(c!='1'&&c!='0')c=getchar();
				a[i][j]=c^48;
			}
		for(int i=1;i<=n;i++)
		{
			int zerosum=0;
			for(int j=m;j>=1;j--)
			{
				if(a[i][j]==1)zerosum=0;
				else zerosum++;
				k1[i][j]=zerosum;
			}
		}
		for(int i=1;i<=m;i++)
		{
			int zerosum=0;
			for(int j=n;j>=1;j--)
			{
				if(a[j][i]==1)zerosum=0;
				else zerosum++;
				k2[j][i]=zerosum;
			}
		}
		dfs();
		printf("%lld %lld\n",cans,fans);
	}
	return 0;
} 
