#include<bits/stdc++.h>
using namespace std;

int T,id;
int n,m,c,f;
char a[1009][1009];
int ansc[9],ansf[9];
long long mod=998244353;

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	for(int l=1;l<=T;l++){
		cin>>n>>m>>c>>f;
		ansc[l]=0;
     	ansf[l]=0;
     	for(int i=1;i<=n;i++){
    		for(int j=1;j<=m;j++){
    			cin>>a[i][j];
    		}
    	}
	    for(int i=1;i<=n;i++){
    		for(int j=1;j<=m;j++){
    		    if(a[i][j] == '0' && (a[i+1][j] == '0' && a[i+2][j] == '0')){
    		    	if(a[i][j+1] == '0' && a[i+2][j+1] == '0'){
    		    		ansc[l]++;
					}
					if(a[i][j+1] == '0' && (a[i][j+2] == '0' && a[i+2][j+1] == '0')){
						ansc[l]++;
					}
					if(a[i][j+1] == '0' && (a[i+2][j+2] == '0' && a[i+2][j+1] == '0')){
						ansc[l]++;
					}
					if((a[i][j+1] == '0' && a[i][j+2] == '0' )&& (a[i+2][j+1] == '0' && a[i+2][j+2] == '0')){
						ansc[l]++;
						if(a[i][j+3] == '0' && a[i+2][j+3]){
							ansc[l]+=2;
							if(a[i][j+4] == '0' && a[i+2][j+4]){
					    		ansc[l]+=2;
					    		if(a[i][j+5] == '0' && a[i+2][j+5]){
				    	    		ansc[l]+=2;
				    	    	}
					    	}
						}
						
					}
    			}
    			if((a[i][j] == '0' && a[i+1][j] == '0' )&& (a[i+2][j] == '0' && a[i+3][j] == '0')){
    				if(a[i][j+1] == '0' && a[i+3][j+1] == '0'){
    					ansc[l]++;
					}
					if(a[i][j+1] == '0' && a[i+3][j+1] == '0' && a[i][j+2] == '0'){
						ansc[l]++;
					}
					if(a[i][j+1] == '0' && a[i+3][j+1] == '0' && a[i+3][j+2] == '0'){
						ansc[l]++;
					}
					if(a[i][j+1] == '0' && a[i+3][j+1] == '0' && a[i][j+2] == '0' && a[i+3][j+2] == '0'){
						ansc[l]++;
						if(a[i][j+3] == '0' && a[i+3][j+3]){
							ansc[l]+=2;
							if(a[i][j+4] == '0' && a[i+3][j+4]){
					    		ansc[l]+=2;
					    		if(a[i][j+5] == '0' && a[i+3][j+5]){
					        		ansc[l]+=2;
					        	}
					    	}
						}
					}
				}
    			if((a[i][j] == '0' && a[i+1][j] == '0' )&& (a[i+2][j] == '0' && a[i+3][j] == '0')){
    			    if(a[i][j+1] == '0' && a[i+2][j+1] == '0' ){
    			    	ansf[l]++;
					}
					if(a[i][j+1] == '0' && (a[i][j+2] == '0' && a[i+2][j+1] == '0')){
						ansf[l]++;
					}
					if(a[i][j+1] == '0' && (a[i+2][j+2] == '0' && a[i+2][j+1] == '0')){
						ansf[l]++;
					}
					if((a[i][j+1] == '0' && a[i][j+2] == '0' )&& (a[i+2][j+1] == '0' && a[i+2][j+2] == '0')){
						ansf[l]++;
					}
				}
    		}
    	}
   		ansc[l] = (ansc[l]*c) % mod;
		ansf[l] = (ansf[l]*f) % mod;
	}
	for(int l=1;l<=T;l++){
		if(c == 0 && f == 0){
			ansc[l] = 0;
			ansf[l] = 0;
		}
		else if(c == 0){
			ansc[l] = 0;
			ansf[l]=ansf[l];
		}
		else if(f == 0){
			ansf[l] = 0;
			ansc[l] = ansc[l];
		}
		else if(c != 0 && f != 0){
			ansc[l]=ansc[l];
			ansf[l]=ansf[l];
		}
		cout<<ansc[l];
		cout<<" ";
		cout<<ansf[l];
		cout<<endl;
	}
	return 0;
}
/*
1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

*/
