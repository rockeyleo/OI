#include<bits/stdc++.h>
using namespace std;

int n,m;
int u[50000],v[50000];
long long mod=1000000007;
int ans=1,tot,pd[50000];

int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	tot=0;
	for(int i=1;i<=m;i++){
		cin>>u[i]>>v[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
	    	if(u[i] == u[j] || u[i] == v[j] || v[i] == v[j])
	    	tot++;
		}
    	if(m == 1){
    		ans=n*2+1;
    	}
    	if(m>=2){
    		ans=n*46;
		}
	}
	ans=ans%mod;
	cout<<ans;
	return 0;
}
