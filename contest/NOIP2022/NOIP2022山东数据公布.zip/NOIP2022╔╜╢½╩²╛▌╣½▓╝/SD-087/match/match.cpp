#include<bits/stdc++.h>
using namespace std;

int T,n;
int a[250000],b[250000];
int Q;
int l[250000],r[250000];
int ans[250000],tot;
long long minn=1,mino=1;
int p,q;

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	cin>>Q;
	for(int j=1;j<=Q;j++){
		cin>>l[j]>>r[j];
		for(int i=l[j];i<=r[j];i++){
			for(int l=i;l>=1;l--){
			    if(a[i]>=minn){
			    	minn = a[l];
				}
				if(b[i]>=mino){
					mino=b[l];
				}
				ans[j]+=minn*mino;
			}
			//ans[j]+=a[i]*b[i];
		}
	}
	for(int j=1;j<=Q;j++){
		printf("%d\n",ans[j]);
		
	}
	return 0;
}
