#include<bits/stdc++.h>
using namespace std;

int T,n,m,k,op[1009];
int a[4090];
int cz[4090]

int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>T;
	for(int l=1;l<=T;l++){
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++){
			cin>>a[i];
		}
		if(k == 1){
			op[l] == m;
		}
		if(n==2 ){
			if(k>=2){
				op[l]=n*k+1;
			}
			
		}
		
	}
	for(int l=T;l<=T;l++){
		if(k == m){
			cout<<op[l]<<endl;
    		for(int i=1;i<=op[l];i++){
    			cout<<"1"<<" "<<"1"<<endl;
    	    }
		}
		else{
			cout<<op[l]<<endl;
			for(int i=1;i<=op[l];i++){
				cout<<"1"<<" "<<"2"<<endl;
			}
		}
	}
	
	return 0;
}
