#include<iostream>
#include<cstdio>
#include<stack>
#include<cstring>
using namespace std;
stack<int>nf;
int cds[2000006];
bool tp[1005];
int num[1005];
int ctp[305];
int ced[305];
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T;
	scanf("%d",&T);
	int n,m,k;
	int u;
	while(T--){
		memset(tp,0x00,sizeof tp);
		memset(num,0x00,sizeof num);
		memset(ctp,0x00,sizeof ctp);
		memset(ced,0x00,sizeof ced);
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<n;++i){
			nf.push(i);
		}
		for(int i=1;i<=m;++i){
			scanf("%d",&cds[i]);
		}
		if(k==2*n-2){
			for(int i=1;i<=m;++i){
				if(num[cds[i]]!=0){
					if(tp[cds[i]]){
						cout<<1<<' '<<num[cds[i]]<<'\12';
						nf.push(cds[i]);
						ctp[num[cds[i]]]=0;
						num[cds[i]]=0;
					}
					else{
						cout<<1<<' '<<n<<'\12';
						cout<<2<<' '<<num[cds[i]]<<' '<<n<<'\12';
						if(ctp[num[cds[i]]]!=0)nf.push(num[cds[i]]);
						ced[num[cds[i]]]=ctp[num[cds[i]]];
						ctp[num[cds[i]]]=0;
						if(ced[num[cds[i]]]!=0){
							tp[ced[num[cds[i]]]]=false;
						}
						num[cds[i]]=0;
					}
				}
				else{
					cout<<1<<' '<<nf.top()<<'\12';
					num[cds[i]]=nf.top();
					if(ced[num[cds[i]]]!=0){
						ctp[num[cds[i]]]=cds[i];
						tp[cds[i]]=true;
						nf.pop();
					}
					else{
						ced[num[cds[i]]]=cds[i];
						tp[cds[i]]=false;
					}
				}
			}
		}
		else{
			bool pd=false;
			u=n;
			for(int i=1;i<=m;++i){
				if(num[cds[i]]!=0){
					if(tp[cds[i]]){
						cout<<1<<' '<<num[cds[i]]<<'\12';
						nf.push(cds[i]);
						ctp[num[cds[i]]]=0;
						num[cds[i]]=0;
					}
					else{
						if(pd){
							if(ctp[num[cds[i]]]==0){
								cout<<1<<' '<<num[cds[i]]<<'\12';
								ced[num[cds[i]]]=0;
								u=num[cds[i]];
								num[cds[i]]=0;
								pd=false;
							}
							else{
								cout<<"qwq";
								break;
							}
						}		
						cout<<1<<' '<<u<<'\12';
						cout<<2<<' '<<num[cds[i]]<<' '<<u<<'\12';
						if(ctp[num[cds[i]]]!=0)nf.push(num[cds[i]]);
						ced[num[cds[i]]]=ctp[num[cds[i]]];
						ctp[num[cds[i]]]=0;
						if(ced[num[cds[i]]]!=0){
							tp[ced[num[cds[i]]]]=false;
						}
						num[cds[i]]=0;
					}
				}
				else{
					if(nf.top()==u&&ced[nf.top()]==0){
						nf.pop();
						pd=false;
					}
					if(nf.empty()){
						if(tp[cds[i+1]]==false){
							cout<<1<<' '<<num[cds[i+1]]<<'\12';
							cout<<1<<' '<<u;
							cout<<2<<' '<<u<<' '<<num[cds[i+1]]<<'\12';
							ced[num[cds[i+1]]]=ctp[num[cds[i+1]]];
							ctp[num[cds[i+1]]]=cds[i];
							num[cds[i]]=num[cds[i+1]];
							num[cds[i+1]]=0;
							tp[ced[num[cds[i]]]]=false;
							tp[cds[i]]=true;
							++i;
							continue;
						}
						nf.push(u);
						pd=true;
						u=0;
					}
					cout<<1<<' '<<nf.top();
					num[cds[i]]=nf.top();
					if(ced[num[cds[i]]]!=0){
						ctp[num[cds[i]]]=cds[i];
						tp[cds[i]]=true;
						nf.pop();
					}
					else{
						ced[num[cds[i]]]=cds[i];
						tp[cds[i]]=false;
					}
				}
			}
		}
	}
}
//30~100
/*
I just solve the participies that k = 2n-2.
just use the n-1 to save them.
and the last is used to 2.
*/
