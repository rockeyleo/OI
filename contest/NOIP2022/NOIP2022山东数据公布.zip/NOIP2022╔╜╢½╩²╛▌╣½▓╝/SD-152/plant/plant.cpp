#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int mp[1007][1007];
int s1[1007][1007];
int r1[1007][1007];
long long s2[1007][1007];
long long s3[1007][1007];
#define MOD 998244353
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id;
	int n,m;
	scanf("%d%d",&T,&id);
	char c;
	int i,j;
	int C,F;
	long long ans1,ans2;
	while(T--){
		scanf("%d%d%d%d",&n,&m,&C,&F);
		memset(mp,0x00,sizeof mp);
		memset(s1,0x00,sizeof s1);
		memset(s2,0x00,sizeof s2);
		memset(r1,0x00,sizeof r1);
		memset(s3,0x00,sizeof s3);
		for(i=1;i<=n;++i){
			for(j=1;j<=m;++j){
				do{
					c=(char)getchar();
				}while(c<'0'||c>'1');
				mp[i][j]='1'-c;
			}
		}
		
		for(i=n;i>=1;--i){
			s1[i][m+1]=0;
			for(j=m;j>=1;--j){
				if(mp[i][j]==1){
					s1[i][j]=s1[i][j+1]+1;
				}
			}
		}
		for(j=1;j<=m;++j){
			for(i=n;i>=1;--i){
				if(mp[i][j]==1){
					r1[i][j]=r1[i+1][j]+1; 
				}
			}
		}
		for(j=1;j<=m;++j){
			for(i=n;i>=1;--i){
				if(mp[i][j]==1){
					s2[i][j]=(s2[i+1][j]+s1[i][j]-1)%MOD;
					s3[i][j]=(s3[i+1][j]+(r1[i][j]-1)*(s1[i][j]-1)%MOD)%MOD;
				}
			}
		}
		ans1=0;
		ans2=0;
		for(i=1;i<n;++i){
			for(j=1;j<m;++j){
				if(mp[i][j]==1&&mp[i+1][j]==1){
					ans1=(ans1+(s1[i][j]-1)*(s2[i+2][j])%MOD)%MOD;
					ans2=(ans2+(s1[i][j]-1)*(s3[i+2][j])%MOD)%MOD;
				}
			}
		}
		cout<<(ans1*C)%MOD<<' '<<(ans2*F)%MOD<<'\12';
	}
	return 0;
}
//100
/*
When receive the problem,the limit of n and m means that the time must below n square,or with a log.
Then I solve it with the n square time.
Easy to find that the C must be composed with two lines and a line to connect them.
So we just conduct the second line.
Easy to find that the solutions is the number that are below and connect with a line.
So we just give it a sum and divide it.
The next Problem is F.
We could find that the F is no more than C without a line.
So we just times the num in a line with the nums below.
And then Solve it like C.
*/
