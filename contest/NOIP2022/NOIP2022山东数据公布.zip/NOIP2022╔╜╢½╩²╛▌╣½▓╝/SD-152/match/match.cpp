#include<iostream>
#include<cstdio>
using namespace std;
int inp[250005];
struct node{
	int l,r;
	int mx;
	node*lc,*rc;
	void pushup(void){
		mx=max(lc->mx,rc->mx);
	}
	void build(int L,int R){
		l=L,r=R;
		if(l==r){
			mx=inp[l];
			lc=rc=nullptr;
			return;
		}
		lc=new node;
		rc=new node;
		lc->build(L,(L+R)>>1);
		rc->build(((L+R)>>1)+1,R);
		pushup();
	}
	int ask(int L,int R){
		if(L<=l&&R>=r){
			return mx;
		}
		if(L>r||l>R){
			return 0;
		}
		else return max(lc->ask(L,R),rc->ask(L,R));
	}
};
void read(int&ans){
	ans=0;
	int us=getchar();
	while(us<48||us>57)us=getchar();
	while(us>47&&us<58){
		ans=(ans<<1)+(ans<<3)+(us^48);
		us=getchar();
	}
}
node*roota;
node*rootb;
unsigned long long s1[4005][4005];
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T,n,i;
	read(T);read(n);
	roota=new node;
	rootb=new node;
	for(i=1;i<=n;++i){
		read(inp[i]);
	}
	roota->build(1,n);
	for(i=1;i<=n;++i){
		read(inp[i]);
	}
	rootb->build(1,n);
	read(T);
	int l,r;
	for(l=1;l<=n;++l){
		for(r=l;r<=n;++r){
			s1[l][r]=roota->ask(l,r)*rootb->ask(l,r);
		}
	}
	for(l=1;l<=n;++l){
		for(r=1;r<=n;++r){
			s1[l][r]+=s1[l][r-1];
		}
	}
	while(T--){
		read(l);
		read(r);
		unsigned long long ans=0;
		for(i=l;i<=r;++i){
			ans=ans+s1[i][r];
		}
		cout<<ans<<'\12';
	}
}//20
/*
Use the tree or Splay to get max.
and sum it to use n square with log n.
(I fail to write a ST...
*/
