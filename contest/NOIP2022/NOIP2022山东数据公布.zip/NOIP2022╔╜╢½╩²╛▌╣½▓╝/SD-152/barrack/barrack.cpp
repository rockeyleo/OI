#include<iostream>
#include<cstdio>
#define MOD 1000000007
using namespace std;
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	unsigned long long ans=1;
	for(int i=1;i<=n;++i)ans=ans*2%MOD;
	--ans;
	for(int i=1;i<=m;++i)ans=ans*2%MOD;
	cout<<ans;
}
//0~30
/*
if there's no cut line.
the answer will be (2^n-1)*2^m.
*/
