#include<iostream>
#include<cstdio>
#define mod 1000000007
using namespace std;
int kd(){
	int x=0,f=1;
	char a=getchar();
	while(a<'0'||a>'9'){
		if(a=='-'){
			f=-1;
		}
		a=getchar();
	}
	while(a>='0'&&a<='9'){
		x=x*10+a-'0';
		a=getchar();
	}
	return x*f;
}
int n,m;
struct node{
	int to;
	int nxt;
}edge[1000010];
int head[500010],tot;
void addedge(int u,int v){
	edge[++tot].to=v;
	edge[tot].nxt=head[u];
	head[u]=tot;
}
long long f[500010][2];
long long g[500010];
int du[500010];
int fa[500010];
long long sum[500010];
long long ksm(long long x,int y){
	long long ans=1;
	while(y){
		if(y%2==1){
			ans=ans*x%mod;
		}
		x=x*x%mod;
		y/=2;
	}
	return ans;
}
long long ans=0;
void dfs(int u){
	du[u]--;
	for(int i=0;i<=du[u];i++){
		g[i]=0;
	}
	g[0]=1;
	sum[u]=1;
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].to;
		if(v==fa[u]){
			continue;
		}
		fa[v]=u;
		dfs(v);
		sum[u]+=sum[v];
		for(int j=du[u];j>=1;j--){
			g[j]=(g[j]*f[v][0]%mod*2%mod+g[j-1]*f[v][1]%mod)%mod;
		}
		g[0]=g[0]*f[v][0]%mod*2%mod;
	}
	f[u][0]=g[0];
	for(int j=0;j<=du[u];j++){
		f[u][1]=(f[u][1]+g[j])%mod;
	}
	ans=(ans+f[u][1]*ksm(2,n-sum[u])%mod)%mod;
	f[u][1]=f[u][1]*2%mod;
	f[u][1]=(f[u][1]-g[0]+mod)%mod;
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		u=kd();v=kd();
		du[u]++;
		du[v]++;
		addedge(u,v);
		addedge(v,u);
	}
	if(m==n-1){
		du[1]++;
		ans=0;
		dfs(1);
		cout<<ans;
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
