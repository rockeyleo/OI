#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int kd(){
	int x=0,f=1;
	char a=getchar();
	while(a<'0'||a>'9'){
		if(a=='-'){
			f=-1;
		}
		a=getchar();
	}
	while(a>='0'&&a<='9'){
		x=x*10+a-'0';
		a=getchar();
	}
	return x*f;
}
int t,n,q;
unsigned long long a[200010],b[200010];
struct node{
	int l,r;
	int maxa;
	int maxb;
}tree[800010];
void build(int i,int l,int r){
	tree[i].l=l;
	tree[i].r=r;
	if(l==r){
		tree[i].maxa=l;
		tree[i].maxb=r;
		return ;
	}
	int mid=(l+r)/2;
	build(i*2,l,mid);
	build(i*2+1,mid+1,r);
	if(a[tree[i*2].maxa]>a[tree[i*2+1].maxa]){
		tree[i].maxa=tree[i*2].maxa;
	}
	else{
		tree[i].maxa=tree[i*2+1].maxa;
	}
	if(b[tree[i*2].maxb]>b[tree[i*2+1].maxb]){
		tree[i].maxb=tree[i*2].maxb;
	}
	else{
		tree[i].maxb=tree[i*2+1].maxb;
	}
	return ;
}
int search1(int i,int l,int r){
	if(tree[i].l>=l&&tree[i].r<=r){
		return tree[i].maxa;
	}
	if(tree[i*2].r>=r){
		return search1(i*2,l,r);
	}
	if(tree[i*2+1].l<=l){
		return search1(i*2+1,l,r);
	}
	int s1=search1(i*2,l,r);
	int s2=search1(i*2+1,l,r);
	if(a[s1]>a[s2]){
		return s1;
	}
	else{
		return s2;
	}
}
int search2(int i,int l,int r){
	if(tree[i].l>=l&&tree[i].r<=r){
		return tree[i].maxb;
	}
	if(tree[i*2].r>=r){
		return search2(i*2,l,r);
	}
	if(tree[i*2+1].l<=l){
		return search2(i*2+1,l,r);
	}
	int s1=search2(i*2,l,r);
	int s2=search2(i*2+1,l,r);
	if(b[s1]>b[s2]){
		return s1;
	}
	else{
		return s2;
	}
}
unsigned long long ans(int l,int r){
	if(r<l){
		return 0;
	}
	int s1=search1(1,l,r);
	int s2=search2(1,l,r);
	unsigned long long tot=a[s1]*b[s2];
	if(s1>s2){
		swap(s1,s2);
	} 
	tot=tot*(r-s2+1)*(s1-l+1);
	tot=tot+ans(l,s2-1)+ans(s1+1,r)-ans(s1+1,s2-1);
	return tot;
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(int i=1;i<=n;i++){
		a[i]=kd();
	}
	for(int i=1;i<=n;i++){
		b[i]=kd();
	}
	build(1,1,n);
	cin>>q;
	while(q--){
		int l,r;
		l=kd();r=kd();
		unsigned long long tot=ans(l,r);
		printf("%llu\n",tot);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
