#include<iostream>
#include<cstdio>
#define mod 998244353
using namespace std;
int t,id;
int n,m,c,f;
char a[1010][1010];
long long hou[1010][1010];
long long xia[1010][1010];
long long cans[1010][1010];
long long fans[1010][1010];
long long cc,ff;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--){
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
		}
		for(int i=1;i<=n;i++){
			for(int j=m-1;j>=1;j--){
				if(a[i][j]=='1'){
					hou[i][j]=0;
					continue;
				}
				if(a[i][j+1]=='1'){
					hou[i][j]=0;
				}
				else{
					hou[i][j]=hou[i][j+1]+1;
				}
			}
		}
		for(int j=1;j<=m;j++){
			for(int i=n-1;i>=1;i--){
				if(a[i][j]=='1'){
					xia[i][j]==0;
					continue;
				}
				if(a[i+1][j]=='1'){
					xia[i][j]=0;
				}
				else{
					xia[i][j]=xia[i+1][j]+1;
				}
			}
		}
		for(int j=1;j<=m;j++){
			long long ftot=0;
			long long ctot=0;
			for(int i=n;i>=1;i--){
				if(a[i+1][j]=='1'){
					ftot=0;
					ctot=0;
				}
				else{
					fans[i][j]=ftot*hou[i][j]%mod;
					cans[i][j]=ctot*hou[i][j]%mod;
					ftot=(ftot+xia[i+1][j]*hou[i+1][j]%mod)%mod;
					ctot=(ctot+hou[i+1][j])%mod;
				}
			}
		}
		cc=0;
		ff=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cc=(cc+cans[i][j])%mod;
				ff=(ff+fans[i][j])%mod;
				cans[i][j]=0;
				fans[i][j]=0;
				hou[i][j]=0;
				xia[i][j]=0;
			}
		}
		cc=cc*c%mod;
		ff=ff*f%mod;
		cout<<cc<<" "<<ff<<endl; 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
