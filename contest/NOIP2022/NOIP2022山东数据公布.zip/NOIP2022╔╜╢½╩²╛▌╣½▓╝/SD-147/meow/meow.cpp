#include<iostream>
#include<cstdio>
#define INF 1000000000
using namespace std;
int kd(){
	int x=0,f=1;
	char a=getchar();
	while(a<'0'||a>'9'){
		if(a=='-'){
			f=-1;
		}
		a=getchar();
	}
	while(a>='0'&&a<='9'){
		x=x*10+a-'0';
		a=getchar();
	}
	return x*f;
}
int t;
int n,m,k;
int a[2000010];
int nxt[2000010];
int nxt2[2000010];
int bef[2000010];
int xyg[2000010];
int top[310];
bool p1[2000010],p2[2000010];
int ans[2000010];
int tong[610];
struct node{
	int opt;
	int y,e;
}f[4000010];
int dui[310][2];
int tot[310];
int cnt=0;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	t=kd();
	while(t--){
		n=kd();m=kd();k=kd();
		for(int i=1;i<=m;i++){
			a[i]=kd();
		}
		for(int i=1;i<=k;i++){
			tong[i]=0;
		}
		for(int i=1;i<=n;i++){
			top[i]=0;
		}
		for(int i=1;i<=m;i++){
			nxt[i]=0;
			nxt2[i]=0;
			xyg[i]=0;
			bef[i]=0;
			p1[i]=0;
			p2[i]=0;
		}
		if(k==2*n-2){
			for(int i=1;i<=m;i++){
				tong[a[i]]++;
				if(tong[a[i]]%2==0){
					for(int j=1;j<n;j++){
						if(dui[j][tot[j]]==a[i]){
							f[++cnt].opt=1;
							f[cnt].y=j;
							tot[j]--;
							break;
						}
						else if(tot[j]==2&&dui[j][1]==a[i]){
							f[++cnt].opt=1;
							f[cnt].y=n;
							f[++cnt].opt=2;
							f[cnt].y=n;
							f[cnt].e=j;
							break;
						}
					}
				}
				else{
					for(int j=1;j<n;j++){
						if(tot[j]<=1){
							dui[j][++tot[j]]=a[i];
							f[++cnt].opt=1;
							f[cnt].y=j;
							break;
						}
					}
				}
			}
			cout<<cnt<<endl;
			for(int i=1;i<=cnt;i++){
				cout<<f[i].opt<<" ";
				if(f[i].opt==1){
					cout<<f[i].y<<endl;
					f[i].y=0;
				}
				else{
					cout<<f[i].y<<" "<<f[i].e<<endl;
					f[i].y=f[i].e=0;
				}
				f[i].opt=0;
			}
			cnt=0;
			continue;
		}
		for(int i=m;i>=1;i--){
			if(tong[a[i]]==0){
				tong[a[i]]=i;
			}
			else{
				nxt[i]=tong[a[i]];
				nxt2[tong[a[i]]]=i;
				tong[a[i]]=0;
			}
		}
		for(int i=1;i<=n;i++){
			top[i]=0;
		}
		p1[0]=1;
		p2[0]=1;
		nxt[0]=INF; 
		for(int i=1;i<=m;i++){
			p1[i]=1;
			p2[i]=1;
			if(ans[i]!=0){
				if(top[ans[i]]==nxt2[i]){
					f[++cnt].opt=1;
					f[cnt].y=ans[i];
					top[ans[i]]=bef[top[ans[i]]];
				}
				else{
					for(int j=1;j<=n;j++){
						if(top[j]==0){
							f[++cnt].opt=1;
							f[cnt].y=j;
							f[++cnt].opt=2;
							f[cnt].y=j;
							f[cnt].e=ans[i];
							bef[xyg[nxt2[i]]]=0;
							break;
						}
					}
				}
				continue;
			}
			int cun1=0;
			int cun2=0;
			for(int j=1;j<=n;j++){
				if(p1[top[j]]==1){
					if((nxt[top[j]]<=nxt[top[cun1]]||cun1==0)&&nxt[top[j]]>nxt[i]){
						cun1=j;
					}
				}
				if(p2[top[j]]==1){
					if((nxt[top[j]]>=nxt[top[cun2]]||cun2==0)&&nxt[top[j]]<nxt[i]){
						cun2=j;
					}
				}
			}
			if(cun1!=0){
				f[++cnt].opt=1;
				f[cnt].y=cun1;
				ans[nxt[i]]=cun1;
				xyg[top[cun1]]=i;
				bef[i]=top[cun1];
				if(top[cun1]!=0){
					p2[i]=0;
				}
				top[cun1]=i;
			}
			else{
				f[++cnt].opt=1;
				f[cnt].y=cun2;
				ans[nxt[i]]=cun2;
				xyg[top[cun2]]=i;
				bef[i]=top[cun2];
				top[cun2]=i;
			}
		}
		cout<<cnt<<endl;
		for(int i=1;i<=cnt;i++){
			cout<<f[i].opt<<" ";
			if(f[i].opt==1){
				cout<<f[i].y<<endl;
				f[i].y=0;
			}
			else{
				cout<<f[i].y<<" "<<f[i].e<<endl;
				f[i].y=f[i].e=0;
			}
			f[i].opt=0;
		}
		cnt=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
