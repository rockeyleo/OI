//Ըlr,glj,fgy,ljh���и��ҹ������һ��֮�������� 
//���80�� 
#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int T,id,n,m,c,f,cnt;
int keng[1145][1145],dp[1145][1145],bp[1145][1145];
long long ans;
int red(){
	int as=0;int fl=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='0')fl=-1;ch=getchar();}
	while(isdigit(ch)){as=as*10+ch-'0';ch=getchar();}
	return as*fl;
}

void init(){
	n=red(),m=red();
	c=red(),f=red();
	memset(keng,0,sizeof(keng));
	memset(bp,0,sizeof(bp));
	memset(dp,0,sizeof(dp));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			keng[i][j]=getchar();
			keng[i][j]-='0';
		}
	}
	
}

void chuli(){
	for(int i=1;i<=n;i++){
		cnt=0;
		for(int j=m;j>=1;j--){
			if(!keng[i][j])	cnt++,dp[i][j]=cnt;
			else	cnt=0;
		}
	}
	for(int i=1;i<=m-1;i++){
		cnt=0;
		for(int j=n;j>=1;j--){
			if(!keng[j][i])	cnt++,bp[j][i]=cnt;
			else	cnt=0;
		}
	}
	if(c==0)	printf("0 ");
	else{
		for(int i=1;i<=n-2;i++){
			for(int j=1;j<=m-1;j++){
				if(dp[i][j]>=2){
					for(int k=i+1;k<=n;k++){
						if(dp[k][j]&&k==i+1)	continue;
						if(dp[k][j]){
							if(dp[k][j]==1)	continue;
							else	ans+=((dp[k][j]-1)*(dp[i][j]-1))%mod,ans%=mod;
						}
						else break;
					}
				}
			}
		}
		printf("%lld ",ans);
	}
	ans=0;
	if(f==0)	printf("0");
	else{
		for(int i=1;i<=n-3;i++){
			for(int j=1;j<=m-1;j++){
				if(dp[i][j]>=2){
					for(int k=i+1;k<=n-1;k++){
						if(dp[k][j]&&k==i+1)	continue;
						if(dp[k][j]){
							if(dp[k][j]==1)	continue;
							else	ans+=((dp[k][j]-1)*(dp[i][j]-1)*bp[k+1][j])%mod,ans%=mod;
						}
						else break;
					}
				}
			}
		}
		printf("%lld",ans);
	}
}

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=red();id=red();
	for(int i=1;i<=T;i++){
		init();
		chuli();
		printf("\n");
	}
	return 0;
} 
