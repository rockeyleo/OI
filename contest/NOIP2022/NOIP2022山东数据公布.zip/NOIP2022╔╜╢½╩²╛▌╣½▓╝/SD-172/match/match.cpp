#include<bits/stdc++.h>
using namespace std;
const int maxn=10005;
int f1[10005][10005],f2[10005][10005];
int n,T,Q,a[maxn],b[maxn],xuan1,xuan2;
unsigned long long ans,zan,sum;
int red(){
	int as=0;int fl=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='0')fl=-1;ch=getchar();}
	while(isdigit(ch)){as=as*10+ch-'0';ch=getchar();}
	return as*fl;
}

void init(){
	T=red();n=red();
	for(int i=1;i<=n;i++)
		a[i]=red();
	for(int i=1;i<=n;i++)
		b[i]=red();
	Q=red();
}

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	init();
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			f1[i][j]=max(f1[i][j-1],a[j]);
			f2[i][j]=max(f1[i][j-1],b[j]);
		}
	}
	for(int i=1;i<=Q;i++){
		int l,r;
		l=red();r=red();
		for(int p=l;p<=r;p++){
			for(int q=p;q<=r;q++){
				xuan1=f1[p][q];
				xuan2=f2[p][q];
				zan=xuan1*xuan2;
				sum+=zan;
			}
		}
	}
	printf("%llu",sum);
	return 0;
}
