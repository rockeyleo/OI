#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

using namespace std;

long long n,m,u[10000],v[10000];
string a[10000];
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>u[i]>>v[i];
	}
	
   

	fclose(stdin);
	fclose(stdout);
	return 0;
}




