#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

using namespace std;

long long T,id,n,m,c,f,vc,vf;
string a[10000];
int main(){
	//freopen("plant.in","r",stdin);
	//freopen("plant.out","w",stdout);
	
	cin>>T>>id;
	cin>>n>>m>>c>>f;
    for(int i=1;i<=n;i++){
    	cin>>a[i];
	}
	if(c==0&&f==0){
		cout<<"0"<<" "<<"0";
		return 0;
	}
	
    for(int i=1;i<=n;i++){
    	int x1,x2,x3,y0,y1,y2;
    	x1=i;
    	for(int s=i+1;s<=n;s++){
    		x2=s;
		}
    	
    	for(int j=1;j<=m;j++){
    		y0=j;
    		for(int k=j;k<=m;k++){
    			y1=k;
    			for(int l=j;l<=m;l++){
    				for(int o=y0;o<=y1;o++){
    					if(a[x1][o]!='1'){
    						for(int u=y0;u<=y2;u++){
    							if(a[x2][u]!='1')vc++;
							}
						}
					}
				}
			}
		}
		
	}
	for(int i=1;i<=n;i++){
    	int x1,x2,x3,y0,y1,y2;
    	x1=i;
    	for(int s=i+1;s<=n;s++){
    		x2=s;
    		for(int ii=s;ii<=n;ii++){
    			x3=ii;
			}
		}
    	for(int j=1;j<=m;j++){
    		y0=j;
    		for(int k=j;k<=m;k++){
    			y1=k;
    			for(int l=j;l<=m;l++){
    				for(int o=y0;o<=y1;o++){
    					if(a[x1][o]!='1'){
    						for(int u=y0;u<=y2;u++){
    							if(a[x2][u]!='1'){
    								for(int tt=x1;tt<=x3;tt++){
    									if(a[tt][y0]!='1')vf++;
									}
								}
							}
						}
					}
				}
			}
		}
		
	}
    cout<<vc*c<<" "<<vf*f;

	//fclose(stdin);
	//fclose(stdout);
	return 0;
}




