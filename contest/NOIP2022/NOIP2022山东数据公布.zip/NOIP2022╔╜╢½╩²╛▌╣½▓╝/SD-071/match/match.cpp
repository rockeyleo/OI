#include <cstring>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <queue>
#define int long long
using namespace std;

const int maxn = 3010;
int T, n, A[3010][3010], a[maxn], b[maxn], q, B[maxn][maxn];

struct node {
	int l, r, maxx1, maxx2;
}tree[maxn << 2];

void pushup(int rt) {
	tree[rt].maxx1 = max(tree[rt << 1].maxx1, tree[rt << 1 | 1].maxx1);
	tree[rt].maxx2 = max(tree[rt << 1].maxx2, tree[rt << 1 | 1].maxx2);
}

void build (int rt, int l, int r) {
	tree[rt].l = l;
	tree[rt].r = r;
	if (l == r) {
		tree[rt].maxx1 = a[l];
		tree[rt].maxx2 = b[l];
		return ;
	}
	int mid = (l + r) >> 1;
	build (rt << 1, l, mid);
	build (rt << 1 | 1, mid + 1, r);
	pushup(rt);
}

int q1uery(int rt, int L, int R) {
	int l = tree[rt].l;
	int r = tree[rt].r;
	if (l >= L && r <= R) {
		return tree[rt].maxx1;
	}
	int mid = (l + r) >> 1, ans = -1e18;	
	if (L <= mid) ans = max(ans, q1uery(rt << 1, L, R));
	if (R > mid) ans = max(ans, q1uery(rt << 1 | 1, L, R));
	return ans;
}

int q2uery(int rt, int L, int R) {
	int l = tree[rt].l;
	int r = tree[rt].r;
	if (l >= L && r <= R) {
		return tree[rt].maxx2;
	}
	int mid = (l + r) >> 1, ans = -1e18;	
	if (L <= mid) ans = max(ans, q2uery(rt << 1, L, R));
	if (R > mid) ans = max(ans, q2uery(rt << 1 | 1, L, R));
	return ans;
}

signed main () {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	scanf("%lld%lld", &T, &n);
	for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	for (int i = 1; i <= n; i++) scanf("%lld", &b[i]);
	scanf("%lld", &q);
//	build (1, 1, n); 
	for (int i = 1; i <= n; i++) {
		int maxx1 = a[i], maxx2 = b[i];
		for (int j = i; j <= n; j++) {
			maxx1 = max(a[j], maxx1);
			maxx2 = max(b[j], maxx2);
//			int t1 = q1uery(1, i, j);
//			int t2 = q2uery(1, i, j);
			A[i][j] = maxx1 * maxx2;
		}
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			B[i][j] = B[i][j - 1] + B[i - 1][j] + A[i][j] - B[i - 1][j - 1];
		}
	}
	for (int i = 1; i <= q; i++) {
		int ans = 0;
		int l, r;
		scanf("%lld%lld", &l, &r);
//		printf("%lld%lld\n", B[r][r] - B[l - 1][r] - B[r][l - 1] + B[l - 1][l - 1]);
		cout << B[r][r] - B[l - 1][r] - B[r][l - 1] + B[l - 1][l - 1] << '\n';
	}
	return 0;
} 
