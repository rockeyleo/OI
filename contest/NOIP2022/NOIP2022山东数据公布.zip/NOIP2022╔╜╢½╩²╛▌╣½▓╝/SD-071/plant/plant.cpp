#include <cstring>
#include <cstdio>
#include <iostream>
#include <algorithm>
#define int long long
using namespace std;

const int maxn = 1e3 + 10, mod = 998244353;
int T, iid;
int n, m, c, f;
int a[maxn][maxn], s[maxn][maxn], d[maxn][maxn]; 
int kkk[maxn][maxn];

signed main () {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	scanf("%lld%lld", &T, &iid);
	while (T--) {
		memset(a, 0, sizeof a);
		memset(s, 0, sizeof s);
		memset(d, 0, sizeof d);
		memset(kkk, 0, sizeof kkk);
//		cin >> n >> m >> c >> f;
	 	scanf("%lld%lld%lld%lld", &n, &m, &c, &f);
	 	for (int i = 1; i <= n; i++) {
	 		for (int j = 1; j <= m; j++) {
	 			char opt;
	 			cin >> opt;
	 			a[i][j] = (opt == '1');
			 }
		}
		for (int i = 1; i <= n; i++) {
			for (int j = m; j >= 1; j--) {
				if (a[i][j] == 1) continue;
				else s[i][j] = s[i][j + 1] + 1;
			}
		}
		for (int j = 1; j <= m; j++) {
			for (int i = 1; i <= n; i++) {
				if (a[i][j] == 1) continue;
				else d[i][j] = d[i - 1][j] + s[i][j + 1];
			}
		}
		for (int j = 1; j <= m; j++) {
			for (int i = n; i >= 1; i--) {
				if (a[i][j]) continue;
				else kkk[i][j] = kkk[i + 1][j] + 1;
			}
		}
		int ansc = 0, ansf = 0;
		for (int i = 3; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				if (a[i - 1][j] || a[i - 2][j]) continue;
				ansc += (d[i - 2][j] * s[i][j + 1]) % mod;
				ansc %= mod;
				ansf += ((d[i - 2][j] * s[i][j + 1]) % mod * kkk[i + 1][j]) % mod;
				ansf %= mod;
			}
		}
		cout << ansc * c % mod << " " << ansf * f % mod<< '\n';
	}
	return 0;
} 
