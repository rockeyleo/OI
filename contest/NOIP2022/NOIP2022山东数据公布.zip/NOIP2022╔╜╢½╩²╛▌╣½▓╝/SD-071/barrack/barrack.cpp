#include <cstring>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <queue>
#define int long long
using namespace std;

const int maxn = 1e6 + 10, mod = 1e9 + 7;
int n, m, num, head[maxn], vis[maxn], Vis[maxn], ans;

struct node {
	int nex, to, flagg;
}edge[maxn << 1];

void add(int from, int to) {
	edge[++num].nex = head[from];
	edge[num].to = to;
	edge[num].flagg = 0;
	head[from] = num;
}

void dfs2(int u) {
	vis[u] = 1;
	for (int i = head[u]; i; i = edge[i].nex) {
		int to = edge[i].to;
		if (edge[i].flagg) continue;
		if (vis[to]) continue;
//		vis[to] = 1;
		dfs2(to);
	}
}

void dfs(int dep, int sum) {
	if (dep == n + 1) {
		if (!sum) return ;
		int res = 1;
//		for (int i = 1; i <= n; i++) cout << Vis[i] << " ";
//		cout << endl;
		for (int j = 1; j <= m; j++) {
			edge[j * 2 - 1].flagg = 1, edge[j * 2].flagg = 1; 
			for (int i = 1; i <= n; i++) {
				if (Vis[i]) {
					for (int k = 1; k <= n; k++) vis[k] = 0;
					dfs2(i);
					break;
				}
			}
			int fla = 0;
			edge[j * 2 - 1].flagg = 0, edge[j * 2].flagg = 0;	
			for (int i = 1; i <= n; i++) {
				if (Vis[i] == 1 && vis[i] == 0) {
					fla = 1;
					break;
				}
			}
			if (!fla) res *= 2ll, res %= mod;
		}
		ans += res;
		ans %= mod;
		return ;
	}
	dfs(dep + 1, sum);
	Vis[dep] = 1;
	dfs(dep + 1, sum + 1);
	Vis[dep] = 0;
}

signed main () {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	for (int i = 1; i <= m; i++) {
		int u, v;
		scanf("%lld%lld", &u, &v);
		add(u, v);
		add(v, u);
	}
	dfs(1, 0);
	cout << ans % mod;
	return 0;
} 
