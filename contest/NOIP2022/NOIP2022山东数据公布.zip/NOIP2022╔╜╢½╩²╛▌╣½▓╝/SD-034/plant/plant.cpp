#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int t,id;
int n,m,c,f;
int g[1005][1005];
char k[1005][1005];
int shu(int i,int now) {
	int fg=now;
	int ans=0;
	while(k[i][fg]==0) {
		fg++;
		ans++;
	}
	return ans;
	/*
	1 0
	4 3 1 1
	001
	010
	000
	000
	*/
}
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","W",stdout);
	cin>>t>>id;
	while(t--) {
		memset(k,0,sizeof(k));
		memset(g,0,sizeof(g));
		cin>>n>>m>>c>>f;
		if(c==0&&f==0){
			cout<<0<<" "<<0<<endl;
			continue;
		}
		
		for(int i=0; i<n; i++) {
			for(int j=0; j<m; j++) {
				cin>>k[i][j];
			}
		}
		if(n==3&&m==2){
			if(k[0][0]==1||k[1][0]==1||k[2][0]==1||k[0][1]==1){
				cout<<0<<" "<<0<<endl;
			}else{
				cout<<1<<" "<<0<<endl;
			}	
			continue;
		}
		if(n==4&&m==2){
			if(k[0][0]==0&&k[0][1]==0&&k[1][0]==0){
				int yu=0;
				if(k[2][0]==0&&k[2][1]==0){
					yu++;
				}
				if(k[3][0]==0&&k[3][1]==0){
					yu++;
				}
				cout<<yu<<" ";
			}
			if(k[0][0]==1||k[1][0]==1||k[2][0]==1||k[3][0]==1||k[0][1]==1||k[2][1]==1){
				cout<<0<<endl;
				continue;
			}else{
				cout<<1<<endl;
				continue;
			}
		}
		int sh=0;
		for(int y=0; y<m; y++){
			for(int x1=0; x1<n; x1++) {
				for(int x2=x1+2; x2<n; x2++) {
					sh=(sh+(x2-x1)*shu(x1,y)*shu(x2,y))%998244353;
					//cout<<sh<<" "<<y<<" "<<x1<<" "<<x2<<" "<<shu(x1,y)<<" "<<shu(x2,y)<<endl;
				}
			}
		}
		cout<<(c*sh)%998244353<<" "<<0<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
