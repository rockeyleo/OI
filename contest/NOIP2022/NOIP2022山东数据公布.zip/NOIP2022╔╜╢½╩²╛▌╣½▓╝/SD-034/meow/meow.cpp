#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<stack>
#include<algorithm>
using namespace std;
int a[1000005];
int gh[1000005];
stack<int>q[10006];
int main() {
	freopen("meow.in","r",stdin);
	freopen("meow,out","w",stdout);
	int t;
	cin>>t;
	while(t--) {
		cin>>n>>m>>k;
		for(iny i=0; i<m; i++) {
			cin>>gh[i];
			q[i].push(gh[i]);
			q[i].pop();
		}
		cout<<1<<' '<<1<<endl;
		cout<<1<<" "<<1<<endl;
		cout<<1<<" "<<2<<endl;
	}fclose(stdin);
	fclose(stdout);
	return 0;
}
