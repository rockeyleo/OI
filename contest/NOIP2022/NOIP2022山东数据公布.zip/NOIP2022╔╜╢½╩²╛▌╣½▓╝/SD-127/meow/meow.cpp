#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int a=1,b=0;
	char c=getchar();
	while(c<'0' || c>'9') {
		if(c=='-') a=-1;
		c=getchar();
	}
	while(c>='0' && c<='9') {
		b=b*10+(c-'0');
		c=getchar();
	}
	return a*b;
}
inline void write(int n)
{
	if(n<0) {
		putchar('-');
		n=n*-1;
	}
	if(n<10) {
		putchar(n+'0');
	} else {
		write(n/10);
		putchar((n%10)+'0');
	}
}

int T;//����
int n,m,k;//ջ��/����/����
int a;//�� ��(α) �����洢

vector<int> z[301];//ջ ��
vector<int> cache;

struct opt {
	int type,a,b;
} o;
vector<opt> op;

void remove1(int i)
{
	if(z[i].size()==1) {
		z[i].clear();
		return;
	}
	cache=z[i];
	z[i].clear();
	for(int j=1; j<cache.size(); j++) {
		z[i].push_back(cache[j]);
	}

}

int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=read();
	while(T--) {
		op.clear();
		n=read();
		m=read();
		k=read();
		for(int i=0; i<m; i++) {
			a=read();

			bool remove=false;
			int minn=100000000,mini=0;
			/*
						bool isaaa=false;//�����ײ��Ƿ�����ͬ�ģ����û�в�ռ��
						for(int j=1; j<=n; j++) {

							if(z[j].size()>0) {
								if(z[j][0]==a) {
									isaaa=true;
								}
							}
						}
			*/

			for(int j=1; j<=n; j++) {
				if(z[j].size()>0) {
					if(z[j][z[j].size()-1]==a) {
						o.type=1;
						o.a=j;
						o.b=0;
						op.push_back(o);
						remove=true;
						z[j].pop_back();
					}
				}

				/*
									if(z[j].size()<minn) {
										if(z[j].size()==0) {
											if(isaaa) {
												minn=z[j].size();
												mini=j;
											}
										} else {

											minn=z[j].size();
											mini=j;
										}
									}*/
				if(z[j].size()<minn) {
					minn=z[j].size();
					mini=j;
				}

			}

			if(!remove) {
				z[mini].push_back(a);
				o.type=1;
				o.a=mini;
				o.b=0;
				op.push_back(o);
			}


			for(int j=1; j<=n-1; j++) {
				for(int k=j+1; k<=n; k++) {
					if(z[j].size()>0 && z[k].size()>0) {

						if(z[j][z[j].size()-1]==z[k][z[k].size()-1]) {
							remove1(j);
							remove1(k);
							o.type=2;
							o.a=j;
							o.b=k;
							op.push_back(o);
						}
					}
				}

			}

		}

		write(op.size());
		cout<<endl;

		for(int i=0; i<op.size(); i++) {
			if(op[i].type==1) {
				write(1);
				putchar(' ');
				write(op[i].a);
				cout<<endl;
			} else if(op[i].type==2) {
				write(2);
				putchar(' ');
				write(op[i].a);
				putchar(' ');
				write(op[i].b);
				cout<<endl;
			} else {
				//cout<<"��"<<i<<"�β�����"<<op[i].type<<endl;
			}
		}
		/*
		cout<<"aaaa"<<endl;

		for(int j=1; j<=n; j++) {

			cout<<j<<": ";
			for(int i=0; i<z[j].size(); i++) {
				cout<<z[j][i]<<" ";
			}
			cout<<endl;
		}*/
	}
	return 0;
}
