#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int a=1,b=0;
	char c=getchar();
	while(c<'0' || c>'9') {
		if(c=='-') a=-1;
		c=getchar();
	}
	while(c>='0' && c<='9') {
		b=b*10+(c-'0');
		c=getchar();
	}
	return a*b;
}
inline void write(unsigned long long n)
{
	if(n<0) {
		putchar('-');
		n=n*-1;
	}
	if(n<10) {
		putchar(n+'0');
	} else {
		write(n/10);
		putchar((n%10)+'0');
	}
}

int T,n;
int a[250001],b[250001];
int Q;
int l,r;
unsigned long long s=0;

int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();
	n=read();
	for(int i=1; i<=n; i++) {
		a[i]=read();
	}
	for(int i=1; i<=n; i++) {
		b[i]=read();
	}
	Q=read();
	while(Q--) {
		s=0;
		l=read();
		r=read();
		for(int p=l; p<=r; p++) {
			for(int q=p; q<=r; q++) {
				unsigned long long maxa=0,maxb=0;
				for(int i=p; i<=q; i++) {
					if(a[i]>maxa) {
						maxa=a[i];
					}
					if(b[i]>maxb) {
						maxb=b[i];
					}
				}
				//cout<<p<<" "<<q<<" "<<maxa<<" "<<maxb<<endl;
				s+=maxa*maxb;
			}
		}
		write(s);
		cout<<endl;
	}
	return 0;
}
