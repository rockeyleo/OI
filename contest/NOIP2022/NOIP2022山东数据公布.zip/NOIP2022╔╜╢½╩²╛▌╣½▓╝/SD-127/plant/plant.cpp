#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int a=1,b=0;
	char c=getchar();
	while(c<'0' || c>'9') {
		if(c=='-') a=-1;
		c=getchar();
	}
	while(c>='0' && c<='9') {
		b=b*10+(c-'0');
		c=getchar();
	}
	return a*b;
}
inline void write(int n)
{
	if(n<0) {
		putchar('-');
		n=n*-1;
	}
	if(n<10) {
		putchar(n+'0');
	} else {
		write(n/10);
		putchar((n%10)+'0');
	}
}


int mp[1001][1001];
int T,id;
int n,m,c,f;

int jiejia(int n)
{
	int r=0;
	while(n>0) {
		r+=n;
		n--;
	}
	return r;
}


int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);

//n->x m->y

	T=read();
	while(T--) {

		id=read();

		n=read();
		m=read();
		c=read();
		f=read();

		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				mp[i][j]=getchar()-'0';
				//cout<<mp[i][j];
			}
			getchar();
			//cout<<endl;
		}

		if(id==5) {
			n=ceil(n/3*2);
		}
		if(id==6) {
			m=ceil(m/4*3);
		}

		int vc=0,vf=0;

		if(n>=3 && m>=2 && c==1) {
			/*
			for(int i=1; i<=n-2; i++) {//ȷ��C��һ������
				for(int j=i+2; j<=n; j++) {//�ڶ���
					int end1;
					for(end1=1; end1<=m; end1++) {
						if(mp[i][end1]==1) {
							break;
						}
					}
					int end2;
					for(end2=1; end2<=m; end2++) {
						if(mp[j][end2]==1) {
							break;
						}
					}
					if(end1>m)end1=m;
					if(end2>m)end2=m;

					cout<<i<<" "<<j<<" "<<end1<<" "<<end2<<endl;
					vc+=(end1-1)*(end2-1);
				}
			}
			*/


			for(int x1=1; x1<=n-2; x1++) {//��1
				for(int x2=x1+2; x2<=n; x2++) {//hang 2

					for(int y0=1; y0<=m-1; y0++) {//��0
						bool fa=false;
						for(int xm=x1; xm<=x2; xm++) {
							if(mp[xm][y0]==1) {
								fa=true;
								break;
							}
						}
						if(fa) {
							continue;
						}



						int y1;//lie1
						for(y1=y0; y1<=m; y1++) {
							if(mp[x1][y1]==1) {
								break;
							}
						}



						int y2;//lie2
						for(y2=y0; y2<=m; y2++) {
							if(mp[x2][y2]==1) {
								break;
							}
						}




						//cout<<x1<<" "<<x2<<" "<<y0<<" "<<y1<<" "<<y2<<endl;
						vc+=(y1-y0-1)*(y2-y0-1);
					}

				}
			}


		}


		if(n>=4 && m>=2 && f==1) {
			/*
			for(int i=1; i<=n-2; i++) {//ȷ��C��һ������
				for(int j=i+2; j<=n; j++) {//�ڶ���
					int end1;
					for(end1=1; end1<=m; end1++) {
						if(mp[i][end1]==1) {
							break;
						}
					}
					int end2;
					for(end2=1; end2<=m; end2++) {
						if(mp[j][end2]==1) {
							break;
						}
					}
					if(end1>m)end1=m;
					if(end2>m)end2=m;

					cout<<i<<" "<<j<<" "<<end1<<" "<<end2<<endl;
					vc+=(end1-1)*(end2-1);
				}
			}
			*/


			for(int x1=1; x1<=n-2; x1++) {//��1
				for(int x2=x1+2; x2<=n-1; x2++) {//hang 2
					for(int x3=x2+1; x3<=n; x3++) {//hang 3
						for(int y0=1; y0<=m-1; y0++) {//��0
							bool fa=false;
							for(int xm=x1; xm<=x3; xm++) {
								if(mp[xm][y0]==1) {
									fa=true;
									break;
								}
							}
							if(fa) {
								continue;
							}



							int y1;//lie1
							for(y1=y0; y1<=m; y1++) {
								if(mp[x1][y1]==1) {
									break;
								}
							}



							int y2;//lie2
							for(y2=y0; y2<=m; y2++) {
								if(mp[x2][y2]==1) {
									break;
								}
							}




							//cout<<x1<<" "<<x2<<" "<<y0<<" "<<y1<<" "<<y2<<endl;
							vf+=(y1-y0-1)*(y2-y0-1)%998244353;
						}

					}
				}
			}


		}



		write(vc%998244353);
		putchar(' ');
		write(vf%998244353);
		cout<<endl;
	}
	return 0;
}
