#include<bits/stdc++.h>
#define int long long
#define ULL unsigned long long
#define max(x,y) x>y?x:y
using namespace std;
const int N=3e5;
const int mod=pow(2,64);
int t,n,q,l,r,a[N],b[N],f1[N][26],f2[N][26];
inline int read(){
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-f;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return f*x;
}
inline void print(int x){if(x<0)putchar('-'),x=-x;if(x>9)print(x/10);putchar(x%10+'0');}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	t=read();n=read();
	for(int i=1;i<=n;i++) a[i]=read(),f1[i][0]=a[i];
	for(int i=1;i<=n;i++) b[i]=read(),f2[i][0]=b[i];
	for(int j=1;j<=20;j++){
		for(int i=1;i+(1<<j)-1<=n;i++)
		f1[i][j]=max(f1[i][j-1],f1[i+(1<<(j-1))][j-1]);
	}
	for(int j=1;j<=20;j++){
		for(int i=1;i+(1<<j)-1<=n;i++)
		f2[i][j]=max(f2[i][j-1],f2[i+(1<<(j-1))][j-1]);
	}
	q=read();
	while(q--){
		ULL ans=0;
		l=read();r=read();
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				int k=log2(j-i+1);
				ans=(ans+((max(f1[i][k],f1[j-(1<<k)+1][k]))%mod*(max(f2[i][k],f2[j-(1<<k)+1][k]))%mod)%mod)%mod;
			}
		}
		print(ans);
		printf("\n");
	}
	return 0;
}
/*
0 2
2 1
1 2
1 
1 2
*/
