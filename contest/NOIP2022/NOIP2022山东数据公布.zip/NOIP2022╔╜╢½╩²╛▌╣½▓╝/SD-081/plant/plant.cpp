#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e3+10;
const int mod=998244353;
int t,Id,n,m,c,f,ac,af,a[N][N],vis[N][N];
inline int read(){
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-f;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return f*x;
}
inline int read1(){
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-f;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=ch-'0';return f*x;}
}
inline void print(int x){if(x<0)putchar('-'),x=-x;if(x>9)print(x/10);putchar(x%10+'0');}
void clean(){
//	memset(a,0,sizeof(a));
	ac=0;af=0;
	memset(vis,0,sizeof(vis));
}
int F_l(int x,int y){
	int tot=0;
	for(int i=x+1;i<=n;i++){
		if(!a[i][y])
		tot++;
		else return tot;
	}
	return tot;
}
int F_h(int x,int y){
	int tot=0;
	for(int i=y+1;i<=m;i++){
		if(!a[x][i])
		tot++;
		else return tot;
	}
	return tot;
}
int Find_c(int x,int y){
//	if(F_h(x,y)>=2)
	int tot=0,l=F_l(x,y);//l���ŵ� 
	if(l>=2){
		int H=F_h(x,y),h;
		if(H<1) return 0;
		for(int i=x+2;i<=min(x+l,n);i++){
			h=F_h(i,y);
			if(h>=1){
				tot=(tot+(H)*h)%mod;
			}
		}
	}
	return tot;
}
int Find_f(int x,int y){
	int tot=0,l=F_l(x,y);//l���ŵ� 
	if(l>=3){
		int H=F_h(x,y),h;
		if(H<1) return 0;
		for(int i=x+2;i<min(n,x+l);i++){
			h=F_h(i,y);
			if(h>=1){
				tot=(tot+((H)*h)*(x+l-i))%mod;
			}
		}
	}
	return tot;
}
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	t=read();Id=read();
	while(t--){
		clean();
		n=read();m=read();c=read();f=read();
		if(Id==1){
			printf("0");
			return 0;
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				a[i][j]=read1();
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(!a[i][j]){
					if(!a[i+1][j]&&!a[i][j+1])
					ac=(ac+Find_c(i,j))%mod,af=(af+Find_f(i,j))%mod;
				}
			}
		}
		print((ac*c)%mod);printf(" ");print((af*f)%mod);printf("\n");
	}
	return 0;
}
