#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e6+10;
const int M=666;
int t,n,m,k,cnt,a1[N],a2[N],a3[N],a4[N],op[N],a[N],vis[M];
inline int read(){
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-f;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return f*x;
}
void clean(){
	memset(a1,0,sizeof(a1));
	memset(vis,0,sizeof(vis));//�᲻��T
	cnt=0;
}
void clean1(){
	memset(a1,0,sizeof(a1));
	memset(a2,0,sizeof(a2));
	memset(a3,0,sizeof(a3));
	memset(a4,0,sizeof(a4));
	memset(vis,0,sizeof(vis));
	cnt=0;
}
inline void print(int x){if(x<0)putchar('-'),x=-x;if(x>9)print(x/10);putchar(x%10+'0');}
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	t=read();
	if(t%10==2){
		for(int z=1;z<=t;z++){
			clean();
			n=read();m=read();k=read();
			int h1=1,t1=0;
			for(int i=1;i<=m;i++) a[i]=read();
			int i=0;
			while(i<m){
				++i;
				if(!vis[a[i]]){
					++t1;
					cnt++;
					a1[t1]=a[i];
					vis[a[i]]=1;
//					printf("1 1\n");
					op[cnt]=1;
				}
				else {
					if(a[i]==a1[h1]&&h1<t1){
						h1++;
						++cnt;
						op[cnt]=2;
						++cnt;
						op[cnt]=3;
//						printf("1 2\n");
//						printf("2 1 2\n");
					}
					else if(a[i]==a1[t1]&&h1<t1){
						++cnt;
						op[cnt]=1;
//						printf("1 1\n");
						t1--;
					}
					else {
						++t1;
						cnt++;
						a1[t1]=a[i];
						op[cnt]=1;
					}
				}
			}
			print(cnt);
			printf("\n");
			for(int i=1;i<=cnt;i++){
				if(op[i]==1){
					printf("1 1\n");
				}
				else if(op[i]==2){
					printf("1 2\n");
				}
				else printf("2 1 2\n");
			}
		}
	}
//==========================================
	else {
		for(int z=1;z<=t;z++){
			clean1();
			n=read();m=read();k=read();
			int h1=1,h2=1,h3=1,h4=1,t1=0,t2=0,t3=0,t4=0;
			for(int i=1;i<=m;i++) a[i]=read();
			int i=0;
			while(i<m){
				++i;
				if(!vis[a[i]]){
					++t1;
					cnt++;
					a1[t1]=a[i];
					vis[a[i]]=1;
//					printf("1 1\n");
					op[cnt]=1;
				}
				else {
					if(a[i]==a1[h1]&&h1<t1){
						h1++;
						++cnt;
						op[cnt]=2;
						++cnt;
						op[cnt]=3;
//						printf("1 2\n");
//						printf("2 1 2\n");
					}
					else if(a[i]==a1[t1]&&h1<t1){
						++cnt;
						op[cnt]=1;
//						printf("1 1\n");
						t1--;
					}
					else {
						++t1;
						cnt++;
						a1[t1]=a[i];
						op[cnt]=1;
					}
				}
			}
			print(cnt);
			printf("\n");
			for(int i=1;i<=cnt;i++){
				if(op[i]==1){
					printf("1 1\n");
				}
				else if(op[i]==2){
					printf("1 2\n");
				}
				else printf("2 1 2\n");
			}
		} 
	}
//	while(t--){
//		clean();
//		n=read();m=read();k=read();
//	}
	return 0;
}
