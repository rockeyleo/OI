#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
const int N=5e5+10;
const int M=1e6+10;
int n,m,x,y,cnt,ans,head[N];
struct node{
	int u,v,nxt;
}a[N];
void add(int u,int v){
	a[++cnt]=(node){u,v,head[u]};
	head[u]=cnt;
}
inline int read(){
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-f;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return f*x;
}
inline void print(int x){if(x<0)putchar('-'),x=-x;if(x>9)print(x/10);putchar(x%10+'0');}
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		x=read();y=read();
		add(x,y);add(y,x);
	}
	if(m==(n-1)){
		ans=(ans+n+2)%mod;
		for(int i=1;i<n;i++){
			ans=(ans+(2*(i-1)%mod+((n-i)*(i))%mod)%mod)%mod;
		}
		print((ans+1)%mod);
		return 0;
	}
	return 0;
}
