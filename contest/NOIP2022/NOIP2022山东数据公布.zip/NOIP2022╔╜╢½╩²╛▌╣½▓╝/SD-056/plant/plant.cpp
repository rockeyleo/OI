#include<iostream>
#include<cstring>
#include<cstdio>
#define mod 998244353
using namespace std;
const int MAXN=1005;
int t,infd;
int n,m,c,f;
int ansC,ansF; 
char garden[MAXN][MAXN];
void growC(int x,int y)
{
	int xf=x,yf=y;
	int yup,ydo;
	for(int i=xf;i<=n;i++)
	{
		if(garden[i][yf]=='0' && garden[i][yf+1]=='0' && i==xf)
		{
			while(garden[i][y+1]=='0' && y+1<=m)
			{
				y++;
			}
			yup=y;
		}
		y=yf;
		if(garden[i][yf]=='0' && garden[i][yf+1]=='0' && i-x>=2)
		{
			while(garden[i][y+1]=='0' && y+1<=m)
			{
				y++;
			}
			ydo=y;
		}
		y=yf;
	}
	ansC+=(yup-yf)*(ydo-yf);
	//cout<<ansC<<endl;
}
int growF(int x,int y)
{
	int xf=x,yf=y;
	int yup,ydo;
	int n0,n1;
	for(int i=xf;i<n;i++)
	{
		if(garden[i+1][yf]=='1' && i+1<=n)
		{
			n0=i;
			break;
		}
		if(garden[i+1][yf]=='0' && garden[i][yf+1]=='0' && i==xf)
		{
			while(garden[i][y+1]=='0' && y+1<=m)
			{
				y++;
			}
			yup=y;
		}
		y=yf;
		if(garden[i+1][yf]=='0' && garden[i][yf+1]=='0' && i-x>=2)
		{
			n1=i;
			while(garden[i][y+1]=='0' && y+1<=m)
			{
				y++;
			}
			ydo=y;
		}
		y=yf;
		n0=i;
	}
	ansF+=(n0-n1)*(yup-yf)*(ydo-yf);
	//cout<<ansF<<endl;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&t,&infd);
	while(t--)
	{
		ansC=0;
		ansF=0;
		scanf("%d%d%d%d",&n,&m,&c,&f);
		if(c==0 && f==0)
		{
			cout<<"0 0"<<endl;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cin>>garden[i][j];
			}
		}
		for(int i=1;i<=n-2;i++)
		{
			for(int j=1;j<=m-1;j++)
			{
				if(garden[i][j]=='0')
				{
					growC(i,j);
					growF(i,j);
				}
			}
		}
		cout<<ansC%mod<<" "<<ansF%mod<<endl;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

114 514
90+1+4+4+15==114
450+60+4=514
*/ 
