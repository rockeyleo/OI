#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
const int MAXN=0x7fffffff;
int t;
int n,m,k;
int element[MAXN];
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++)
		{
			cin>>element[i];
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}

