#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e6+10;
const double pi=3.141592;
const int INF=0x3f3f3f3f;
const int mod=998244353;
int a[1010][1010],n,m,T,id,c,f,ans1,ans2;
void C(){
	int x1=1,x2,y1=1,y2=m,y3=m;
	x2=x1+2;
	while(x2>x1+1){
		for(int i=1;i<=n-x1-1;i++){
			for(int j=y1;j<=m;j++){
				if(a[x1][j]==1){
					y2=j-1;
					break;
				}
			}
			for(int j=y1;j<=m;j++){
				if(a[x2][j]==1){
					y3=j-1;
					break;
				}
			}
			if(y3>=2&&y2>=2){
				ans1+=(y2-y1)*(y3-y1)%mod;
				ans1%=mod;
			}
			x2++;
			y3=m;
			y2=m;
		}
		x1++;
	}
}
void F(){
	int x1=1,x2,x3,y1=1,y2=m,y3=m;
	x2=x1+2;
	x3=x2+1;
	while(x2>x1+1&&n>=x3){
		for(int i=1;i<=n-x1-2;i++){
			for(int j=y1;j<=m;j++){
				if(a[x1][j]==1){
					y2=j-1;
					break;
				}
			}
			for(int j=y1;j<=m;j++){
				if(a[x2][j]==1){
					y3=j-1;
					break;
				}
			}
			if(y3>=2&&y2>=2){
				ans2+=(y2-y1)*(y3-y1)%mod;
				ans2%=mod;
			}
			x2+=i;	
			x3++;
			y3=m;
			y2=m;	
		}
		x1++;
	}
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&T,&id);
	while(T--){
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				scanf("%d",&a[i][j]);
			}
		}
		if(c==0&&f==0){
			printf("0 0\n");
		}
		C();
		F();
		printf("%d %d\n",ans1*c,ans2*f);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

