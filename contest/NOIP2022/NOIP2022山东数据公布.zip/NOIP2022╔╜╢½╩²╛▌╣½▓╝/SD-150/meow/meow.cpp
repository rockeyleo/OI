#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e7+10;
const double pi=3.141592;
const int INF=0x3f3f3f3f;
int T,n,m,k,a[N],t1,t2,t3;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m,&k);
		for(int i=1;i<=m;i++){
			scanf("%d",&a[i]);
		}
		for(int i=1;i<=2*m;i++){
			
		}
	}
	fclose(stdin);
	fclose(stdout);
}

