#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e6+10;
const double pi=3.141592;
const int INF=0x3f3f3f3f;
const ll mod=0x3f3f3f3f3f3f3f3f;
int T,n,a1[N],a2[N],Q,l,r;
ll f1,f2,f3;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d%d",&T,&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a1[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&a2[i]);
	}
	scanf("%d",&Q);
	for(int i=1;i<=Q;i++){
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;i++){
			f1+=a1[i]*a2[i];
		}
		for(int i=l;i<=r-1;i++){
			for(int j=l+1;j<=r;j++){
				f2+=max(a1[i],a1[j])*max(a2[i],a2[j]);
			}
		}
		int mid=(l+r)/2;
		f3=(f1%mod+f2%mod)%mod;
		printf("%lld\n",f3);
		f1=0;
		f2=0;
		f3=0;
	}
	fclose(stdin);
	fclose(stdout);
}
