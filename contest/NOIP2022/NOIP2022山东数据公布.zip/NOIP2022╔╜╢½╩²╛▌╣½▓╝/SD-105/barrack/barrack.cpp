#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,hd=1,tl=1,dl[500009],tot,head[1000009],b[500009];
struct note
{
	int nxt;
	int to;
}edge[1009];
void ad(int u,int v)
{
	edge[++tot].to=v;
	edge[tot].nxt=head[u];
	head[u]=tot;
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int uu,vv;
		cin>>uu>>vv;
		ad(uu,vv);
		ad(vv,uu);
	}
	long long ans=0,xj=1;
	for(int i=1;i<=n;i++)
	{
		ans+=(i*xj);
		ans%=1000000007;
		xj*=2;
	}
	cout<<ans;
	return 0;	
} 
