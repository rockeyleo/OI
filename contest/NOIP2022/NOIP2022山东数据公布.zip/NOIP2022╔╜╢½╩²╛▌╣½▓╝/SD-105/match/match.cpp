#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int l,r,n,k,a[250009],b[250009],q,zda[15555][15555],zdb[15555][15555];
unsigned long long ans;
int mmax(int x,int y)
{
	int z;
	x>y? z=x:z=y;
	return z;
}
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>k>>n;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	if(n<=15550)
	{
		for(int i=1;i<=n;i++)
		{
			int maxa=a[i],maxb=b[i];
			for(int j=i;j<=n;j++)
			{
				maxa=zda[i][j]=mmax(maxa,a[j]);
				maxb=zdb[i][j]=mmax(maxb,b[j]);
			}
		}
		cin>>q;
		for(int k=1;k<=q;k++)
		{
			cin>>l>>r;
			ans=0;
			for(int i=l;i<=r;i++)
			{
				for(int j=i;j<=r;j++)
				{
					ans+=zda[i][j]*zdb[i][j];
				}
			}
			cout<<ans<<endl;
		}
		
	}
	else
	{
		cin>>q;
		for(int k=1;k<=q;k++)
		{
			cin>>l>>r;
			ans=0;
			for(int i=l;i<=r;i++)
			{
				for(int j=i;j<=r;j++)
				{
					int maxa=0,maxb=0;
					for(int pq=i;pq<=j;pq++)//zzd
					{
						maxa=mmax(maxa,a[pq]);
						maxb=mmax(maxb,b[pq]);
					}
					ans+=maxa*maxb;
				}
			}
			cout<<ans<<endl;
		}
	}
	return 0;	
}
