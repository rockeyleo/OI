#include<iostream>
#include<cstdio>
using namespace std;
int t,id,n,m,c,f,sx[1009][1009],sy[1009][1009],to[1009][1009],cans,fans;
char s[1009][1009];
bool map[1009][1009];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	if(id==1)
	{
		cout<<"0 0";
	}
	for(int kl=1;kl<=t;kl++)
	{
		cin>>n>>m>>c>>f;
		cans=fans=0;
		for(int i=1;i<=n;i++)
		{
			cin>>s[i];
			for(int j=1;j<=m;j++)
			{
				map[i][j]=(int)(s[i][j-1]-'0');
				sx[i][j]=sx[i][j-1]+map[i][j];
				sy[j][i]=sy[j][i-1]+map[i][j];
			}
		}
		for(int i=1;i<=n;i++)
		{
			int tot=0;
			for(int j=1;j<=m-1;j++)
			{
				if(j<=tot)
				{
					to[i][j]=tot;
					continue;
				}
				if(!map[i][j])
				{
					for(int k=j+1;k<=m;k++)
					{
						if(!map[i][k])
						{
							to[i][j]++;
						}
						else
						{
							tot=to[i][j];
							break;
						}
					}
				}
			}
		}
		for(int i=1;i<=n-2;i++)//x1
		{
			for(int j=i+2;j<=n;j++)//x2
			{
				for(int k=1;k<=m-1;k++)//y0
				{
					if(sy[k][i-1]==sy[k][j])//y0 x1->x2
					{
						long long zj=to[i][k]*to[j][k];
						cans+=((zj)%998244353);
						cans%=998244353;
						int cs=0;
						for(int jj=j+1;jj<=n;jj++)//x3
						{
							if(!map[jj][k]&&f==1)//x3,y0
							{
								cs++;
							}
							else
							{
								break;
							}
						}
						fans+=((zj*cs)%998244353);
						fans%=998244353;
					}
				}
			}
		}
		cout<<cans<<" "<<fans;
	}
	return 0;	
} 
