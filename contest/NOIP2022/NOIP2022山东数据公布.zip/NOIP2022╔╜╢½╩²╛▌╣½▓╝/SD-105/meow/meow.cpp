#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int t,n,m,k,a[2000009],op,b[2000009],ansf[2000009],anss[2000009],anssl[2000009];
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	for(int kl=1;kl<=t;kl++)
	{
		int totf=0,tots=0;
		memset(a,0,sizeof(0));
		cin>>n>>m>>k;
		for(int i=1;i<=m;i++)
		{
			cin>>a[i];
		}
		if(m<=n)
		{
			op+=m;
			for(int i=1;i<=m;i++)
			{
				ansf[++totf]=i;
			}
			for(int i=1;i<=m-1;i++)
			{
				for(int j=i+1;j<=m;j++)
				{
					if(a[i]==a[j]&&b[i]!=1&&b[j]!=1)
					{
						op++;
						anss[++tots]=i;
						anssl[tots]=j;
						b[i]=b[j]=1;
					}			
				}
			}
		}
		cout<<op<<endl;
		for(int i=1;i<=totf;i++)
		{
			cout<<"1 "<<ansf[i]<<endl;
		}
		for(int i=1;i<=tots;i++)
		{
			cout<<"2 "<<anss[i]<<" "<<anssl[i]<<endl;
		}
	}
	return 0;	
} 
