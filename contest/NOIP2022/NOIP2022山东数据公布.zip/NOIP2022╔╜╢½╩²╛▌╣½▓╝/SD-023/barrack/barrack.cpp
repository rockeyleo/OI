#include<iostream>
#include<cstdio>
#define N 500005
#define M 1000006
#define mod 1000000007
#define intt long long
using namespace std;
intt n,m,last[N],nx[M],to[N],fr[N],ans,vs,tot=1;
struct edge{
	intt f,t;
}ed[M];
bool opt[M],vis[N];
void add(intt x,intt y){
	to[++tot]=y;
	fr[tot]=x;
	nx[tot]=last[x];
	last[x]=tot;
}
void dfs2(int x){
	vis[x]=1;
	vs++;
	for(int i=last[x];i;i=nx[i])
		if(opt[i]&&!vis[to[i]])
			dfs2(to[i]);
}
void dfs(int x){
	if(x==m+1){
		for(intt i=1;i<=n;i++)
			if(!vis[i]){
				vs=0;
				dfs2(i);
				ans+=(1<<vs);
			}
		for(int i=1;i<=n;i++)vis[i]=0;
		return;
	}
	opt[x+1]=opt[(x+1)^1]=1;
	dfs(x+1);
	opt[x+1]=opt[(x+1)^1]=0;
	dfs(x+1);
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(intt i=1,x,y;i<=m;i++){
		cin>>x>>y; 
		add(x,y);
		add(y,x);
	}
	dfs(1);
	cout<<ans-n;
	return 0; 
}
//yxx lw jh
