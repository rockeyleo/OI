#include<iostream>
#include<cstdio>
#define uint unsigned long long
#define N 250005
using namespace std;
uint id,n,a1[N],a2[N],st[N],top,an1[N],an2[N],ans,q,an3[N],an4[N],st2[N],top2;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>id>>n;
	for(uint i=1;i<=n;i++)an1[i]=an2[i]=N;
	for(uint i=1;i<=n;i++){
		cin>>a1[i];
		while(top&&a1[i]>a1[st[top]])an1[st[top--]]=i;
		st[++top]=i;
	}
	for(uint i=n;i>=1;i--){
		while(top2&&a1[i]>a1[st[top2]])an3[st[top2--]]=i;
		st2[++top2]=i;
	}
	top=top2=0;
	for(uint i=1;i<=n;i++){
		cin>>a2[i];
		while(top&&a2[i]>a2[st[top]])an2[st[top--]]=i;
		st[++top]=i;
	}
	for(uint i=n;i>=1;i--){
		while(top2&&a2[i]>a2[st[top2]])an4[st[top2--]]=i;
		st2[++top2]=i;
	}
//	for(uint i=1;i<=n;i++)cout<<an3[i]<<' '<<an4[i]<<endl;
	cin>>q;
	for(uint l,r;q;q--){
		cin>>l>>r;
		uint i=l,j=l;
		while(an1[i]<=r||an2[j]<=r)
			if(an1[i]<an2[j]){
				ans+=a1[i]*a2[j]*(an1[i]-i)*(an1[i]-i);
				i=an1[i];
			}
			else{
				ans+=a1[i]*a2[j]*(an2[j]-j)*(an2[i]-j);
				j=an2[j];
			}
		ans+=a1[i]*a2[j]*(r-max(i,j)+1)*(r-max(i,j)+1);
		j=i=r;
		while(an3[i]>=l||an4[j]>=l)
			if(an3[i]>an4[j]){
				ans+=a1[i]*a2[j]*(i-an3[i])*(i-an3[i]);
				i=an3[i];
			}
			else{
				ans+=a1[i]*a2[j]*(j-an4[j])*(j-an4[j]);
				j=an4[j];
			}
		ans+=a1[i]*a2[j]*(min(i,j)-l+1)*(min(i,j)-l+1);
		cout<<ans<<endl;
		ans=0;
	}
	return 0; 
}
//yxx lw jh
