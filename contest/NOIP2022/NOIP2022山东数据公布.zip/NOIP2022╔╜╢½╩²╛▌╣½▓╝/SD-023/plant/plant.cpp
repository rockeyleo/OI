#include<iostream>
#include<cstdio>
#define N 1005
#define mod 998244353
using namespace std;
int t,id,n,m,sum0[N][N],pre[N][N],ans[N][N],ansc,ansf,ans2[N][N];
bool c,f,mp[N][N];
char a[N][N];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--){
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++){
				cin>>a[i][j];
				if(a[i][j]=='0')mp[i][j]=1;
			}
		for(int i=1;i<=n+1;i++)
			for(int j=m,sum=0;j>=1;j--)
				if(mp[i][j]){
					sum0[i][j]=sum;
					sum++;
					sum%=mod;
				}
				else{
					sum0[i][j]=-1;
					sum=0;
				}
		for(int j=1;j<=m;j++)
			for(int i=1;i<=n+1;i++)
				if(sum0[i][j]>=0){
					pre[i][j]=(pre[i-1][j]+sum0[i][j])%mod;
					if(sum0[i-1][j]!=-1)ans[i][j]=(pre[i-2][j]*sum0[i][j]+ans[i-1][j])%mod;
					ans2[i][j]=ans[i-1][j]+ans2[i-1][j];
				}
				else{
					ansc=(ansc+ans[i-1][j])%mod;
					ansf=(ansf+ans2[i-1][j])%mod;
				}
		cout<<c*ansc<<' '<<f*ansf<<endl;
	}
	return 0;
}
//jh yxx lw
