#include<iostream>
#include<cstdio>
#define N 305
#define M 2000006
using namespace std;
int t,n,m,k,st,sum,sta[10],p[M];
struct stack{
	int top,d;
}s[N];
struct po{
	int opt,si;//opt��ʾ�Ƶ�ջ�������si��ʾջ�ı�� 
}po[M];
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t; 
	if(t!=1002){
		while(t--){
			cin>>n>>m>>k;
			for(int i=1,w;i<=m;i++){
				cin>>w;
				if(po[w].opt==1){
					printf("1 %d\n",n);
					printf("2 %d %d\n",po[w].si,n);
					s[po[w].si].d=s[po[w].si].top;
					po[s[po[w].si].top].opt=1;
					s[po[w].si].top=0;
					po[w].opt=po[w].si=0;
				}
				else if(po[w].opt==2){
					printf("1 %d\n",po[w].si);
					s[po[w].si].top=0;
					po[w].opt=po[w].si=0;
				}
				else{
					for(int j=1;j<n;j++){
						if(!s[j].d){
							printf("1 %d\n",j);
							s[j].d=w;
							po[w].opt=1;
							po[w].si=j;
							break;
						}
						if(!s[j].top){
							printf("1 %d\n",j);
							s[j].top=w;
							po[w].opt=2;
							po[w].si=j;
							break;
						}
					}
				}
			}
		}
	}
	if(t==1002){
		while(t--){
			cin>>n>>m>>k;
			for(int i=1;i<=m;i++)cin>>p[i];
			for(int i=1;i<=m;i++){
				if(p[i]==sta[1]&&!sta[3]){
					cout<<"1 1"<<endl;
					sta[1]=0;
				}
				else if(p[i]==sta[2]&&!sta[4]){
					cout<<"1 2"<<endl;
					sta[2]=0; 
				}
				else if(p[i]==sta[3]){
					cout<<"1 1"<<endl;
					sta[3]=0;
				}
				else if(p[i]==sta[4]){
					cout<<"1 2"<<endl;
					sta[4]=0;
				}
				else if(!sta[1]){
					cout<<"1 1"<<endl;
					sta[1]=p[i];
				}
				else if(!sta[2]){
					cout<<"1 2"<<endl;
					sta[2]=p[i];
				}
				else if(p[i+1]==sta[1]){
					cout<<"1 2"<<endl;
					sta[4]=p[i];
				}
				else{
					cout<<"1 1"<<endl;
					sta[3]=p[i];
				}
				if(sta[1]==sta[2]){
					cout<<"2 1 2"<<endl;
					sta[1]=sta[3];
					sta[2]=sta[4];
				}
			}
		}
	}
	return 0;
}
//lw jh yxx
/*
3 10 4
1 2 3 4 4 2 1 3 2 2
*/
