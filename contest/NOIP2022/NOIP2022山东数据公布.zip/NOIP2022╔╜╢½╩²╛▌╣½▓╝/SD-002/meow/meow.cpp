#include<bits/stdc++.h>
using namespace std;
//const int N=  ;
int T,f[15];
int n,m,k,a[15];
int s[305],op;
queue<int> q[305]; 
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	while(scanf("%d"),&T){
		scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<=m;i++){
			scanf("%d",&a[i]);
		}
		for(int i=1;i<=m;i++){
			//scanf("%d",&a[i]);
			for(int j=1;j<=n;j++){
				for(int k=1;k<=m;k++){
					if(a[i]==a[k]){
					q[j].push(a[i]);
					op+=2;
					i++;
					break;
				}
				else if(a[i]!=a[k]){
					if(!q[j].empty()&&q[j].front()!=q[j+1].front()){
						q[j].push(a[i]);
						op++;
						break;
					}
					else{
						if(j+1>=n){
							q[j].push(a[i]);
						}
						else q[j+1].push(a[i]);
						op++;
						break;
					}
				}
				if(q[j].front()==q[j-1].front()){
					q[j].pop();
					q[j-1].pop();
					op++;
				} 
				}
			}
		}
		printf("%d\n",op);
		for(int i=1;i<=m;i++){
			for(int j=1;j<=n;j++){
				if(a[i]==a[i-1]){
					q[j].push(a[i]);
					i++;
					printf("1 %d\n",j);
					break;
				}
				else if(a[i]!=a[i-1]){
					if(!q[j].empty()){
						q[j].push(a[i]);
						printf("1 %d\n",j);
						break;
					}
					else{
						if(j+1>=n){
							q[j].push(a[i]);
							printf("1 %d\n",j);
						}
						else{
							q[j+1].push(a[i]);
							printf("1 %d\n",j+1);	
						}
						break;
					}
				}
				if(q[j].front()==q[j-1].front()){
					q[j].pop();
					q[j-1].pop();
					printf("2 %d %d\n",j-1,j);
				} 
			}
		}
//			for(int j=1;j<=m;j++){
//				if(a[i]==a[j]){
//					if(i==j-1){
//						
//					}
//				}
//			} 
//			if(a[i]==a[i-1]){
//				q.push
//			}
//			return 0;
//		}
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=m;j++){
//				int x=i;
//				if(a[j]==a[j-1]){
//					q[i].push(a[i]);
//				} 
//			}
//		} 
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=m;j++){
//				if(q[i]==q[i]){
//					return 0;
//				}
//			}
//		} 
	}
//	 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
