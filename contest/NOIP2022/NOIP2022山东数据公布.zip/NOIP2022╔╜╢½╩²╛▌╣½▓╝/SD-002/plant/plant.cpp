#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#define ll long long
using namespace std;
struct node{
	string s;
}a[1005];\
char b[1005][1005];
//const int N=  ;
int T,id,n,m,c,f,sum[305];
int x1,x2,y,y2;
ll ans1,ans2;
ll ansx,ansy;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	while(cin>>T>>id&&!id){
		cin>>n>>m>>c>>f;
		for(int x=1;x<=n;x++){
			for(int i=1;i<=m;i++){
				cin>>b[x][i];
			}
		}
		if(n<2||m<=2){
			printf("0 0");
			return 0;
		}
		for(int i=1;i<=n;i++){
			for(int j=2;j<=m;j++){
				if(b[i][j]=='1'){
					continue;
				}
				//cout<<b[i-1][j]<<" "<<b[i][j]<<endl;
				if(b[i][j]==b[i][j-1]){
					sum[i]++;
					x2=i;
					if(x1==0&&sum[i]){
						x1=i;
						//y=j;
					}
					if(!y&&b[i-1][j-1]==b[i][j-1]){
						y=j-1;
					}
					if(x1+1<x2&&j==m){
						ans1+=sum[x1]*sum[x2];
						//break;
					}
				}
			} 
		} 
		for(int i=1;i<=n-1;i++){
			for(int j=2;j<=m;j++){
				if(b[i][j]==49){
					continue;
				}
				if(b[i][j]==b[i][j-1]){
					if(x1==0){
						x1=i;
						//y=j;
					}
					if(!y&&b[i-1][j]==b[i][j]){
						y=j;
						
					}
					x2=i;
					if(b[i-1][y]==b[i][y]&&x1+1<x2){
						ans2++;
						y=0;
						//break;
					}
				}
			}
			
		}
		ansx=c*ans1%998244353 ;
		ansy=c*ans2%998244353 ;
		printf("%lld %lld",ansx,ansy); 
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
