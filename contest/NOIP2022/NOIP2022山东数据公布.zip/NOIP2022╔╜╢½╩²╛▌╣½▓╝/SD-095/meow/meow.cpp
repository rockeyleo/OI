#include <bits/stdc++.h>
using namespace std;
 
#define int long long 
#define itn long long 
#define space putchar(' ')
#define endl putchar('\n')

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') {
			f = -1;
		}
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9') {
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	return x * f;
}

const int N = 1001000;
deque<int> q[310];
int a[N];
int cnt;

struct iaa {
	int a, b, c;
} ans[N];

signed main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	int t = read();
	srand(time(0));
	while (t--) {
		cnt = 0;
		for (int i = 1; i <= n; i++) {
			while (!q[i].empty()) {
				q[i].pop_front();
			}
		}
		int n = read(), m = read(), k = read();
		for (int i = 1; i <= m; i++) {
			a[i] = read();
			bool bj = 0;
			for (int j = 1; j <= n; j++) {
				if (q[j].empty()) {
					continue;
				}
				if (a[i] == q[j].back()) {
					ans[++cnt].a = 1, ans[cnt].b = j;
					bj = 1;
					break;
				}
				if (a[i] == q[j].front()) {
					q[j].pop_front();
					ans[++cnt].a = 1, ans[cnt].b = n;
					ans[++cnt].a = 2, ans[cnt].b = n, ans[cnt].c = j;
					bj = 1;
					break;
				}
			}
			if (!bj) {
				int d = rand() % n;
				q[d].push_back(a[i]);
				ans[++cnt].a = 1, ans[cnt].b = d;
			}
		}
		cout << cnt, endl;
		for (int i = 1; i <= cnt; i++) {
			if (ans[i].a == 1) {
				cout << 1, space, cout << ans[i].b, endl;
			}
			else {
				cout << 2, space, cout << ans[i].b, space, cout << ans[i].c, endl;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
