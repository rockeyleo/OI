#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	srand(time(0));
	cout << rand();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
