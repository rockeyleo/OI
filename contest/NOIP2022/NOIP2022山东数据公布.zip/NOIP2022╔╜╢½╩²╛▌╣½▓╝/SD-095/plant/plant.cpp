#include <bits/stdc++.h>
using namespace std;

#define int long long
#define itn long long
#define mian main
#define endl putchar('\n')
#define space putchar(' ')

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') {
			f = -1;
		}
		ch = getchar();
 	}
 	while (ch >= '0' && ch <= '9') {
 		x = (x << 1) + (x << 3) + (ch ^ 48);
 		ch = getchar();
	}
	return x * f;
}

const int N = 1001000;
int a[2010][2010];
int n, m, cnt = 1, cntt, cnttt, c, f, ansc, ansf;

signed main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	int t = read(), id = read();
	while (t--) {
		ansc = ansf = 0;
		n = read(), m = read(), c = read(), f = read();
		char ch;
		while (cnt <= n) {
			ch = getchar();
			if (ch == '\r' || ch == '\n') {
				cnt++;
				cntt = 0;
				continue;
			}
			if (ch == '0') {
				a[cnt][++cntt] = 0;
			}
			else {
				a[cnt][++cntt] = 1;
			}
		}
		cnt = 0, cntt = 0;
		if (c == 0 && f == 0) {
			cout << 0, space, cout << 0, endl;
		}
		else {
			for (int i = 1; i <= n - 2; i++)  {
				for (int j = 1; j <= m - 1; j++) {
					cnt = cntt = cnttt = 0;
					if (a[i][j]) {
						continue;
					}
					if (a[i + 1][j]) {
						continue;
					}
					if (a[i + 2][j]) {
						continue;
					}
					if (a[i][j + 1]) {
						continue;
					}
					if (a[i + 2][j + 1]) {
						continue;
					}
					int k = j + 1, kk = i + 2, kkk = j + 1;
					while (a[kk][j] != 1) {
						if (kk > n) {
							break;
						}
						cnttt++;
						kk++;
					}
					kk = i + 2;
					while (a[kk][j] != 1) { 
						if (kk > n) {
							break;
						}
						cnttt--;
						kkk = j + 1;
						while (a[kk][kkk] != 1) {
							if (kkk > m) {
								break;
							}
							cntt += cnttt;
							cnt++;
							kkk++;
						}
						kk++;
					}
					while (a[i][k] != 1) {
						if (k > m) {
							break;
						}
						ansc += cnt;
						ansf += cntt;
						k++;
					}
				}
			}
			cout << c * ansc, space, cout << f * ansf, endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
	
