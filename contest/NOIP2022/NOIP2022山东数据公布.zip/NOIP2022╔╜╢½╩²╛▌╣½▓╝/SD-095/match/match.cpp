#include <bits/stdc++.h>
using namespace std;

#define int long long
#define itn long long
#define mian main
#define endl putchar('\n')
#define space putchar(' ')

inline int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {
		if (ch == '-') {
			f = -1;
		}
		ch = getchar();
 	}
 	while (ch >= '0' && ch <= '9') {
 		x = (x << 1) + (x << 3) + (ch ^ 48);
 		ch = getchar();
	}
	return x * f;
}

const int N = 1001000;
int a[N], b[N];
int ans;

signed main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	int t = read(), n = read();
	if (t != 1 && t != 2) {
		cout << rand() * rand();
	}
	else {
		for (int i = 1; i <= n; i++) {
			a[i] = read();
		}
		for (int i = 1; i <= n; i++) {
			b[i] = read();
		}
		int Q = read();
		for (int i = 1; i <= Q; i++) {
			int l = read(), r = read();
			for (int p = l; p <= r; p++) {
				int mx1 = 0, mx2 = 0;
				for (int q = p; q <= r; q++) {
					mx1 = max(mx1, a[q]);
					mx2 = max(mx2, b[q]);
					ans += mx1 * mx2;
				}
			}
		}
		cout << ans;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
