#include<bits/stdc++.h>
#define rep(i , a , n) for(int i(a) ; i <= n ; i++)
#define per(i , a , n) for(int i(n) ; i >= a ; i--)
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define db double
using namespace std;
template<typename T>
inline void read(T &x){
	T ch = getchar() , ans = 0 , fl = 1;
	while(!isdigit(ch)){
		if(ch == '-') fl = -1;
		ch = getchar();
	}
	while(isdigit(ch)){
		ans = (ans<<1) + (ans<<3) + (ch^48);
		ch = getchar();
	}
	x = fl*ans;
}
template<typename T , typename ...Args>
inline void read(T &x , Args &...args){
	read(x);read(args...);
}
int n , m;
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	return 0;
}

