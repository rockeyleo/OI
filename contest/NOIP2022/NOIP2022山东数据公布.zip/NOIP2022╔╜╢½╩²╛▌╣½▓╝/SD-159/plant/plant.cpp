#include<bits/stdc++.h>
#define int long long
#define rep(i , a , n) for(signed i(a) ; i <= n ; i++)
#define per(i , a , n) for(signed i(n) ; i >= a ; i--)
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define db double
const int md = 998244353;
using namespace std;
template<typename T>
inline void read(T &x) {
	T ch = getchar() , ans = 0 , fl = 1;
	while(!isdigit(ch)) {
		if(ch == '-') fl = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		ans = (ans<<1) + (ans<<3) + (ch^48);
		ch = getchar();
	}
	x = fl*ans;
}
template<typename T , typename ...Args>
inline void read(T &x , Args &...args) {
	read(x);
	read(args...);
}
int n , m , c , f , a[1005][1005] , colomn[1005][1005]  , row[1005][1005] , mul[1005][1005] , prec[1005][1005] , prer[1005][1005];
char hc[1005][1005];
void dc(int i ,int j) {
	if(a[i][j] == 1) return;
	colomn[i][j] = 1;
	if(j == m) return;
	dc(i , j + 1);
	colomn[i][j] = colomn[i][j+1] + 1;
	return;
}
void dr(int i , int j) {
	if(a[i][j] == 1)return;
	row[i][j] = 1;
	if(i == n) return;
	dr(i + 1 , j);
	row[i][j] = row[i+1][j] + 1;
	return;
}
void reset() {
	memset(mul , 0 ,sizeof mul);
	memset(prec , 0 ,sizeof prec);
	memset(prer , 0 , sizeof prer);
	memset(row , 0 ,sizeof row);
	memset(colomn , 0 ,sizeof colomn);
	memset(a , 0 ,sizeof a);
}
//int qp(int a , int b){
//	int res = 1;
//	while(b){
//		if(b&1){
//			res = (res * a)%md;
//		}
//		a = (a*a)%md;
//		b >>= 1;
//	}
//	return res;
//}
//int inv(int n){
//	return qp(n , md - 2);
//}
//int C(int n , int m){
//	return fac[m]*inv(fac[m - n] * fac[n])%md;
//}
void solve() {//i��j��
	read(n  , m , c , f);
//	cerr<<n << m << c << f;
	long long ansc = 0, ansf = 0;
	rep(i , 1 , n) {
		scanf("%s" , hc[i]+1);
	}
	rep(i , 1 , n) rep(j , 1 , m) a[i][j] = hc[i][j]^'0';
	rep(i , 1 , n)
	rep(j , 1 , m)
	if(a[i][j] == 0) {
		if(1 - colomn[i][j]) {
			dc(i , j);
		}
		if(1 - row[i][j]) {
			dr(i , j);
		}
	}
	//����ǰ׺��
	rep(i , 1 , m)
	rep(j , 1 , n)
	prec[j][i] = (prec[j - 1][i] + colomn[j][i] - 1)%md,(prer[j][i] = prer[j - 1][i]%md + ((colomn[j][i]-1)%md*(row[j][i] - 1)%md)%md) %= md;
	//�ж�
	rep(i , 1 , n) {
		rep(j , 1 , m) {
			int delta = i + row[i][j] - 1;
			int mid = i + 1;
			if(delta > mid && 1 - a[i][j]) {
					int left = colomn[i][j] - 1;
					int right1 = prec[delta][j] - prec[mid][j],right2 = prer[delta][j] - prer[mid][j];
//					ansc+=C(left , 2)*C(right1,2);
//					ansf+=C(left , 2)*C(right2,2);
					(ansc+=(left%md*right1%md)%md)%=md;
					(ansf+=(left%md*right2%md)%md)%=md;
			}
		}
	}
	printf("%lld %lld\n",(ansc*=c)%=md,(ansf*=f)%=md);
	return ;
}
signed main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	clock_t c1 = clock();
	int tt , id;
	read(tt , id);
	while(tt--) {
		reset();
		solve();
	}
	cerr<<endl << "Time:" << clock() - c1 << "ms" << endl;
	return 0;
}

