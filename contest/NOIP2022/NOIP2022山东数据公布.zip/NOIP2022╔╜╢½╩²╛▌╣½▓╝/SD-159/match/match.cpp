#include<bits/stdc++.h>
#define rep(i , a , n) for(int i(a) ; i <= n ; i++)
#define per(i , a , n) for(int i(n) ; i >= a ; i--)
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define db double
using namespace std;
template<typename T>
inline void read(T &x){
	T ch = getchar() , ans = 0 , fl = 1;
	while(!isdigit(ch)){
		if(ch == '-') fl = -1;
		ch = getchar();
	}
	while(isdigit(ch)){
		ans = (ans<<1) + (ans<<3) + (ch^48);
		ch = getchar();
	}
	x = fl*ans;
}
template<typename T , typename ...Args>
inline void read(T &x , Args &...args){
	read(x);read(args...);
}
int n , m , q;
int st1[250010][26] , lg[250010] , st2[250010][26];
int a[250010] , b[250010];
void init(){
	lg[0] = -1;
	rep(i , 1 , 250000){
		lg[i] = lg[i >> 1] + 1;
	}
	rep(i , 1 ,n){
		st1[i][0] = a[i];
		st2[i][0] = b[i];
	} 
	rep(i , 1 , 25){
		for(int j = 1 ; j + (1 << i ) -1 <= n ; i++){
			st1[j][i] = max(st1[j][i - 1] , st1[j + (1 << (i-1))][i-1]);
			st2[j][i] = max(st2[j][i - 1] , st2[j + (1 << (i-1))][i-1]);
		}
	}
}
int query_a(int l ,int r){
	int len = lg[r - l + 1];
	return max(st1[l][len] , st1[r - (1<<(r - l + 1))][len]);
}
int query_b(int l ,int r){
	int len = lg[r - l + 1];
	return max(st2[l][len] , st2[r - (1<<(r - l + 1))][len]);
}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(m , n);
	rep(i , 1 , n){
		read(a[i]);
	}
	rep(i , 1 , n){
		read(b[i]);
	}
	read(q);
	while(q--){
		unsigned long long ans = 0;
		int l ,r;
		read(l , r);
		rep(u , l , r){
			rep(v , u , r){
				ans += query_a(u , v) * query_b(u , v);
			}
		}
		printf("%u" , ans);
	}
	return 0;
}

