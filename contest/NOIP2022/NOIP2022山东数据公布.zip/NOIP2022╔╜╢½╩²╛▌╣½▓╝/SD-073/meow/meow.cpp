#include<bits/stdc++.h>
//#include<set>
//#define int long long
using namespace std;
const int MOD=998244353;
const int MAX=310;
inline int read(){
	int ret=0,f=0;char c=getchar();
	for(;!isdigit(c);c=getchar()) f|=(c=='-');
	for(;isdigit(c);c=getchar()) ret=(ret<<3)+(ret<<1)+(c^'0');
	return f?-ret:ret;
}
/*
ÿk+1����һ�����ٻ����һ��һ����
k=2n-2ʱ��������ÿ��ջ�з�������
��Ϊ���ܱ�֤��һ��ջΪ�գ�������ͬʱ���Ե�һʱ��ɾ�� 
*/
int T;
namespace Sub1{
	void solve(){
		int stc[MAX][3],tp[MAX];
		int ans[(int)2e6+10][3];
		while(T--){
			int cnt=0;
			int n=read(),m=read(),k=read(),sum=n;
			for(int i=1;i<=n;i++){
				tp[i]=0;
				stc[i][1]=stc[i][2]=stc[i][0]=0;
			}
			for(int i=1;i<=m;i++){
				int x=read(),jl=0,f=0;
				for(int j=1;j<=n;j++){
					if(tp[j]==1){
						ans[++cnt][0]=1;
						ans[cnt][1]=j;
//						printf("1 %d\n",j);
						if(stc[j][tp[j]]==x) tp[j]--;
						else stc[j][++tp[j]]=x;
						f=1;
						break;
					}
					else if(tp[j]==0){
						if(sum>1){
							ans[++cnt][0]=1;
							ans[cnt][1]=j;
//							printf("1 %d\n",j);
							stc[j][++tp[j]]=x;
							f=1;sum--;break;
						}
						else jl=j;
					}
				}
//				cout<<jl<<endl;
				if(!f){
					for(int j=1;j<=n;j++)
						if(stc[j][1]==x){
							ans[++cnt][0]=1;
							ans[cnt][1]=jl;
//							printf("1 %d\n",jl,j);
							ans[++cnt][0]=2;
							ans[cnt][1]=j;
							ans[cnt][2]=jl;
//							printf("2 %d %d\n",jl,j);
							stc[jl][1]=stc[jl][2];
							stc[j][1]=stc[j][2];
							tp[jl]=tp[j]=1;
						}
				}
			}
			cout<<cnt<<'\n';
			for(int i=1;i<=cnt;i++){
				cout<<ans[i][0]<<' ';
				if(ans[i][0]==1) cout<<ans[i][1]<<'\n';
				else cout<<ans[i][1]<<' '<<ans[i][2]<<'\n';
			}
		}
		return ;
	}
}
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	T=read();
//	if(T==1001)
	Sub1::solve();
}
/*
1
2 4 2
1 2 1 2
*/
