#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MOD=998244353;
const int MAX=1e3+10;
inline int read(){
	int ret=0,f=0;char c=getchar();
	for(;!isdigit(c);c=getchar()) f|=(c=='-');
	for(;isdigit(c);c=getchar()) ret=(ret<<3)+(ret<<1)+(c^'0');
	return f?-ret:ret;
}
/*
����ÿһ��Ԥ����һ��f[j]��ʾ��j��ʼ���������0�ĸ���
����ÿһ��Ԥ����һ��g[i]��ʾ��i��ʼ���������0�ĸ���
����ö������
����f����ÿһ����һ��һά��׺�ͣ�O(nm)��� 
*/
char c[MAX][MAX];
int f[MAX][MAX],g[MAX][MAX],h[MAX][MAX];
inline int ask(int j,int l,int r){
	return f[r][j]-f[l+1][j];
}
inline int ask2(int j,int l,int r){
	return h[r][j]-h[l+1][j];
}
signed main(){
//	return system("fc plant3.ans plant.out"),0;
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=read(),id=read();
	while(T--){
		int n=read(),m=read(),xx=read(),yy=read();
		for(int i=1;i<=n;i++) scanf("%s",c[i]+1);
		memset(f,0,sizeof f); 
		memset(g,0,sizeof g); 
		memset(h,0,sizeof h); 
		for(int i=1;i<=n;i++)
			for(int j=m;j>=1;j--){
				if(c[i][j]=='1') f[i][j]=0;
				else{
					if(j==m) f[i][j]=1;
					else f[i][j]=f[i][j+1]+1;
				}
			}
		for(int j=1;j<=m;j++)
			for(int i=n;i>=1;i--){
				if(c[i][j]=='1'){
					g[i][j]=0;
					f[i][j]=f[i+1][j];
				}
				else{
					if(i==n) g[i][j]=1;
					else{
						g[i][j]=g[i+1][j]+1;
						f[i][j]+=f[i+1][j];
					}
				}
			}
		for(int j=2;j<=m;j++) 
			for(int i=1;i<=n;i++)
				h[i][j]=(h[i+1][j]+ask(j,i,i)*g[i+1][j-1])%MOD; 
		int ans1=0,ans2=0;
		for(int j=1;j<m;j++)//ö������
			for(int i=1;i+2<=n;i++){//ö�ٵ�һ������
				if(g[i][j]>=3) ans1=(ans1+ask(j+1,i,i)*ask(j+1,i+g[i][j]-1,i+2))%MOD;
				if(g[i][j]>=4&&i+3<=n) ans2=(ans2+ask(j+1,i,i)*ask2(j+1,i+g[i][j]-2,i+2))%MOD;
//				cout<<ans2<<endl; 
			}
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=m;j++){
//				cout<<f[i][j]<<" ";
//			}
//			cout<<endl;
//		}
		cout<<ans1*xx<<" "<<ans2*yy<<endl;
	}
	return 0;
}
/*
3 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111
6 6 1 1
000010
011000
000110
010000
011000
000000
4 3 1 1
001
010
000
000
*/
