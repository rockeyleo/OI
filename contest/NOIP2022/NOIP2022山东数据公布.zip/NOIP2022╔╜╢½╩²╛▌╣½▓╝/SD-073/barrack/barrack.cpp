#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MOD=1e9+7;
const int MAX=2e5+10;
inline int read(){
	int ret=0,f=0;char c=getchar();
	for(;!isdigit(c);c=getchar()) f|=(c=='-');
	for(;isdigit(c);c=getchar()) ret=(ret<<3)+(ret<<1)+(c^'0');
	return f?-ret:ret;
}
int n,m,ans,fa[MAX],vis[MAX];
int fid(int x){return fa[x]==x?fa[x]:fid(fa[x]);}
int u[MAX],v[MAX],cnt;
void dfs2(int stp){
//	if(fid(stp))
	if(stp==m+1){
		int sum=0;
		for(int i=1;i<=n;i++)
			if(vis[i]&&fid(i)==i) sum++;
		if(sum==1) ans=(ans+cnt)%MOD;
		return ;
	}
	int t=fa[v[stp]];
	if(vis[u[stp]]&&vis[v[stp]]){
		if(fid(u[stp])!=fid(v[stp])) fa[fid(v[stp])]=fid(u[stp]);
		dfs2(stp+1);
	}
	fa[v[stp]]=t;
	dfs2(stp+1);
	return ;
}
void dfs1(int stp){
	if(stp==n+1){
		int sum=0;
		cnt=1;
		for(int i=1;i<=m;i++)
			if(!vis[u[i]]&&!vis[v[i]]);
				cnt=(cnt<<1)%MOD;
//		cout<<cnt<<endl;
		for(int i=1;i<=n;i++) sum+=vis[i],fa[i]=i;
		if(!sum) return ;
		dfs2(1);
		return ;
	}
	vis[stp]=1;dfs1(stp+1);
	vis[stp]=0;dfs1(stp+1);
	return ;
}
signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++) u[i]=read(),v[i]=read();
	if(n<=16&&m<=25) dfs1(1);
	else{
		int jl=1;
		for(int i=1;i<=n-2;i++) jl=(jl<<1)%MOD;
		ans=(jl*(n*(n-1)/2%MOD)%MOD+(jl<<1))%MOD;
	}
	cout<<ans;
	return 0;
}
