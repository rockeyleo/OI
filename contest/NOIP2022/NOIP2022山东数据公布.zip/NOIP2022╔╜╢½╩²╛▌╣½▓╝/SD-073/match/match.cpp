#include<bits/stdc++.h>
//#define int long long
using namespace std;
const int MOD=998244353;
const int MAX=2e5+10;
inline int read(){
	int ret=0,f=0;char c=getchar();
	for(;!isdigit(c);c=getchar()) f|=(c=='-');
	for(;isdigit(c);c=getchar()) ret=(ret<<3)+(ret<<1)+(c^'0');
	return f?-ret:ret;
}
int a[MAX],b[MAX];
unsigned long long ans[3010][3010];
signed main(){
//	return system("fc match3.ans match.out"),0;
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T=read(),n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	for(int i=1;i<=n;i++)
		for(int j=i,ma=0,mb=0;j<=n;j++){
			ma=max(ma,a[j]);
			mb=max(mb,b[j]);
			ans[i][j]=ma*mb;
		}
//	for(int i=1;i<=n;i++,cout<<endl)
//		for(int j=1;j<=n;j++)
//			cout<<ans[i][j]<<" ";
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			ans[i][j]+=ans[i][j-1];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			ans[i][j]+=ans[i-1][j];
	int q=read();
	while(q--){
		int l=read(),r=read();
		cout<<(ans[r][r]-ans[r][l-1]-ans[l-1][r]+ans[l-1][l-1])<<'\n';
	}
	return 0;
}
/*
0 2
2 1
1 2
1
1 2
*/
