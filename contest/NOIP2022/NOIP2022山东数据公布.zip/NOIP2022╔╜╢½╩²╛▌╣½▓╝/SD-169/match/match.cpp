#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int t,n,a[250005],b[250005],q;
long long ans=0;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout); 
	scanf("%d%d",&t,&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++ ) scanf("%d",&b[i]);
	scanf("%d",&q);
	while(q--) {
		int l,r;
		ans=0;
		scanf("%d%d",&l,&r);
		for(int i=l;i<=r;i++) {
			for(int j=i;j<=r;j++) {
				int maxnn1=0,maxnn2=0;
				for(int k=i;k<=j;k++) {
					maxnn1=max(maxnn1,a[k]);
					maxnn2=max(maxnn2,b[k]);
				}
				ans=(ans+maxnn1*maxnn2);
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}

