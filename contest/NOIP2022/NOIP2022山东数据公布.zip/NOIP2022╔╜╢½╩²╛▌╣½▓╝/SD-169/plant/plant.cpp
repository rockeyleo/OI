#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int INF=998244353;
int t,id,n,m,c,f,a[1005][1005],sum[1005][1005],flag[1005][1005];
long long temp[1005][1005];
long long ansc=0,ansf=0;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&t,&id);
	while(t--)
	{
		memset(temp,0,sizeof(temp));
		memset(sum,0,sizeof(sum));
		memset(flag,0,sizeof(flag));
		ansc=0;
		ansf=0;
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++) {
			string t;
			cin>>t;
			for(int j=0;j<m;j++) {
				if(t[j]=='1') a[i][j+1]=1;
				else if(t[j]=='0') a[i][j+1]=0;
				if(i-2>=1&&a[i-1][j+1]==0&&a[i-2][j+1]==0&&a[i][j+1]==0) {
					flag[i-2][j+1]=1;
				}
			}
		}

		if(id==1) {
			printf("0 0\n");
			continue;
		}
		for(int i=1;i<=n;i++) {
			for(int j=m;j>=1;j--) {
				if(a[i][j]==1) {
					sum[i][j]=0;
					continue;
				}
				if(j==m&&a[i][j]==0) {
					sum[i][j]=1;
					continue;
				}
				sum[i][j]=sum[i][j+1]+1;
			}
		}
		for(int i=1;i<m;i++) {
			for(int j=1;j<=n-2;j++) {
				if(flag[j][i]==0||a[j][i]==1) continue;
				for(int k=j+2;k<=n;k++) {
					if(a[k][i]==1) break;
					ansc=(ansc+(sum[j][i+1]*sum[k][i+1]%INF)%INF)%INF;
					temp[k][i]=(temp[k][i]+sum[j][i+1]*sum[k][i+1]%INF)%INF;
				}
			}
		}
		if(f==0) {
			printf("%lld 0\n",ansc%INF);
			continue;
		}
		memset(sum,0,sizeof(sum));
		for(int i=1;i<=m;i++) {
			for(int j=n;j>=1;j--) {
				if(a[j][i]==1) {
					sum[j][i]=0;
					continue;
				}
				if(j==n&&a[j][i]==0) {
					sum[j][i]=1;
					continue;
				}
				sum[j][i]=sum[j+1][i]+1;
				if(temp[j][i]!=0&&j+1<=n&&sum[j+1][i]>0) {
					ansf=(ansf+(temp[j][i]*sum[j+1][i]%INF)%INF)%INF;
				}
			}
		}
		printf("%lld %lld\n",((long long)c*ansc%INF)%INF,((long long)f*ansf%INF)%INF);
	}
	return 0;
}

