#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const long long INF=1e9+7;
int n,m,a[3005][3005],c[3005][3005],choose[3005],ch=0;
long long ans=0;
struct node{
	int u,v,chose;
}road[5005];
void floyd()
{
	if(ch==0) return ;
	memset(c,0,sizeof(c));
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) c[i][j]=a[i][j];
	}
	for(int k=1;k<=n;k++) {
		for(int i=1;i<=n;i++) {
			for(int j=i+1;j<=n;j++) {
				if(c[i][k]==1&&c[k][j]==1) {
					c[i][j]=1;
					c[j][i]=1;
				}
			}
		}
	}
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			if((choose[i]==1&&choose[j]==1)&&(c[i][j]==0||c[j][i]==0)) {
				return ;
			}
		}
	}
	ans=(ans+1)%INF;
	return ;
}
void dfs(int now)
{
	if(now==n+m+1) {
		floyd();
		return ;
	}
	if(now>n&&now<=n+m) {
		a[road[now-n].u][road[now-n].v]=0;
		a[road[now-n].v][road[now-n].u]=0;
		road[now-n].chose=0;
		dfs(now+1);
		a[road[now-n].u][road[now-n].v]=1;
		a[road[now-n].v][road[now-n].u]=1;
		road[now-n].chose=1;
		dfs(now+1);
	}else if(now>=1&&now<=n) {
		choose[now]=0;
		dfs(now+1);
		choose[now]=1;
		ch++;
		dfs(now+1);
		ch--;
	}
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	memset(a,0,sizeof(a));
	memset(road,0,sizeof(road));
	memset(choose,0,sizeof(choose));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		a[i][i]=1;
		c[i][i]=1;
	}
	for(int i=1;i<=m;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		road[i].u=u;
		road[i].v=v;
		a[u][v]=1;
		a[v][u]=1;
	}
	dfs(1);
	printf("%lld\n",ans%INF);
	return 0;
}

