#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int t,n,m,k,topp=0,flag=0;
int a[2000006];
struct node1{
	int top,last,first,xx[20];
}x[305];
struct node2{
	int tep,s1,s2;
}ans[4000006];
bool check()
{
	for(int i=1;i<=n;i++) {
		if(x[i].top!=0) return 0;
	}
	return 1;
}
void dfs(int step)
{
	if(flag==1||step>2*m) return ;
	if(topp==0) {
		if(check()&&step>=m&&step<=2*m) {
			flag=1;
			printf("%d\n",step);
			for(int i=1;i<=step;i++) {
				if(ans[i].tep==1) {
					printf("1 %d\n",ans[i].s1);
				}else{
					printf("2 %d %d\n",ans[i].s1,ans[i].s2);
				}
			}
			return ;
		}
	}
	for(int i=1;i<=n;i++) {
		if(x[i].top>=1) {
			for(int j=1;j<=n;j++) {
				if(j==i) continue;
				if(x[i].last==x[j].last) {
					ans[step+1].tep=2;
					ans[step+1].s1=i;
					ans[step+1].s2=j;
					x[i].top--;
					x[j].top--;
					x[i].last=x[i].first;
					x[j].last=x[j].first;
					dfs(step+1);
				}
			}
		}
	}
	for(int i=1;i<=n;i++) {
		if(x[i].top==1&&x[i].last==a[topp]) {
			x[i].top--;
			x[i].last=0;
			ans[step+1].tep=1;
			ans[step+1].s1=i;
			dfs(step+1);
		}
		if(x[i].top==2&&x[i].first==a[topp]) {
			x[i].top--;
			x[i].first=0;
			ans[step+1].tep=1;
			ans[step+1].s1=i;
			dfs(step+1);
		}
		if(x[i].top==0) {
			x[i].top++;
			x[i].last=a[topp];
			ans[step+1].tep=1;
			ans[step+1].s1=i;
			dfs(step+1);
		}
		if(x[i].top==1&&x[i].last!=a[topp]) {
			x[i].top++;
			x[i].first=a[topp];
			ans[step+1].tep=1;
			ans[step+1].s1=i;
			dfs(step+1);
		}
	}
}
void dfsmin(int step)
{
	if(flag==1||step>2*m) return ;
	if(topp==0) {
		if(check()&&step>=m&&step<=2*m) {
			flag=1;
			printf("%d\n",step);
			for(int i=1;i<=step;i++) {
				if(ans[i].tep==1) {
					printf("1 %d\n",ans[i].s1);
				}else{
					printf("2 %d %d\n",ans[i].s1,ans[i].s2);
				}
			}
			return ;
		}
	}
	for(int i=1;i<=n;i++) {
		if(topp-1>=0) {
			int tt;
			if(x[i].xx[x[i].top]==a[topp]) {
				tt=1;
				x[i].top--;
				topp--;
			}else{
				tt=2;
				x[i].top++;
				x[i].xx[x[i].top]=a[topp];
				topp--;
			}
			ans[step+1].tep=1;
			ans[step+1].s1=i;
			dfs(step+1);
			topp++;
			if(tt==1) {
				x[i].top++;
			}else{
				x[i].top--;
			}
		}
	}
	for(int i=1;i<=n;i++) {
		if(x[i].top>=1) {
			for(int j=1;j<=n;j++) {
				if(i==j) continue;
				if(x[i].xx[x[i].top]==x[j].xx[x[j].top]) {
					x[i].top--;
					x[j].top--;
					ans[step+1].tep=2;
					ans[step+1].s1=i;
					ans[step+1].s2=j;
					dfs(step+1);
					x[i].top++;
					x[j].top++;
				}
			}
		}
		
	}
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		flag=0;
		memset(x,0,sizeof(x));
		scanf("%d%d%d",&n,&m,&k);
		topp=0;
		for(int i=m;i>=1;i--) {
			topp++;
			scanf("%d",&a[i]);
		}
		if(m<=14) {
			dfsmin(0);
			continue;
		}
		dfs(0);
	}
	return 0;
}

