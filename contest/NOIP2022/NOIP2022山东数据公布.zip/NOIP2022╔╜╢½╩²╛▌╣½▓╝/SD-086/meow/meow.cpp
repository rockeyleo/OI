#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+1,mod=998244353;
int t,n,m,k,a[N<<1],zhan[301][N];
int js,op,x,s1,s2,top,bac;
deque<int>q1,q2,q3;
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cin>>n>>m>>k;
	}
	
	return 0;
}
/*
......
*/ 
