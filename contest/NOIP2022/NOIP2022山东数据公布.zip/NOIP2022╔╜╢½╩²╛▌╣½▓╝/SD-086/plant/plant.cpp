#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e3+1,mod=998244353;
int n,m,c,f,t,id;
int dis[N][N],ansc,ansf;
char a[N][N];
int jl1[N][N],jl2[N][N],jl3[N][N],jl4[N][N],jl5[N][N],jl6[N][N];
int main()
{	
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
//	cin>>t>>id;
	while(t--)
	{
		cout<<0<<endl;
	}
	return 0;
} 

/*
4 3 1 1
001
010
000
000
*/
//		for(int i=1;i<=n;++i)
//		{
//			for(int j=1;j<=m;++j)
//			{
//				for(int k=1;k<=m;++k)
//				{
//					for(int x=j;x<=k;++x)
//					{
//						if(a[x][i]!='0') break; 
//					}
//				}
//			}
//		}
//		cout<<(ansc*c)%mod<<" ";	
