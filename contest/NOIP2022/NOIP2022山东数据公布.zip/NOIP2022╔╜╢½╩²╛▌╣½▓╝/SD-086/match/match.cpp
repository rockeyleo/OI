#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+1;
const ll mod=2^64;
int n,q,l,r,id,mxa,mxb;
int a[N],b[N];
ll ans;
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>id>>n;
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&b[i]);
	}
	cin>>q;
	while(q--)
	{
		ans=0;
		scanf("%d%d",&l,&r);
		ans+=a[r]*b[r];
//		cout<<a[l]<<" "<<b[l]<<"\n"<<a[r]<<" "<<b[r]<<"\n";
		for(int i=l;i<=r;++i)
		{	
//			mxa=0; mxb=0;
//			for(int j=l;j<=i;++j)
//			{
			mxa=max(mxa,a[i]);
			mxb=max(mxb,b[i]);
//			}
//			cout<<mxa<<" "<<mxb<<endl;
			ans+=(mxa*mxb)%mod;
		}
		cout<<ans<<"\n";
	}
	return 0;
}
/*

0 2
2 1
1 2
1
1 2




*/ 

