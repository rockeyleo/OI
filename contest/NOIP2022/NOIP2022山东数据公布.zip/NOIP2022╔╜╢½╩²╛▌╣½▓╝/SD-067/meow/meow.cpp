#include <bits/stdc++.h>

const int N = 2e6 + 9;
int T, n_stk, n_card, n_color, a[N], whr[N];
std::vector<int> rec[N];
int top, stk[N], n_opt;

void mian() {
	scanf("%d%d%d", &n_stk, &n_card, &n_color);
	for (int i = 1; i <= n_color; ++i) rec[i].clear();
	for (int i = 1; i <= n_card; ++i) {
		scanf("%d", &a[i]);
		rec[(a[i] + 1) / 2].push_back(i);
	}
	n_opt = n_card;
	for (int i = 1; i <= n_color / 2; ++i) {
		top = 0;
		for (auto j: rec[i]) {
			stk[++top] = j;
			if (top > 1 && a[stk[top]] == a[stk[top - 1]])
				whr[stk[top]] = whr[stk[top - 1]] = i, top -= 2;
		}
		n_opt += top / 2;
		for (int j = 1; j <= top / 2; ++j) whr[stk[j]] = i;
		for (int j = top / 2 + 1; j <= top; ++j) whr[stk[j]] = n_stk;
	}
	printf("%d\n", n_opt);
	top = 0;
	for (int i = 1; i <= n_card; ++i) {
		printf("1 %d\n", whr[i]);
		if (whr[i] == n_stk) stk[++top] = a[i];
	}
	for (int i = 1; i <= top; ++i)
		printf("2 %d %d\n", (stk[i] + 1) / 2, n_stk);
}

int main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	scanf("%d", &T);
	while (T--) mian();
	return 0;
}
