#include <bits/stdc++.h>

int scan() {
	int x = 0; char ch = getchar();
	for (; ch < '0' || '9' < ch; ch = getchar());
	for (; '0' <= ch && ch <= '9'; ch = getchar())
		x = x * 10 + ch - '0';
	return x;
}
int Min(int x, int y) { return x < y ? x : y; }
int Max(int x, int y) { return x > y ? x : y; }

const int N = 3e5 + 9;
int id, n, Q, a[N], b[N], nxta[N], nxtb[N], t[N];

void modify(int x, int k) {
	for (; x <= n; x += (x & (-x))) t[x] = Min(t[x], k);
}
int query(int x) {
	int res = n + 1;
	for (; x; x -= (x & (-x))) res = Min(res, t[x]);
	return res;
}

int main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	id = scan(), n = scan();
	for (int i = 1; i <= n; ++i) a[i] = scan();
	for (int i = 1; i <= n; ++i) b[i] = scan();
	for (int i = 1; i <= n; ++i) t[i] = n + 1;
	for (int i = n; i; --i) {
		nxta[i] = query(n - a[i] + 1);
		modify(n - a[i] + 1, i);
	}
	for (int i = 1; i <= n; ++i) t[i] = n + 1;
	for (int i = n; i; --i) {
		nxtb[i] = query(n - b[i] + 1);
		modify(n - b[i] + 1, i);
	}
	Q = scan();
	while (Q--) {
		int l = scan(), r = scan();
		unsigned long long ans = 0;
		for (int p = l; p <= r; ++p) {
			int q = p, mxa = 0, mxb = 0;
			while (true) {
				mxa = Max(mxa, a[q]), mxb = Max(mxb, b[q]);
				int jumpTo = Min(nxta[q], nxtb[q]);
				unsigned long long res = Min(r, jumpTo - 1) - q + 1;
				res *= mxa, res *= mxb, ans += res;
				if (jumpTo <= r) q = jumpTo;
				else break;
			}
		}
		printf("%llu\n", ans);
	}
	return 0;
}
