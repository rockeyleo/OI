#include <bits/stdc++.h>

const int N = 1009, Mo = 998244353;
int T, id, n, m, c, f, len[N][N];
char mp[N][N];

void mian() {
	scanf("%d%d%d%d", &n, &m, &c, &f);
	memset(len, 0, sizeof len);
	for (int i = 1; i <= n; ++i) {
		scanf("%s", mp[i] + 1);
		for (int j = m, lst = m + 1; j; --j) {
			if (mp[i][j] == '1') lst = j;
			else len[i][j] = lst - j;
		}
	}
	for (int j = 1; j <= m; ++j) mp[0][j] = mp[n + 1][j] = '1';
	int ansC = 0, ansF = 0;
	for (int j = 1; j < m; ++j) {
		for (int i = 1, st = N; i <= n + 1; ++i) {
			if (mp[i][j] == '1' && mp[i - 1][j] == '0') {
				int ed = i - 1;
				for (int k = st + 1, res = 0; k <= ed; ++k) {
					ansC += 1ll * len[k][j + 1] * res % Mo, ansC %= Mo;
					res += len[k - 1][j + 1], res %= Mo;
				}
				for (int k = st + 1, res = 0; k < ed; ++k) {
					ansF += 1ll * len[k][j + 1] * res % Mo * (ed - k) % Mo;
					ansF %= Mo;
					res += len[k - 1][j + 1], res %= Mo;
				}
			}
			if (mp[i][j] == '0' && mp[i - 1][j] == '1') st = i;
		}
	}
	printf("%d %d\n", c * ansC, f * ansF);
}

int main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	scanf("%d%d", &T, &id);
	while (T--) mian();
	return 0;
}
