#include <bits/stdc++.h>

int scan() {
	int x = 0; char ch = getchar();
	for (; ch < '0' || '9' < ch; ch = getchar());
	for (; '0' <= ch && ch <= '9'; ch = getchar())
		x = x * 10 + ch - '0';
	return x;
}

const int N = 5e5 + 9, M = 2e6 + 9, Mo = 1000000007;
int n, m, tot = 1, head[N], nxt[M], ver[M];

void addEdge(int u, int v) {
	ver[++tot] = v;
	nxt[tot] = head[u], head[u] = tot;
}

bool bri[M];
int dfc, dfn[N], low[N];

void Tarjan(int u, int inEdge) {
	dfn[u] = low[u] = ++dfc;
	for (int i = head[u]; i; i = nxt[i]) {
		int v = ver[i];
		if (!dfn[v]) {
			Tarjan(v, i);
			low[u] = std::min(low[u], low[v]);
			if (low[v] > dfn[u])
				bri[i] = bri[i ^ 1] = true;
		}
		else if (i != (inEdge ^ 1))
			low[u] = std::min(low[u], dfn[v]);
	}
}

bool vis[N];
int cnt, bel[N], sz[N];

void dfs(int u) {
	vis[u] = true, bel[u] = cnt, ++sz[cnt];
	for (int i = head[u]; i; i = nxt[i]) {
		if (bri[i]) continue;
		int v = ver[i];
		if (vis[v]) continue;
		dfs(v);
	}
}

int subtSz[N];
std::vector<int> cver[N];

void calcSubtSz(int u, int fa) {
	subtSz[u] = 1;
	for (auto v: cver[u]) {
		if (v == fa) continue;
		calcSubtSz(v, u);
		subtSz[u] += subtSz[v];
	}
}

int pw[M], f[N][2], ans, myArr[N], pre[N], suf[N];

void dp(int u, int fa) {
	f[u][1] = pw[sz[u]] - 1, f[u][0] = 1;
	for (auto v: cver[u]) {
		if (v == fa) continue;
		dp(v, u);
		int res = (f[v][1] + f[v][0]) % Mo;
		res = (res + pw[subtSz[v]]) % Mo;
		f[u][1] = 1ll * f[u][1] * res % Mo;
		f[u][0] = 1ll * f[u][0] * res % Mo;
	}
///////////////////////////////////////////////////////////////
	int res = 1, pnt = 0;
	for (auto v: cver[u]) {
		if (v == fa) continue;
		myArr[++pnt] = pw[subtSz[v]];
		res = 1ll * res * pw[subtSz[v]] % Mo;
	}
	f[u][0] = (f[u][0] - res) % Mo;
///////////////////////////////////////////////////////////////
	pre[0] = suf[pnt + 1] = 1;
	for (int i = 1; i <= pnt; ++i)
		pre[i] = 1ll * pre[i - 1] * myArr[i] % Mo;
	for (int i = pnt; i; --i)
		suf[i] = 1ll * suf[i + 1] * myArr[i] % Mo;
///////////////////////////////////////////////////////////////
	int now = 0, resul = f[u][0];
	for (auto v: cver[u]) {
		if (v == fa) continue;
		++now;
		int temp = 1ll * pre[now - 1] * suf[now + 1] % Mo;
		temp = 1ll * (f[v][0] + f[v][1]) % Mo * temp % Mo;
		resul = (resul - temp) % Mo;
	}
///////////////////////////////////////////////////////////////
	ans += 1ll * f[u][1] * pw[cnt - subtSz[u]] % Mo;
	ans %= Mo;
	ans += 1ll * resul * pw[cnt - subtSz[u]] % Mo;
	ans %= Mo;
}

int main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	n = scan(), m = scan();
	for (int i = 1; i <= m; ++i) {
		int u = scan(), v = scan();
		addEdge(u, v); addEdge(v, u);
	}
	Tarjan(1, 0);
	for (int i = 1; i <= n; ++i)
		if (!vis[i]) { ++cnt; dfs(i); }
	for (int u = 1; u <= n; ++u)
		for (int i = head[u]; i; i = nxt[i]) {
			int v = ver[i];
			if (bel[u] == bel[v]) continue;
			cver[bel[u]].push_back(bel[v]);
		}
	calcSubtSz(1, 0);
	pw[0] = 1;
	for (int i = 1; i <= std::max(n, m); ++i)
		pw[i] = 2ll * pw[i - 1] % Mo;
	dp(1, 0);
	ans = 1ll * ans * pw[m - cnt + 1] % Mo;
	ans = (ans % Mo + Mo) % Mo;
	printf("%d", ans);
	return 0;
}
