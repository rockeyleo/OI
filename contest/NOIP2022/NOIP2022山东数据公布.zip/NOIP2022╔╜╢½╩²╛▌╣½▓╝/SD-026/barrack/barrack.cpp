#include<bits/stdc++.h>
using namespace std;
int n,m;
const int N=1e6+10;
const int mod=1e9+7;
/*int he[N],ne[N],e[N],idx=0;
void add(int x,int y){
	e[++idx]=y;ne[idx]=he[x];he[x]=idx;
}
int a[N],sum=0,b[N];
void dfs(int x){
	if(sum==n){
		int res=0;
		for(int i=1;i<=n;i++){
			if(!a[i]||!b[i]){
				res=1;break;
			}
		}
		ans++;
		if(!res)return ;
	}
	if(a[x]==0&&b[i]==0)sum++;
	b[x]=1;
	for(int i=he[x];i;i=ne[i]){
		if(a[e[i]]==0)a[e[i]]=1;
		a[x]=1;
		dfs(e[i]);
		b[x]=1;
	}
	
	b[x]=0;
	for(int i=he[x];i;i=ne[i]){
		if(a[e[i]]==0)a[e[i]]=1;
	}
}*/
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(time(0));
	cin>>n>>m;
	int a=rand()%mod+1;
	cout<<a<<endl;
	return 0;
}



