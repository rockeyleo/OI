#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstring>
using namespace std;
const int N=1010;
typedef long long ll;
int a[N][N];
int f[N][N][3];
const int mod=998244353;
//f[][][0]��  1�� 
struct node{
	int i,j;
}p[N];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	cin>>t>>id;
	while(t--){
		int n,m,c,fu;
		cin>>n>>m>>c>>fu; 
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				char c;
				cin>>c;
				if(c=='1')a[i][j]=1;
				else a[i][j]=0;
				f[i][j][0]=f[i][j][1]=0;
			}
		}
		int sum=0;
		for(int i=1;i<=n;i++){
			int now=0;
			for(int j=m;j>=1;j--){
				if(a[i][j])now=0;
				else f[i][j][1]=now++;
			}
		}
		for(int j=1;j<=m;j++){
			int now=0;
			for(int i=n;i>=1;i--){
				if(a[i][j])now=0;
				else f[i][j][0]=now++;
			}
		}
		for(int j=1;j<=m;j++){
			for(int i=1;i<=n;i++){
				if(f[i][j][0]>=2&&f[i][j][1]>=1)p[++sum]={i,j},i+=f[i][j][0];
			}
		}
		ll ans=0,maxn=0;
		for(int u=1;u<=sum;u++){
			int i=p[u].i,j=p[u].j;
			ll res=0;
			int last=-1,lastis=-1;
			for(int k=i;k<=i+f[i][j][0];k++){
				if(f[k][j][1]==0)continue;
				//cout<<k<<" "<<j<<" ";
				if(lastis==k-1)res-=last;//
				ans=(ans+(ll)f[k][j][1]*res%mod)%mod;
				maxn=(maxn+(ll)f[k][j][0]*res*f[k][j][1]%mod)%mod;
				if(k!=i)res+=f[k][j][1];
				else res=f[k][j][1];
				if(lastis==k-1)res+=last;//
				last=f[k][j][1],lastis=k;
				//cout<<ans<<endl;
			}
		}
		cout<<c*ans%mod<<" "<<fu*maxn%mod<<endl;
	} 
	return 0;
}
/*
����һλ��AFO��OIer:
ңԶ�İ�����ķ����
���������ε�ingo 

Ȼ���ҵı�����Ҫ����
�ҵ���Ҳ��һ�̲�ͣ�ز���
�һ�����AFO 
NOIP rp++ 
*/

