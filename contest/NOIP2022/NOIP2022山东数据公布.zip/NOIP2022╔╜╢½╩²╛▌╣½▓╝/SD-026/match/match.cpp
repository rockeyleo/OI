#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstring>
using namespace std;
int read(){
	char c=getchar();
	int f=1,s=0;
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*f;
}
int a[10001];
int b[10001];
int f1[1001][1001],f2[1001][1001];
int n;
void init(){
	for(int j=0;j<=20;j++){
		for(int i=1;i<=n-(1<<j)+1;i++){
			if(!j)f1[i][j]=a[i];
			else f1[i][j]=max(f1[i][j-1],f1[i+(1<<j-1)][j-1]);
		}
	}
}
void init1(){
	for(int j=0;j<=20;j++){
		for(int i=1;i<=n-(1<<j)+1;i++){
			if(!j)f2[i][j]=b[i];
			else f2[i][j]=max(f2[i][j-1],f2[i+(1<<j-1)][j-1]);
		}
	}
}
long long query(int l,int r){
	int len=r-l+1;
	int k=log(len)/log(2);
	return max(f1[l][k],f1[r-(1<<k)+1][k]);
}
long long query1(int l,int r){
	int len=r-l+1;
	int k=log(len)/log(2);
	return max(f2[l][k],f2[r-(1<<k)+1][k]);
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int t=read();
	n=read();
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	int q=read();
	init();
	init1();
	while(q--){
		int l,r;
		l=read();r=read();
		unsigned long long ans=0;
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				ans=(ans+(unsigned long long)query(i,j)*query1(i,j));
			}
		}
		cout<<ans<<endl;
	} 
	return 0;
}



