#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstring>
using namespace std;
int read(){
	char c=getchar();
	int f=1,s=0;
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*f;
}
const int N=1e6+10,M=5e7+10;
int a[N];
int n,m,k;
int st[M];
int s[2][2];
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int t=read();
	while(t--){
		m=read(),n=read(),k=read();
		for(int i=1;i<=n;i++)a[i]=read();
		int ans=0;
		for(int i=1;i<=n;i++){
			if(s[0][0]&&s[1][0]){
				if(a[i]==s[1][0])s[1][0]=0,st[++ans]=2;
				else if(a[i]==s[0][0])s[0][0]=0,st[++ans]=1;
				else{
					if(a[i+1]==s[0][0]){
						s[0][0]=0;s[1][1]=a[i++];
						st[++ans]=2,st[++ans]=1;
					}
					else if(a[i+1]==a[i])i++,st[++ans]=1,st[++ans]=1;
					else {
						s[1][0]=0;s[0][1]=a[i++];
						st[++ans]=1,st[++ans]=2;
					}
				}
			}
			else if(!s[0][0]&&!s[1][1]){
				if(a[i]!=s[1][0])s[0][0]=a[i],st[++ans]=1;
				else s[1][0]=0,st[++ans]=2;
			}
		    else if(!s[1][0]&&!s[0][1]){
				if(a[i]!=s[0][0])s[1][0]=a[i],st[++ans]=2;
				else s[0][0]=0,st[++ans]=1;
			}
			else if(s[0][1]&&s[0][0]){
				if(a[i]==s[0][0]){
					s[0][0]=s[0][1];s[0][1]=0;
					st[++ans]=2,st[++ans]=3;
				}
				else if(a[i]==s[0][1]){
					s[0][1]=0;
					st[++ans]=1;
				}
				else {
					if(a[i+1]==s[0][0]){
						s[0][0]=s[0][1];s[0][1]=a[i++];
						st[++ans]=1,st[++ans]=2,st[++ans]=3; 
					}
					else if(a[i+1]==s[0][1]){
						s[1][0]=a[i++];s[0][1]=0;
						st[++ans]=2,st[++ans]=1;
					}
					else i++,st[++ans]=1,st[++ans]=1;
				}
			}
			else if(s[1][1]&&s[1][0]){
				if(a[i]==s[1][0]){
					s[1][0]=s[1][1];s[1][1]=0;
					st[++ans]=1,st[++ans]=3;
				}
				else if(a[i]==s[1][1]){
					s[1][1]=0;
					st[++ans]=2;
				}
				else {
					if(a[i+1]==s[1][0]){
						s[1][0]=s[1][1];s[1][1]=a[i++];
						st[++ans]=2,st[++ans]=1,st[++ans]=3;
					}
					else if(a[i+1]==s[1][1]){
						s[0][0]=a[i++];s[1][1]=0;
						st[++ans]=1,st[++ans]=2;
					}
					else i++,st[++ans]=1,st[++ans]=1;
				}
			}
		}
		cout<<ans<<endl;
		for(int i=1;i<=ans;i++){
			if(st[i]==3)cout<<"2 1 2"<<endl;
			else cout<<1<<" "<<st[i]<<endl;
		}
	}
	return 0;
}
