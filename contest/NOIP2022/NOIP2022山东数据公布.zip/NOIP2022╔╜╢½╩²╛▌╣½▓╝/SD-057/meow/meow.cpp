#include<bits/stdc++.h>

#define ll long long
#define fi first
#define se second
#define mkp make_pair
#define pii pair<int,int>
#define INF 0x3f3f3f3f
#define For(i,l,r) for(int i=(l);i<=(r);i++)
#define for_son(u) for(int e=head[u];e;e=nxt[e])
#define pb push_back
#define gc getchar
#define pc putchar

using namespace std;

char aa;

namespace ljh
{

namespace IO
{
	int rd()
	{
		int x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void wr(int x,char ch)
	{
		static int st[14];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}

	ll ll_rd()
	{
		ll x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void ll_wr(ll x,char ch)
	{
		static int st[22];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}
}

using namespace IO;

const int N=305,M=2e6+5,mod=0;

int T,n,m,k;
int ans;
struct Node{
	int op,s1,s2;
}sq[M<<1];

namespace task1
{
	int q[N][2];
//	bool vis[N<<1];
	void solve()
	{
//		puts("ljh");
		ans=0;
		n=rd(),m=rd(),k=rd();
		For(i,1,m){
			int x=rd(),y=(x+1)/2;
			if(q[y][0]==x){
				sq[++ans]={1,n,0}; 
				sq[++ans]={2,y,n};
				q[y][0]=q[y][1],q[y][1]=0;
			}
			else{
				sq[++ans]={1,y,0};
				if(!q[y][0]) q[y][0]=x;
				else{
					if(!q[y][1]) q[y][1]=x;
					else q[y][1]=0;
				}
			}
		}
		wr(ans,'\n');
		For(i,1,ans){
			if(sq[i].op==1){
				wr(1,' '),wr(sq[i].s1,'\n'); 
			}
			else wr(2,' '),wr(sq[i].s1,' '),wr(sq[i].s2,'\n');
		}
	}
	void main()
	{
		while(T--) solve();
	}
}

//namespace task2
//{
//	void solve()
//	{
//		
//	}
//	
//	void main()
//	{
//		while(T--) solve();
//	}
//}

namespace task3
{
	int a[N]; 
	int q[N][N*N],h[N],t[N];
	bool flag=false;
	
	void dfs(int x,int len,int now)
	{
		if(flag||len>m*2) return ;
		if((m*2-len)*2<now+(m-x+1)) return ;
		if(x>m&&!now){
			flag=true;
			wr(len,'\n');
			For(i,1,len){
				if(sq[i].op==1) wr(1,' '),wr(sq[i].s1,'\n');
				else wr(2,' '),wr(sq[i].s1,' '),wr(sq[i].s2,'\n');
			}
			return ;
		}
		if(x<=m){
			if(x<m&&a[x]==a[x+1])
			{
				sq[len+1]={1,1,0},sq[len+2]={1,1,0};
				dfs(x+2,len+2,now);
				return ;
			}
			For(i,1,n){
				sq[len+1]={1,i,0};
				if(h[i]<=t[i]&&q[i][t[i]]==a[x]){
					--t[i];
					dfs(x+1,len+1,now-1);
					++t[i];
				}
				else{
					int raw=q[i][t[i]+1];
					q[i][++t[i]]=a[x];
					dfs(x+1,len+1,now+1);
					q[i][t[i]]=raw;
					--t[i];
				}
			}
		}
		For(i,1,n-1){
			if(h[i]<=t[i]){
				For(j,i+1,n){
					if(h[j]<=t[j]){
						if(q[i][h[i]]==q[j][h[j]]){
							sq[len+1]={2,i,j};
							++h[i],++h[j];
							dfs(x,len+1,now-2);
							--h[i],--h[j]; 
						}
					}
				}
			}
		}
	}
	
	void solve()
	{
		flag=false;
		n=rd(),m=rd(),k=rd();
		For(i,1,n) h[i]=1,t[i]=0;
		For(i,1,m) a[i]=rd();
		dfs(1,0,0);
	}
	
	void main()
	{
		while(T--) solve();
	}
}

void main()
{
	T=rd();
//	task3::main();
	if(T%10==1) task1::main();
//	else if(T%10==2) task2::main();
	else task3::main();
}

/*
1
2 4 2
1 2 1 2

1
3 14 5
1 2 4 2 3  4 5 3 4 2  1 2 5 4

*/

}

char bb;

int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	ljh::main();
	fclose(stdin);
	fclose(stdout);
//	cerr<<(&bb-&aa)/1024/1024<<endl;
	return 0;
}


