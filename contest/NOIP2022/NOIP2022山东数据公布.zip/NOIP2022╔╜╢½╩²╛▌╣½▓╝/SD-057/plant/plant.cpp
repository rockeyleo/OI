#include<bits/stdc++.h>

#define ll long long
#define fi first
#define se second
#define mkp make_pair
#define pii pair<int,int>
#define INF 0x3f3f3f3f
#define For(i,l,r) for(int i=(l);i<=(r);i++)
#define for_son(u) for(int e=head[u];e;e=nxt[e])
#define pb push_back
#define gc getchar
#define pc putchar

using namespace std;

char aa;

namespace ljh
{

namespace IO
{
	int rd()
	{
		int x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void wr(int x,char ch)
	{
		static int st[14];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}

	ll ll_rd()
	{
		ll x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void ll_wr(ll x,char ch)
	{
		static int st[22];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}
}

using namespace IO;

const int N=1005,mod=998244353;

int n,m,C,F;
char mp[N][N];
int rg[N][N],dn[N][N];

inline void add(int &x,const int y)
{
	x=(x+y>=mod?x+y-mod:x+y);
}

void solve()
{
	n=rd(),m=rd(),C=rd(),F=rd();
	For(i,1,n) scanf("%s",mp[i]+1);
	int ansc=0,ansf=0;
	memset(rg,0,sizeof(rg));
	memset(dn,0,sizeof(dn));
	For(i,1,n){
		for(int j=m;j>=1;j--){
			if(mp[i][j]=='0'){
				if(j<m&&mp[i][j+1]=='0') rg[i][j]=rg[i][j+1]+1;
				else rg[i][j]=0;
			}
		}
	}
	For(j,1,m){
		for(int i=n;i>=1;i--){
			if(mp[i][j]=='0'){
				if(i<n&&mp[i+1][j]=='0') dn[i][j]=dn[i+1][j]+1;
				else dn[i][j]=0;
			}
		}
	}
	For(j,1,m){
		int tmp=0;
		For(i,1,n){
			if(mp[i][j]=='0'){
				add(ansc,1ll*tmp*rg[i][j]%mod);
				add(ansf,1ll*tmp*rg[i][j]%mod*dn[i][j]%mod);
				if(i>1&&mp[i-1][j]=='0') add(tmp,rg[i-1][j]); 
			}
			else tmp=0;
		}
	}
	wr(C*ansc,' '),wr(F*ansf,'\n');
}

void main()
{
	int T=rd(),id=rd();
	while(T--) solve();
}
/*
*/

}

char bb;

int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ljh::main();
	fclose(stdin);
	fclose(stdout);
//	cerr<<(&bb-&aa)/1024/1024<<endl;
	return 0;
}


