#include<bits/stdc++.h>

#define ull unsigned long long
#define ll long long
#define fi first
#define se second
#define mkp make_pair
#define pii pair<int,int>
#define INF 0x3f3f3f3f
#define For(i,l,r) for(int i=(l);i<=(r);i++)
#define for_son(u) for(int e=head[u];e;e=nxt[e])
#define pb push_back
#define gc getchar
#define pc putchar

using namespace std;

char aa;

namespace ljh
{

namespace IO
{
	int rd()
	{
		int x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void wr(int x,char ch)
	{
		static int st[14];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}

	ll ll_rd()
	{
		ll x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void ll_wr(ll x,char ch)
	{
		static int st[22];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}
}

using namespace IO;

const int N=2.5e5+5,M=3005,mod=0;

int T,n,q,a[N],b[N];
int lf[N],rg[N];
int mxa[M][M],mxb[M][M];
ull f[M][M],s[M][M];

//unsigned ll ask(int *a,int l,int r)
//{
//	For(i,l,r) lf[i]=rg[i]=0;
//	For(i,l,r){
//		while(top&&(a[i]>a[st[top]]||(a[i]==a[st[top]]&&i>st[top]))){
//			rg[st[top]]=i;
//			--top;
//		}
//		st[++top]=i;
//	}
//	while(top) rg[st[top]]=r+1,--top;
//	
//	for(int i=r;i>=l;i--){
//		while(top&&(a[i]>a[st[top]]||(a[i]==a[st[top]]&&i>st[top]))){
//			lf[st[top]]=i;
//			--top;
//		}
//		st[++top]=i;
//	}
//	while(top) lf[st[top]]=l-1,--top;
//	unsigned ll res=0;
//	For(i,l,r){
//		unsigned ll x=rg[i]-lf[i]+1;
//		res+=x*(x+1)/2;
//	}
//	return res;
//}

void main()
{
	T=rd(),n=rd();
	For(i,1,n) a[i]=rd();
	For(i,1,n) b[i]=rd();
	For(i,1,n){
		For(j,i,n){
			mxa[i][j]=max(mxa[i][j-1],a[j]);
			mxb[i][j]=max(mxb[i][j-1],b[j]);
			f[i][j]=(ull)mxa[i][j]*mxb[i][j];
		}
	}
	For(i,1,n){
		For(j,1,n){
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+f[i][j];
		}
	}
	q=rd();
	while(q--){
		int l=rd(),r=rd();
		ull res=(s[r][r]-s[l-1][r]-s[r][l-1]+s[l-1][l-1]);
		printf("%llu\n",res);
	} 
}

/*
0 2
2 1
1 2
1
1 2
*/

}

char bb;

int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	ljh::main();
	fclose(stdin);
	fclose(stdout);
//	cerr<<(&bb-&aa)/1024/1024<<endl;
	return 0;
}


