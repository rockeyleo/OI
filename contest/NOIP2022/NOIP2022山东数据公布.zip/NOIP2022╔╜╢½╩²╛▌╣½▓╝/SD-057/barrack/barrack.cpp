#include<bits/stdc++.h>

#define ll long long
#define fi first
#define se second
#define mkp make_pair
#define pii pair<int,int>
#define INF 0x3f3f3f3f
#define For(i,l,r) for(int i=(l);i<=(r);i++)
#define for_son(u) for(int e=head[u];e;e=nxt[e])
#define pb push_back
//#define gc getchar
#define pc putchar

using namespace std;

char aa;

namespace ljh
{

namespace IO
{
	const int SIZ=1<<20;
	char ibuf[SIZ],*P1,*P2;
	#define gc() (P1==P2&&(P2=(P1=ibuf)+fread(ibuf,1,SIZ,stdin),P1==P2)?EOF:*P1++)
	int rd()
	{
		int x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void wr(int x,char ch)
	{
		static int st[14];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}

	ll ll_rd()
	{
		ll x=0,f=1;
		char ch=gc();
		while(ch<'0'||ch>'9'){
			if(ch=='-') f=-1;
			ch=gc();
		}
		while(ch>='0'&&ch<='9'){
			x=x*10+ch-'0';
			ch=gc();
		}
		return x*f;
	}

	void ll_wr(ll x,char ch)
	{
		static int st[22];
		int top=0;
		do{
			st[++top]=x%10;
			x/=10;
		}while(x);
		while(top) pc(st[top--]+'0');
		pc(ch);
	}
}

using namespace IO;

const int N=5e5+5,M=1e6+5,mod=1e9+7;

int n,m;
ll p2[N+M];
int cnt=1,head[N],nxt[M<<1],to[M<<1]; 
int low[N],dfn[N],num;
bool cut[M<<1];
int col[N];
int sv[N],se[N],dcc;
vector<int>g[N];
ll f[N][3];

inline void add(int &x,const int y)
{
	x=(x+y>=mod?x+y-mod:x+y);
}

inline void add_edge(int u,int v)
{
	nxt[++cnt]=head[u];
	to[cnt]=v;
	head[u]=cnt;
}

void Tar(int u,int from)
{
	dfn[u]=low[u]=++num;
	for_son(u){
		int v=to[e];
		if(!dfn[v]){
			Tar(v,e);
			low[u]=min(low[u],low[v]);
			if(low[v]>dfn[u]) cut[e]=cut[e^1]=true;
		}
		else if(e!=(from^1)) low[u]=min(low[u],dfn[v]);
	}
}

void paint(int u,int C)
{
	col[u]=C;
	for_son(u){
		if(cut[e]) continue;
		int v=to[e];
		if(!col[v]) paint(v,C);
	}
}

void dp(int u,int fa)
{
	f[u][0]=1;
//	bool lf=true;
	For(i,0,(int)g[u].size()-1){
		int v=g[u][i];
		if(v==fa) continue;
		dp(v,u);
//		lf=false;
		ll g[3]={f[u][0],f[u][1],f[u][2]};
		f[u][0]=g[0]*f[v][0]%mod*2%mod;
		f[u][1]=(g[0]*f[v][1]%mod+g[1]*f[v][0]%mod*2%mod+g[1]*f[v][1]%mod)%mod;
		f[u][2]=(g[0]*(f[v][2]*2%mod+f[v][1])%mod+g[2]*f[v][0]%mod*2%mod)%mod;
	}
	ll v0=p2[se[u]],v1=(p2[sv[u]+se[u]]-v0+mod)%mod;
	ll g[3]={f[u][0],f[u][1],f[u][2]};
	f[u][0]=g[0]*v0%mod;
	f[u][1]=(g[0]*v1%mod+g[1]*(v0+v1)%mod)%mod;
	f[u][2]=g[2]*v0%mod;
}

void main()
{
	n=rd(),m=rd();
	p2[0]=1;
	For(i,1,n+m) p2[i]=p2[i-1]*2%mod;
	For(i,1,m){
		int u=rd(),v=rd();
		add_edge(u,v),add_edge(v,u);
	}
	Tar(1,0);
	For(i,1,n){
		if(!col[i]){
			++dcc;
			paint(i,dcc);
		}
	}
	for(int e=2;e<=cnt;e+=2){
		int u=to[e^1],v=to[e];
		if(cut[e]){
			g[col[u]].pb(col[v]),g[col[v]].pb(col[u]);
		}
		else ++se[col[u]];
	}
	For(i,1,n) ++sv[col[i]];
	dp(1,0);
	wr((f[1][1]+f[1][2])%mod,'\n');
}
/*
4 4
1 2
2 3
3 1
1 4
*/

}

char bb;

int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	ljh::main();
	fclose(stdin);
	fclose(stdout);
//	cerr<<(&bb-&aa)/1024/1024<<endl;
	return 0;
}


