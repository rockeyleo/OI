#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<climits>
#include<cstdio>
#include<string>
#include<deque>
#define MAXN 1000000
using namespace std;
int a[MAXN];
bool s[400];
int n,m,K;
int Read(){
	int a=0,s=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		ch=(ch=='-'?s=-1:s=1);
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a=a*10+ch-'0';
		ch=getchar();
	}
	return a*s;
}
void Print(int p){
	char ch[30];
	int k=0;
	if(p<0){
		putchar('-');
		p=p*-1;
	}
	do{
		ch[k]=p%10+'0';
		p=p/10;
		k++;
	}while(p>0);
	for(int i=k-1;i>=0;i--)
		putchar(ch[i]);
	return;
}
void PRINT(){
	deque<int>q[400];
	int k=0;
	for(int i=1;i<=m;i++){
		int b=a[i]/2;
		if(b!=0){
			if(q[b].empty()){
				q[b].push_front(a[i]);
				k++;
			}else if(q[b].back()==a[i]){
				k++;
				q[b].pop_back();
			}else if(q[b].front()==a[i]){
				k=k+2;
				q[b].pop_front();
			}else{
				k++;
			}
		}else{
			k++;
		}
	}
	printf("%d\n",k);
	return;
}
void PRINT_1(){
	deque<int>q[400];
	int s4;
	bool s2=0,s3=0;
	for(int i=1;i<=m;i++){
		int b=a[i]/2;
		if(b!=0){
			if(q[b].empty()){
				q[b].push_back(a[i]);
				putchar('1');
				putchar(' ');
				Print(b+1);
				putchar('\n');
			}else if(q[b].back()==a[i]){
				putchar('1');
				putchar(' ');
				Print(b+1);
				putchar('\n');
				q[b].pop_back();
			}else if(q[b].front()==a[i]){
				putchar('1');
				putchar(' ');
				Print(1);
				putchar('\n');
				putchar('2');
				putchar(' ');
				Print(b+1);
				putchar(' ');
				putchar('1');
				putchar('\n');
				q[b].pop_front();
			}else{
				putchar('1');
				putchar(' ');
				Print(b+1);
				putchar('\n');
				q[b].push_back(a[i]);
			}
		}else{
			if(s2==0){
				memset(s,0,sizeof(s));
				bool s1=0;
				for(int j=i+1;;j++){
					int b=a[j]/2;
					if(a[j]==1)break;
					if(!q[b].empty()){
						if(q[b].front()==a[j])s1=1;
						if(q[b].back()==a[j])s[a[j]]=1;
					}
				}
				if(s2==0){
					s4=1;
					putchar('1');
					putchar(' ');
					putchar('1');
					putchar('\n');
				}else{
					for(int j=2;j<n/2;j++)
						if(s[j]==0){
							s4=j+1;
							break;
						}
					putchar('1');
					putchar(' ');
					Print(s4);
					putchar('\n');
				}
				s2=1;
			}else{
				putchar('1');
				putchar(' ');
				Print(s4);
				putchar('\n');
				s2=0;
			}
		}
	}
} 
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int t=Read();
	while(t--){
		n=Read();
		m=Read();
		K=Read();
		for(int i=1;i<=m;i++)
			a[i]=Read();
		PRINT();
		PRINT_1();
	}
	return 0;
}

