#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<climits>
#include<cstdio>
#include<string>

using namespace std;

int Read(){
	long long a,s=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		ch=(ch=='-'?s=-1:s=1);
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a=a*10+ch-'0';
		ch=getchar();
	}
	return a*s;
}
void Print(long long p){
	char ch[30];
	int k=0;
	if(p<0){
		putchar('-');
		p=p*-1;
	}
	do{
		ch[k]=p%10+'0';
		p=p/10;
		k++;
	}while(p>0);
	for(int i=k-2;i>=0;i--)
		putchar(ch[i]);
	return;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t=Read(),id=Read();
	
	return 0;
}

