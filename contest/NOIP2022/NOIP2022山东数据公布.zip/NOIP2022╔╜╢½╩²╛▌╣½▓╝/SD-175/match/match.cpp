#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
#define N 250100
int T,n,a[N],b[N];
struct node{
	int l,r,val;
}Tree1[N<<2],Tree2[N<<2];
inline int read(){
	int ans=0;
	char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>47&&ch<58){
		ans=(ans<<3)+(ans<<1)+(ch^48);
		ch=getchar();
	}
	return ans;
}
void build1(int x,int l,int r){
	Tree1[x].l=l;
	Tree1[x].r=r;
	if(l==r){
		Tree1[x].val=a[l];
		return;
	}
	int mid=(l+r)>>1;
	build1(x<<1,l,mid);
	build1((x<<1)+1,mid+1,r);
	Tree1[x].val=max(Tree1[x<<1].val,Tree1[(x<<1)+1].val);
}
void build2(int x,int l,int r){
	Tree2[x].l=l;
	Tree2[x].r=r;
	if(l==r){
		Tree2[x].val=b[l];
		return;
	}
	int mid=(l+r)>>1;
	build2(x<<1,l,mid);
	build2((x<<1)+1,mid+1,r);
	Tree2[x].val=max(Tree2[x<<1].val,Tree2[(x<<1)+1].val);
}
long long query1(int x,int l,int r){
	int l1=Tree1[x].l,r1=Tree1[x].r,mid=(l1+r1)>>1;
	if(l<=l1&&r>=r1) return Tree1[x].val;
	long long ans=0;
	if(l<=mid) ans=max(ans,query1(x<<1,l,r));
	if(r>mid) ans=max(ans,query1((x<<1)+1,l,r));
	return ans;
}
long long query2(int x,int l,int r){
	int l1=Tree2[x].l,r1=Tree2[x].r,mid=(l1+r1)>>1;
	if(l<=l1&&r>=r1) return Tree2[x].val;
	long long ans=0;
	if(l<=mid) ans=max(ans,query2(x<<1,l,r));
	if(r>mid) ans=max(ans,query2((x<<1)+1,l,r));
	return ans;
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();n=read();
	int i,j,h,q,x,y;
	for(i=1;i<=n;i++) a[i]=read();
	for(i=1;i<=n;i++) b[i]=read();
	build1(1,1,n);build2(1,1,n);
	q=read();
	for(i=1;i<=q;i++){
		x=read();y=read();
		unsigned long long ans=0;
		for(j=x;j<=y;j++){
			for(h=j;h<=y;h++) ans+=query1(1,j,h)*query2(1,j,h);
		}
		cout<<ans<<"\n";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
