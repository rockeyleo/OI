#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define N 500100
#define M 2000100
#define P 1000000007
int n,m,head[N],tot=-1;
long long f[N][2];
bool setj[N];
struct node{
	int u,v,nxt;
}edge[M];
void add(int x,int y){
	edge[++tot].u=x;
	edge[tot].v=y;
	edge[tot].nxt=head[x];
	head[x]=tot;
}
inline int read(){
	int ans=0;
	char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>47&&ch<58){
		ans=(ans<<3)+(ans<<1)+(ch^48);
		ch=getchar();
	}
	return ans;
}
long long qpow(int x,int y){
	if(!y) return 1;
	if(y&1) return x*qpow(x,y^1)%P;
	long long ans=qpow(x,y>>1);
	return ans*ans%P;
}
void dfs1(int x,int fa){
	f[x][0]=f[x][1]=1;
	for(int i=head[x];~i;i=edge[i].nxt){
		if(edge[i].v==fa) continue;
		dfs1(edge[i].v,x);
		f[x][0]=(f[x][0]*(f[edge[i].v][0]*2+f[edge[i].v][1]*2)%P)%P;
		f[x][1]=(f[x][1]*(f[edge[i].v][0]*2+f[edge[i].v][1])%P)%P;
	}
}
void solve1(){//����DP 
	dfs1(1,0);
	long long ans1=(f[1][0]+f[1][1])%P;
	long long ans2=qpow(2,m);//ȫ��������Ӫ 
	printf("%lld",(ans1-ans2+P)%P);
}
void solve2(){//�����㣬��� 
	int i,j,zt,cnt;
	long long ans=0;
	for(i=1;i<(1<<n);i++){
		zt=i;cnt=0;
		for(j=1;j<=n;j++){
			setj[j]=(zt&1);
			zt=zt>>1;
		}
		for(j=0;j<=tot;j+=2){
			if(!setj[edge[j].u]||!setj[edge[j].v]) cnt++;
		}
		ans=(ans+qpow(2,cnt))%P;
	}
	printf("%lld",ans);
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	memset(head,-1,sizeof(head));
	n=read();m=read();
	int i,x,y;
	for(i=1;i<=m;i++){
		x=read();y=read();
		add(x,y);add(y,x);
	}
	if(m==n-1){
		solve1();
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	if(n<=16) solve2();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
