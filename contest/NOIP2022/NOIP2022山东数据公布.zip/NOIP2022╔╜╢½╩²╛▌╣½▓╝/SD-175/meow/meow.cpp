#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
