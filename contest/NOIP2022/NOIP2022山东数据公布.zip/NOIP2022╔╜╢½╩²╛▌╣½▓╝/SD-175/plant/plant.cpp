#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define N 1010
#define P 998244353
int n,m,C,F,b[N][N],c[N][N];
long long ansqzh[N];
char a[N][N];
inline int read(){
	int ans=0;
	char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>47&&ch<58){
		ans=(ans<<3)+(ans<<1)+(ch^48);
		ch=getchar();
	}
	return ans;
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id,i,j,h;
	t=read();id=read();
	while(t--){
		long long ansc=0,ansf=0;
		n=read();m=read();C=read();F=read();
		memset(b,0,sizeof(b));
		memset(c,0,sizeof(c));
		for(i=1;i<=n;i++){
			scanf("%s",a[i]+1);
			a[i][m+1]=49;
		}
		for(j=1;j<m+2;j++) a[n+1][j]=49;
		for(i=1;i<=n;i++){
			for(j=1;j<m+2;j++){
				if(a[i][j]==48) continue;
				for(h=j-1;h>=0&&a[i][h]==48;h--) b[i][h]=j-h;
			}
		}
		for(j=1;j<=m;j++){
			for(i=1;i<n+2;i++){
				if(a[i][j]==48) continue;
				for(h=i-1;h>=0&&a[h][j]==48;h--) c[h][j]=i-h;
			}
		}
		for(j=1;j<=m;j++){
			ansqzh[j]=0;
			for(i=1;i<=n;i++){//���¶��� 
				if(a[i][j]==48){
					if(i>2&&a[i-1][j]==48&&a[i-2][j]==48) ansqzh[j]=(ansqzh[j]+b[i-2][j]-1)%P;
					ansc=(ansc+ansqzh[j]*(b[i][j]-1)%P)%P;
					ansf=(ansf+ansqzh[j]*(b[i][j]-1)%P*(c[i][j]-1)%P)%P;
				}
				else ansqzh[j]=0;//�����ϰ���ǰ������ 
			}
		}
		printf("%lld %lld\n",C*ansc,F*ansf);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
