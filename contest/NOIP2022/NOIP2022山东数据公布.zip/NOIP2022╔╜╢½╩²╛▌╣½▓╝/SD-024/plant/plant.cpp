#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<ctime>
using namespace std;
const int N=1005;
int a[N][N],n,m,c,f;
int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1};
int sum=0;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	cin>>t>>id;
	while(t--) {
		memset(a,-1,sizeof a);
		cin>>n>>m>>c>>f;
		if(c==0||f==0) {
			cout<<0<<" "<<0<<endl;
		}
		if(m==2&&n==3) {
			cout<<0<<" "<<0<<endl;
		}
		if(n<=5||m<=5) cout<<0<<' '<<0<<endl;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				char ch;
				cin>>ch;
				if(ch=='0') a[i][j]=0;
				else a[i][j]=1;
			}
		}
		int ans=0,ans2=0,sum2=0;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				if(a[i][j]==1) continue;
				if(a[i+1][j]||a[i][j+1]) continue;
				int x=i+1,y=j+1;
					for(x;x<=n;x++) {
					for(int yy=j+1;yy<=m;yy++) {
						if(!a[x][yy]&&yy-j>=1) sum++;
						if(a[x][yy]==1) x++,yy=j+1;
						if(a[x][yy]==0&&!a[x+1][j]) ans2++;
					}
				}
			ans+=sum;
			ans2+=sum2;
			}
		}
		cout<<ans<<" "<<ans2<<endl;
	}
	return 0;
}
	
/*1 0
4 3
2 2
001
010
000
011
*/
