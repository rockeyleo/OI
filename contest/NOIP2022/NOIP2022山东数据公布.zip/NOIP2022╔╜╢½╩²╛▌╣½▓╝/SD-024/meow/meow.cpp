#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<ctime>
#include<stack>
using namespace std;
const int N=1e6+10;
int t,n,m,k;
int w[N],a[N],b[N];
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t>>n>>m>>k;
	while(t--) {
		for(int i=1;i<=n;i++) {
			cin>>w[i];
		}
		int cnt=1;
		a[cnt]=w[1];
		for(int i=2;i<=n;i++) {
			if(w[i]!=a[cnt]) {
				cout<<"1 1"<<endl;
				a[++cnt]=w[i];
			}
			else {
				cout<<"2 1 2"<<endl;
				cnt--;
			}
		}
	}
	return 0;
}
	

