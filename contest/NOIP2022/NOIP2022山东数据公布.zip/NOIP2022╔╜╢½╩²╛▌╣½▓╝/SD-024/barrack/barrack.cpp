#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<ctime>
using namespace std;
const int N=1e5+10;
int n,m;
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	while(m--) {
		int u,v;
		cin>>u>>v;
	}
	if(m==n-1) {
		cout<<n+n*m*(m-1)+1;
	}
	if(m==n) {
		cout<<m*(n-1)+n;
	}
	return 0;
}
