#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<ctime>
using namespace std;
const int N=1e6+10;
long long MOD=pow(2,64);
int a[N],b[N];
int t,n,q;
struct node{
	int l,r;
	int v;
}tr1[N],tr2[N];
void pushup(int u) {
	tr1[u].v=max(tr1[u*2].v,tr1[u*2+1].v);
	tr2[u].v=max(tr2[u*2].v,tr2[u*2+1].v);
}
void build1(int u,int l,int r) {
	tr1[u]={l,r};
	if(l==r) {
		tr1[u].v=a[l];
		return;
	}
	int mid=(l+r)>>1;
	build1(u*2,l,mid);
	build1(u*2+1,mid+1,r);
}
void build2(int u,int l,int r) {
	tr2[u]={l,r};
	if(l==r) {
		tr2[u].v=b[l];
		return;
	}
	int mid=(l+r)>>1;
	build2(u*2,l,mid);
	build2(u*2+1,mid+1,r);
	pushup(u);
}
long long query1(int u,int l,int r) {
	if(tr1[u].l>=l&&tr1[u].r<=r) {
		return tr1[u].v;
	}
	long long ans=-100000;
	int mid=(tr1[u].l+tr1[u].r)>>1;
	if(l<=mid) {
		ans=max(ans,query1(u*2,l,r));
	}
	if(r>mid) {
		ans=max(ans,query1(u*2+1,l,r));
	}
	return ans;
}
long long query2(int u,int l,int r) {
	if(tr2[u].l>=l&&tr2[u].r<=r) {
		return tr2[u].v;
	}
	long long ans=-100000;
	int mid=(tr2[u].l+tr2[u].r)>>1;
	if(l<=mid) {
		ans=max(ans,query2(u*2,l,r));
	}
	if(r>mid) {
		ans=max(ans,query2(u*2+1,l,r));
	}
	return ans;
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int j=1;j<=n;j++) cin>>b[j];
	build1(1,1,n);	build2(1,1,n);
	cin>>q;
	while(q--) {
		long long ans=0;
		int l,r;
		cin>>l>>r;
		for(int i=l;i<=r;i++) {
			for(int j=l;j<=r;j++) {
				if(i>j) continue;
				ans=ans+(query1(1,i,j)*query2(1,i,j)%MOD);
			}
		}
		cout<<ans%MOD<<endl;
	}
	return 0;
}
