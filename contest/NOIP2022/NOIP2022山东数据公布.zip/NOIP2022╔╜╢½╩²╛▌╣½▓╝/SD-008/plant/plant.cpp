#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
#define S 1005
#define mod 998244353
int n,m,c,f;
char chang[S][S];
int x[S][S],y[S][S],x2[S][S];
int sum[S],sum1[S];
int ans_c,ans_f;
void find_c(){
	for(int j=1;j<=m;j++){
		for(int i=1;i<=n;i++)sum[i]=sum1[i]=0;
		for(int i=1;i<=n;i++){
			sum[i]=y[i][j]-j;
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			sum1[i]=sum1[i-1]+sum[i];
		}
		for(int i=1;i<=n;i++){
			if(x[i][j]-i<=1)continue;
			ans+=sum[i]*(sum1[x[i][j]]-sum1[i+1]);
			ans%=mod;
		}
		ans_c+=ans;
		ans_c%=mod;
	}
}
void find_f(){
	for(int j=1;j<=m;j++){
		for(int i=1;i<=n;i++)sum[i]=sum1[i]=0;
		for(int i=1;i<=n;i++){
			sum[i]=y[i][j]-j;
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			sum1[i]=sum1[i-1]+sum[i];
		}
		for(int i=3;i<=n;i++){
			if(i-x2[i][j]<=1)continue;
			ans+=sum[i]*(sum1[i-2]-sum1[x2[i][j]-1])*(x[i][j]-i);
			ans%=mod;
		}
		ans_f+=ans;
	}
}
int  main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	cin>>t>>id;
while(t--){
	cin>>n>>m>>c>>f;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>chang[i][j];
		}
	}	
	for(int i=1;i<=n;i++){
		int tag=m;
		for(int j=m;j>=1;j--){
			if(chang[i][j]=='1'){
				tag=0;
				y[i][j]=j;
				continue;
			}
			if(tag==0){
				tag=j;
			}
			y[i][j]=tag;
		}
	}
	for(int j=1;j<=m;j++){
		int tag=n;
		for(int i=n;i>=1;i--){
			if(chang[i][j]=='1'){
				tag=0;
				x[i][j]=i;
				continue;
			}
			if(tag==0){
				tag=i;
			}
			x[i][j]=tag;
		}
	}//x is y^ ,y is x^
		for(int j=1;j<=m;j++){
		int tag=1;
		for(int i=1;i<=n;i++){
			if(chang[i][j]=='1'){
				tag=0;
				x[i][j]=i;
				continue;
			}
			if(tag==0){
				tag=i;
			}
			x2[i][j]=tag;
		}
	}
/*	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cout<<x2[i][j]<<" ";
		}
		cout<<endl;
	}*/	
	find_c();
	cout<<(ans_c*c)%mod<<" ";
	find_f();
	cout<<(f*ans_f)%mod;
	cout<<endl;	
}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
