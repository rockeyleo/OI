#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#include<stack>
using namespace std;
#define S 1000005
#define mod 10000007
int opr[S];
stack<int>op;
int T; 
int dui[S];
int a1[S],a2[S],a3[S];
int num[S];
int l1,l2,l3;
int r1,r2,r3;
int n,m,k;
int dfs(int i){
	int f1=0,f2=0,f3=0;
	if(a1[r1-1]==a1[r1]){
		r1-=2;
		f1=1;
	}
	if(a2[r2-1]==a2[r2]){
		r2-=2;
		f2=1;
	}
	if(a3[r3-1]==a3[r3]){
		r3-=2;
		f3=1;
	}
	if(i>m){
		if(l1>r1&&l2>r2&&l3>r3)return 1;
		else return 0;
	}
	while(1){
	if(a1[l1]==a2[l2]){
		l1++;
		l2++;
		op.push(4);
		continue;
	}
   else	if(a1[l1]==a3[l3]){
		l1++;
		l3++;
		op.push(5);
		continue;
	}
	else if(a3[l3]==a2[l2]){
		l2++;
		l3++;
		op.push(6);
		continue;
	}	
	break;
	}
	int ans=0;
	op.push(1);
	a1[++r1]=dui[i];
	if(ans=dfs(i+1))return ans+1;
	op.pop();
	op.push(2);
	a2[++r2]=dui[i];
	if(ans=dfs(i+1))return ans+1;
	op.pop();
	op.push(3);
	a3[++r3]=dui[i];
	if(ans=dfs(i+1))return ans+1;
	op.pop();
	if(f1)r1++;
	if(f2)r2++;
	if(f3)r3++;
	return  0;
}
signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	
	cin>>T;
	for(int t=1;t<=T;t++){
		l1=l2=l3=1;
		cin>>n>>k>>m;
		for(int i=1;i<=n;i++){
			cin>>dui[i];num[dui[i]]++;
		}
		int ans=dfs(1);
		cout<<ans-1;
		int i=1;
		while(!op.empty()){
			opr[++i]=op.top();
			op.pop() ;
		}
		for(int i=1;i<=ans;i++){
			switch(opr[i]){
				case 1:{
					cout<<"1 1"<<endl;
					break;
				}
				case 2:{
					cout<<"1 2"<<endl;
					break;
				}
				case 3:{
					cout<<"1 3"<<endl;
					break;
				}
				case 4:{
					cout<<"2 1 2"<<endl;
					break;
				}
				case 5:{
					cout<<"2 1 3"<<endl;
					break;
				}
				case 6:{
					cout<<"2 2 3"<<endl;
					break;
				}
			}
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
