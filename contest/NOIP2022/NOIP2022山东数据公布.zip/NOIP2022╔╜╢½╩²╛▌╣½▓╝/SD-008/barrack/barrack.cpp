#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
#define S 1000
#define mod 1000000007
int head[S],nxt[S],p,to[S],len[S];
int ans;
void add(int v,int u){
	p++;len[p]=v;
	nxt[p]=head[v];
	head[v]=p;
	to[p]=u;
}
int n,m,v[S];
int fa[S];
int find (int x){
	if(fa[x]==x)return x;
	return fa[x]=find(fa[x]);
}
int siz[S];
int check(){
	int ss=0;
	int flag;
	for(int i=1;i<=n;i++){
		if(v[i])flag=find(i);
		break;
	}
	for(int i=1;i<=n;i++){
		if(v[i]&&flag==find(i))ss++;
		if(v[i]&&flag!=find(i))return 0;
	}
	return ss;
}
void dfs(int x){
	if(x>m){
		int ss;
		if(ss=check()){
			ans+=(1<<ss)-1;
			ans%=mod;
		}
		return ;
	}
	dfs(x+1);
	int fat=fa[to[x]];
	fa[to[x]]=find(len[x]);
	v[to[x]]=1;
	v[len[x]]=1; 
	dfs(x+1);
	return ;
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	if(m==n-1){
		for(int i=2;i<=n;i++){
			ans+=(1<<i)-1;
			ans%=mod;
		}
		ans+=n;
		cout<<ans%mod;
		return 0; 
	} 
	p=1;len[p]=0;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
	}
	to[1]=len[2];
	dfs(1);
	cout<<ans+n<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
