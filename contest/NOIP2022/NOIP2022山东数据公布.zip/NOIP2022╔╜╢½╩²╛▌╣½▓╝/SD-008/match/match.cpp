#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
using namespace std;
#define S 1000
#define int long long
#define mod 10000007
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cout<<0; 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
