#include <bits/stdc++.h>
using namespace std;
#define mk make_pair
#define fi first
#define se second

inline int read() {
	int s = 0, w = 1;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') w = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		s = s * 10 + ch - '0';
		ch = getchar();
	}
	return w == -1 ? -s : s;
}
const int mod = 1e9 + 7;
inline int Add(int x, int y) {
	return  (x + y) >= mod ? (x + y - mod) : (x + y);
}
inline int Dec(int x, int y) {
	return (x - y) < 0 ? (x - y + mod) : (x - y);
}
inline int Mul(int x, int y) {
	return 1ll * x * y % mod;
}
inline int qpow(int x, int y) {
	int res = 1; while(y) {
		if(y & 1) res = Mul(res, x);
		x = Mul(x, x); y >>= 1;
	}
	return res;
}
inline void cadd(int &x, int y) {
	x = (x + y) >= mod ? (x + y - mod) : (x + y);
}
inline void cdel(int &x, int y) {
	x = (x - y) < 0 ? (x - y + mod) : (x - y);
}
inline void cmin(int &x, int y) {
	x = min(x, y);
}
inline void cmax(int &x, int y) {
	x = max(x, y);
}
char sss;
const int N = 1e6 + 10;
const int iv2 = ((mod + 1) / 2);
namespace Refined_heart {
	int f[N];
	int n, m, siz[N], H[N];
	int head[N], tot = 1, ecnt = 1;
	map <int, int> lk[N];
	struct E {
		int nxt, to;
	} e[N << 2], o[N << 2];
	struct edge{
		int u, v;
	} eg[N << 1];
	inline void link(int x, int y) {
		e[++tot] = (E){head[x], y};
		head[x] = tot;
	}
	inline void linkt(int x, int y) {
		o[++ecnt] = (E){H[x], y};
		H[x] = ecnt;
	}
	int cut[N << 1], low[N], dfn[N], dfstime;
	int vcc, col[N], vis[N], sz[N];
	int pw[N];
	void tarjan(int x, int ine) {
		dfn[x] = low[x] = ++dfstime; 
		for(int i = head[x]; i; i = e[i].nxt) {
			int v = e[i].to;
			if((i ^ 1) == ine) continue;
			if(!dfn[v]) {
				tarjan(v, i);
				low[x] = min(low[x], low[v]);
				if(low[v] > dfn[x]) {
					cut[i] = cut[i ^ 1] = 1;
				}
			}
			else {
				low[x] = min(low[x], dfn[v]);
			}
		}
	}
	void dfs(int x) {
		vis[x] = 1; col[x] = vcc; ++siz[vcc];
		for(int i = head[x]; i; i = e[i].nxt) {
			if(cut[i]) continue;
			int v = e[i].to;
			if(vis[v]) continue;
			dfs(v);
		}
	}
	int ans = 0;
	int ec[N];
	int esz[N];
	void DFS(int x, int fa) {
		sz[x] = 1;
		esz[x] = ec[x];
		int dg = 0;
		for(int i = H[x]; i; i = o[i].nxt) {
			int v = o[i].to;
			if(v == fa) continue;
			DFS(v, x); ++dg;
			++esz[x]; esz[x] += esz[v];
		}
		f[x] = pw[dg];
		f[x] = Mul(f[x], Dec(pw[siz[x]], 1));
		int res = 1, sum = 0;
		int res2 = 1;
		int dc = 1;
		for(int i = H[x]; i; i = o[i].nxt) {
			int v = o[i].to;
			if(v == fa) continue;
			res = Mul(res, Add(f[v], pw[esz[v]]));
			res2 = Mul(res2, Add(Mul(f[v], iv2), pw[esz[v]]));
			dc = Mul(dc, pw[esz[v]]);
		}
		for(int i = H[x]; i; i = o[i].nxt) {
			int v = o[i].to;
			if(v == fa) continue;
			sum = Add(sum, Mul(f[v], Mul(dc, qpow(pw[esz[v]], mod - 2)))); 
		}
		int Z = res; Z = Dec(Z, dc);
		Z = Dec(Z, sum);
//		cout << "Z = " << Z << '\n';
		Z = Add(Z, Mul(f[x], res2));
//		cout << "Z = " << Z << '\n';
//		cout << "fx = " << f[x] << '\n';
//		cout << "res = " << res << " res2 = " << res2 << '\n';
//		cout << "pw = " << m - esz[x] << '\n';
//		cout << "ec = " << ec[x] << '\n';
//		cout << "siz = " << siz[x] << '\n';
		Z = Mul(Z, pw[m - esz[x] + ec[x]]);
		ans = Add(ans, Z);
//		cout << "add = " << Z << '\n';
		int A = Mul(f[x], res2);
		int B = Dec(res2, dc);
		B = Mul(B, pw[dg]);
		f[x] = Add(A, B);
		f[x] = Mul(f[x], pw[ec[x]]);
//		cout << "A = " << A << " B = " << B << '\n';
//		cout << "x = " << x << " f = " << f[x] << '\n';
//		cout << "----------------------\n";
	}
	void solve() {
		n = read(); m = read();
		pw[0] = 1;
		for(int i = 1; i <= m; ++i) pw[i] = Add(pw[i - 1], pw[i - 1]);
		for(int i = 1; i <= m; ++i) {
			int u = read(), v = read();
			link(u, v); link(v, u);
			eg[i] = (edge){u, v};
		}
		tarjan(1, 0);
		for(int i = 1; i <= n; ++i) if(!col[i]) {
			++vcc;
			dfs(i);
		}
		for(int i = 1; i <= m; ++i) {
			int u = eg[i].u, v = eg[i].v;
			if(col[u] == col[v]) {
				++ec[col[u]];
				continue;
			}
			int cu = col[u], cv = col[v];
			if(lk[cu][cv]) continue;
			lk[cu][cv] = lk[cv][cu] = 1;
			linkt(cu, cv);
			linkt(cv, cu);
		}
		DFS(1, 0);
//		cout << "vcc = " << vcc << '\n';
		cout << ans << '\n';
	}
}
char ttt;
int main() {
//	cerr << "memory = " << 1.0 * abs(&sss - &ttt) / 1024 / 1024 << " MB\n";
//	freopen("in.txt", "r", stdin);
	freopen("barrack.in", "r", stdin); //962776497
	freopen("barrack.out", "w", stdout);

	Refined_heart :: solve();
	return 0;
}

