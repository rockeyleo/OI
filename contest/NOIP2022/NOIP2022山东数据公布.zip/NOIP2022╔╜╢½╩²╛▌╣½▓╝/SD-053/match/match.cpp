#include <bits/stdc++.h>
using namespace std;
#define mk make_pair
#define fi first
#define se second
inline int read() {
	int s = 0, w = 1;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') w = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		s = s * 10 + ch - '0';
		ch = getchar();
	}
	return w == -1 ? -s : s;
}
char sss;
const int N = 3e5 + 10; 
const int TN = N << 2;
namespace Refined_heart {
	
	int T, n, Q;
	
	
	int a[N], b[N];
	
	int st1[N], top1, st2[N], top2;
	struct SGT {
		
		unsigned long long sum[TN];
		int lp[TN], rp[TN], tag[TN];
		void build(int x, int L, int R) {
			tag[x] = sum[x] = 0;
			lp[x] = L; rp[x] = R;
			if(L == R) return ;
			int mid = (L + R) >> 1;
			build(x << 1, L, mid);
			build(x << 1 | 1, mid + 1, R); 
		}
		inline void pushr(int x, unsigned long long v) {
			sum[x] = 1ull * (rp[x] - lp[x] + 1) * v;
			tag[x] = v;
		}
		inline void pushdown(int x) {
			if(tag[x]) {
				unsigned long long v = tag[x];
				sum[x << 1] = 1ull * (rp[x << 1] - lp[x << 1] + 1) * v;
				tag[x << 1] = v;
				sum[x << 1 | 1] = 1ull * (rp[x << 1 | 1] - lp[x << 1 | 1] + 1) * v;
				tag[x << 1 | 1] = v;
				tag[x] = 0;
			}
		}
		void change(int x, int l, int r, int v) {
			if(l > r) return ;
			if(lp[x] >= l && rp[x] <= r) {
				pushr(x, v);
				return ;
			}
			pushdown(x);
			int mid = (lp[x] + rp[x]) >> 1;
			if(l <= mid) change(x << 1, l, r, v);
			if(mid < r) change(x << 1 | 1, l, r, v);
			sum[x] = sum[x << 1] + sum[x << 1 | 1];
		}
		#define mid ((L + R) >> 1)
		unsigned long long query(int x, int L, int R, int l, int r) {
			if(l > r) return 0;
			if(L >= l && R <= r) return sum[x];
			pushdown(x);
			unsigned long long ans = 0;
			if(l <= mid) ans = query(x << 1, L, mid, l, r);
			if(mid < r) ans += query(x << 1 | 1, mid + 1, R, l, r);
			return ans; 
		}
		void dfs(int x, int L, int R) {
			tag[x] = lp[x] = rp[x] = sum[x] = 0;
			if(L == R) return ;
			dfs(x << 1, L, mid);
			dfs(x << 1 | 1, mid + 1, R);
		}
	} T1, T2;
	unsigned long long ans = 0, res = 0;
	void work(int l, int r) {
		top1 = top2 = 0;
		T1.build(1, l, r);
		T2.build(1, l, r);
		ans = 0;
		res = 0;
		for(int i = l; i <= r; ++i) {
			while(top1 && a[i] > a[st1[top1]]) {
				int ll = st1[top1], rr = st1[top1 - 1] + 1;
				swap(ll, rr);
				unsigned long long qs = T2.query(1, l, r, ll, rr);
				res -= qs * a[st1[top1]];
				--top1;
			}
			int ll = st1[top1] + 1, rr = i;
			res += T2.query(1, l, r, ll, rr) * a[i];
			st1[++top1] = i;
			T1.change(1, ll, rr, a[i]);
			while(top2 && b[i] > b[st2[top2]]) {
				int qll = st2[top2], qrr = st2[top2 - 1] + 1;
				swap(qll, qrr);
				unsigned long long qs = T1.query(1, l, r, qll, qrr);
				res -= qs * b[st2[top2]];
				--top2;
			}
			ll = st2[top2] + 1, rr = i;
			res += T1.query(1, l, r, ll, rr) * b[i];
			T2.change(1, ll, rr, b[i]);
			ans += res;
			st2[++top2] = i;
		}
		cout << ans << '\n';
		T1.dfs(1, l, r);
		T2.dfs(1, l, r);
	}
	
	void solve() {
		T = read(); n = read();
		for(int i = 1; i <= n; ++i) a[i] = read();
		for(int i = 1; i <= n; ++i) b[i] = read();
		Q = read();
		for(int i = 1; i <= Q; ++i) {
			int l = read(), r = read();
			work(l, r);
		}
	}
}
char ttt;
int main() {
//	cerr << "Memory = " << 1.0 * abs(&ttt - &sss) / 1024 / 1024 << " MB\n";
//	freopen("in.txt", "r", stdin);
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);

	Refined_heart :: solve();
	return 0;
}

