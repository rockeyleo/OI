#include <bits/stdc++.h>
using namespace std;
#define mk make_pair
#define fi first
#define se second
//#define int long long
inline int read() {
	int s = 0, w = 1;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') w = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		s = s * 10 + ch - '0';
		ch = getchar();
	}
	return w == -1 ? -s : s;
}
const int mod = 998244353;
inline int Add(int x, int y) {
	return  (x + y) >= mod ? (x + y - mod) : (x + y);
}
inline int Dec(int x, int y) {
	return (x - y) < 0 ? (x - y + mod) : (x - y);
}
inline int Mul(int x, int y) {
	return 1ll * x * y % mod;
}
inline int qpow(int x, int y) {
	int res = 1; while(y) {
		if(y & 1) res = Mul(res, x);
		x = Mul(x, x); y >>= 1;
	}
	return res;
}
inline void cadd(int &x, int y) {
	x = (x + y) >= mod ? (x + y - mod) : (x + y);
}
inline void cdel(int &x, int y) {
	x = (x - y) < 0 ? (x - y + mod) : (x - y);
}
inline void cmin(int &x, int y) {
	x = min(x, y);
}
inline void cmax(int &x, int y) {
	x = max(x, y);
}
const int N = 1010;
namespace Refined_heart {
	int T, n, m, C, F;
	char str[N][N];
	int rlen[N][N];
	int sumr[N][N]; 
	int down[N][N];
	int dlen[N][N];
	int sumd[N][N];
	int testcase;
	void clear() {
		for(int i = 0; i <= n + 1; ++i) {
			for(int j = 0; j <= m + 1; ++j) {
				rlen[i][j] = sumr[i][j] = dlen[i][j] = down[i][j] = sumd[i][j] = 0;
			}
		}
	}
	void solve() {
		T = read(); testcase = read(); while(T--) {
			n = read(); m = read(); C = read(); F = read();
			for(int i = 1; i <= n; ++i) {
				scanf("%s", str[i] + 1);
			}
			for(int i = 1; i <= n; ++i) {
				for(int j = m; j; --j) {
					if(str[i][j] == '1') rlen[i][j] = 0;
					else rlen[i][j] = rlen[i][j + 1] + 1;
				}
			}
			for(int i = 1; i <= n; ++i) {
				for(int j = 1; j <= m; ++j) {
					if(rlen[i][j]) --rlen[i][j];
				}
			}
			for(int i = 1; i <= m; ++i) {
				for(int j = 1; j <= n; ++j) {
					sumr[i][j] = sumr[i][j - 1] + rlen[j][i];
				}
			}
			for(int i = n; i >= 1; --i) {
				for(int j = 1; j <= m; ++j) {
					if(str[i][j] == '1') down[i][j] = 0;
					else {
						down[i][j] = i;
						if(i + 1 <= n && str[i + 1][j] != '1') down[i][j] = down[i + 1][j];
					}
				}
			}
			int VC = 0, VF = 0;
			for(int i = 1; i <= n; ++i) {
				for(int j = 1; j <= m; ++j) {
					if(!rlen[i][j]) continue;
					int p = down[i][j];
					if(p <= i + 1) continue;
					int sm = Dec(sumr[j][p], sumr[j][i + 1]);
					if(!sm) continue;
					VC = Add(VC, Mul(sm, rlen[i][j]));
				}
			}
			int ansC = Mul(VC, C);
			for(int i = 1; i <= n; ++i) {
				for(int j = 1; j <= m; ++j) {
					if(!down[i][j]) continue;
					dlen[i][j] = down[i][j] - i;
				}
			}
			for(int i = 1; i <= m; ++i) {
				for(int j = 1; j <= n; ++j) {
					cadd(sumd[i][j], Add(sumd[i][j - 1], Mul(dlen[j][i], rlen[j][i])));
				}
			}
//			for(int i = 1; i <= n; ++i) {
//				for(int j = 1; j <= m; ++j) {
//					cout << dlen[i][j] << " ";
//				}
//				cout << '\n';
//			}
//			cout << "----------\n";
//			for(int i = 1; i <= n; ++i) {
//				for(int j = 1; j <= m; ++j) {
//					cout << rlen[i][j] << " ";
//				}
//				cout << '\n';
//			}
			for(int i = 1; i <= n; ++i) {
				for(int j = 1; j <= m; ++j) {
					if(!rlen[i][j] || !dlen[i][j]) continue;
					int p = down[i][j];
					if(p <= i + 2) continue;
					int sm = Dec(sumd[j][p], sumd[j][i + 1]);
//					cout << "i = " << i << " j = " << j << " rlen = " << rlen[i][j] << " sm = " << sm << '\n';
//					cout << "p = " << p << '\n';
//					cout << "sumd = " << sumd[j][p] << '\n';
//					cout << "sum2 = " << sumd[j][i + 1] << '\n';
					cadd(VF, Mul(sm, rlen[i][j]));
				}
			}
			int ansF = Mul(VF, F);
			cout << ansC << " " << ansF << '\n';
			clear();
		}
	}
}
int main() {
//	freopen("in.txt", "r", stdin);
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);

	Refined_heart :: solve();
	return 0;
}

