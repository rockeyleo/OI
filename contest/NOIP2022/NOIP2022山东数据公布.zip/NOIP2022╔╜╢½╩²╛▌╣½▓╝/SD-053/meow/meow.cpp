#include <bits/stdc++.h>
using namespace std;
#define mk make_pair
#define fi first
#define se second

inline int read() {
	int s = 0, w = 1;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') w = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		s = s * 10 + ch - '0';
		ch = getchar();
	}
	return w == -1 ? -s : s;
}
const int mod = 998244353;
inline int Add(int x, int y) {
	return  (x + y) >= mod ? (x + y - mod) : (x + y);
}
inline int Dec(int x, int y) {
	return (x - y) < 0 ? (x - y + mod) : (x - y);
}
inline int Mul(int x, int y) {
	return 1ll * x * y % mod;
}
inline int qpow(int x, int y) {
	int res = 1; while(y) {
		if(y & 1) res = Mul(res, x);
		x = Mul(x, x); y >>= 1;
	}
	return res;
}
inline void cadd(int &x, int y) {
	x = (x + y) >= mod ? (x + y - mod) : (x + y);
}
inline void cdel(int &x, int y) {
	x = (x - y) < 0 ? (x - y + mod) : (x - y);
}
inline void cmin(int &x, int y) {
	x = min(x, y);
}
inline void cmax(int &x, int y) {
	x = max(x, y);
}
const int N = 1001;
const int M = 2e6 + 10;
namespace Refined_heart {
	int T;
	struct Node {
		int op, s1, s2;
		Node(int x_ = 0, int y_ = 0, int z_ = 0) {
			op = x_; s1 = y_; s2 = z_;
		}
		inline void print() {
			if(op == 1) {
				cout << op << " " << s1 << '\n';
			}
			else {
				cout << op << " " << s1 << " " << s2 << '\n';
			}
		}
	};
	vector <Node> qans;
	int n, m, K, gt[M];
	// qing kong ta !!!!
	namespace Check {
		deque <int> q[N];
		bool check() {
			for(int i = 1; i <= n; ++i) q[i].clear();
			int p = 1;
			for(auto tmp : qans) {
				int op = tmp.op;
				if(tmp.s1 > n || tmp.s2 > n) {
//					cerr << "??\n";
					return false;
				}
				if(op == 1) {
					if(!q[tmp.s1].empty() && q[tmp.s1].back() == gt[p]) q[tmp.s1].pop_back();
					else q[tmp.s1].push_back(gt[p]);
					p = p + 1;
				}
				else {
					int u = tmp.s1, v = tmp.s2;
					if(q[v].empty() || q[u].empty()) {
//						cerr << "p = " << p << '\n';
//						cerr << ">>\n";
						return false; 
					}
					if(q[u].front() == q[v].front()) {
						q[u].pop_front();
						q[v].pop_front();
					}
				}
			}
			for(int i = 1; i <= n; ++i) if(!q[i].empty()) return false;
			return true;
		}
	}
	namespace Sub1 {
		int st[N][2], siz[N];
		int app[N];
		
		void solve() {
			while(T--) {
				qans.clear();
				n = read(); m = read(); K = read();
				for(int i = 1; i <= n * 2; ++i) st[i][0] = st[i][1] = siz[i] = app[i] = 0;
				for(int i = 1; i <= m; ++i) {
					int vl = gt[i] = read();
					int id = (vl + 1) / 2;
					if(!app[vl]) {
						app[vl] = 1;
						st[id][siz[id]++] = vl;
						qans.push_back(Node(1, id));
					}
					else {
						app[vl] ^= 1;
						if(st[id][siz[id] - 1] == vl) {
							qans.push_back(Node(1, id));
							continue;
						}
						qans.push_back(Node(1, n));
						qans.push_back(Node(2, id, n));
						st[id][0] = st[id][siz[id] - 1];
						--siz[id];
					}
				}
				assert(Check::check());
				cout << (int) qans.size() << '\n';
				for(auto tmp : qans) {
					tmp.print();
				}
			}
		}
	}
	namespace Sub2 {
		struct Line {
			int l, r;
			Line(int x_ = 0, int y_ = 0) {
				l = x_; r = y_;
			}
		};
		Line seq[N];
		int prepos[N], node; 
		vector <Node> now[M];
		void solve() {
			n = read(); m = read(); K = read(); qans.clear(); node = 0;
			if(n == 1) {
				for(int i = 1; i <= m; ++i) {
					gt[i] = read();
					qans.push_back(Node(1, 1));
				}
				cout << (int) qans.size() << '\n';
				for(auto tmp : qans) tmp.print();
				return ;
			}
			for(int i = 1; i <= K; ++i) prepos[i] = 0;
			for(int i = 1; i <= m; ++i) gt[i] = read();
			for(int i = 1; i <= m; ++i) now[i].clear();
			for(int i = 1; i <= m; ++i) {
				int v = gt[i];
				if(!prepos[v]) {
					prepos[v] = i;
					continue;
				}
				seq[++node] = (Line){prepos[v], i};
				prepos[v] = 0;
				now[prepos[v]].push_back(node);
			}
			
			for(int i = 1; i <= m; ++i) {
				
			}
		}
	}
	namespace Sub3 {
		deque <int> q[20];
		deque <int> u[20];
		int app[N];
		int ok;
		bool work() {
			for(int i = 1; i <= n; ++i) u[i] = q[i];
			int presiz = (int) qans.size();
//			cerr << "m = " << m << " psiz = " << presiz << '\n';
			while(1) {
				if((int) qans.size() > m + m) {
//					cerr << "!!!\n";
					while((int) qans.size() > presiz) {
						qans.pop_back();
					}
					return false;
				}
				int c = 0;
				int uu = 0, vv = 0;
				for(int i = 1; i <= K; ++i) app[i] = 0;
				for(int i = 1; i <= n; ++i) {
					if(u[i].empty()) continue;
					++c;
					int vl = u[i].front();
					if(!app[vl]) app[vl] = i;
					else {
						uu = app[vl];
						vv = i;
						break;
					}
				}
				if(c == 0) {
					return true;
				}
				
				if(!uu || !vv) {
					while((int) qans.size() > presiz) {
						qans.pop_back();
					}
//					cerr << "!!!\n";
//					cerr << qans.back().op << '\n';
					return false;
				}
//				++ins;
				qans.push_back(Node(2, uu, vv));
				u[uu].pop_front();
				u[vv].pop_front();
//				cerr << "pop it\n";
			}
			while((int) qans.size() > presiz) {
				qans.pop_back();
			}
//			cerr << "!!\n";
			return false;
		}
		void dfs(int p) {
//			cerr << p << '\n';
			if(ok) return ;
			if((int) qans.size() > m + m) return ;
			if(p == m + 1) {
//				cerr << qans.back().op << '\n';
//				cerr << "sz = " << qans.size() << '\n';
				work();
				return ;
			}
			int pfg = 0;
			for(int i = 1; i <= n; ++i) {
				int fg = 0;
				if(ok) return ;
				if(!q[i].empty() && q[i].back() == gt[p]) fg = 1, pfg = 1;
				if(!fg && pfg) continue;
				if(fg) q[i].pop_back();
				else q[i].push_back(gt[p]);
				qans.push_back(Node(1, i));
				dfs(p + 1);
				if(ok) return ;
				if(fg) q[i].push_back(gt[p]);
				else q[i].pop_back();
				qans.pop_back();
			}
		}
		void solve() {
			qans.clear(); ok = 0;
			n = read(); m = read(); K = read();
			for(int i = 1; i <= m; ++i) gt[i] = read();
			for(int i = 1; i <= n; ++i) q[i].clear();
			dfs(1);
//			cerr << Check::check() << '\n';
//			assert(Check::check());
			cout << (int) qans.size() << '\n';
			for(auto tmp : qans) tmp.print();
			qans.clear();
		}
	}
	void solve() {
		T = read();
		if(T % 10 == 1) {
			Sub1 :: solve();
			return ;
		}
		if(T % 10 == 3) {
			while(T--) Sub3 :: solve();
			return ;
		}
		while(T--) Sub2 :: solve();
	}
}
int main() {
//	freopen("in.txt", "r", stdin);
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);

	Refined_heart :: solve();
	return 0;
}

