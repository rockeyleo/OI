#include<bits/stdc++.h>
#define int long long
#define OP putchar(' ');
#define T cout<<"mbplb\n";
using namespace std;

const int N=1e3+10;

inline int read(){
	register char ch=getchar();
	register int x=0;
	register char t=0;
	while(ch<'0'||ch>'9') { t|=ch=='-'; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+(ch^48); ch=getchar(); }
	return t?-x:x;
}

inline void write(int x){
	if(x<0) { putchar('-'); x=~(x-1); }
	if(x>9) { write(x/10); }
	putchar(x%10+'0');
}

int n,m,c,f,ans,ans1,ans2;
int mapp[N][N];

inline void xuanc(int x,int y,int yi){
	if(yi==0){
		return ;
	}
	int jl=0, flag=0;
	int endd=x;
	while(mapp[endd][y]==0&&endd<=n){
		endd++;
	}
	endd--;
	for(int i=x+1;i<=n;++i){
		int op=y;
		if(mapp[i][y]==1){
			return ;
		}
		flag=0;
		while(mapp[i][op]==mapp[i][op+1]&&op<m){
			op++;
			if(i-x>1){
				ans1+=yi;
			}
			flag++;
		}
		if(flag>=1){
			if(endd-x<3){
				continue;
			}
			int num=0, op=y;
			while(mapp[i][op]==0&&op<=m){
				++op; ++num;
			}
			ans2+=(endd-i)*yi*(num-1);
		}
	}
}

signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int P=read(); int Id=read();
	while(P--){
		n=read(); m=read(); c=read(); f=read();
		string l;
		for(int i=1;i<=n;++i){
			cin>>l;
			for(int j=1;j<=m;++j){
				mapp[i][j]=l[j-1]-'0';
			}
		}
		for(int i=1;i<=n-2;++i){
			for(int j=1;j<=m;++j){
				int jl=0, flag=0;
				while(mapp[i][j]==mapp[i][j+jl]&&mapp[i][j]==0&&j+jl<=m){
					jl++;
					flag=1;
				}
				if(flag==1){
					xuanc(i,j,jl-1);
				}
			}
		}
		write(ans1*c);
		OP
		write(ans2*f);
		puts("");
	}
	fclose(stdin);
	fclose(stdout);
	return 0; 
}
