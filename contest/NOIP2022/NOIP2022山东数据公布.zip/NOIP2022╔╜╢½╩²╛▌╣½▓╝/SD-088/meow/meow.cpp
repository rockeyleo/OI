#include<bits/stdc++.h>
#define int long long
#define OP putchar(' ');
#define T cout<<"mbplb\n";
using namespace std;

const int N=1e3+10;

inline int read(){
	register char ch=getchar();
	register int x=0;
	register char t=0;
	while(ch<'0'||ch>'9') { t|=ch=='-'; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+(ch^48); ch=getchar(); }
	return t?-x:x;
}

inline void write(int x){
	if(x<0) { putchar('-'); x=~(x-1); }
	if(x>9) { write(x/10); }
	putchar(x%10+'0');
}

int n,m,k;
int q[N][N],l[N],r[N],sum[N],a[N];

signed main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int P=read();
	while(P--){
		int cnt=0;
		memset(sum,0,sizeof(sum));
		memset(r,0,sizeof(r));
		memset(l,0,sizeof(l));
		n=read(); m=read(); k=read(); 
		for(int j=1;j<=m;++j){
			int x=read(), flag=0;
			for(int i=1;i<=cnt;++i){
				if(q[i][r[i]]==x){
					write(1); OP
					write(i);
					putchar('\n');
					r[i]--;
					flag=1;
					break;
				}
				if(q[i][l[i]]==x){
					write(1); OP
					write(cnt+1);
					putchar('\n');
					l[i]++;
					flag=1;
					break;
				}
			}
			if(flag!=1){
				r[++cnt]=1;
				q[cnt][r[cnt]]=x;
				write(1); OP
				write(cnt);
				putchar('\n');
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

