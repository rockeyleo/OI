#include<bits/stdc++.h>
#define int long long
#define OP putchar(' ');
#define T cout<<"mbplb\n";
using namespace std;

const int N=1e6+10;
const int MOD=1e9+10;

inline int read(){
	register char ch=getchar();
	register int x=0;
	register char t=0;
	while(ch<'0'||ch>'9') { t|=ch=='-'; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+(ch^48); ch=getchar(); }
	return t?-x:x;
}

inline void write(int x){
	if(x<0) { putchar('-'); x=~(x-1); }
	if(x>9) { write(x/10); }
	putchar(x%10+'0');
}

int n,m,ans,sum;
int a[N];

signed main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	n=read(); m=read();
	for(int i=1;i<=m;++i){
		int x=read(), y=read();
	}
	ans=1;
	for(int i=1;i<=n;++i){
		ans*=2;
		if(ans>=MOD){
			ans%=MOD;
		}
	}
	int ans1=1;
	for(int i=1;i<=m;++i){
		ans1*=2;
		sum+=ans1;
		if(sum>=MOD){
			sum%=MOD;
		}
	}
	ans+=sum-1;
	ans%=MOD;
	write(ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

