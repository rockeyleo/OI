#include<bits/stdc++.h>
#define int long long
#define OP putchar(' ');
#define T cout<<"mbplb\n";
using namespace std;

const int N=1e6+10;

inline int read(){
	register char ch=getchar();
	register int x=0;
	register char t=0;
	while(ch<'0'||ch>'9') { t|=ch=='-'; ch=getchar(); }
	while(ch>='0'&&ch<='9') { x=(x<<1)+(x<<3)+(ch^48); ch=getchar(); }
	return t?-x:x;
}

inline void write(int x){
	if(x<0) { putchar('-'); x=~(x-1); }
	if(x>9) { write(x/10); }
	putchar(x%10+'0');
}

int n,m;
int a[N];

signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	m=read(); n=read();
	for(int i=1;i<=n;++i){
		a[i]=read();
	} 
	for(int i=1;i<=n;++i){
		a[i]=read();
	}
	int P=read();
	int l,r=l;
	l%=64;
	l=pow(2,l);
	l+=r;
	cout<<l;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

