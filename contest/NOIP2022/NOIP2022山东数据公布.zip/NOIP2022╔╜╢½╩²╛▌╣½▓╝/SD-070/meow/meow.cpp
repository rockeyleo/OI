/*
all people here is god,only I am a trash.
nice CCF,nice Problem
although I can't do it.

�����뿴 �� 
freopen("meow.in",'r',stdin);
freopen("meow2.in","r",stdin);
freopen("meow.in","w",stdin);
freopen("meow.in","r",stdout);
feropen("meow.in","r",stdin);
freopen("meow.out","r",stdin);
freopen("meow","r",stdin);
//freopen("meow.in","r",stdin);
freopen("")


*/ 
#include<bits/stdc++.h>
#define FINISH return(0)
using namespace std;
const int AI=1e3+1;
const int SI=1e4+2;
const int BI=1e5+7;
const int KI=1e6+1;
const int CI=1e7+9;
const int FI=1e8+5;
const int iINF=1e9;
int read(){int x=0;int w=1;char ch=getchar();while(ch<'0' || ch>'9'){if(ch='-'){w=-1;}ch=getchar();}while(ch>='0' && ch<='9'){x=x*10+(ch-'0');ch=getchar();}return x*w;}
stack<int>a;
deque<int>q[AI];
int opt[KI];
int s1a[KI];
int s2a[KI];
int s3a[KI]; 

int n,m,k;
void dfs(int u,int ans)
{
	bool flag=0;
	for(int i=1;i<=n;i++)
	{
		if(!q[i].empty())
		{
			flag=1;
		}
	}
	if(a.empty() && flag==0)
	{
		cout<<ans<<endl;
		for(int i=1;i<=ans;i++)
		{
			cout<<opt[i]<<' ';
			if(opt[i]==1)
			{
				cout<<s1a[i]<<'\n';
			}
			else
			{
				cout<<s2a[i]<<' '<<s3a[i]<<'\n';
			} 
		}
	}
	for(int i=u;i<=m;i++)
	{
		for(int j=1;j<=2;j++)
		{
			opt[i]=j;
			if(j==1)
			{
				for(int p=1;p<=n;p++)
				{
					s1a[i]=p;
					if(q[p].front()==a.top())
					{
						a.pop();q[p].pop_front();
					}
				}
			}
		}
	}
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T=read();
	while(T--)
	{
		n=read();
		m=read();
		k=read();
		for(int i=1;i<=m;i++)
		{
			int x=read();
			a.push(x);
		}
		dfs(1,0);
	}
}
