/*
�����ԡ� 
bzero.
by SoN114514ri.
*/
#include<bits/stdc++.h>
#define FINISH return(0)
using namespace std;
const int AI=1e3+1;
const int SI=1e4+2;
const int BI=1e5+7;
const int KI=1e6+1;
const int CI=1e7+9;
const int FI=1e8+5;
const int iINF=1e9;
int read(){int x=0;int w=1;char ch=getchar();while(ch<'0' || ch>'9'){if(ch='-'){w=-1;}ch=getchar();}while(ch>='0' && ch<='9'){x=x*10+(ch-'0');ch=getchar();}return x*w;}
/*
I hate this problem;
it is so hard,,,
������ˣ������ټģ� 

�����뿴 �� 
freopen("barrack.in",'r',stdin);
freopen("barrack2.in","r",stdin);
freopen("barrack.in","w",stdin);
freopen("barrack.in","r",stdout);
feropen("barrack.in","r",stdin);
feroepn("barrack.in","r",stdin);
freopen("barrack.out","r",stdin);
freopen("barrack","r",stdin);
//freopen("barrack.in","r",stdin);


*/ 


int main()
{
	srand(time(0));
	freopen("barrack.in","r",stdin);
 	freopen("barrack.out","w",stdout);
 	cout<<rand(); 
	FINISH;
}
