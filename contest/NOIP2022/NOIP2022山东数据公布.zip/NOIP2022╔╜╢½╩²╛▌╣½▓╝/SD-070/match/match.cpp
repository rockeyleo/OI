/*
�����뿴 �� 
freopen("match.in",'r',stdin);
freopen("match.in","r",stdin);
freopen("match.in","w",stdin);
freopen("match.in","r",stdout);
feropen("match.in","r",stdin);
freopen("match.out","r",stdin);
freopen("match","r",stdin);
//freopen("match.in","r",stdin);



*/ 
#include<bits/stdc++.h>
#define FINISH return(0)
#define int long long
using namespace std;
const int AI=1e3+1;
const int SI=1e4+2;
const int BI=1e5+7;
const int KI=1e6+1;
const int CI=1e7+9;
const int FI=1e8+5;
const int iINF=1e9;
int read(){int x=0;int w=1;char ch=getchar();while(ch<'0' || ch>'9'){if(ch='-'){w=-1;}ch=getchar();}while(ch>='0' && ch<='9'){x=x*10+(ch-'0');ch=getchar();}return x*w;}
int a[KI];
int b[KI];
signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T=read();
	int n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}	
	for(int i=1;i<=n;i++)
	{
		b[i]=read();
	}
	int Q=read();
	while(Q--)
	{
		int ans=0;
		int l=read();
		int r=read();
		for(int p=l;p<=r;p++)
		{
			for(int q=l;r>=q;q++)//qlr%%%
			{
				int ma=0;
				int mb=0;
				for(int i=p;i<=q;i++)
				{
					ma=max(ma,a[i]);
					mb=max(mb,b[i]);
				}
				ans+=ma*mb%18446733709551616ull;
			}
		}
		cout<<ans%18446733709551616ull<<'\n';
	}
	FINISH;
}

