/*
step1.dfs
step2.think
step3.die

why it always cout<<0<<' '<<0<<'\n'; ???
suck it,trash problem break my time!!!
T1,6pts;

This problem send me to AFO!!!

fuck it.

ALl problem can kill me

I lost myself

I hope tommorrow is better than today

I hope NOIP2023,I can AK.

goodbye 2022

I will never forget it;
it killed me.






6+0+0+8......

�����뿴 �� 
freopen("plant.in",'r',stdin);
freopen("plant.in","r",stdin);
freopen("plant.in","w",stdin);
freopen("plant.in","r",stdout);
feropen("plant.in","r",stdin);
freopen("plant.out","r",stdin);
freopen("plant","r",stdin);
//freopen("plant.in","r",stdin);
freopen("plant",".inr",stdin);


by SoN9ri
*/
#include<bits/stdc++.h>
#define FINISH return(0)
using namespace std;
const int AI=1e3+1;
const int SI=1e4+2;
const int BI=1e5+7;
const int KI=1e6+1;
const int CI=1e7+9;
const int FI=1e8+5;
const int iINF=1e9;
const int mx[]={-1,1,0,0};
const int my[]={0,0,-1,1};
int read(){int x=0;int w=1;char ch=getchar();while(ch<'0' || ch>'9'){if(ch='-'){w=-1;}ch=getchar();}while(ch>='0' && ch<='9'){x=x*10+(ch-'0');ch=getchar();}return x*w;}
char a[AI][AI];
int vis[AI][AI];
int ansc,ansf;
int n,m;
void dfs(int x,int y)
{
	if(x==n && m==y)
	{
		bool flag=1;
		for(int xa=1;xa<=n;xa++)
		{
			for(int xb=xa+2;xb<=n;xb++)
			{	
				for(int ya=1;ya<=m;ya++)
				{
					for(int p=xa;p<=xb;p++)
					{
						if(a[p][ya]!='*')
						{
							return ;
						}
					}
					for(int yb=ya+1;yb<=m;yb++)
					{
						for(int p=ya;p<=yb;p++)
						{
							if(a[xa][p]!='*')
							{
								return ;	
							}						
						}
					}
					for(int yc=ya+1;yc<=m;yc++)
					{
						for(int p=ya;p<=yc;p++)
						{
							if(a[xb][p]!='*')
							{
								return ;
							}
						}
					}
				}
			}
		}
		if(flag)
		{
			ansc++;
		}
		for(int xa=1;xa<=n;xa++)
		{
			for(int xb=xa+2;xb<=n;xb++)
			{
				for(int xc=xb+1;xc<=n;xc++)
				{
					for(int ya=1;ya<=m;ya++)
					{
						for(int p=xa;p<=xc;p++)
						{
							if(a[p][ya]!='*')
							{
								return ;
							}
						}
					}
				}
			}
		}
	}
	for(int i=0;i<4;i++)
	{
		int rx=x+mx[i];
		int ry=y+my[i];
		if(rx>=1 && rx<=n && ry<=m && ry>=1 && !vis[rx][ry])
		{
			vis[rx][ry]=1;
			if(a[rx][ry]=='1')
			{
				dfs(rx,ry);
			}
			else
			{
			for(int k=1;k<=2;k++)
			{
				char s=a[rx][ry];
				if(k==1)
				{
					a[rx][ry]='*';
				}
				else a[rx][ry]='0';
				dfs(rx,ry);
				a[rx][ry]=s;
			}
			vis[rx][ry]=0;
		}
		} 	 
	}
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=read();
	int id=read();
	if(id==1)
	{
		while(T--)
		{
			cout<<0<<' '<<0<<endl;
		}
	}
	else
	{
		while(T--)
		{
			n=read();
			m=read();
			int c=read();
			int f=read();
			if(m==2)
			{
				cout<<0<<' '<<0<<endl;
			}
			else
			{
				for(int i=1;i<=n;i++)
				{
					for(int j=1;j<=m;j++)
					{
						cin>>a[i][j];
					}
				}
				dfs(1,1);
				cout<<ansc<<' '<<0<<endl;
			}
		}
	}
	FINISH;
	
	
}
