#include<bits/stdc++.h>
#define int long long
#define ll long long
using namespace std;
const int MOD=1e9+7;
ll read() {ll x=0; int f=1; char c=getchar();while(c<'0'||c>'9') {if(c=='-') f=0;c=getchar();}while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+c-'0';c=getchar(); }return f?x:-x;}
struct node {
	int f, t;
}e[2000006];
int n, m;
int far[500005];
int find(int x) {return far[x]==x?x:far[x]=find(far[x]);}
bool pd[2000006];
int cnt[2000006];
ll mi[2000006];
ll ans;
void dfs(int x){
	if(x==m+1) {
		for(int i=1; i<=n; ++i) far[i]=i, cnt[i]=0;
		for(int i=1; i<=m; ++i) {
			if(pd[i]==0) continue ;
			int fx=find(e[i].f), fy=find(e[i].t);
			if(fx==fy) continue ;
			far[fx]=fy;
		}
		for(int i=1; i<=n; ++i) cnt[find(i)]++;
		for(int i=1; i<=n; ++i) {
			ans+=mi[cnt[i]]-1;
			ans%=MOD;
		}
		return ;
	}
	pd[x]=1;
	dfs(x+1);
	pd[x]=0;
	dfs(x+1);
}
signed main() {
	freopen("barrack.in", "r", stdin);
	freopen("barrack.out", "w", stdout);
	n=read(); m=read();
	mi[0]=1;
	for(int i=1; i<=n; ++i) mi[i]=(mi[i-1]*2)%MOD;
	for(int i=1; i<=m; ++i) {
		e[i].f=read(); e[i].t=read();
	}
	if(m<=25) {
		dfs(1);
		cout<<ans;
		return 0;
	}
	ans+=mi[n-1]*n%MOD; ans%=MOD;
	for(int i=2; i<=n; ++i) {
		ans+=mi[n-i]*mi[i-2]*(n-i+1)%MOD;
		ans%=MOD;
	}
	cout<<ans;
}
