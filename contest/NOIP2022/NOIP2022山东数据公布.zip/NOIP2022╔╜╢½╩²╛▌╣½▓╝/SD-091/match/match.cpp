#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll read() {ll x=0; int f=1; char c=getchar();while(c<'0'||c>'9') {if(c=='-') f=0;c=getchar();}while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+c-'0';c=getchar(); }return f?x:-x;}
int T, n, l, r, q;
unsigned long long a[300005], b[300005];
unsigned long long ans[3003][3003];
int main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	T=read();
	n=read();
	for(int i=1; i<=n; ++i) a[i]=read();
	for(int i=1; i<=n; ++i) b[i]=read();
	for(int l=1; l<=n; ++l) {
		unsigned long long maxxa=0, maxxb=0;
		for(int r=l; r<=n; ++r) {
			maxxa=max(maxxa, a[r]);
			maxxb=max(maxxb, b[r]);
			ans[l][r]=maxxa*maxxb;
			ans[l][r]+=ans[l][r-1];
		}
	}
	q=read();
	while(q--) {
		int l=read(), r=read();
		unsigned long long Ans=0;
		for(int i=l; i<=r; ++i) Ans+=ans[i][r];
		cout<<Ans;
		putchar('\n');
	}
}

