#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll read() {ll x=0; int f=1; char c=getchar();while(c<'0'||c>'9') {if(c=='-') f=0;c=getchar();}while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+c-'0';c=getchar(); }return f?x:-x;}
int T;
int n, m, K;
int a[2000006];
int sta[603][10];
struct node {
	int op, s1, s2;
}ans[2000006];
int top;
deque<int>q[4];
int sz[2000006];
bool flag=0;
void dfs(int x) {
	if(flag) return ;
	if(x==m+1) {
		int top=0;
		q[1].clear();
		q[2].clear();
		q[3].clear();
		for(int i=1; i<=m; ++i) {
			ans[++top]=(node){1, sz[i], 0};
			if(q[sz[i]].size()) {
				if(q[sz[i]].back()!=a[i])
				q[sz[i]].push_back(a[i]);
			}
			else {
				q[sz[i]].push_back(a[i]);
				for(int j=1; j<=3; ++j) {
					if(j==sz[i]) continue ;
					if(q[j].size()==0) continue ;
					if(q[j].front()==a[i]) {
						ans[++top]=(node){2, sz[i], j};
						q[j].pop_front();
						q[sz[i]].pop_front();
					}
					break;
				}
			}
		}
		if(q[1].size()||q[2].size()||q[3].size()) return ;
		flag=1;
		for(int i=1; i<=top; ++i) {
			cout<<ans[i].op; putchar(' '); cout<<ans[i].s1;
			if(ans[i].op==2) {putchar(' '); cout<<ans[i].s2;}
			putchar('\n');
		}
		return ;
	}
	for(int i=1; i<=3; ++i) {
		sz[x]=i;
		dfs(x+1);
	}
}
int main() {
	freopen("meow.in", "r", stdin);
	freopen("meow.out", "w", stdout);
	T=read();
	if(T==1001) {
		int TT=T;
		while(TT--) {
			top=0;
			n=read(); m=read(); K=read();
			for(int i=1; i<=m; ++i) a[i]=read();
			for(int i=1; i<=m; ++i) {
				int k=(a[i]+1)/2;
				if(sta[k][1]==0) sta[k][1]=a[i], ans[++top]=(node){1, k, 0};
				else {
					if(sta[k][1]==a[i]) {
						sta[k][1]=sta[k][2];
						sta[k][2]=0;
						ans[++top]=(node){1, n, 0};
						ans[++top]=(node){2, k, n};
					}
					else {
						if(sta[k][2]==0) {
							sta[k][2]=a[i];
							ans[++top]=(node){1, k, 0};	
						}
						else {
							sta[k][2]=0;
							ans[++top]=(node){1, k, 0};
						}
					}
				}
			}
			for(int i=1; i<=top; ++i) {
				cout<<ans[i].op; putchar(' '); cout<<ans[i].s1;
				if(ans[i].op==2) {putchar(' '); cout<<ans[i].s2;}
				putchar('\n');
			}
		}
		return 0;
	}
	if(T==1002) {
		int TT=T;
		while(TT--) {
			n=read(); m=read(); K=read();
			top=0;
			for(int i=1; i<=m; ++i) a[i]=read();
			for(int i=1; i<=m; ++i) {
				if(sta[1][1]==0) {
					
					sta[1][1]=a[i]; ans[++top]=(node){1, 1, 0};
					continue ;
				}
				if(sta[1][1]==a[i]) {
					ans[++top]=(node){1, 2, 0};
					ans[++top]=(node){2, 1, 2};
					sta[1][1]=sta[1][2]; sta[1][2]=0;
					continue ;
				}
				if(sta[1][2]==a[i]) {
					ans[++top]=(node){1, 1, 0};
					sta[1][2]=0;
					continue ; 
				}
				if(sta[1][2]==0) {
					if(a[i+1]==a[i]||a[i+1]==sta[1][1]) 
					{ans[++top]=(node){1, 1, 0}; sta[1][2]=a[i]; continue ;}
					if(a[i+2]==a[i+1]) {cout<<i<<endl;
						ans[++top]=(node){1, 1, 0};
						ans[++top]=(node){1, 1, 0};
						ans[++top]=(node){1, 1, 0};
						i+=2; sta[1][2]=a[i];
						continue ;
					}
					if(a[i+2]==a[i]) {
						ans[++top]=(node){1, 2, 0};
						ans[++top]=(node){1, 1, 0};
						ans[++top]=(node){1, 2, 0};
						i+=2; sta[1][2]=a[i+1];
						continue ;
					}
					if(a[i+2]==sta[1][1]) {
						ans[++top]=(node){1, 1, 0};
						ans[++top]=(node){1, 1, 0};
						ans[++top]=(node){1, 2, 0};
						i+=2; sta[1][1]=a[i]; sta[1][2]=a[i+1];
						continue ;
					}
				}
			}
			for(int i=1; i<=top; ++i) {
				cout<<ans[i].op; putchar(' '); cout<<ans[i].s1;
				if(ans[i].op==2) {putchar(' '); cout<<ans[i].s2;}
				putchar('\n');
			}
		}
		return 0;
	}
//	if(T==3) {
		int TT=T;
		while(TT--) {
			n=read(); m=read(); K=read();
			for(int i=1; i<=m; ++i) a[i]=read();
			flag=0;
			dfs(1);
		}
//	}
}
