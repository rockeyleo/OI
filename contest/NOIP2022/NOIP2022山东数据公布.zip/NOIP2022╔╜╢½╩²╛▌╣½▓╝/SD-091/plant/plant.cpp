#include<bits/stdc++.h>
#define int long long
#define ll long long
using namespace std;
const int MOD=998244353;
ll read() {ll x=0; int f=1; char c=getchar();while(c<'0'||c>'9') {if(c=='-') f=0;c=getchar();}while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+c-'0';c=getchar(); }return f?x:-x;}
int id;
int T;
int n, m, c, f;
int a[1003][1003];
ll sz[1003][1003];
ll sz2[1003][1003];
ll ansc, ansf;
ll dp[1003];
signed main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	T=read(); id=read();
	while(T--) {
		n=read(); m=read(); c=read(); f=read();
		for(int i=1; i<=n; ++i) {
			for(int j=1; j<=m; ++j) {
				scanf("%1d", &a[i][j]);
			}
		}
		ansc=0; ansf=0;
		for(int i=1; i<=n; ++i) {
			int wz=m+1;
			for(int j=m; j>=1; --j) {
				if(a[i][j]) sz[i][j]=0, wz=j;
				else sz[i][j]=wz-j-1;
			}
		}
		for(int j=1; j<=m; ++j) {
			memset(dp, 0, sizeof(dp));
			for(int i=1; i<=n; ++i) {
				if(a[i][j]==1) {dp[i]=-1; continue ;}
				dp[i]=sz[i][j]+max(dp[i-1], 0LL); dp[i]%=MOD;
				if(i>=3&&dp[i-1]!=-1&&dp[i-2]!=-1) {
					ansc+=sz[i][j]*dp[i-2]%MOD; ansc%=MOD;
				}
			}
		}
		cout<<ansc; putchar(' ');
		for(int j=1; j<m; ++j) {
			int wz=n+1;
			for(int i=n; i>=1; --i) {
				if(a[i][j]) sz2[i][j]=0, wz=i;
				else sz2[i][j]=(wz-i-1)*sz[i][j]%MOD;
			}
		}
		for(int j=1; j<m; ++j) {
			memset(dp, 0, sizeof(dp));
			for(int i=n; i>=1; --i) {
				if(a[i][j]==1) {dp[i]=-1; continue ;}
				dp[i]=sz2[i][j]+max(dp[i+1], 0LL); dp[i]%=MOD;
				if(i<=n-3&&dp[i+1]!=-1&&dp[i+2]!=-1) {
					ansf+=sz[i][j]*dp[i+2]%MOD; ansf%=MOD;
				}
			}
		}
		cout<<ansf; putchar('\n');
	}
}

