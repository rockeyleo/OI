#include<iostream>
#include<cstdio>
#define endl '\n'
#define int long long
typedef long long ll;
using namespace std;
const int N=1e3+50,P=998244353;
int a[N][N];
int r[N][N],d[N][N],csr[N][N],csr2[N][N];
int n,m;
char s[N];
void solve(){
	int c,f;
	cin>>n>>m>>c>>f;
	for(int i=1;i<=n;i++){
		cin>>(s+1);
		for(int j=1;j<=m;j++){
			a[i][j]=s[j]!='1';
		}
	}
	for(int i=n;i>=1;i--){
		for(int j=m;j>=1;j--){
			r[i][j]=a[i][j+1]?r[i][j+1]+1:0;
			d[i][j]=a[i+1][j]?d[i+1][j]+1:0;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			csr[i][j]=(csr[i-1][j]+r[i][j])%P;
			csr2[i][j]=(csr2[i-1][j]+r[i][j]*(n-i+1)%P)%P;
		}
	}
	int resc=0,resf=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(!a[i][j])continue;
			if(d[i][j]>1)
					resc+=r[i][j]*(csr[i+d[i][j]][j]-csr[i+1][j]+P)%P;
			if(d[i][j]>2)
				resf+=r[i][j]*((csr2[i+d[i][j]-1][j]-csr2[i+1][j])+P+(i+d[i][j]-1-n+P)%P*(csr[i+d[i][j]-1][j]-csr[i+1][j]+P)%P)%P;
			resc%=P,resf%=P;
		}
	}
	resc=(P+resc)%P,resf=(P+resf)%P;
	cout<<resc*c%P<<" "<<resf*f%P<<endl;
}

signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ios::sync_with_stdio(false);
	int t,id;
	cin>>t>>id;
	while(t--)solve();
	return 0;
}
/*
r,d: to right and down
csr r sum in col
csr2 2 lvl sum in col
*/
