#include<iostream>
#include<cstdio>
#include<list>
#define endl '\n'
typedef long long ll;
using namespace std;
int abs(int x){
	return x<0?-x:x;
}
namespace Sub1{
	const int N=350;
	list<int> S[N];
	int sid[N*2];
	void solve(int n,int m,int k){
		int scnt=1,x=1;
		for(int i=1;i<=m;i++){
			int a;
			cin>>a;
			if(sid[a]){
				if(S[sid[a]].front()==a){
					cout<<1<<" "<<sid[a]<<endl;
					S[sid[a]].pop_front();
				}else if(S[sid[a]].back()==a){
					cout<<1<<" "<<1<<endl;
					cout<<2<<" "<<sid[a]<<" "<<1<<endl;
					S[sid[a]].pop_back();
				}else{
					cout<<1<<" "<<sid[a]<<endl;
					S[sid[a]].push_front(a);
				}
			}else{
				scnt+=x;
				x^=1;
				sid[a]=scnt;
				S[sid[a]].push_front(a);
				cout<<1<<" "<<sid[a]<<endl;
			}
		}
	}
}
namespace Sub2{
	int s;
	list<int> l[3];
	int a[1000050],b[1000050];
	void solve(int n,int m,int k){
		for(int i=1;i<=m;i++){
			cin>>a[i];
		}
		int p=m;
		for(int i=m;i>=1;i--){
			if(a[i]!=a[i+1]){
				p=i;
			}
			b[i]=p;
		}
		for(int i=1;i<=m;i++){
			int nxt=a[b[i]+1];
			if(l[1].front()==a[i]){
				l[1].pop_front();
				cout<<"1 1"<<endl;
			}else if(l[2].front()==a[i]){
				l[2].pop_front();
				cout<<"1 2"<<endl;
			}else if(l[1].back()==a[i]){
				l[1].pop_back();
				cout<<"1 2"<<endl<<"2 1 2"<<endl;
			}else if(l[2].back()==a[i]){
				l[2].pop_back();
				cout<<"1 1"<<endl<<"2 1 2"<<endl;
			}else
			if(l[1].size()+l[2].size()<2){
				if(l[1].empty()){
					cout<<"1 1"<<endl;
					l[1].push_front(a[i]);
				}else if(l[2].empty()){
					cout<<"1 2"<<endl;
					l[2].push_front(a[i]);
				}
			}
			else if(l[1].size()*l[2].size()){
				if(nxt==l[1].front()){
					cout<<"1 2"<<endl;
					l[2].push_front(a[i]);
				}else{
					cout<<"1 1"<<endl;
					l[1].push_front(a[i]);
				}
			}else{
				int sid=l[1].empty();
				if(nxt==l[sid].front()){
					l[3-sid].push_front(a[i]);
					cout<<"1 "<<3-sid<<endl;
				}else{
					l[sid].push_front(a[i]);
					cout<<"1 "<<sid<<endl;
				}
			}
		}
	}
}

void solve(){
	int n,m,k;
	cin>>n>>m>>k;
	if(k==2*n-2){
		Sub1::solve(n,m,k);
	}else if(n==2){
		Sub2::solve(n,m,k);
	}
}

int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	ios::sync_with_stdio(false);
	int t;
	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

