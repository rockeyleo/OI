#include<cstring>
#include<random>
#include<ctime>
#include<iostream>
#include<vector>
#include<cstdio>
#define int long long
#define endl '\n'
typedef long long ll;
using namespace std;
const int N=5e5+500,M=1e6+500;
struct Edge{
	int u,v,next;
} edges[M*2];
int eid=-1;
bool bridge[M*2];
int head[N];
void add_edge(int u,int v){
	edges[++eid]=(Edge){u,v,head[u]};
	head[u]=eid;
}
vector<int> T[N];
int n,m;
int dfn[N],low[N],dcnt=0;
void tarjan(int u,int fi=-1){
	dfn[u]=low[u]=++dcnt;
	for(int i=head[u];i!=-1;i=edges[i].next){
		if(i==fi||i==(fi^1))continue;
		int v=edges[i].v;
		if(dfn[v]){
			low[u]=min(low[u],dfn[v]);
		}else{
			tarjan(v,i);
			low[u]=min(low[u],low[v]);
			if(low[v]>dfn[u]){
				bridge[i]=bridge[i^1]=true;
			}
		}
	}
}
int colors[N];
int cid=0;
int ecnt[N],ncnt[N];
void dfs(int u){
	colors[u]=cid;
	ncnt[cid]++;
	for(int i=head[u];i!=-1;i=edges[i].next){
		if(bridge[i])continue;
		ecnt[cid]++;
		int v=edges[i].v;
		if(colors[v]==cid)continue;
		dfs(v);
	}
}
void build(){
	tarjan(1);
	for(int i=1;i<=n;i++){
		if(!colors[i])cid++,dfs(i);
	}
	for(int i=0;i<=eid;i++){
		if(bridge[i]&&(i&1)){
			int u=colors[edges[i].u],v=colors[edges[i].v];
			T[u].push_back(v);
			T[v].push_back(u);
		}
	}
}
const ll P=1e9+7;
ll fpow(ll a,int b){
	if(b==0)return 1;
	if(b&1)return fpow(a*a%P,b/2)*a%P;
	else return fpow(a*a%P,b/2);
}
ll f[N],g[N],esum[N];
void dp(int u,int fa){
	f[u]=fpow(2,ncnt[u]+ecnt[u]/2),g[u]=0;
	esum[u]=ecnt[u]/2;
	for(int v:T[u]){
		if(v==fa)continue;
		dp(v,u);
		esum[u]+=esum[v]+1;
	}
	ll x=1;
	for(int v:T[u]){
		if(v==fa)continue;
		f[u]=(f[u]*(f[v]+fpow(2,esum[v])))%P;
		x=x*fpow(2,esum[v])%P;
		g[u]=(g[u]+(f[v]-1)*fpow(2,(esum[u]-esum[v]-1))+g[v]*fpow(2,(esum[u]-esum[v])))%P;
	}
	f[u]=(f[u]-x+P+1)%P;
}
signed main(){
	freopen("barrack2.in","r",stdin);
	freopen("barrack.out","w",stdout);
	ios::sync_with_stdio(false);
	memset(head,-1,sizeof(head));
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		add_edge(u,v);
		add_edge(v,u);
	}
	build();
	int root=1;
	dp(root,0);
	ll res=f[root]+g[root]-fpow(2,m);
//	ll res=(P+fpow(2,m+1)*(g[1])%P-fpow(2,m))%P;
	cout<<res<<endl;
	return 0;
}

