#include<iostream>
#include<cstdio>
#define endl '\n'
typedef unsigned long long ull;
using namespace std;
const int N=100;
int a[N],b[N];

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	ios::sync_with_stdio(false);
	int T,n;
	cin>>t>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)cin>>b[i];
	int q;
	cin>>q;
	for(int i=1;i<=q;i++){
		int l,r;
		cin>>l>>r;
		ull res=0;
		for(int p=l;p<=r;p++){
			for(int q=p;q<=r;q++){
				ull ma=0,mb=0;
				for(int k=p;k<=q;k++){
					ma=max(ma,a[i]);
					mb=max(mb,b[i]);
				}
				res+=ma*mb;
			}
		}
		cout<<res<<endl;
	}
	return 0;
}

