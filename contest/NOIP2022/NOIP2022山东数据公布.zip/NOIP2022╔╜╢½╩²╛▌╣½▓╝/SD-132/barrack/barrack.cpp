#include<cstdio>
#include<iostream>
#include<queue>
#include<stack>
#include<cmath>
#define LL long long
#define mod 1000000007
using namespace std;
int n,m;
LL ans=0;
LL qpow(LL x,int n){
	if(n==0) return 1;
	if(n==1) return x%mod;
	if(n%2==0) return qpow((x*x)%mod,n/2);
	else return (qpow((x*x)%mod,n/2)*x)%mod;
}

int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
//	cout<<qpow(n,m)<<endl;
	if(m==n-1){
		for(int i=1;i<=n;i++){
			LL t;
			if(i==1||i==2) t=1;
			else t=qpow(2,i-2);
//			cout<<i<<" : "<<qpow(2,n-i)<<" "<<t<<endl;
			(ans+=(n-i+1)*t*qpow(2,n-i))%=mod;
		}
		cout<<ans<<endl;
	}
	return 0;
} 
