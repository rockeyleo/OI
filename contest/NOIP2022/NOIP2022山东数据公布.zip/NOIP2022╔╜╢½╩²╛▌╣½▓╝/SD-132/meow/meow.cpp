#include<cstdio>
#include<iostream>
#include<queue>
#include<stack>
#include<cmath>
#include<cstring>
#include<set>
#define N 2000006
#define M 605
using namespace std;
int T,n,m,k,f;
int arr[N],vis[M<<1],id[M<<1],st[M][3];
int mq;
struct node{
	int a,b,c;
}qus[N<<1];
set<int> qk,bk;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		qk.clear();
		bk.clear();
		memset(vis,0,sizeof(vis));
		memset(st,0,sizeof(st));
		memset(id,0,sizeof(id));
		mq=0;
		scanf("%d%d%d",&n,&m,&k);
		int cnt1=n,cnt2=0;
		for(int i=1;i<=n;i++) qk.insert(i);
		for(int i=1;i<=m;i++)  scanf("%d",&arr[i]);
		int i=1;
		for(;i<=m;) {
			if(arr[i]==arr[i+1]) {
				qus[++mq]=(node){1,1,0};
				qus[++mq]=(node){1,1,0};
				i+=2;
				continue;
			}
			if(!vis[arr[i]]){
//				cout<<"@@ ";
				if(bk.size()>0) {
					int cc2=*bk.begin();
					bk.erase(cc2);
					qus[++mq]=(node){1,cc2,0};
//					printf("1 %d\n",cc2);
					st[cc2][1]=arr[i];
					vis[arr[i]]=1;
					id[arr[i]]=cc2;
					i++;
				}
				else if(qk.size()>1){
					int cc1=*qk.begin();
					qk.erase(cc1);
					qus[++mq]=(node){1,cc1,0};
//					printf("1 %d\n",cc1);
					vis[arr[i]]=1;
					id[arr[i]]=cc1;
					st[cc1][0]=arr[i];
					bk.insert(cc1);
					i++;
				}
				else {
					int dis=arr[i],ff=0,vv[M<<1];
					memset(vv,0,sizeof(vv));
					for(int j=i+1;;j++){
						if(arr[j]==st[id[arr[j]]][0]&&vv[st[id[arr[j]]][1]]==0){
							vis[dis]=1;
							id[dis]=id[arr[j]];
							st[id[arr[j]]][2]=dis;
							qus[++mq]=(node){1,id[arr[j]],0};
//							printf("1 %d\n",id[arr[j]]);
							ff=1;
							i++;
							break;
						}
						vv[arr[j]]=1;
						if(arr[j]==dis) break;
					}
					if(ff==0){
						vis[dis]=1;
						int cc1=*qk.begin();
						qus[++mq]=(node){1,cc1,0};
//						printf("1 %d\n",cc1);
						qk.erase(cc1);
						bk.insert(cc1);
						st[cc1][0]=dis;
						id[dis]=cc1;
						i++;
					}
				}
//				cout<<" **"<<endl;
			}
			else if(vis[arr[i]]){
//				cout<<"!!! "<<cnt1<<" "<<cnt2<<" "<<id[arr[i]]<<" "<<st[id[arr[i]]][0]<<" "<<st[id[arr[i]]][1]<<endl;
				if(st[id[arr[i]]][1]==arr[i]||st[id[arr[i]]][1]==0) {
					qus[++mq]=(node){1,id[arr[i]],0};
//					cout<<"1 "<<id[arr[i]]<<endl;
					vis[arr[i]]=0;
					if(st[id[arr[i]]][1]==0) {
						int cc2=*bk.begin();
						bk.erase(cc2);
						qk.insert(cc2),st[id[arr[i]]][0]=0;
					}
					else {
						qk.erase(id[arr[i]]);
						st[id[arr[i]]][0]=st[id[arr[i]]][1],st[id[arr[i]]][1]=0,bk.insert(id[arr[i]]);
					}
					st[id[arr[i]]][1]=0;
					
				}
				else {
					int cc1=*qk.begin(),cc2=*bk.begin();
					qus[++mq]=(node){1,cc1,0};
					qus[++mq]=(node){2,cc1,id[arr[i]]};
//					printf("1 %d\n",cc1);
//					printf("2 %d %d\n",cc1,id[arr[i]]);
					vis[arr[i]]=0;
					if(st[id[arr[i]]][2]==0){
						st[id[arr[i]]][0]=st[id[arr[i]]][1];
						st[id[arr[i]]][1]=0;
						bk.insert(id[arr[i]]);
						qk.erase(id[arr[i]]);
					}
					else {
						st[id[arr[i]]][0]=st[id[arr[i]]][1];
						st[id[arr[i]]][1]=st[id[arr[i]]][2];
						st[id[arr[i]]][2]=0;
					}
				}
				i++;
			} 
		}
		cout<<mq<<endl;
		for(int i=1;i<=mq;i++){
			printf("%d ",qus[i].a);
			if(qus[i].a==1) printf("%d\n",qus[i].b);
			else printf("%d %d\n",qus[i].b,qus[i].c);
		}
	}
	return 0;
} 
