#include<cstdio>
#include<iostream>
#include<queue>
#include<stack>
#include<cmath>
#include<cstring>
#define LL long long
#define N 1005
#define mod 998244353
using namespace std;
int T,id,n,m,c,f;
int arr[N][N],R[N][N],D[N][N];
char ch[N];
LL ans1,ans2;

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&T,&id);
	while(T--){
		ans1=0,ans2=0;
		memset(R,0,sizeof(R));
		memset(D,0,sizeof(D));
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++) {
			cin>>ch;
			for(int j=m-1;j>=0;j--){
				arr[i][j+1]=ch[j]-'0';
				if(arr[i][j+1]==1) R[i][j+1]=0;
				else R[i][j+1]=R[i][j+2]+1;
			}
		}
		for(int j=1;j<=m;j++){
			for(int i=n;i>=1;i--){
				if(arr[i][j]==1) D[i][j]=0;
				else D[i][j]=D[i+1][j]+1;
			}
		}
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=m;j++) cout<<arr[i][j]<<" ";
//			cout<<endl;
//		}
		for(int j=1;j<=m;j++){
			LL res=0,now=0,las=0;
			for(int i=1;i<=n;i++){
				if(arr[i][j]==1) {
					res=0,now=0,las=0;
					continue;
				}
				res+=las;
				las=now;
				now=R[i][j]-1;
				(ans1+=res*now)%=mod;
				(ans2+=res*now*(D[i][j]-1))%=mod;
			}
		}
		cout<<(c*ans1)%mod<<" "<<(f*ans2)%mod<<endl;
	}
	return 0;
} 
