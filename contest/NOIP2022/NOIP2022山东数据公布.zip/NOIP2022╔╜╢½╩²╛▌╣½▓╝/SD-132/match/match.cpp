#include<cstring>
#include<cstdio>
#include<iostream>
#include<cmath>
#define LL long long
#define N 2000005
using namespace std;
int T,n,q;
int arr[N],brr[N];
LL ans;
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++) scanf("%d",&arr[i]);
	for(int i=1;i<=n;i++) scanf("%d",&brr[i]);
	cin>>q;
	for(int i=1,l,r;i<=q;i++){
		ans=0;
		scanf("%d%d",&l,&r);
		for(int j=l;j<=r;j++){
			int max1=0,max2=0;
			for(int k=j;k<=r;k++){
				max1=max(max1,arr[k]);
//				if(brr[k]>max2) max2=brr[k];
				max2=max(max2,brr[k]);
				ans+=max1*max2;
				
			}
		}
		cout<<ans<<endl;
		
	}
	return 0;
} 
