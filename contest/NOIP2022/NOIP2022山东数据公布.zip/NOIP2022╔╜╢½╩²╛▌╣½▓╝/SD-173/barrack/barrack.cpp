#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;
long long ans,a,b,mod=1000000007,ansed=1;
void jiecheng(long long x){
	if(x==0)return;
	ansed*=x;
	jiecheng(x-1);
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n,m;
	cout<<n*m*2;
	return 0;
}
