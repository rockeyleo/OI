#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;

int main(){
	freopen("match.out","w",stdout)
	cout<<8;
}
