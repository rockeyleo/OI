#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;
long long opt_h[5000][5000],opt_c[5000][5000],opt_c_lx[5000][5000],sum[5000][5000],matrix[5000][5000],ans=0,f_ans=0,mod=998244353;
unsigned long long T,id,n,m,c,f;
signed main(void){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("plant.in","r",stdin);
    freopen("plant.out","w",stdout);
    cout<<1<<" "<<1;
	return 0;
}
