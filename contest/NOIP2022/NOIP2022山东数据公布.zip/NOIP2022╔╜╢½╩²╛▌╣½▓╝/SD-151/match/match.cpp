//#include<bits/stdc++.h>
#include<iostream>
#include<iomanip>
#include<cstdio>
#include<algorithm>
#include<queue>
#include<cmath>
#include<cstring>
#include<cstdlib>
#define ll long long
#define reg register int
#define gc getchar()
#define MAXN 250010
#define MAXM 2010
#define MOD
using namespace std ;
inline ll read( void );

int T,N,Q,L,R;
unsigned long long DD[MAXM][MAXM];
int A[MAXN],B[MAXN];
int AT[MAXN<<2],BT[MAXN<<2];
inline void buildA( int x , int l , int r ){
	if( l == r ){
		AT[x] = A[l];
		return ;
	}
	int mid = ( l + r ) >> 1;
	buildA(x*2,l,mid);
	buildA(x*2+1,mid+1,r);
	AT[x] = max(AT[x*2],AT[x*2+1]);
}
inline void buildB( int x , int l , int r ){
	if( l == r ){
		BT[x] = B[l];
		return ;
	}
	int mid = ( l + r ) >> 1 ;
	buildB(x*2,l,mid);
	buildB(x*2+1,mid+1,r);
	BT[x] = max( BT[x*2] , BT[x*2+1] );
}
inline bool IN_RANGE( int l , int r , int L , int R ){
	if( l >= L && r <= R ) return 1;
	return 0;
}
inline bool OUT_RANGE( int l , int r , int L , int R ){
	if( r < L || l > R ) return 1;
	return 0;
}
inline ll searchA( int x , int l , int r , int L , int R ){
	if( IN_RANGE(l,r,L,R) ) return AT[x];
	else if( OUT_RANGE(l,r,L,R) ) return -9999999;
	else{
		int mid = ( l + r ) >> 1 ;
		int a1 = searchA(x*2,l,mid,L,R);
		int a2 = searchA(x*2+1,mid+1,r,L,R);
		return max(a1,a2);
	}
}
inline ll searchB( int x , int l , int r , int L , int R ){
	if( IN_RANGE(l,r,L,R) ) return BT[x];
	else if( OUT_RANGE(l,r,L,R) ) return -9999999;
	else{
		int mid = ( l + r ) >> 1 ;
		int a1 = searchB(x*2,l,mid,L,R);
		int a2 = searchB(x*2+1,mid+1,r,L,R);
		return max(a1,a2);
	}
}
unsigned long long ans = 0 ;
int L1,R1,l1,r1;


int main( void ){

	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
//  T4 ������
	T = read();
	N = read();
	for( reg i = 1 ; i <= N ; i++ )
		A[i] = read();
	for( reg j = 1 ; j <= N ; j++ )
		B[j] = read();
	Q = read();
	buildA(1,1,N);
	buildB(1,1,N);
	for( reg i = 1 ; i <= Q ; i++ ){
		
		L1 = read();
		R1 = read();
		//���ǿ��԰ѱ�����������������������´ο���ֱ��ʹ�� 
		for( l1 = L1 ; l1 <= R1 ; l1++ ){
			for( r1 = l1 ; r1 <= R1 ; r1++ ){
				if( DD[l1][r1] )
					ans += DD[l1][r1] ;
				else{
					DD[l1][r1] = searchA(1,1,N,l1,r1) * searchB(1,1,N,l1,r1);
					ans += DD[l1][r1];
					//ans��ull��Ȼ�������ȡģ
					//�ȴ���C�Ȼ���ټӵ�ans��
					//��ΪC��ansһ����ull�����Բ��õ���������� 
				}
				
			}
		}
		cout << ans << endl ;
		ans = 0 ;
		
		
	}

	fclose(stdin);
	fclose(stdout);
	return 0;

}

inline ll read( void ){

	ll x = 0 , f = 0 ;
	char ch = gc ;
	while( !isdigit(ch) )
		f |= ( ch == '-' ) , ch = gc ;
	while( isdigit(ch) )
		x = ( x << 1 ) + ( x << 3 ) + ( ch ^ 48 ) , ch = gc ;
	return f ? -x : x ;

}

