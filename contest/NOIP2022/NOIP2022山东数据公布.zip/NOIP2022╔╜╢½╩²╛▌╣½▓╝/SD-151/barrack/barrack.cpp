//#include<bits/stdc++.h>
#include<iostream>
#include<iomanip>
#include<cstdio>
#include<algorithm>
#include<queue>
#include<cmath>
#include<cstring>
#include<cstdlib>
#define ll long long
#define reg register int
#define gc getchar()
#define MAXN 1000010
#define MOD 1000000007
using namespace std ;
inline ll read( void );

struct edge{
	int to,nxt;
}E[MAXN<<2];
int head[MAXN],tot;
inline void link( int from , int to ){
	
	E[++tot].to = to ;
	E[tot].nxt = head[from];
	head[from] = tot;
	
}

inline ll fast_pow( int x , int m ){
	
	//����x^m
	ll base = x ;
	ll ans = 1 ;
	while( m ){
		
		if( m&1 ) ans *= base;
		ans %= MOD ;
		base = base*base;
		base %= MOD ;
		m >>= 1 ;
		
	}
	return ans%MOD ;
	
}

int main( void ){

	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
//	/*
	int N = read();
	int M = read();
	for( reg i = 1 ; i <= M ; i++ ){
		int U = read();
		int V = read();
		link(U,V);
		link(V,U);
	}
	if( N == 1 ){
		cout << 2 << endl 
		return 0;
	}
	else if( N == 2 && M >= 2 ){
		
		cout << fast_pow(2,N+M);
		return 0;
		
	}
	else if( N == 2 && M == 1 ){
		cout << 5 << endl 
		return 0;
	}
	else if( M == N-1 ){
		//����n(n+3)*2^(M-1)
		ll ans = ( N * (N+3) * fast_pow(2,M-1) ) % MOD ;
		cout << ans << endl ;
		return 0;
	}
//	*/
	
//	cout << fast_pow(2,3) << endl ;
	
	fclose(stdin);
	fclose(stdout);
	return 0;

}

inline ll read( void ){

	ll x = 0 , f = 0 ;
	char ch = gc ;
	while( !isdigit(ch) )
		f |= ( ch == '-' ) , ch = gc ;
	while( isdigit(ch) )
		x = ( x << 1 ) + ( x << 3 ) + ( ch ^ 48 ) , ch = gc ;
	return f ? -x : x ;

}

