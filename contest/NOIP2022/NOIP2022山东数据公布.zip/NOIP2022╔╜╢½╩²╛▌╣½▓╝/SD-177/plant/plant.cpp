#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
long long rd(){char ch=getchar();long long x=0,f=1;while(ch<'0' || '9'<ch){if(ch=='-'){f=-1;}ch=getchar();}
			   while('0'<=ch && ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*f;}

const long long N=1010,mod=998244353;
long long t,id,n,m,C,F,a[N+10][N+10],f[N+10][N+10],nt[N+10][N+10],g[N+10][N+10],h[N+10][N+10],ans1,ans2;
string s;

void init(){
	long long i,j,u,v;
	ans1=ans2=0;
	for(i=0;i<=n+1;i++){
		for(j=0;j<=m+1;j++){
			a[i][j]=f[i][j]=g[i][j]=h[i][j]=nt[i][j]=0;
		}
	}
}

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	long long i,j,u,v,k;
	t=rd();id=rd();
	while(t--){
		n=rd();m=rd();C=rd();F=rd();
		init();
		for(i=1;i<=n;i++){
			cin>>s;
			for(j=1;j<=m;j++){
				a[i][j]=s[j-1]-'0';
			}
		}
		for(i=1;i<=n;i++){
			for(j=1;j<=m;j++){
				if(a[i][j]==1){
					f[i][j]=-1;
					continue;
				}
				if(f[i][j]) continue;
				for(u=j+1;u<=m;u++){
					if(a[i][u]) break;
				}
				u--;
				for(v=u;v>=j;v--){
					f[i][v]=u-v;
				}
			}
		}
		for(j=1;j<=m;j++){
			for(i=1;i<=n;i++){
				if(a[i][j]==0 && !nt[i][j]){
					for(u=i+1;u<=n;u++){
						if(a[u][j]==1) break;
					}
				}
				else{
					continue;
				}
				for(v=u-1;v>=i;v--){
					nt[v][j]=u-1;
				}
				i=u-1;
			}
		}
		for(j=1;j<=m;j++){
			for(i=2;i<=n;i++){
				if(a[i-1][j]==0 && a[i-2][j]==0){
					h[i][j]=(f[i-2][j]+h[i-1][j])%mod;
				}
			}
		}
		//C
		if(C){
			for(j=1;j<=m;j++){
				for(i=1;i<=n;i++){
					if(f[i][j]>=0){
						ans1=(ans1+f[i][j]*h[i][j]%mod)%mod;
					}
				}
			}
			printf("%lld ",ans1);
		}
		else{
			putchar('0'),putchar(' ');
		}
		//F
		if(F){
			for(j=1;j<=m;j++){
				for(i=1;i<=n;i++){
					if(!a[i][j])
						g[i][j]=f[i][j]*(nt[i][j]-(i))%mod;
					else g[i][j]=-1;
				}
			}
			for(j=1;j<=m;j++){
				for(i=1;i<=n;i++){
					if(f[i][j]>=0){
						ans2=(ans2+g[i][j]*h[i][j]%mod)%mod;
					}
				}
			}
			printf("%lld\n",ans2);
		}
		else{
			putchar('0'),putchar('\n');
		}
	}
	return 0;
}
