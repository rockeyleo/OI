#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<deque>
#include<queue>
using namespace std;
int rd(){char ch=getchar();int x=0,f=1;while(ch<'0' || '9'<ch){if(ch=='-'){f=-1;}ch=getchar();}
			   while('0'<=ch && ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*f;}
void wr(int x){
	if(x<=9){
		putchar(x+'0');
		return;
	}
	wr(x/10);
	putchar(x%10+'0');
}
const int N=310,K=620,M=2e6+10;
int t,n,m,k,a[M+10],s[K+10],b[N+10][2],ans;
deque <int> q[N+10];
queue <int> p;
struct chu{
	int op,x,y;
}z[2*M+10];

void init(){
	long long i;
	ans=0;
	while(!p.empty()) p.pop();
	for(i=0;i<=n;i++) b[i][0]=b[i][1]=0;
	for(i=0;i<=2*n;i++) s[i]=0;
}

int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int i,j,u,v;
	t=rd();
	while(t--){
		n=rd();m=rd();k=rd();
		init();
		for(i=1;i<=m;i++){
			a[i]=rd();
		}
		if(k==2*n-2){
			for(i=1;i<=n-1;i++){
				for(j=0;j<=1;j++){
					u=j*n+i;
					p.push(u);
				}
			}
			for(i=1;i<=m;i++){
				if(s[a[i]]!=0){
					u=s[a[i]]%n;v=s[a[i]]/n;
					if(v==1){
						ans++;
						z[ans].op=1;
						z[ans].x=u;
						p.push(s[a[i]]);
						s[a[i]]=0;
						b[u][v]=0;
					}
					else if(v==0){
						if(b[u][1]==0){
							ans++;
							z[ans].op=1;
							z[ans].x=u;
							p.push(s[a[i]]);
							s[a[i]]=0;
							b[u][v]=0;
						}
						else{
							ans++;
							z[ans].op=1;
							z[ans].x=n;
							ans++;
							z[ans].op=2;
							z[ans].x=u;
							z[ans].y=n;
							if(b[u][1]){
								b[u][0]=b[u][1];
								b[u][1]=0;
								s[b[u][0]]=u;
								p.push(u+n);
							}
							else p.push(s[a[i]]);
							s[a[i]]=0;
						}
					}
				}
				else{
					while(!p.empty()){
						j=p.front();p.pop();
						u=j%n;v=j/n;
						if(b[u][v]==0) break;
					}
					ans++;
					z[ans].op=1;
					z[ans].x=u;
					s[a[i]]=j;
					b[u][v]=a[i];
				}
			}
		}
		wr(ans),putchar('\n');
		for(i=1;i<=ans;i++){
			if(z[i].op==1){
				putchar('1'),putchar(' '),wr(z[i].x);
			}
			else{
				putchar('2'),putchar(' '),wr(z[i].x),putchar(' '),wr(z[i].y);
			}
			putchar('\n');
		}
	}
	return 0;
}
