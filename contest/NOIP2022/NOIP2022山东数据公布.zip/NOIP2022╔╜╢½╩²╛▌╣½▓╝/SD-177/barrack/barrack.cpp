#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
long long rd(){char ch=getchar();long long x=0,f=1;while(ch<'0' || '9'<ch){if(ch=='-'){f=-1;}ch=getchar();}
			   while('0'<=ch && ch<='9'){x=x*10+ch-'0';ch=getchar();}return x*f;}

const long long N=3010,M=5010,mod=1e9+7;
long long n,m,f[N+10],ans,now;
struct edge{long long u,v;}e[M+10];

long long ksm(long long bs,long long po){
	if(po==0) return 1;
	if(po==1) return bs%mod;
	long long ha=ksm(bs,po>>1)%mod;
	if(po&1) return ha*ha%mod*bs%mod;
	return ha*ha%mod;
}
long long fnd(long long u){
	if(u==f[u]) return u;
	return f[u]=fnd(f[u]);
}

long long check(long long opn,long long opm){
	long long a[N+10],b[M+10];
	long long i,j,u,v;
	for(i=1;i<=n;i++){
		a[i]=(opn&1);
		opn>>=1;
	}
	for(i=1;i<=m;i++){
		b[i]=(opm&1);
		opm>>=1;
	}
	for(i=1;i<=m;i++){
		if(b[i]==0){
			for(j=1;j<=n;j++){
				f[j]=j;
			}
			for(j=1;j<=m;j++){
				if(j!=i){
					u=fnd(e[j].u);v=fnd(e[j].v);
					f[u]=v;
				}
			}
			for(u=1;u<=n;u++){
				for(v=u+1;v<=n;v++){
					if(a[u] && a[v] && fnd(u)!=fnd(v)){
						return 0;
					}
				}
			}
		}
	}
	return 1;
}

int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	long long i,j,u,v;
	n=rd();m=rd();
	for(i=1;i<=m;i++){
		u=rd();v=rd();
		e[i].u=u;e[i].v=v;
	}
	if(n>=20 || m>=25){
		cout<<0<<endl;
		return 0;
	}
	long long op1,op2;
	long long mn=ksm(2,n)-1,mm=ksm(2,m)-1;
	for(op1=1;op1<=mn;op1++){
		for(op2=0;op2<=mm;op2++){
			ans+=check(op1,op2);
		}
	}
	cout<<ans<<endl;
	return 0;
}
