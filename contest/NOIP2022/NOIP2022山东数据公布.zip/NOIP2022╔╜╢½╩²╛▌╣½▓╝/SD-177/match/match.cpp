#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const long long N=3010;		   
struct Segment_Tree{
	struct node{unsigned long long sum;}t[4*N+10];
	unsigned long long a[N+10];
	#define ls (u<<1)
	#define rs (u<<1|1)
	void rf(long long u){t[u].sum=max(t[ls].sum,t[rs].sum);}
	void build(long long u,long long l,long long r){
		if(l==r){
			t[u].sum=a[l];
			return;
		}
		long long mid=l+r>>1;
		build(ls,l,mid);
		build(rs,mid+1,r);
		rf(u);
	}
	unsigned long long query(long long u,long long l,long long r,long long x,long long y){
		if(x<=l && r<=y){
			return t[u].sum;
		}
		long long mid=l+r>>1;
		unsigned long long res=0;
		if(x<=mid) res=max(res,query(ls,l,mid,x,y));
		if(mid+1<=y) res=max(res,query(rs,mid+1,r,x,y));
		return res;
	}
}A,B;

long long id,n,t;
unsigned long long ans;

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	long long i,j,u,v;
	cin>>id>>n;
	for(i=1;i<=n;i++){
		cin>>A.a[i];
	}
	for(i=1;i<=n;i++){
		cin>>B.a[i];
	}
	A.build(1,1,n);B.build(1,1,n);
	cin>>t;
	while(t--){
		ans=0;
		cin>>u>>v;
		for(i=u;i<=v;i++){
			for(j=i;j<=v;j++){
				ans+=A.query(1,1,n,i,j)*B.query(1,1,n,i,j);
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
