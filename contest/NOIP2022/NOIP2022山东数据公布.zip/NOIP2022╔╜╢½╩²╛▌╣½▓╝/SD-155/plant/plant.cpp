#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
const int N=1050,mod=998244353;
int a[N][N],righ[N][N],dowwn[N][N],n,m,c,f;
long long C,F;
void work(int x,int y){
	int l=righ[x][y],p=2;
	while(p<=dowwn[x][y]){
		if(righ[x+p][y]){
			C+=1ll*righ[x+p][y]*l;C%=mod;
			F+=1ll*righ[x+p][y]*(dowwn[x][y]-p)*l;F%=mod;
		}
		p++;
	}
	return;
}
vector<pair<int,int> >q;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;scanf("%d%d",&t,&id);
	while(t--){
		q.clear();
		C=0;F=0;
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++){
				char c=getchar();
				while(c!='0'&&c!='1')c=getchar();
				a[i][j]=c-'0';	
			}
		if(id==1){
			printf("0 0\n");
			return 0;
		}
		for(int i=1;i<=n;i++)righ[i][m]=0;
		for(int i=1;i<=m;i++)dowwn[n][i]=0;
		for(int i=n;i>=1;i--){
			for(int j=m;j>=1;j--){
				if(a[i][j+1]==0&&j+1<=m)righ[i][j]=righ[i][j+1]+1;
				else righ[i][j]=0;
				if(a[i+1][j]==0&&i+1<=n)dowwn[i][j]=dowwn[i+1][j]+1;
				else dowwn[i][j]=0;
			}
		}
		for(int i=1;i<=n-2;i++)
			for(int j=1;j<=m-1;j++)
				if(a[i][j]==0&&righ[i][j]&&dowwn[i][j]>=2)
					q.push_back({i,j});
			for(auto i:q){
				int x=i.first,y=i.second;
				int l=righ[x][y],p=2;
					while(p<=dowwn[x][y]){
						if(righ[x+p][y]){
							C+=1ll*righ[x+p][y]*l;C%=mod;
							F+=1ll*righ[x+p][y]*(dowwn[x][y]-p)*l;F%=mod;
						}
					p++;
				}
			}
		if(f==0)F=0;
		printf("%lld %lld\n",C,F);
	}
	return 0;
}
