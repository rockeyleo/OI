#include<iostream>
#include<cstdio>
#include<stack>
#include<vector>
using namespace std;
const int N=650;
int a[N],up[N],down[N],stk[N][N];
stack<int> q;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int t;scanf("%d",&t);
	int u=t;
	while(t){
		for(int i=1;i<=N-1;i++){up[i]=0;down[i]=0;}
		for(int i=1;i<=N-1;i++)for(int j=1;j<=N-1;j++)stk[i][j]=0;
		int n,m,k;scanf("%d%d%d",&n,&m,&k);
		for(int i=1;i<=m;i++)scanf("%d",&a[i]);
		for(int i=m;i>=1;i--) q.push(a[i]);
		if(n==1){
			while(!q.empty()){
				q.pop();
				printf("1 1\n");
			}
		}
		if(u%10==2){
			while(!q.empty()){
				int v=q.top();q.pop();
				int nxt=0;
				if(!q.empty())nxt=q.top();
				if(stk[1][up[1]]==v){
					up[1]--;
					printf("1 1\n");
				}
				else if(stk[2][up[2]]==v){
					up[2]--;
					printf("1 2\n");
				}
				else if(up[1]==down[1]&&stk[2][down[2]+1]==v){
					down[2]++;
					printf("1 1\n");
					printf("2 1 2\n");
				}
				else if(up[2]==down[2]&&stk[1][down[1]+1]==v){
					down[1]++;
					printf("1 2\n");
					printf("2 1 2\n");
				}
				else if(up[1]==down[1]){
					up[1]++;
					stk[1][1]=v;
					printf("1 1\n");
				}
				else if(up[2]==down[2]){
					up[2]++;
					stk[2][1]=v;
					printf("1 2\n");
				}
				else{
					if(nxt==stk[2][up[2]]||nxt==v){
						up[1]++;
						stk[1][up[1]]=v;
						printf("1 1\n");
					}
					if(nxt==stk[1][up[1]]){
						up[2]++;
						stk[2][up[2]]=v;
						printf("1 2\n");
					}
				}
			}
			t--;
			continue;
		}
		else{
			int num=0;
			while(!q.empty()){
				int v=q.top(),j=0;q.pop();
				for(int i=1;i<n;i++){
					if(stk[i][up[i]]==v){
						printf("1 %d\n",i);
						up[i]--;j=1;
						if(up[i]==down[i])num--;
						break;
					}
				}
				if(j==0){
					for(int i=1;i<n;i++){
						if(stk[i][down[i]+1]==v){
							down[i]++;
							if(down[i]==up[i])num--;
							printf("1 %d\n",n);
							printf("2 %d %d\n",i,n);
							j=1;break;
						}
					}
				}
				if(j==0&&num<n){
					for(int i=1;i<n;i++){
						if(up[i]==down[i]){
							printf("1 %d\n",i);
							stk[i][++up[i]]=v;
							j=1;num++;
							break;
						}
					}
				}
				if(j==0){
					for(int i=1;i<n;i++){
						if(up[i]==down[i]+1){
							printf("1 %d\n",i);
							stk[i][++up[i]]=v;
							j=1;num++;
							break;
						}
					}
				}
			}
		}
		t--;
	}
	return 0;
}
