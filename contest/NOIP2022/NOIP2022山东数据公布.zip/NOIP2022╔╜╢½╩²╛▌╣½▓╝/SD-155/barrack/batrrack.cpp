#include<iostream>
#include<cstdio>
using namespace std;
const int mod=1e9+7,N=500010,M=1000010;
int idx,t[N],ne[N],h[N];
void addedge(int a,int b){
	t[++idx]=b;ne[idx]=h[a];h[a]=idx;
}
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		addedge(u,v);addedge(v,u);
	}
	if(n==1){
		printf("1\n");
		return 0;
	}
	return 0;
} 
