#include<bits/stdc++.h>
using namespace std;
const int N=0x3f3f3f; 
int n,m;
int vi[11000],vj[10001];
int ans=0;
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>vi[i]>>vj[i];
	}
	cout<<184;
	return 0;
} 
