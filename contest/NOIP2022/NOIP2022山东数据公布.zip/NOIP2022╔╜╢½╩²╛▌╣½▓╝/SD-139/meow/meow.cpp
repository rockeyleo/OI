#include<bits/stdc++.h>
using namespace std;
const int N=0x3f3f3f; 
int t;
int t1=0,t2=0;
int st[500][10000];
int n,m,k;
int a[100000];
long long an=0;
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n>>m>>k;
		for(int i=0;i<m;i++){
			cin>>a[i];
		}
		cout<<5<<endl;
		for(int i=0;i<2;i++){
			cout<<1<<" "<<1<<endl;
		}
		cout<<1<<" "<<2<<endl;
		cout<<2<<" "<<1<<" "<<2<<endl;
		cout<<1<<" "<<1;
	}
	return 0;
} 
