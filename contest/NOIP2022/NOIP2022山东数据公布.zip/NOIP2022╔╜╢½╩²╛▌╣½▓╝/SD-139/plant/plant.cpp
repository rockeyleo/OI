#include<bits/stdc++.h>
using namespace std; 
int t,id;
int n,m,c,f;
int a[1005][1005];
long long an=0;
long long ss=1;
void tt(int x,int y){
	ss=0;an=0;
	if(a[x][y+1]==1||a[x+1][y]==1||a[x+2][y]==1){  
	 return ;
	}
	for(int i=x;i<=n;i++){
			for(int j=y;j<=m;j++){
				if(i!=x+1){
					if(a[i][j]==1){
						break;
					}
					if(a[i][j]==0&&i==x&&j!=y){
						ss++;
					}
					if(a[i][j]==0&&i!=x&&j!=y){
						an++;
					}
				}
			}
		}
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--){
		cin>>n>>m>>c>>f;
		if(c==0&&f==0){
			cout<<0<<" "<<0;
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				cin>>a[i][j];
			}
		}
		int uu=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i][j]!=1){
					tt(i,j);
					uu+=an*ss;
				}
			}
		}
		cout<<uu<<" "<<n/4;
	}
	return 0;
} 
