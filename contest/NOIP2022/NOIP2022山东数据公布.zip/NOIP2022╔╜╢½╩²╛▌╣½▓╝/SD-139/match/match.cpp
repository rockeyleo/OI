#include<bits/stdc++.h>
using namespace std;
const int N=0x3f3f3f; 
int a[100000];
int b[100000];
int t,n;
int q;
long long oo=0;
int c[10000];
int d[10000];
int c1[10000];
int d1[10000];
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>t>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	cin>>q;
	while(q--){
		int l,r;
		cin>>l>>r;
		int o1=0;
		for(int i=l;i<=r;i++){
			o1++;
			c[o1]=a[i];
			c1[o1]=i;
		}
		o1=0;
		for(int i=l;i<=r;i++){
			o1++;
			d[o1]=b[i];
			d1[o1]=i;
		}
		if(t==0||t>=10&&t<=13||t>=22&&t<=25){
			for(int i=1;i<=o1-1;i++){
				for(int j=i;j<=o1-1;j++){
					if(c[j]>c[j+1]){
						int o=c[j];
						c[j]=c[j+1];
						c[j+1]=o;
						o=c1[j];
						c1[j]=c1[j+1];
						c1[j+1]=o;
					}
					if(d[j]>d[j+1]){
						int o=d[j];
						d[j]=d[j+1];
						d[j+1]=o;
						o=d1[j];
						d1[j]=d1[j+1];
						d1[j+1]=o;
					}
				}
			}
		}
		int aa=0;
		int bb=0;
		for(int i=l;i<=r;i++){
			for(int j=i;j<=r;j++){
				for(int k=o1;k>=1;k--){
					if(c1[k]>=i&&c1[k]<=j){
						aa=c[k];
						break;
					}
				}
				for(int k=o1;k>=1;k--){
					if(d1[k]>=i&&d1[k]<=j){
						bb=d[k];
						break;
					}
				}
				oo+=aa*bb;
			}
		}
		cout<<oo;
	}
	return 0;
} 
