#include <bits/stdc++.h>
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    if(ch<'0'||ch>'9'){
		f=-1;
		ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
    }
    return x*f;
}
inline void print(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		print(x/10);
	}
	putchar(x%10+'0');

}
int a[2000005],sta[305];
int ful[305],n,m,k;
int search(int x,int y){
	for(int i=m-1;i>=1;i--){
		if(a[i]==y)return i; 
	}
	return 0;
}
void move(int x,int y){
	if(sta[y])
	sta[y]=a[x];
	a[x]=0;
	cout<<1<<" "<<y<<endl;
	return;
}
int search1(int x){
	for(int i=1;i<=n;i++){
		if(sta[i]==x)return i;
	}
}
int main(){
	//freopen(" ","r",stdin);
	//freopen(" ","w",stdout);
	int t;
	cin>>t;
	while(t--){
		int x;
		n,m,k,x=0;
		cin>>n>>m>>k;
		for(int i=m;i>=1;i--){
			cin>>a[i];	
		}
		int temp=1;
		for(int i=m;i>m-n;i--){
			move(a[i],temp);
			temp++;
		}
		for(int i=m-n+1;i>=0;i--){
//			int q=search(i,a[i]);
//			int ff=i-q;
//			if(q){
//				if(ff<=n){
//					for(int j=1;j<=ff;j++){
//						move(i-j+1,search1(i-j+1));
//					}
//					i=i-q-1;
//					move(i,search1(i));				
//				}
//				//cout<<endl<<i<<endl;
//			}else{
//				move(i,search1(i));
//			}
			move(i,search1(i));
		}	
	}
	
	return 0;
}

