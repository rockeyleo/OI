#include <bits/stdc++.h>
//#include <iostream>
//#include <cstdio>
//#include <cstring>
#define mod 998244353
using namespace std;
int t,id,a[1005][1005];
int n,m,c,f;
int endc,endf;
string si;
void bfs(int x,int y){
	int ok=n-x;
	int xx=2,yy=1,yyy=1,tempf=0;
	for(;;yy++){
		if(a[x][y+yy]==0)break;
	}
	yy--;
	for(;xx<=ok;xx++){
		if(a[x+xx][y]==0){
			break;
		}		
		yyy=1;
		for(;yyy<=m-y;yyy++){
			if(a[x+xx][y+yyy]==0)break;	
		}
		if(xx>1&&a[x+xx][y+1]==1){
			int con=1;
			while(1){
				if(a[x+xx+con][y]==1&&x+xx<=n-x){
					con++;
					tempf++;
				}else break;
			}	
		}
		yyy--;
		int waaa=yy*yyy;
		cout<<waaa<<endl;
		endc=(endc+waaa)%mod;
		endf=(endf+tempf*waaa)%mod;
		tempf=0;
	}
}
void solve(){
	int ans=0;
	for(int i=1;i<=n-2;i++){
		for(int j=1;j<=m-1;j++){
			if(a[i][j]==1&&a[i+1][j]==1&&a[i+2][j]==1&&a[i][j+1]==1)bfs(i,j);
		}
	}
}

int main(){
	freopen("plant2.in","r",stdin);
	//freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--){
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			char si[1005];		
			for(int j=1;j<=m;j++){
				cin>>si[j];
				if(si[j]-'0'==1){
					a[i][j]=0;
				}else a[i][j]=1;
			}
		}
		solve();
		cout<<endc*c<<" "<<endf*f<<endl;
		
	}
	return 0;
}

