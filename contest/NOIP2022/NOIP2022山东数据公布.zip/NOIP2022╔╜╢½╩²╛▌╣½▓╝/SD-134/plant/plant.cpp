#include<bits/stdc++.h>
#define ll long long
#define N 1010
#define fi first
#define se second
#define vc vector
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
#define dec(i,l,r) for(int i=(r);i>=(l);i--)
#define mp make_pair
#define pb push_back
using namespace std;

const int INF=0x3f3f3f3f;
const int mod=998244353;

typedef pair<int,int> P;
typedef unsigned long long ull;
typedef vector<int> vi;

template<typename T> inline void read(T &x){
	x=0;int f=1;char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f*=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0';
	x*=f;
}

int T,id,n,m,c,f,dn[N][N],ri[N][N],a[N][N],b[N];
char s[N][N];

int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	read(T);read(id);
	while(T--){
		int ans1=0,ans2=0;
		read(n);read(m);read(c);read(f);
//		rep(i,1,n)rep(j,1,m) read(a[i][j]);
		rep(i,1,n) scanf("%s",s[i]+1);
		rep(i,1,n)rep(j,1,m) a[i][j]=s[i][j]-'0';
		rep(i,1,n+1)rep(j,1,m+1) dn[i][j]=ri[i][j]=0;
		rep(i,1,n)rep(j,1,m)if(a[i][j]==0){
			dn[i][j]=1;ri[i][j]=1;
		}
		rep(i,1,n)dec(j,1,m-1)if(a[i][j]==0)ri[i][j]=max(ri[i][j],ri[i][j+1]+1);
//		rep(i,1,n){
//			rep(j,1,m) printf("%d ",ri[i][j]);
//			puts("");
//		}
		dec(i,1,n)rep(j,1,m)if(a[i][j]==0) dn[i][j]=max(dn[i][j],dn[i+1][j]+1);
		rep(i,1,m){
			rep(j,1,n) b[j]=ri[j][i];
			int sum=0;
			dec(j,1,n){
				if(b[j]==0){
					sum=0;
					continue;	
				}
				if(b[j+1]==0){
					sum+=b[j]-1;
					sum%=mod;
					continue;
				}
				ans1=(ans1+1ll*(b[j]-1)*(sum-(b[j+1]-1))%mod)%mod;
				sum+=b[j]-1;
				sum%=mod;
//				printf("j=%d ans1=%d\n",j,ans1);
			}
		}
		printf("%d ",ans1*c%mod);
		rep(i,1,m){
			rep(j,1,n) b[j]=ri[j][i];
			int sum=0;
			dec(j,1,n){
				if(b[j]==0){
					sum=0;continue;
				}
				if(b[j+1]==0){
					sum+=1ll*(b[j]-1)*(dn[j][i]-1)%mod;
					sum%=mod;
					continue;
				}
				ans2=(ans2+1ll*(b[j]-1)*(sum-1ll*(b[j+1]-1)*(dn[j+1][i]-1)%mod)%mod)%mod;
				sum+=1ll*(b[j]-1)*(dn[j][i]-1)%mod;
				sum%=mod;
			}
		}
		printf("%d\n",ans2*f%mod);
	}
}
