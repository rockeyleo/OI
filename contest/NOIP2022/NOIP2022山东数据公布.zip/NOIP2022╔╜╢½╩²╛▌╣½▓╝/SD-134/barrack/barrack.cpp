#include<bits/stdc++.h>
#define ll long long
#define N 2000010
#define fi first
#define se second
#define vc vector
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
#define mp make_pair
#define pb push_back
using namespace std;

const int INF=0x3f3f3f3f;
const int mod=1e9+7;

typedef pair<int,int> P;
typedef unsigned long long ull;
typedef vector<int> vi;

template<typename T> inline void read(T &x){
	x=0;int f=1;char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f*=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0';
	x*=f;
}

struct edge{
	int to,next;
	inline void Init(int to_,int ne_){
		to=to_;next=ne_;
	}
}li[N];
int head[N],n,m,dfn[N],low[N],tail=1;
bool bri[N];
int tot,etot;

inline void ad(int from,int to){
	li[++tail].Init(to,head[from]);head[from]=tail;
}
inline void tarjan(int k,int _edge){
	dfn[k]=low[k]=++tot;
	for(int x=head[k];x;x=li[x].next){
		int to=li[x].to;
		if(!dfn[to]){
			tarjan(to,x);low[k]=min(low[k],low[to]);
		}
		else if(x!=_edge^1) low[k]=min(low[k],dfn[to]);
	}
}

int main(){
	read(n);read(m);
	rep(i,1,m){
		int u,v;read(u);read(v);ad(u,v);ad(v,u);
	}
}
// I can solve T3 but there is no time.
