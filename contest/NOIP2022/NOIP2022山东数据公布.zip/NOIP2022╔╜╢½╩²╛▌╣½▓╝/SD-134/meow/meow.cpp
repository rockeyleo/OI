#include<bits/stdc++.h>
#define ll long long
#define N 2000100
#define fi first
#define se second
#define vc vector
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
#define mp make_pair
#define pb push_back
using namespace std;

const int INF=0x3f3f3f3f;

typedef pair<int,int> P;
typedef unsigned long long ull;
typedef vector<int> vi;

template<typename T> inline void read(T &x){
	x=0;int f=1;char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f*=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0';
	x*=f;
}

int T,n,m,K,a[N],em;
int b[N][2];
struct Ope{
	int op,a,b;
	inline Ope(int op,int a) : op(op),a(a){}
	inline Ope(int op,int a,int b) : op(op),a(a),b(b) {}
};
vc<Ope> ans;

inline int push1(int op,int a){
	ans.pb(Ope(op,a));return ans.size();
}
inline int push2(int op,int a,int b){
	ans.pb(Ope(op,a,b));return ans.size();
}

int main(){
	read(T);
	while(T--){
		read(n);read(m);read(K);
		rep(i,1,n) read(a[i]);
	}
}

//how to solve T2
