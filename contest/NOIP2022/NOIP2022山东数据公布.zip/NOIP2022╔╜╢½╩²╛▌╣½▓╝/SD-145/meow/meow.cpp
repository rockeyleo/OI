#include<bits/stdc++.h>
using namespace std;
const int N = 100003;
#define x1 NeveRGonnAGiveyouUP
#define x2 NevergonNALetyouDowN
#define y1 NeVergonnaRUNarouNd
#define y2 AndDesertYOU
//remember to check long long or freopen()!!!
int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return f==-1?-x:x;
}
//remember to check long long or freopen()!!!
#define Strelitzia_ 0
//remember to check long long or freopen()!!!
void check1() {
	puts("I love 002 forever!!!");
}
void check2() {
	puts("sto Zyb INF times");
}
void pcheck(int id) {
	std::cout<<id<<" live! live! live!"<<std::endl;
}
//remember to check long long or freopen()!!!

int t,n,m,k,a[2000001],q_sz[601],anshop,isemp,isemp1;
std::pair<int,int> belong_type[601];
std::deque<int> q[601];
struct myans {
	int id1,id2,type;
} ans[4000001];
namespace k_equal_to_2n_2 {
	void sol() {
		anshop=0;
		for(int i=1; i<=m; i++) {
			if(!belong_type[a[i]].first) {
				int nowid=1;
				for(int j=2; j<=n; j++)
					if(!q[j].size()) {
						nowid=j;
						break;
					}
				if(nowid!=1) {
					q[nowid].push_front(a[i]);
					belong_type[a[i]].first=nowid;
					belong_type[a[i]].second=0;//under
					ans[++anshop].type=1,ans[anshop].id1=nowid;
					continue;
				}
				for(int j=2; j<=n; j++)
					if(q[j].size()<=1) {
						nowid=j;
						break;
					}
				q[nowid].push_front(a[i]);
				belong_type[a[i]].first=nowid;
				belong_type[a[i]].second=1;//up
				ans[++anshop].type=1,ans[anshop].id1=nowid;
				continue;
			}
			if(belong_type[a[i]].second==1) {
				q[belong_type[a[i]].first].pop_front();
				ans[++anshop].type=1,ans[anshop].id1=belong_type[a[i]].first;
				belong_type[a[i]].first=0;
				continue;
			}
			q[belong_type[a[i]].first].pop_back();
			ans[++anshop].type=1,ans[anshop].id1=1;
			ans[++anshop].type=2,ans[anshop].id1=1,ans[anshop].id2=belong_type[a[i]].first;
			belong_type[a[i]].first=0;
		}
		printf("%d\n",anshop);
		for(int i=1; i<=anshop; i++) {
			if(ans[i].type==1) printf("1 %d\n",ans[i].id1);
			else printf("2 %d %d\n",ans[i].id1,ans[i].id2);
		}
	}
	void mian() {
		for(int nowt=1; nowt<=t; nowt++) {
			n=read(),m=read(),k=read();
			for(int i=1; i<=m; i++) a[i]=read();
			sol();
		}
	}
}
signed main() {
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	t=read();
	if(t%10==1) k_equal_to_2n_2::mian();
}

/*

It is unbelieveable that 3.ans is "114 514".
homohomohomohomo...
114514

 */

/*

//freopen("")
//fropen("barrac1.in","w","stdin");
//fropen("barrack.ans","r,stdout");

check my code pelease.
I wrote <TengWangGeXu> to <have a good job>.

find me: luogu uid = 676638
name: Strelitzia_

Zyb bless me get 1=!!!

*/

/*

I love 002 forever!!!

 */

/*

yuzhanggujun,hongduxinfu.
xingfenyizhen,dijiehonglu.
jinsanjiangerdaiwuhu,kongmanjingeryinouyue.
wuhuatianbao,longguangsheniudouzhixu;
renjiediling,xuruxiachenfanzhita.
xiongzhouwulie,juncaixingchi.
taihuangzhenyixiazhijiao,binzhujindongnanzhimei.
duduyangongzhiyawang,qijiyaolin;
yuwenxinzhouzhiyifan,canweizanzhu.
shixunxiujia,shengyouruyun.
qianlifengying,gaopengmanzuo.
tengjiaoqifeng,mengxueshizhicizong;
zidianqingshuang,wangjiangjunzhiwuku.
jiajunzuozai,luchumingqu;
tongzihezhi,gongfengshengjian.

shiweijiuyue,xushusanqiu.
liaoshuijinerhantanqing,yanguangningermushanzi.
yancanfeiyushanglu,fangfengjingyuchonge.
lindizizhichangzhou,detianrenzhijiuguan.
cengluansongcui,shangchuchongxiao.
feigeliudan,xialinwudi.
hetingfuzhu,qiongdaoyuzhiyinghui;
guidianlangong,jigangluanzhitishi.

pixiuta,fudiaomeng.
shanyuankuangqiyingshi,chuanzeyuqihaishu.
lvyanpudi,zhongmingdingshizhijia;
gejianmijin,qingquehuanglongzhizhu.
yunxiaoyuji,caichequming.
luoxiayuguwuqifei,qiushuigongchangtianyise.
yuzhouchangwan,xiongqiangtenglizhibin;
yanzhenjinghan,shengduanhengyangzhifu.

yaojinfuchang,yixingchuanfei.
shuanglaifaerqingfengsheng,qiangeningerbaiyune.
suiyuanlvzhu,qilingpengzezhizun;
yeshuizhuhua,guangzhaolinchuanzhibi.
simeiju,ernanbing.
qiongdimianyuzhongtan,jiyuyouyuxiari.
tiangaodijiong,jueyuzhouzhiwuqiong.
xingjinbeilai,shiyingxuzhiyoushu.
wangchanganyurixia,muwukuaiyuyunjian.
guanshannanyue,shuibeishiluzhiren?
pingshuixiangfeng,jinshitaxiangzhike.
huaidihunerbujian,fengxuanshiyihenian?

jiehu!
shiyunbuqi,mingyunduochuan.
fengtangyilao,liguangnanfeng.
qujiayiyuchangsha,feiwushengzhu;
cuanlianghongyuhaiqu,qifamingshi?
suolaijunzijianji,darenzhiming.
laodangyizhuang,ningyibaishouzhixin;
qiongqieyijian,buzhuiqingyunzhizhi.
zhuotanquanerjueshuang,chuhezheyiyouhuan.
beihaisuishe,fuyaokejie;
dongyuyishi,sangyufeiwan.
mengchanggaojie,kongyubaoguozhiqing;
ruanjichangkuang,qixiaoqiongtuzhiku?

bo,sanchiweiming,yijieshusheng.
wuluqingying,dengzhongjunzhiruoguan;
youhuaitoubi,muzongquezhichangfeng.
shezanhuyubailing,tuochenhunyuwanli.
tariquting,daopeilidui;
jinzimeijue,xituolongmen.
yantyibufeng,fulingyunerzixi;
zhongqijiyu,zouliushuiyihecan?

wuhu!
shengdibuchang,shengyannanzai.
lantingyiyi,zixinqiuxu.
linbiezengyan,xingchengenyuweijian;
denggaozuofu,shisuowangyuqungong.
ganjiebihuai,gongshiduanyin;
yiyanjunfu,siyunjucheng.
qingsapanjiang,geqingluhaiyuner:

..........................

tengwanggaogelinjiangzhu,peiyuminghuanbagewu.
huadongchaofeinanfuyun,zhulianmujuanxishanyu.
xianyuntanyingriyouyou,wuhuanxingyijiduqiu.
gezhongdizijinhezai?jianwanchangjiangkongziliu.

 */
