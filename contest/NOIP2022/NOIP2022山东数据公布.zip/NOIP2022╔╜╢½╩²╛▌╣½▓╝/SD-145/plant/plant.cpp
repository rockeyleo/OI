#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 100003;
#define x1 NeveRGonnAGiveyouUP
#define x2 NevergonNALetyouDowN
#define y1 NeVergonnaRUNarouNd
#define y2 AndDesertYOU
//remember to check long long or freopen()!!!
int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return f==-1?-x:x;
}
//remember to check long long or freopen()!!!
#define Strelitzia_ 0
//remember to check long long or freopen()!!!
void check1() {
	puts("I love 002 forever!!!");
}
void check2() {
	puts("sto Zyb INF times");
}
void pcheck(int id) {
	std::cout<<id<<"live! live! live!"<<std::endl;
}
//remember to check long long or freopen()!!!
const int MAXN=1007,mod=998244353;
bool mp[MAXN][MAXN];
char chmp[MAXN];
int cntx[MAXN][MAXN],cnty[MAXN][MAXN],cntansc[MAXN][MAXN];
int cntansf[MAXN][MAXN],t,n,m,c,f,id,ansc,ansf;
int cntansc_real[MAXN][MAXN],cntansf_real[MAXN][MAXN];
namespace Sol {
	void dfs_x(int nowx,int nowy) {
		if(!mp[nowx][nowy]) return;
		if(cntx[nowx][nowy-1]) {
			cntx[nowx][nowy]=cntx[nowx][nowy-1]-1;
			return;
		}
		int nownowy=nowy;
		while(mp[nowx][nownowy]&&nownowy<=m) nownowy++;
		cntx[nowx][nowy]=nownowy-nowy;
	}
	void dfs_y(int nowx,int nowy) {
		if(!mp[nowx][nowy]) return;
		if(cnty[nowx-1][nowy]) {
			cnty[nowx][nowy]=cnty[nowx-1][nowy]-1;
		}
		int nownowx=nowx;
		while(mp[nownowx][nowy]&&nownowx<=n) nownowx++;
		cnty[nowx][nowy]=nownowx-nowx;
	}
	void dfs_ans_c(int nowx,int nowy) {
		/*

		make nowx,nowy is left_up:
		if cntans[nowx-1][nowy] then we have cntans[nowx][nowy]-(cntx[nowx+1][nowy]-1).
		then the ans is sum_{i=1}^{n}sum_{j=1}^{m} cntans[i][j].
		difficulty: yellow
		but I cannot solve it.
		:(

		 */
		if(!mp[nowx][nowy]||nowx>n-2||nowy>m-1||!mp[nowx+1][nowy]||!mp[nowx+2][nowy]||!mp[nowx][nowy+1]) return;
		if(cntansc[nowx-1][nowy]) {
			cntansc[nowx][nowy]=((cntansc[nowx-1][nowy]-(cntx[nowx+1][nowy]-1))%mod+mod)%mod;
			cntansc_real[nowx][nowy]=cntansc[nowx][nowy]*(cntx[nowx][nowy]-1);
			return;
		}
		int nownowx=nowx;
		while(mp[nownowx][nowy]&&mp[nownowx+1][nowy]&&mp[nownowx+2][nowy]&&nownowx+2<=n) {
			cntansc[nowx][nowy]+=(cntx[nownowx+2][nowy]-1);
			cntansc[nowx][nowy]%=mod;
			nownowx++;
		}
		cntansc_real[nowx][nowy]=cntansc[nowx][nowy]*(cntx[nowx][nowy]-1);
		cntansc_real[nowx][nowy]%=mod;
	}
	void dfs_ans_f(int nowx,int nowy) {
		/*

		also make nowx,nowy is left_up:
		if(cntansy)[nowx-1][nowy] then we have cntansy[nowx][nowy]=cntnasy[nowx-1][nowy]-(cntx[nowx+1][nowy]-1)-(cnty[nowx+1][nowy]-1)-(cnty[nowx-1][nowy]-3)
		fk that I cannot solve this!!!I can only O(n^2*m)...
		to be AFO.

		 */
		if(nowx>n-3||nowy>m-1) return;
		if(!mp[nowx][nowy]||!mp[nowx+1][nowy]||!mp[nowx+2][nowy]||!mp[nowx+3][nowy]||!mp[nowx][nowy+1]) return;
		if(cntansf[nowx-1][nowy]) {
			cntansf[nowx][nowy]=((cntansf[nowx-1][nowy]-(cntx[nowx+1][nowy]-1)*(cnty[nowx+2][nowy]))%mod+mod)%mod;
			cntansf_real[nowx][nowy]=(cntansf[nowx][nowy]*(cntx[nowx][nowy]-1))%mod;
			return;
		}
		int nownowx=nowx;
		while(mp[nownowx][nowy]&&mp[nownowx+1][nowy]&&mp[nownowx+2][nowy]&&mp[nownowx+3][nowy]&&nownowx+3<=n) {
			cntansf[nowx][nowy]+=(cntx[nownowx+2][nowy]-1)*(cnty[nownowx+3][nowy]);
			cntansf[nowx][nowy]%=mod;
			nownowx++;
		}
		cntansf_real[nowx][nowy]=(cntansf[nowx][nowy]*(cntx[nowx][nowy]-1))%mod;
	}
	void mian() {
		n=read(),m=read(),c=read(),f=read();
		ansc=ansf=0;
		for(int i=1; i<=n; i++) for(int j=1; j<=m; j++)
			cntx[i][j]=cnty[i][j]=cntansc[i][j]=cntansf[i][j]=cntansc_real[i][j]=cntansf_real[i][j]=0;
		for(int i=1; i<=n; i++) {
			scanf("%s",chmp+1);
			for(int j=1; j<=m; j++) mp[i][j]=chmp[j]=='0';
		}
		for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) dfs_x(i,j);
		for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) dfs_y(i,j);
		for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) dfs_ans_c(i,j);
		if(f) for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) dfs_ans_f(i,j);
		for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) ansc=(ansc+cntansc_real[i][j])%mod;
		if(f) for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) ansf=(ansf+cntansf_real[i][j])%mod;
		printf("%lld %lld\n", ansc*c,ansf*f);
	}
}
signed main() {
	 freopen("plant.in","r",stdin);
	 freopen("plant.out","w",stdout);
	t=read(),id=read();
	for(int i=1; i<=t; i++) Sol::mian();
	return Strelitzia_;
}

/*

It is unbelieveable that 3.ans is "114 514".
homohomohomohomo...
114514

 */

/*

//freopen("")
//fropen("barrac1.in","w","stdin");
//fropen("barrack.ans","r,stdout");

check my code pelease.
I wrote <TengWangGeXu> to <have a good job>.

find me: luogu uid = 676638
name: Strelitzia_

Zyb bless me get 1=!!!

*/

/*

I love 002 forever!!!

 */

/*

yuzhanggujun,hongduxinfu.
xingfenyizhen,dijiehonglu.
jinsanjiangerdaiwuhu,kongmanjingeryinouyue.
wuhuatianbao,longguangsheniudouzhixu;
renjiediling,xuruxiachenfanzhita.
xiongzhouwulie,juncaixingchi.
taihuangzhenyixiazhijiao,binzhujindongnanzhimei.
duduyangongzhiyawang,qijiyaolin;
yuwenxinzhouzhiyifan,canweizanzhu.
shixunxiujia,shengyouruyun.
qianlifengying,gaopengmanzuo.
tengjiaoqifeng,mengxueshizhicizong;
zidianqingshuang,wangjiangjunzhiwuku.
jiajunzuozai,luchumingqu;
tongzihezhi,gongfengshengjian.

shiweijiuyue,xushusanqiu.
liaoshuijinerhantanqing,yanguangningermushanzi.
yancanfeiyushanglu,fangfengjingyuchonge.
lindizizhichangzhou,detianrenzhijiuguan.
cengluansongcui,shangchuchongxiao.
feigeliudan,xialinwudi.
hetingfuzhu,qiongdaoyuzhiyinghui;
guidianlangong,jigangluanzhitishi.

pixiuta,fudiaomeng.
shanyuankuangqiyingshi,chuanzeyuqihaishu.
lvyanpudi,zhongmingdingshizhijia;
gejianmijin,qingquehuanglongzhizhu.
yunxiaoyuji,caichequming.
luoxiayuguwuqifei,qiushuigongchangtianyise.
yuzhouchangwan,xiongqiangtenglizhibin;
yanzhenjinghan,shengduanhengyangzhifu.

yaojinfuchang,yixingchuanfei.
shuanglaifaerqingfengsheng,qiangeningerbaiyune.
suiyuanlvzhu,qilingpengzezhizun;
yeshuizhuhua,guangzhaolinchuanzhibi.
simeiju,ernanbing.
qiongdimianyuzhongtan,jiyuyouyuxiari.
tiangaodijiong,jueyuzhouzhiwuqiong.
xingjinbeilai,shiyingxuzhiyoushu.
wangchanganyurixia,muwukuaiyuyunjian.
guanshannanyue,shuibeishiluzhiren?
pingshuixiangfeng,jinshitaxiangzhike.
huaidihunerbujian,fengxuanshiyihenian?

jiehu!
shiyunbuqi,mingyunduochuan.
fengtangyilao,liguangnanfeng.
qujiayiyuchangsha,feiwushengzhu;
cuanlianghongyuhaiqu,qifamingshi?
suolaijunzijianji,darenzhiming.
laodangyizhuang,ningyibaishouzhixin;
qiongqieyijian,buzhuiqingyunzhizhi.
zhuotanquanerjueshuang,chuhezheyiyouhuan.
beihaisuishe,fuyaokejie;
dongyuyishi,sangyufeiwan.
mengchanggaojie,kongyubaoguozhiqing;
ruanjichangkuang,qixiaoqiongtuzhiku?

bo,sanchiweiming,yijieshusheng.
wuluqingying,dengzhongjunzhiruoguan;
youhuaitoubi,muzongquezhichangfeng.
shezanhuyubailing,tuochenhunyuwanli.
tariquting,daopeilidui;
jinzimeijue,xituolongmen.
yantyibufeng,fulingyunerzixi;
zhongqijiyu,zouliushuiyihecan?

wuhu!
shengdibuchang,shengyannanzai.
lantingyiyi,zixinqiuxu.
linbiezengyan,xingchengenyuweijian;
denggaozuofu,shisuowangyuqungong.
ganjiebihuai,gongshiduanyin;
yiyanjunfu,siyunjucheng.
qingsapanjiang,geqingluhaiyuner:

..........................

tengwanggaogelinjiangzhu,peiyuminghuanbagewu.
huadongchaofeinanfuyun,zhulianmujuanxishanyu.
xianyuntanyingriyouyou,wuhuanxingyijiduqiu.
gezhongdizijinhezai?jianwanchangjiangkongziliu.

 */
