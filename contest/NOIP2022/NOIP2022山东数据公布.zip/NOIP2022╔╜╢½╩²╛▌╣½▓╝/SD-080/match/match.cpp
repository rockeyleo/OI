#include<bits/stdc++.h>
#define ll long long
#define reg register
#define ull unsigned long long
#define int long long
using namespace std;
const int N = 1e6+5;
const int M = 2005;
const int INF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3f;
//const __int128 mod = 18446744073709551616;
void print(int x){if(x<0) putchar('-'),x=-x; if(x>9) print(x/10);putchar(x%10+48);}
inline ll read()
{
	ll f = 0, x = 0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(; isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch&15);
	return f ? -x : x;
}
ull quick_pow(int x,int p)
{
	ull res=1;
	while(p)
	{
		if(p&1) res=res*x;
		x=x*x; p>>=1;
	}
	return res;
}
int T,n,q,ans,aa,bb,a[N],b[N];
signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read(),n=read();
	for(reg int i=1;i<=n;i++) a[i]=read();
	for(reg int j=1;j<=n;j++) b[j]=read();
	q=read();
	while(q--)
	{
		ans=0;
		int l=read(),r=read();
		for(reg int i=l;i<=r;i++)
		{
			for(reg int j=i;j<=r;j++)
			{
				for(reg int k=i;k<=j;k++)
				{
					aa=max(aa,a[k]); bb=max(bb,b[k]);
				}
			ans=(ans+(aa*bb));
			aa=0,bb=0;
			}
		}
		cout<<ans<<"\n"; 
	}
	return 0;
}
/*
0 2
2 1
1 2
1
1 2
*/
