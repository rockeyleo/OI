#include<bits/stdc++.h>
#define ll long long
#define reg register
#define ull unsigned long long
//#define int long long
using namespace std;
const int N = 1005;
const int M = 2005;
const int mod = 998244353;
const int INF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3f;
void print(int x){if(x<0) putchar('-'),x=-x; if(x>9) print(x/10);putchar(x%10+48);}
inline ll read()
{
	ll f = 0, x = 0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(; isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch&15);
	return f ? -x : x;
}
char ch[N][N];
int n,m,c,f,ansc,ansf,mp[N][N];
inline void clear(){memset(mp,0,sizeof(mp));}
signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=read(),id=read();
	while(T--)
	{
		clear();
		n=read(),m=read(),c=read(),f=read();
		if(c==0 && f==0) {printf("0 0\n"); continue ;}
		for(reg int i=1;i<=n;i++) scanf("%s",ch[i]+1);
		for(reg int i=1;i<=n;i++)
		{
			for(reg int j=1;j<=m;j++)
				if(ch[i][j]=='1') mp[i][j]=1;
		}
		if(id==2)
		{
			for(reg int i=1;i<=n;i++)
			{
				for(reg int j=1;j<=m;j++)
				{
					if(mp[1][1] || mp[1][2] || mp[2][1] || mp[3][1] || mp[3][2]) {printf("0 0\n");continue ;}
					else {printf("1 0\n"); continue ;}
				}
			}
		}
		if(id==3) 
		{
			if(mp[2][1] || mp[3][1]) {printf("0 0\n");continue ;}
			if((mp[1][2] && mp[2][2]) || (mp[3][2] && mp[4][2])) {printf("0 0\n");continue ;}
			if((mp[1][1] && !mp[2][2] && !mp[4][1] && !mp[4][2])) {printf("1 0\n"); continue ;}
			if(!mp[1][1] && !mp[1][2] && !mp[2][1] && !mp[2][2] && !mp[3][1] && !mp[3][2] && !mp[4][1] && !mp[4][2]){printf("3 1\n");continue;}
			if(!mp[1][1] && !mp[1][2] && !mp[2][1] && mp[2][2] && !mp[3][1] && !mp[3][2] && !mp[4][1] && mp[4][2]) {printf("1 1\n");continue;}
			if(!mp[1][1] && !mp[1][2] && !mp[2][1] && mp[2][2] && !mp[3][1] && !mp[3][2] && !mp[4][1] && !mp[4][2]){printf("2 1\n");continue;}
			if(!mp[1][1] && !mp[1][2] && !mp[2][1] && !mp[2][2] && !mp[3][1] && mp[3][2] && !mp[4][1] && !mp[4][2]){printf("2 0\n");continue;}
		}
	} 
	return 0;
}
/*
1 0 
4 3 1 1
001
010
000
000

4 2
*/
