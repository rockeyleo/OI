#include<bits/stdc++.h>
#include<stack>
#define ll long long
#define reg register
#define ull unsigned long long
//#define int long long
using namespace std;
const int N = 1100;
const int M = 2005;
const int mod = 1e9+7;
const int INF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3f;
void print(int x){if(x<0) putchar('-'),x=-x; if(x>9) print(x/10);putchar(x%10+48);}
inline ll read()
{
	ll f = 0, x = 0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(; isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch&15);
	return f ? -x : x;
}
//stack<int> s1;
//stack<int> s2;
int n,m,k,cnt,a[N],stc[N][N],jis[N];
inline void dfs(int x)
{
	if(x==m+1) {return ;}
	for(reg int i=1;i<=m;i++)
	{
		stc[i][++jis[i]]=a[x];
		bool opt=1;
		if(a[x]==stc[i][jis[i]-1])
		{
			opt = 0;
			stc[i][jis[i]]=0;
			stc[i][jis[i]-1]=0;
			jis[i]++;
			cnt++; 
		}
		else
		{
			cnt++;
			stc[i][jis[i]]=x;
		}
	}
}
signed main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T=read();
	srand(time(NULL));
	while(T--)
	{
		n=read(),m=read(),k=read();
		for(reg int i=1;i<=m;i++) a[i]=read();
		for(reg int i=1;i<=n;i++)
		{
			printf("%d",n);puts("");
			if(i==1) {puts("1 1");continue ;}
			int res=rand()%2+1;
			if(res==1) printf("1 %d\n",1,rand()%2+1);
			else printf("2 %d %d\n",1,rand()%2+1,rand()%2+1);
		}
	}
	return 0;
}
/*
1
2 4 2
1 2 1 2
*/
