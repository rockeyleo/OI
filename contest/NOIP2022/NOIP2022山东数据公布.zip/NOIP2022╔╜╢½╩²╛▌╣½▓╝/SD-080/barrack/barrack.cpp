#include<bits/stdc++.h>
#include<queue>
#define pii pair<int,int>
#define ll long long
#define reg register
#define ull unsigned long long
//#define int long long
using namespace std;
const int N = 1e6+5;
const int M = 2005;
const int mod = 1e9+7;
const int INF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3f;
void print(int x){if(x<0) putchar('-'),x=-x; if(x>9) print(x/10);putchar(x%10+48);}
inline ll read()
{
	ll f = 0, x = 0;
	char ch = getchar();
	for(;!isdigit(ch);ch=getchar()) f|=(ch=='-');
	for(; isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+(ch&15);
	return f ? -x : x;
}
struct node{
	int to,nxt,val;
}e[N];
bool vis[N];
int n,m,cnt,ans,dis[N],num[N],head[N];
inline void add(int u,int v,int w){e[++cnt]=(node){v,head[u],w};head[u]=cnt;}
inline void dij()
{
	priority_queue<pii,vector<pii>,greater<pii> > q;
	memset(dis,INF,sizeof(dis));
	memset(vis,0,sizeof(vis));
	dis[1]=0,vis[1]=1;num[1]=1;
	q.push(make_pair(0,1));
	while(!q.empty())
	{
		int u=q.top().second; q.pop();
		if(vis[u]) continue ;
		vis[u]=1;
		for(reg int i=head[u];i;i=e[i].nxt)
		{
			int v=e[i].to;
			if(dis[v]>dis[u]+e[i].val)
			{
				dis[v]=dis[u]+e[i].val;
				num[v]=num[u];
				q.push(make_pair(dis[v],v));
			}
			else if(dis[v]==dis[u]+e[i].val)
				num[v]=num[v]+num[u];
		}
	}
}
signed main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	srand(time(NULL));
	n=read(),m=read();
	int res=pow(n,m);
	ans=rand()%res;
	for(reg int i=1;i<=m;i++) 
	{
		int u=read(),v=read();
		add(u,v,1),add(v,u,1);
	}
	dij(); 
	for(reg int i=1;i<=n;i++) ans+=num[i];
	ans+=((n*3)+3); ans+=((n+m)/2);
	ans+=(n+m); 
	cout<<ans<<"\n"; 
	return 0;
}
/*
4 4
1 2
2 3
3 1
1 4

184
*/
