#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int T,n,a[N],b[N],Q,max_a,max_b,ans,cn;
struct node{
	int l,r;
}ma[N];
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin>>T>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++) cin>>b[i];
	cin>>Q;
	for(int i=1;i<=Q;i++){
		cin>>ma[i].l>>ma[i].r;
		for(int j=ma[i].l;j<=ma[i].r;j++){
			for(int k=j;k<=ma[i].r;k++){
				max_a=max(max_a,a[k]);
				max_b=max(max_b,b[k]);
			}
			ans=max_a*max_b;
			cn+=ans;
		}
		cout<<cn;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
