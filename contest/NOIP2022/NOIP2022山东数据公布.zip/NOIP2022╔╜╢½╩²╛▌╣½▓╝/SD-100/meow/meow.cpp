#include<bits/stdc++.h>
#include<stack>
using namespace std;
const int N=20;
stack<int>que;stack<int>so_1;stack<int>so_2;
int T,n,m,k,op,opr[N][4],a;
void opra_1(int x){
	int aa=que.top();
	so_1.push(que.top());
	op++;
	opr[op][1]=1;
	opr[op][2]=x;
	if(so_1.top()==aa) so_1.pop(),so_1.pop();
}
void opra_2(int x1,int x2){
	so_1.push(que.top());so_2.push(que.top());
	op++;
	opr[op][1]=2;
	opr[op][2]=x1;opr[op][3]=x2;
	if(so_1.top()==so_2.top()) so_1.pop(),so_2.pop();
}
void pd(int kk){
	if(!que.empty()||!so_1.empty()||!so_2.empty()) opra_1(kk++);
}
int main(){
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	cin>>T;
	for(int i=1;i<=T;i++){
		cin>>n>>m>>k;
		for(int j=1;j<=m;j++) cin>>a,que.push(a);}
	pd(1);
	cout<<op;
	for(int i=1;i<=op;i++){
		for(int j=1;j<=3;j++)
		cout<<opr[i][j]<<" ";
		cout<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
