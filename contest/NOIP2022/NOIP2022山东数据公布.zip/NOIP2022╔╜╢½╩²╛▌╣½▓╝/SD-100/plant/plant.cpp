#include<bits/stdc++.h>
using namespace std;
const int N=1e3+10;
int T,id;
int n,m,c,f,Vc,Vf;
bool mapp[N][N];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	for(int i=1;i<=T;i++){
		cin>>n>>m>>c>>f;
		for(int j=1;j<=n;j++)
		for(int k=1;k<=m;k++)
		cin>>mapp[j][k];	
		cout<<Vc*c<<" "<<Vf*f;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
