#include<bits/stdc++.h>
using namespace std;
const int N=5010;
const long long mod=1e9+7;
int n,m,ans;
bool place[N],ro[N],mapp[N][N];
struct node{
	int u,v;
}road[N];
int main(){
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>road[i].u>>road[i].v;
		mapp[road[i].u][road[i].v]=1;
	}
	for(int i=n;i>=1;i--)
	for(int j=m;j>=1;j--) ans+=i*j;
	cout<<ans*2-n*n;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
