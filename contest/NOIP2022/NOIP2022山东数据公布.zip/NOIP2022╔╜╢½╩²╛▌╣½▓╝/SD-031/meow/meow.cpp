#include <bits/stdc++.h>
using namespace std;

struct node
{
	int t;
	int s;
	int s1,s2;
};
const int N=2000000+5;
int n,m,k;
void read(int &x)
{
	x=0; char ch=getchar();
	while(ch<'0' || ch>'9') ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
}
int a[N];
deque<int> q[300+5];
bool flag,flag2;
node f[N*2];
int ans;
void print()
{
	for(int i=1; i<=ans; i++)
	{
		printf("%d ",f[i].t);
		if(f[i].t==1) printf("%d\n",f[i].s);
		else if(f[i].t==2) printf("%d %d\n",f[i].s1,f[i].s2);
	}
}
void dfs(int x, int cnt)
{
	if(flag2) return;
	if(x>n)
	{
		flag=true;
		for(int i=1; i<=n; i++)
			if(!q[i].empty()) flag=false;
		
		if(flag && cnt>=m && cnt<=m*2)
		{
			ans=cnt; print(); flag2=true;
		}
		
		return;
	}
	for(int i=1; i<=n; i++)
	{
		for(int j=1; j<=n; j++)
			if(!q[i].empty() && !q[j].empty() && i!=j && q[i].front()==q[j].front())
			{
				q[i].pop_front(); q[j].pop_front();
				f[cnt].t=2; f[cnt].s1=i; f[cnt].s2=j;
				dfs(x,cnt+1);
			}
		
		q[i].push_back(a[x]);
		f[cnt].t=1; f[cnt].s=i;
		dfs(x+1,cnt+1);
		if(!q[i].empty()) q[i].pop_back();
	}
}
int main()
{
	freopen("meow.in","r",stdin);
	freopen("meow.out","w",stdout);
	int T; read(T);
	while(T--)
	{
		flag=flag2=false;
		for(int i=1; i<=n; i++) q[i].clear();
		read(n); read(m); read(k);
		for(int i=1; i<=m; i++) read(a[i]);
		dfs(1,0);
	}
	return 0;
}
