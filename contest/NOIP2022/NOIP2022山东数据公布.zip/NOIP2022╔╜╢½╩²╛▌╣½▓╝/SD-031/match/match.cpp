#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;
const int N=3000+5;
int T,Q;
int n,a[N],b[N];
int l,r;
ull f[N][N],g[N][N];
ull ans;
void read(int &x)
{
	x=0; char ch=getchar();
	while(ch<'0' || ch>'9') ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
}
int max2(int x, int y)
{
	return x>y?x:y;
}
void pre()
{
	for(int i=1; i<=n; i++) f[i][i]=a[i],g[i][i]=b[i];
	
	for(int p=1; p<=n; p++)
	for(int i=1; i<=n-p+1; i++)
	{
		int j=i+p-1;
		f[i][j]=max2(f[i][i],f[i+1][j]);
	}
	for(int p=1; p<=n; p++)
	for(int i=1; i<=n-p+1; i++)
	{
		int j=i+p-1;
		g[i][j]=max2(g[i][i],g[i+1][j]);
	}
}
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(T); read(n);
	for(int i=1; i<=n; i++) read(a[i]);
	for(int i=1; i<=n; i++) read(b[i]);
	
	pre();
	read(Q);
	while(Q--)
	{
		read(l); read(r); ans=0;
		for(int p=l; p<=r; p++)
		for(int q=p; q<=r; q++)
			ans=ans+f[p][q]*g[p][q];//%inf;
		cout<<ans<<endl;
	}
	return 0;
}
