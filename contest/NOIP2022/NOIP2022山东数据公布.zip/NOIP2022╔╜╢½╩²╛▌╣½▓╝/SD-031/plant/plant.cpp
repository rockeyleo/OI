#include <bits/stdc++.h>
using namespace std;

const int N=1000+5,inf=998244353;
int n,m,cc,ff;
string s[N];
int f[N][N],g[N][N];
int ans1,ans2;
void read(int &x)
{
	x=0; char ch=getchar();
	while(ch<'0' || ch>'9') ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
}
void work()
{
	if(cc==0 && ff==0) return;
	
	for(int i=1; i<=n; i++)
	for(int j=1; j<=m; j++)
	{
		if(s[i][j]=='0')
		{
			int p,q; p=i+1; q=j+1;
			while(p<=n && s[p][j]=='0') f[i][j]++,p++;
			while(q<=m && s[i][q]=='0') g[i][j]++,q++;
		}
	}
	
	for(int p=1; p<=n; p++)
	for(int q=1; q<=m; q++) if(g[p][q])
	{
		for(int i=p+2; i<=p+f[p][q]; i++) if(g[i][q])
		{
			ans1+=g[i][q]*g[p][q]%inf;
			if(i!=p+f[p][q] && ff) ans2+=g[i][q]*g[p][q]*(f[p][q]-(i-p))%inf;
		}
	}
}
void print()
{
	printf("%d %d\n",ans1*cc%inf,ans2*ff%inf);
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id; read(T); read(id);
	while(T--)
	{
		read(n); read(m); read(cc); read(ff);
		for(int i=1; i<=n; i++)
		{
			cin>>s[i]; s[i]=" "+s[i];
		}
		work();
		print();
		for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++) f[i][j]=g[i][j]=0;
		ans1=ans2=0;
	}
	return 0;
}
