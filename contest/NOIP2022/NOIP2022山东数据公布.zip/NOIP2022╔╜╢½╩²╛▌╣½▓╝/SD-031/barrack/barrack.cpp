#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long ll;
const int inf=1e9+7;
int n,m;
ll ans;
void read(int &x)
{
	x=0; char ch=getchar();
	while(ch<'0' || ch>'9') ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
}
void init()
{
	read(n); read(m);
}
void work()
{
	if(m==n-1)
	{
		ans=(ll)n*m%inf;
		
		ll xx=n-1,m1=(ll)n*(n-1),m2=1;
		for(int i=2; i<=n; i++)
		{
			m2*=i; m2%=inf;
			ans+=m1/m2%inf; ans%=inf;
			xx--; m1*=xx; m1%=inf;
		}
		return;
	}
	
	
}
void print()
{
	cout<<ans;
}
int main()
{
	freopen("barrack.in","r",stdin);
	freopen("barrack.out","w",stdout);
	init();
	work();
	print();
	return 0;
}
