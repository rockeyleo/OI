#include <iostream>
#include <cstdio>
using namespace std;
const int N=3e5+10;
const int Q=3e5+10;
int t,n,q;
int a[N],b[N];
int l[Q],r[Q];
struct node
{
	int left,right;
	int dista,distb;
}tree[N*4];
int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*f;
}
void build(int x,int l,int r)
{
	tree[x].left=l;
	tree[x].right=r;
	if(l==r)
	{
		tree[x].dista=a[l];
		tree[x].distb=b[l];
		return ;
	}
	int mid=(l+r)/2;
	build(x*2,l,mid);
	build(x*2+1,mid+1,r);
	tree[x].dista=max(tree[x*2].dista,tree[x*2+1].dista);
	tree[x].distb=max(tree[x*2].distb,tree[x*2+1].distb);
}
long long querya(int x,int l,int r)
{
	if(tree[x].left>=l&&tree[x].right<=r)
	{
		return tree[x].dista;
	}
	long long res=-1;
	int mid=(tree[x].left+tree[x].right)/2;
	if(l<=mid)
	{
		res=max(res,querya(x*2,l,r));
	}
	if(mid+1<=r)
	{
		res=max(res,querya(x*2+1,l,r));
	}
	return res;
}
long long queryb(int x,int l,int r)
{
	if(tree[x].left>=l&&tree[x].right<=r)
	{
		return tree[x].distb;
	}
	long long res=-1;
	int mid=(tree[x].left+tree[x].right)/2;
	if(l<=mid)
	{
		res=max(res,queryb(x*2,l,r));
	}
	if(mid+1<=r)
	{
		res=max(res,queryb(x*2+1,l,r));
	}
	return res;
}
int main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	t=read();
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		b[i]=read();
	}
	q=read();
	for(int i=1;i<=q;i++)
	{
		l[i]=read();
		r[i]=read();
	}
	build(1,1,n);
	unsigned long long ans=0;
	for(int i=1;i<=q;i++)
	{
		ans=0;
		for(int j=1;j<=r[i]-l[i]+1;j++)
		{
			for(int k=l[i];k<=r[i];k++)
			{
				if(k+j-1>r[i])
				{
					break;
				}
				ans+=(long long)querya(1,k,k+j-1)*(long long)queryb(1,k,k+j-1);
			}
		}
		printf("%llu\n",ans);
	}
	return 0;
}
/*
:( 
*/
