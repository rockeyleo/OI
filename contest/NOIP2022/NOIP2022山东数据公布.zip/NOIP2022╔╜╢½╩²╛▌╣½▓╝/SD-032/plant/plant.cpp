#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
const long long mod=998244353;
const int N=1e3+10;
int T,id;
int n,m,vc,vf;
char s[N][N];
long long t[N][N],f[N][N],C[N][N],ff[N][N];
int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*f;
}
void init()
{
	memset(t,0,sizeof(t));
	memset(f,0,sizeof(f));
	memset(ff,0,sizeof(ff));
	memset(C,0,sizeof(C));
	for(int i=0;i<n;i++)
	{
		for(int j=m-1;j>=0;j--)
		{
			if(s[i][j]=='0')
			{
				t[i][j]=t[i][j+1]+1;
			}
			else
			{
				t[i][j]=0;
			}
		}
	}
	for(int j=0;j<m;j++)
	{
		int ends=n-1;
		for(int i=n-1;i>=0;i--)
		{
			if(s[i][j]=='1')
			{
				C[j][i]=-1;
				ends=i-1;
			}
			else
			{
				C[j][i]=ends;
			}
		}
	}
	for(int j=0;j<m;j++)
	{
		f[j][0]=t[0][j]-1;
		ff[j][0]=(t[0][j]-1)*C[j][0];
		for(int i=1;i<n;i++)
		{
			if(s[i][j]=='1')
			{
				f[j][i]=f[j][i-1];
			}
			else
			{
				f[j][i]=f[j][i-1]+(t[i][j]-1);		
			}
			if(C[j][i]==-1)
			{
				ff[j][i]=ff[j][i-1];
			}
			else
			{
				ff[j][i]=(ff[j][i-1]+(t[i][j]-1)*(C[j][i]-i)%mod)%mod;			
			}
		}	
	}
	//t[i][j]-1;
}
long long Findc()
{
	long long ans_c=0;
	for(int j=0;j<m-1;j++)
	{
		for(int i=0;i<n;i++)
		{
			if(s[i][j]=='1') continue;
			if(C[j][i]!=-1&&C[j][i]-i+1>=3)
			{
				ans_c=(ans_c+((t[i][j]-1)*(f[j][C[j][i]]-f[j][i+1]))%mod)%mod;
			}
		}
	}
	return ans_c;
}
long long Findf()
{
	long long ans_f=0;
	for(int j=0;j<m-1;j++)
	{
		for(int i=0;i<n;i++)
		{
			if(s[i][j]=='1') continue;
			if(C[j][i]!=-1&&C[j][i]-i+1>=4)
			{
				ans_f=(ans_f+((t[i][j]-1)*(ff[j][C[j][i]]-ff[j][i+1]))%mod)%mod;
			}
		}
	}
	return ans_f;
}
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	T=read();
	id=read();
	while(T--)
	{
		n=read();
		m=read();
		vc=read();
		vf=read();
		for(int i=0;i<n;i++)
		{
			scanf("%s",s[i]);
		}
		init();
		//check();
		long long cc=(Findc()*(long long)vc)%mod;
		long long ff=(Findf()*(long long)vf)%mod;
		printf("%lld %lld\n",cc,ff);
	}
	return 0;
}
