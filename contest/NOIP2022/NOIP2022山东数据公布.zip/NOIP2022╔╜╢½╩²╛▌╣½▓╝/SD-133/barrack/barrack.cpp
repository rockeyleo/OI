#include<bits/stdc++.h>
using namespace std;




int main()
{
//	freopen("barrack.in","r",stdin);
//	freopen("barrack.ans","w",stdout);
	cout<<"1";
	
	
	
	
	return 0;
}
