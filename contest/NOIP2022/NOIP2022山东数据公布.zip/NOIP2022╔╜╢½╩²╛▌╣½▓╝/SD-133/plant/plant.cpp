#include<bits/stdc++.h>
using namespace std;
#define maxn 1010
#define Mod 998244353
int T,id;
int n,m,c,f;
int a[maxn][maxn];
int l0[maxn];



int main()
{
//	freopen("plant.in","r",stdin);

	scanf("%d%d",&T,&id);
	if(id==1||id==15)
	{
		while(T--)
			printf("0 0\n");
		return 0;
	}
	scanf("%d%d%d%d",&n,&m,&c,&f);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			char ch=getchar();
			while(ch!='0'&&ch!='1')
				ch=getchar();
			a[i][j]=ch-'0';
		}
	for(int i=1;i<=n;i++)
		a[i][m+1]=1;
	for(int i=1;i<=m;i++)
		a[n+1][i]=1;
	long long ans1=-1,ans2=-1,ans=0;
	for(int i=1;i<=n-1;i++)//mei ju x1
	{
		for(int j=1;j<=m;j++)//mei ju y0
		{
			if(!a[i][j])
			{
				for(int p=j+1;p<=m;p++)
					if(a[i][p])//mei ju y1
					{
						ans1=p-j-1;
						cout<<"ans1="<<ans1<<endl;
						break;
					}
				if(a[i+1][j]) 
					continue;
				for(int k=i+2;k<=n;k++)//mei ju x2
				{
					if(a[k][j])
						break;
					for(int o=2;o<=m;o++)//mei ju y2
					{
						if(a[k][o])
						{
							ans2=o-j-1;
							cout<<"ans2="<<ans2<<endl;
							ans+=ans1*ans2%Mod;
							break;
						}
				    }
				}
			}
		}
	}	
	printf("%lld %lld",ans*c%Mod,ans*c%Mod);
	
	
	
	
	return 0;
}
