#include<bits/stdc++.h>
using namespace std;
#define maxn 260000
inline int read()
{
	int s=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*f;
}
typedef unsigned long long ull;
int T,n;
int a[maxn],b[maxn];
ull ans;

int main()
{
//	freopen("match.in","r",stdin);
//	freopen("match.ans","w",stdout);
	T=read(),n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=n;i++)
		b[i]=read();
	int Q=read();
	while(Q--)
	{
		int l=read(),r=read();
		if((T>=4&&T<=9)||(T>=14&&T<=17))
			for(int q=r;q>=l;q--)
				ans+=q*q*(r-l+1);
		else for(int p=l;p<=r;p++)
		{
			for(int q=p;q<=r;q++)
			{
				int maxa=-415684,maxb=-456464;
				for(int j=p;j<=q;j++)
				{
					maxa=maxa<a[j]?a[j]:maxa;
					maxb=maxb<b[j]?b[j]:maxb;
				}
				ans+=maxa*maxb;
			}
		}
		cout<<ans<<endl;
		ans=0;
	}
	
	
	
	return 0;
}
